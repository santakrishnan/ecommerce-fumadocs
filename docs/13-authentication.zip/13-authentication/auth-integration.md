# Auth Integration — EDI, Auth0 & Gateway

The integration reference for authentication: the components involved (gateway,
authorizer, session-token service, EDI, Auth0), the cross-service sequences that
elevate a session from **ACR1 (OTP / `1fa`)** to **ACR2 (passkey / `2fa:phr`)**,
the session-token lifecycle and refresh model, and the AWS deployment topology.
For the UI-facing flow catalog see [`auth-flows.md`](./auth-flows.md); for the
plain-English journeys see [`auth-user-journeys.md`](./auth-user-journeys.md).


## Actors

| Actor | Role |
|-------|------|
| **User** | Person on the device. |
| **Browser** | Renders the ecommerce app; owns the WebAuthn API (`navigator.credentials.*`). |
| **UI (ECom)** | Next.js app. Orchestrates the flow and calls its own BFF only. |
| **BFF** | Backend-for-frontend. Thin passthrough for `/api/v1/auth/*`; forwards to VPS and relays the browser cookie. |
| **VPS (VisitorProfileService)** | Resolves the visitor/identity profile, persists `auth-metadata` (ACR, factor flags, and the single backend-token expiry `deviceSessionExpiresAt`), and originates auth calls to EDI. |
| **EDI** | Enterprise Digital Identity service (context-path `/digital-id-profile-service`). Talks to Auth0, manages identity linking, and writes the session-token row. |
| **Auth0** | Identity provider. Passwordless OTP, passkey ceremonies, token issuance (ACR claims). |
| **API Gateway** | Sits in the request path. Invokes the Authorizer, stamps the `Set-Cookie` it returns, injects the context as `X-*` headers to downstream services, and renders the error response on a deny. |
| **Authorizer** | Lambda request-authorizer. Reads the session row directly from the session store. It does not create or write sessions; if none is found it returns an anonymous context with a fresh `edi-session-id` for the gateway to set. Enforces the route's required ACR (from `X-Header-Req-ACR`) and denies with 403 when the session ACR is too low. |
| **Session store (DynamoDB)** | `Apigateway-Session-Tokens` table. Source of truth for a session's identity and ACR. Read by the Authorizer; written by the Session-Token Service. |
| **Session-Token Service** | Owns the session-token record (context-path `/session-token-service`): upsert (`PUT .../session-tokens/{sessionId}`, called by EDI after OTP verify), read, invalidate, and a consumer-facing ACR lookup. |

---

<a id="top"></a>

## Scenario summary

| Scenario | What happens | ACR after |
|----------|--------------|-----------|
| [**Session bootstrap**](#session-bootstrap-first-cookie-less-call) | First cookie-less call. Authorizer finds no session, returns anonymous context with a fresh `edi-session-id`; gateway sets the cookie. No row is written. | anonymous (0) |
| [**OTP authentication**](#otp-authentication-establishes-acr1--1fa) | Shopper verifies an OTP (phone or email). EDI resolves identity and upserts the session-token row with tokens and ACR. | `1fa` (1) |
| [**Passkey enrollment**](#passkey-enrollment) | Shopper registers a passkey via WebAuthn. Stores a credential only; ACR is unchanged. | `1fa` (1) |
| [**Passkey step-up**](#passkey-step-up-establishes-acr2--2faphr) | Shopper authenticates with the passkey; EDI upserts the row at the higher ACR. | `2fa:phr` (2/3) |
| [**Sensitive action (ACR enforcement)**](#sensitive-action-at-the-gateway-acr-enforcement) | Gateway invokes the Authorizer, which reads the row and compares ACR to the route's requirement. Allow, or 403 when too low or expired. | unchanged |

---

## Session bootstrap (first cookie-less call)

[Back to top](#top)

The first cookie-less call to an auth endpoint establishes a session id only —
no identity and no auth token yet. Everything below binds onto this session, and
only requests that include the `edi-session-id` cookie resolve to it.

> Most ecommerce functionality (search, VDP, preferences, visitor profile) does
> not pass through this gateway and stays anonymous.

```mermaid
sequenceDiagram
    autonumber
    actor V as Visitor (Browser)
    participant GW as API Gateway
    participant AZ as Authorizer (Lambda)
    participant DDB as Session store (DynamoDB)

    note over V,DDB: First cookie-less call to an auth endpoint - no cookie, no account, no identity

    V->>GW: GET /auth-endpoint (no cookie)
    GW->>AZ: Invoke authorizer (headers, X-Header-Req-ACR)
    AZ->>DDB: GetItem sessionId (from cookie or X-Session-Id)
    DDB-->>AZ: no item (no cookie was sent)
    note over AZ: No session found. Generate a fresh X-Session-Id but do not write it. Context is anonymous (acr level 0, no identityProfileId). Build the Set-Cookie into context.
    AZ-->>GW: Allow (anonymous principal, context with X-Session-Id, anonymous acr, Set-Cookie)

    GW-->>V: 200 OK + Set-Cookie edi-session-id (Max-Age 90d, Secure, HttpOnly, SameSite=Lax)

    note over V: The visitor now holds an edi-session-id cookie, but there is no row in the store yet and no identity. A row is written only when EDI upserts it on OTP sign-in.
```

The `edi-session-id` cookie is the only handle to the session. The Authorizer
minted the id but did not persist it. When EDI later writes the session-token
row on OTP verify, it keys on this id — so if the browser drops the cookie, the
next request gets a different id, the row EDI wrote is never matched again, and
the user keeps looking anonymous.

---

## Sequence: OTP (ACR1) → Passkey enroll → Passkey step-up (ACR2)

### OTP authentication (establishes ACR1 / `1fa`)

[Back to top](#top)

The shopper enters a phone or email, receives an OTP, and verifies it. On success
EDI writes the session-token row; no new cookie is minted.

```mermaid
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant UI as UI (ecommerce)
    participant BFF as BFF
    participant VPS as VisitorProfileService
    participant E as EDI
    participant A as Auth0
    participant STS as Session-Token Service

    U->>B: Enter phone/email, tap Continue
    B->>UI: submit recipient (edi-session-id cookie)
    UI->>BFF: POST /api/v1/auth/otp (channel, recipient, edi-session-id cookie)
    BFF->>VPS: POST /api/v1/auth/otp - cookie passed through
    note over VPS: The edi-session-id cookie flows through from the browser via BFF and identifies the session.
    VPS->>E: POST /digital-id-profile-service/identity/passwordless/start (x-api-version v1, cookie)
    E->>A: POST /passwordless/start (connection sms|email, email or phone_number, send=code)
    A-->>E: OTP challenge accepted
    E-->>VPS: challenge started
    VPS-->>BFF: challenge started
    BFF-->>UI: 200 started
    UI-->>B: Show OTP entry screen

    U->>B: Enter OTP code
    B->>UI: submit code (edi-session-id cookie)
    UI->>BFF: PUT /api/v1/auth/otp (otp, channel, recipient, edi-session-id cookie)
    BFF->>VPS: PUT /api/v1/auth/otp - cookie passed through
    VPS->>E: POST /digital-id-profile-service/identity/passwordless/verify (x-api-version v1, cookie)
    E->>A: POST /oauth/token (grant_type=passwordless/otp, connection sms|email, recipient, otp)
    A-->>E: access_token, id_token, refresh_token (acr 1fa)
    note over E: Extract principal and ACR. Bridge to a phone/email-verified Auth0 DB user (Management API), link identities. Resolve or create the identity-profile binding.
    E->>STS: PUT /session-token-service/v1/api/session-tokens/{sessionId} (identityProfileId, principalSubject, acr, acrLevel, tokens)
    note over STS: Upsert the session-token row keyed by the edi-session-id. The session now has a durable identity and auth token. No new cookie minted.
    STS-->>E: session token stored
    E-->>VPS: verified, identity, profile, acr 1fa
    note over VPS: Persist auth-metadata (otpVerified, otpChannel, acr 1fa) and refresh deviceSessionExpiresAt (single backend token). Merge visitor by customerId if needed.
    VPS-->>BFF: verified, profile, acr 1fa
    BFF-->>UI: 200 verified (same edi-session-id cookie, now carries an auth token)
    UI-->>B: Signed in at ACR1. Show Continue to pre-qualification
```

### Passkey enrollment

[Back to top](#top)

Picks up from an ACR1 session. The shopper registers a passkey via WebAuthn. This
only stores a credential — it does not raise the ACR. During OTP verify, EDI has
already ensured a phone/email-verified Auth0 DB user so the passkey can attach to
a real identity.

```mermaid
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant UI as UI (ecommerce)
    participant BFF as BFF
    participant VPS as VisitorProfileService
    participant E as EDI
    participant A as Auth0

    U->>B: Tap Set up a passkey
    B->>UI: enroll passkey
    UI->>BFF: POST /api/v1/auth/passkey (action: register-options)
    BFF->>VPS: POST /api/v1/auth/passkey (action: register-options)
    VPS->>E: POST /digital-id-profile-service/passkeys/register
    note over E,A: EDI to Auth0 enrollment ceremony.
    E-->>VPS: authnParamsPublicKey, authSession
    VPS-->>BFF: start payload for WebAuthn
    BFF-->>UI: publicKey, authSession
    UI-->>B: pass creation options to WebAuthn

    B->>B: navigator.credentials.create(publicKey)
    B->>U: Device biometric / PIN prompt
    U-->>B: Approve (Face ID / Touch ID / PIN)
    B-->>UI: authnResponse (attestation)
    UI->>BFF: PUT /api/v1/auth/passkey (action: register, authSession, authnResponse)
    BFF->>VPS: PUT /api/v1/auth/passkey (action: register, authSession, authnResponse)
    VPS->>E: POST /digital-id-profile-service/passkeys/register/complete
    note over E,A: EDI to Auth0 verify-and-store ceremony.
    E-->>VPS: verified
    note over VPS: auth-metadata passkeyEnrolled true, passkeyVerified false (enrolled, not yet used)
    VPS-->>BFF: enrolled
    BFF-->>UI: 200 enrolled
    UI-->>B: Passkey saved, proceed to step-up
```

### Passkey step-up (establishes ACR2 / `2fa:phr`)

[Back to top](#top)

Picks up from an ACR1 session with a passkey enrolled. Using the passkey via
WebAuthn elevates the session to ACR2.


```mermaid
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant UI as UI (ecommerce)
    participant BFF as BFF
    participant VPS as VisitorProfileService
    participant E as EDI
    participant A as Auth0

    U->>B: Enter elevated flow (pre-qualification)
    B->>UI: request elevated action
    UI->>BFF: POST /api/v1/auth/passkey (action: login-options)
    BFF->>VPS: POST /api/v1/auth/passkey (action: login-options)
    VPS->>E: POST /digital-id-profile-service/passkeys/authenticate/start
    note over E,A: EDI to Auth0 passkey challenge.
    E-->>VPS: authnParamsPublicKey, authSession
    VPS-->>BFF: start payload for WebAuthn
    BFF-->>UI: publicKey, authSession
    UI-->>B: pass challenge to WebAuthn

    B->>B: navigator.credentials.get(publicKey)
    B->>U: Device biometric / PIN prompt
    U-->>B: Approve assertion
    B-->>UI: authnResponse (assertion)
    UI->>BFF: PUT /api/v1/auth/passkey (action: login, authSession, authnResponse)
    BFF->>VPS: PUT /api/v1/auth/passkey (action: login, authSession, authnResponse)
    VPS->>E: POST /digital-id-profile-service/passkeys/authenticate/complete
    note over E,A: EDI to Auth0 assertion verification and ACR2 token exchange.
    A-->>E: tokens with acr 2fa:phr
    note over E: Resolve profile binding. Upsert the session-token row with the higher ACR. Same session, higher ACR, no new cookie.
    E-->>VPS: authenticated, profile, acr 2fa:phr
    note over VPS: auth-metadata passkeyVerified true, acr 2fa:phr, refresh deviceSessionExpiresAt (single backend token)
    VPS-->>BFF: authenticated, acr 2fa:phr
    BFF-->>UI: 200 authenticated (same edi-session-id cookie, ACR now 2fa:phr)
    UI-->>B: Elevated at ACR2. Render pre-qualification
```

### Sensitive action at the gateway (ACR enforcement)

[Back to top](#top)

With the session at ACR2, the shopper continues into the sensitive pre-qual
action. The gateway invokes the Authorizer, which reads the session and compares
its ACR level to the route's requirement.

```mermaid
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant UI as UI (ecommerce)
    participant BFF as BFF
    participant GW as API Gateway
    participant AZ as Authorizer (Lambda)
    participant DDB as Session store (DynamoDB)

    U->>B: Continue in pre-qual (sensitive action)
    B->>UI: sensitive action request
    UI->>BFF: POST /api/v1/prequal/... (edi-session-id cookie echoed)
    BFF->>GW: forward sensitive action request with edi-session-id cookie
    note over GW: Gateway sets X-Header-Req-ACR for this route (e.g. 2fa:phr = level 3)
    GW->>AZ: Invoke authorizer (Cookie, X-Header-Req-ACR)
    AZ->>DDB: GetItem sessionId
    DDB-->>AZ: session row (acr, acrLevel, identity) or none
    AZ->>AZ: Compare session acrLevel vs required level
    alt ACR sufficient
        AZ-->>GW: Allow (context X-Session-Id, X-Identity-Profile-Id, X-Principal-Subject, X-ACR, X-Grant-Scopes, Set-Cookie)
        GW-->>BFF: 200 authorized (X-* identity headers injected)
        BFF-->>UI: 200 proceed
        UI-->>B: Pre-qual step renders
    else ACR insufficient or session invalid
        AZ-->>GW: Deny (context error insufficient_acr, required_acr, actual_acr)
        GW-->>BFF: 403 insufficient ACR
        BFF-->>UI: 403 step-up required
        UI-->>B: Re-run passkey step-up
    end
```


---

## Timeouts, expiry, and refresh

| Item | Value / behaviour |
|------|-------------------|
| **`edi-session-id` cookie** | Max-Age **90 days**; `Secure`, `HttpOnly`, `SameSite=Lax`. Governs how long the browser keeps sending the cookie — independent of server-side session validity. |
| **Auth token timeout** | **60 minutes**. The session-token row's `expiresAt` is set by EDI to `now + Auth0 access-token lifetime` (`expires_in`, 60 min). Stored on the row; must be a future time on write. |
| **Session validity check** | The Authorizer checks `expiresAt` itself on every call. Missing or past → treated as expired → anonymous context (DynamoDB TTL deletion is not relied on, since it can lag several hours). |
| **OTP code** | Short-lived one-time code (3 minutes), enforced by Auth0. |
| **`refreshable` flag** | Computed from the presence of a refresh token on the row. Marks the auth token as eligible for automatic refresh. |
| **Auth token refresh** | Automatic while the token is `refreshable`. When remaining lifetime falls inside a refresh window (roughly 5 minutes before `expiresAt`), the token is refreshed and the row re-upserted (`PUT .../session-tokens/{sessionId}`) with a new `expiresAt` and updated `accessToken`, `idToken`, and `refreshToken` — keeping the session active with no user prompt. If a refresh fails, the row ages out via DynamoDB TTL and the next call drops to anonymous, requiring a fresh OTP. |
| **Max refreshes** | **5**. After the auth token has been refreshed 5 times, it is no longer refreshed; the next call drops to anonymous and requires a fresh OTP. With a 60-minute token, this gives an effective session ceiling of roughly 6 hours (initial token + 5 refreshes). |
| **Passkey step-up validity** | Unresolved — how long a passkey step-up should keep a session at ACR2 before re-verification. Tracked as an open question; see `auth-flows.md`. |

---

## OTP Constraints (Auth0 / EDI)

For reference. OTP rate limiting and attempt tracking exist in Auth0 but are not surfaced by EDI.

| Constraint | Value | Auth0 Default | Configurable at Auth0? | Supported by EDI? |
|-----------|-------|---------------|----------------------|-------------------|
| Send rate (`/passwordless/start`) | 50 requests/hour per IP | Yes (default) | Yes — via Auth0 rate limit policies (per-tenant, per-endpoint) | Not surfaced |
| OTP code validity (TTL) | **3 minutes** | Yes (default) | Yes — Auth0 dashboard: Authentication → Passwordless → OTP Expiry | Not surfaced |
| OTP code length | 6 digits | Yes (default) | Yes — Auth0 dashboard: OTP Length | Default to align |
| Failed attempts per code | **3 max** — after 3 wrong inputs, the code is invalidated | Yes (hardcoded) | **No** — not configurable | Not surfaced |
| Failed OTP attempts per hour | **10** — hard limit after which a new OTP must be generated | Yes (hardcoded) | **No** — not configurable | Could be surfaced via a counter header, but not today |
| Only latest code valid | Yes — requesting a new code invalidates all previous | Always | No — built into Auth0 | N/A |
| Cooldown between resends | No enforced cooldown (subject to 50/hr IP limit) | No cooldown | Only via custom Auth0 Actions | UI can enforce a client-side cooldown (e.g., 30s) |

---

## Auth-metadata storage & write mechanism

Auth metadata is **scoped to the device**, persisted durably, and written by VPS as part of the auth orchestration it owns. (The field shape returned to clients is the API contract in `../visitor/openapi/visitor-profile-api.yml`; the UI-facing summary is in `auth-overview.md`.)

- **Written by VPS during `/auth/*`:** VPS orchestrates the OTP and passkey ceremonies (UI → BFF → VPS → EDI) and persists auth metadata as a side effect of `PUT /api/v1/auth/otp` (verify) and `PUT /api/v1/auth/passkey` (complete). The client-facing `/api/v1/auth/*` surface is the only write path.
- **Persisted in Postgres (keyed by `device_id`):** Although sessions coordinate via Redis (30-min sliding TTL), auth metadata must survive session timeout. When Redis expires and `/resolve` rotates to a new `sessionId`, the auth metadata is reloaded from Postgres via LEFT JOIN on `device_id`. This is why flow (h) (session timeout) does not lose auth state.
- **Per-device by construction:** Each device fingerprint resolves to its own `visitorId`/`sessionId`/`device_id`. Device-session auth state is device-scoped (`deviceSessionTier`); customer-wide capabilities (contacts, passkeys on other devices, `customerTier`) are visitor-scoped and surfaced under `metadata.auth`. Device A's live session does not affect Device B (see flow (e)).
- **Passkey→device linkage is VPS-owned:** EDI tracks devices at the *profile* level — `GET /profile` returns `deviceHashes[]` (a device fingerprint hash plus a `source`: `AUTHENTICATION_DEVICE`, `FINGERPRINT_WEBHOOK`, `RECOVERY_CHECK`, `INTERNAL`) — but it does **not** link a device hash to a specific passkey. The passkey list (`GET /passkeys`) carries only `id`, timestamps, `userAgent`, and `authenticatorAttachment` — no device id, AAGUID, or label. So the passkey→device link does not exist in EDI: VPS records the current resolved `device_id` against the `authentication_method_id` when this session drives the register/authenticate ceremony, and derives a `deviceLabel` from `userAgent`/`authenticatorAttachment`. This powers `passkeys[].isThisDevice`. VPS can optionally reconcile its own `device_fingerprint_hash` against EDI's `deviceHashes[]` (which uses the same fingerprint hash) to corroborate known devices.
- **Passkey portability is provider-controlled:** The client authenticator and its provider (iCloud Keychain, Google Password Manager, Bitwarden, 1Password, or a hardware key) decide whether a passkey syncs across the user's devices or stays bound to one. Neither VPS nor Auth0 can force either outcome; `authenticatorAttachment` is only a preference hint, and the WebAuthn `BE`/`BS` flags report syncability after the fact. A passkey is usable only on origins that match the configured relying-party ID (`rpId`), so sync across a user's devices is bounded by that `rpId`.
- **Hydrated on session rotation:** When a session expires and `/resolve` creates a new one, auth metadata is reloaded from Postgres (not lost with the Redis session). The new session inherits the device's auth state.

---

## Passkey detection: what each layer provides

Routing a step-up to the right branch (use here, use another device by QR, or enroll) is a client-first decision. Each layer contributes a distinct signal. The full decision model and table are in [`auth-flows.md`](./auth-flows.md#passkey-detection-model).

| Layer | Provides | Answers |
|-------|----------|---------|
| **Browser** (`getClientCapabilities()`) | `userVerifyingPlatformAuthenticator`, `hybridTransport`, `passkeyPlatformAuthenticator` | Can a passkey be used on this device right now, and is a QR path available? |
| **VPS** (`passkeys[]` on `/resolve`) | Whether the user has any passkey, plus per-passkey labels and `isThisDevice` | Does the user have a passkey at all, and how should the manage screen present each one? |
| **EDI** (`GET /passkeys`) | `id`, `credentialType`, timestamps, `userAgent` today; `BE`/`BS`, AAGUID, and device link are enrichment asks | The raw credential records VPS builds `passkeys[]` from. |

The browser owns the usability decision; the server list only tells the UI whether to route to a passkey path or to first-time enrollment. Credential nature (synced vs device-bound) and authenticator labels enrich the manage-passkeys screen — the EDI asks for them are tracked in [`auth-edi-open-questions.md`](./auth-edi-open-questions.md).

---

## Session teardown / logout

Logout (flow (m)) tears down the visitor session and invalidates the auth token.

- **EDI** invalidates the auth token for the `edi-session-id` immediately, via a `POST /auth/logout` single-session capability (a forward EDI ask; see below).
- **Gateway** stamps an expiring `Set-Cookie` so the browser's `edi-session-id` copy is cleared, not only invalidated server-side. Logout enters through the private gateway (VPS) while the cookie was set by the enterprise gateway, so this cross-gateway cookie-clear is a forward ask.
- **VPS** maps the ACR from EDI's logout response to `deviceSessionTier` (anonymous ACR → T0) in the same orchestration, the way it maps ACR everywhere else. The device's `metadata.auth` is retained, so the device stays known for a fast return.

**Bulk invalidation.** A variant invalidates *all other* auth tokens for an identity while keeping the initiating one. The primary-identifier change (below) reuses it, and a future account-deletion flow would too — the same EDI capability with a plural target.

**Forget me completely** (flow (n)) is logout plus two additions: VPS drops the `device_id` ↔ `visitor_id` association server-side, and the client clears everything it controls — cookies, localStorage, and cached resolve data. This is not account deletion.

## Primary identifier change

Changing the primary phone/email used for OTP (flow (o)) proves control of both channels — OTP on the old, then OTP on the new — then swaps.

- **Target (pending EDI).** EDI updates the *registered* identifier on the Auth0 user via the Management API. Auth0 applies strict E.164/geographic validation, requires the connection's attribute configuration to permit it, and expects the new identifier to be verified. Sequence: verify-old → verify-new → EDI swaps the Auth0 identifier → old channel demoted → other sessions invalidated (bulk invalidation above). Passkeys persist, since they are bound to the identity, not the number.
- **Interim (buildable now).** The swap happens at the VPS `contacts[]` layer: the new channel is added and verified, marked `contactRole: primary`, and the old demoted to `recovery`; Auth0's underlying registered identifier is unchanged until EDI supports the swap. **Risk to close:** until the Auth0-level swap exists, VPS must ensure OTP is initiated against the new primary rather than the old registered identifier.

## Forward EDI asks (consolidated)

The logout, forget-me, and identifier-change flows depend on capabilities EDI does not expose today:

1. **Session invalidation** — `POST /auth/logout` for a single session, plus a bulk variant to invalidate an identity's other sessions.
2. **Device unlink** — VPS support to drop the `device_id` ↔ `visitor_id` association for "forget me."
3. **Primary-identifier swap** — verify-old → verify-new → update the Auth0 registered identifier → demote old.
4. **Gateway cookie-clear** — confirmation that the gateway stamps the expiring `Set-Cookie` on a VPS-orchestrated logout.

These are tracked in `auth-flows.md` Open Questions (#16–#19).

---

## EDI Session Timeout — Design Approach

### Principle: Ecom does NOT proactively call EDI

The `edi-session-id` cookie has its own TTL controlled by the enterprise gateway/Auth0. Ecom does not know or attempt to configure this TTL. Ecom manages its own device-session state (`deviceSessionTier` / `deviceSessionExpiresAt`) independently.

**When EDI session expires:**
- **Ecom-only actions** (profile, watchlist, preferences, search): proceed normally. VPS does NOT call EDI. `deviceSessionTier` (backed by `deviceSessionExpiresAt`) is the authority.
- **Enterprise-gated actions** (pre-qual, originations): the call to EDI gets 401 → triggers re-auth (flow i in `auth-flows.md`). This is the designed behavior — reactive, not proactive.

### Why not proactive detection?

- Adding an EDI session-validity check to `/resolve` adds latency to every page load for a scenario that only matters during enterprise actions.
- The 401 from the gateway is a clear, reliable signal.
- Flow (i) already handles it gracefully (passkey-first, then OTP).

### Session lifetime configuration

| Layer | Controls | Configurable by Ecom? |
|-------|----------|----------------------|
| Auth0 access token lifetime | `expiresIn` returned by `/verify` (e.g., 86400s = 24h) | No — Auth0 dashboard setting |
| Auth0 refresh token lifetime | Governed by Auth0 rotation policy | No — Auth0 dashboard setting |
| `edi-session-id` cookie TTL | Enterprise gateway / Auth0 server-side | No — EDI/gateway team controls |
| Ecom `deviceSessionExpiresAt` (drives `deviceSessionTier`) | Computed by VPS: `verifyTime + expiresIn` | Yes — VPS controls the computation |
| Ecom passkey step-up validity | TBD | Yes — ecom decides the window |

### Open: `deviceSessionExpiresAt` vs actual EDI session

`deviceSessionExpiresAt` is computed by VPS from EDI's `expiresIn` at verify time. In theory, the EDI session could expire *before* it (if the gateway has a shorter TTL) or *after* (if Auth0 refreshes the session). Ecom's stance: `deviceSessionTier` / `deviceSessionExpiresAt` govern ecom-level auth decisions. EDI session validity is checked only when an enterprise action is attempted.

---

## E2E Testing Strategy (EDI + Auth0)

### Approach: Contract testing in CI + Real E2E in staging + EDI test endpoints

| Test Type | Environment | Auth0 | EDI | Purpose |
|-----------|-------------|-------|-----|---------|
| Unit tests | Local | Mocked | Mocked | Fast feedback, logic correctness |
| Contract tests | CI | Mocked (OpenAPI-driven) | Mocked | API contract compliance |
| Integration tests | Dev/Staging | Real (test tenant) | Real (test profile) | Full flow verification |
| E2E tests | Staging | Real (test tenant) | Real + test endpoints | Complete user journey |

### EDI Test Endpoints (dev/test environments only)

EDI should provide these endpoints, gated behind `ENVIRONMENT=local|dev|test`:

| Endpoint | Purpose |
|----------|---------|
| `POST /test/users` | Create a test user with specified phone/email. Auto-verifies (bypasses real OTP send). Returns `identityProfileId`. |
| `DELETE /test/users/{identityProfileId}` | Completely remove a test user and all Auth0 state (identities, passkeys, sessions). |
| `POST /test/otp/bypass` | Returns the actual OTP code for a pending verification instead of sending SMS/email. Allows tests to verify without real messaging infrastructure. |
| `DELETE /test/sessions/{identityProfileId}` | Clear all active sessions for a test user. Forces re-auth on next call. |

**Security constraints:**
- These endpoints MUST NOT exist in production builds.
- Gate behind environment check: return 404 in production.
- Require a test API key or internal-only network access.
- Test users should be identifiable (e.g., prefixed with `test_` or flagged in Auth0 metadata).

**Passkey testing:** No mock passkey endpoints. Test real WebAuthn E2E using browser automation (Playwright with virtual authenticator support).
