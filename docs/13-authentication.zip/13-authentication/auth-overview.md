# Auth Session Interaction

How a visitor progresses from anonymous to ACR1 (OTP) to ACR2 (passkey), across
one or more devices.

---

## Documentation map

The authentication design is split across four documents by audience and detail. Start here.

| Document | What it provides | Primary audience |
|----------|------------------|------------------|
| **auth-overview.md** (this file) | The conceptual model: actors, visitor tiers (T0–T3), auth capabilities, the step-up trigger model (hard vs. soft), the auth-metadata summary, and the high-level path progression. The entry point to the doc set. | Everyone — read first |
| **auth-flows.md** | The technical flow catalog: a state diagram for every auth flow, recovery path, and edge case (a–o), with the exact EDI/service calls, auth-metadata writes, and enforcement constraints in the diagram notes. | Engineers implementing the flows |
| **auth-user-journeys.md** | The same flows told as plain-English user journeys — choices, branches, and outcomes. | Product, design, stakeholders |
| **auth-integration.md** | The EDI / Auth0 / gateway integration reference: the session-token lifecycle, OTP constraints, timeout/refresh model, passkey detection layers, and auth-metadata storage. | Engineers integrating with EDI/gateway |
| **auth-edi-open-questions.md** | The consolidated list of asks that depend on EDI, Auth0, the gateway, or VPS infrastructure — passkey detection enrichment, session logout, identity management, and contract fixes. | EDI / platform teams, tech leads |

> API contract (field-level source of truth): `visitor-profile-api.yml`.

---

## Actors

| Actor | Role |
|-------|------|
| **UI** | Next.js ecommerce app. Calls BFF only. |
| **BFF** | Backend-for-frontend. Thin passthrough for `/api/v1/auth/*`; relays the session cookie. |
| **VPS** | VisitorProfileService. Owns visitor/device identity, tier metadata, and auth-metadata. Proxies auth calls to EDI. |
| **EDI** | Enterprise Digital Identity. Manages passkey and OTP ceremonies, identity linking, and session-token writes (via Session-Token Service internally). |

> **Gateway / Authorizer (infra layer)** — see [Session & ACR enforcement](#session--acr-enforcement) below.
> The VPS flows do not need to know about it.

---

## Visitor tiers

| Tier | How achieved | ACR |
|------|-------------|-----|
| **T0** — anonymous | Device resolved, no auth | `anon` |
| **T1** — OTP verified | OTP code accepted | `1fa` |
| **T2** — passkey authenticated | Passkey assertion accepted | `2fa:phr` |

The visitor's anonymous session (device/visitor profile) stays independent of
the auth session. When T1 or T2 is reached, tier metadata is updated on the VPS
side and the `edi-session-id` session row is upserted by EDI.

---

## Auth capabilities

| # | Capability | Tier required | Result |
|---|-----------|--------------|--------|
| 1 | Initiate OTP — by contact (email or phone) | T0+ | Code sent |
| 2 | Initiate OTP — by `contactPointToken` (returning visitor, second device) | T0+ | Code sent |
| 3 | Verify OTP | T0+ | Establishes T1 |
| 4 | Register a passkey (enroll on this device) | T1+ | Credential stored; tier unchanged |
| 5 | Authenticate with a passkey | T0+ | Establishes T2 |
| 6 | Update customer name (set OAuth 2.0 `name` claim) | T1+ | Name updated |
| 7 | Log out (this device) | T1+ | Session ended; device reset to T0, stays known |
| 8 | Forget me completely (shared/public device) | T0+ | Session ended, device unlinked, client cleared |
| 9 | Change primary identifier (phone/email used for OTP) | T2 if a passkey is enrolled, else T1 | New channel becomes primary; old demoted to recovery |

---

## Step-Up Trigger Model

There are no traditional sign-up or create-account actions. The platform offers the user the choice to sign in / up based on business rules and user value; sign-up becomes mandatory only for sensitive actions that deal with PII.

### Hard requirements (non-dismissable)

These cannot proceed without being authenticated:

- **Elevated flows such as completing or viewing loan pre-qualification** → requires T2 (passkey).
- **Book a dealer visit** → requires T1 (phone needed to confirm an appointment).
- **Join another user's shared watchlist** → requires T1 (OTP).
- **Account Information (on profile page)** → requires T1 (OTP): a manageable account (name, phone, email, notification preferences) that exists after sign-up.
- **Pre-qual offer summary (on profile page)** → requires T2 (passkey): sensitive financial data (APR, terms).

### Soft requirements (dismissable)

Proactive prompts triggered by **meaningful activity** — the user didn't ask, but the platform suggests signing up so their activity and preferences persist across devices and can be shared:

- **Adding vehicles to watchlist** → T0; nudge to sign up after a few adds.
- **Saving a search** → T0; nudge after meaningful search activity.
- **Save estimate to profile** → T0 to view, T1 to save.
- **View profile, watchlist, saved searches** → T0; Account Information requires T1, a finance offer requires T2.

Dismissing a prompt stops it; prompts resume only when further meaningful activity is detected. Hard requirements are never dismissable.

---

## Auth metadata (on `/resolve`)

Every page load calls `POST /resolve`, which returns the visitor's auth state: the coarse tiers at the root of `data` (`deviceSessionTier`, `customerTier`, `deviceSessionExpiresAt`) plus a `metadata.auth` block describing *how* the customer can reach each tier — `hasPasskey` / `hasEmail` / `hasPhone` / `hasRecovery` / `hasName` / `name`, the `contacts[]` that can reach T1 (each with a `contactPointToken`), and the `passkeys[]` that can reach T2 (each with `isThisDevice`). The same auth-only view is available on demand via `GET /api/v1/auth/profile`.

Within `contacts[]`, exactly one channel carries `contactRole: primary` — the OTP-preferred channel the account signs in with. Changing the sign-in phone or email is a role transition: the new channel becomes `primary` and the old is demoted to `recovery` (see capability 9 and flow (o)).

The exact field list is defined by the API contract in `../visitor/openapi/visitor-profile-api.yml` (v0.2.0+); persistence and write mechanics are covered in `auth-integration.md`.

---

## Path A — OTP → Passkey enrollment → Passkey step-up

The progressive path. Visitor starts with OTP, then optionally enrolls and uses
a passkey to reach T2.

```mermaid
flowchart TD
    A([Visitor — anonymous T0]) --> B

    B["**1. Initiate OTP**
    UI → BFF → VPS → EDI
    — by contact: email or phone
    — or by contactPointToken (returning / second device)"]

    B --> C["**2. Verify OTP**
    UI → BFF → VPS → EDI
    EDI upserts session-token row (acr: 1fa)
    VPS updates tier T1 + auth-metadata
    Returns: contactPointToken"]

    C --> D([Visitor — T1 / ACR1])

    D --> E["**3. Initiate passkey registration**
    UI → BFF → VPS → EDI
    EDI starts WebAuthn enrollment ceremony with Auth0
    Returns: publicKey options + authSession"]

    E --> F["**4. Device ceremony**
    Browser: navigator.credentials.create(publicKey)
    User approves — Face ID / Touch ID / PIN
    Returns: attestation"]

    F --> G["**5. Complete passkey registration**
    UI → BFF → VPS → EDI
    EDI verifies attestation, stores credential
    VPS updates auth-metadata: passkeyEnrolled
    ACR unchanged (still T1)"]

    G --> H["**6. Initiate passkey authentication**
    UI → BFF → VPS → EDI
    EDI starts WebAuthn assertion ceremony with Auth0
    Returns: publicKey challenge + authSession"]

    H --> I["**7. Device ceremony**
    Browser: navigator.credentials.get(publicKey)
    User approves
    Returns: assertion"]

    I --> J["**8. Complete passkey authentication**
    UI → BFF → VPS → EDI
    EDI verifies assertion, upserts session-token row (acr: 2fa:phr)
    VPS updates tier T2 + auth-metadata: passkeyVerified
    Same edi-session-id cookie, higher ACR"]

    J --> K([Visitor — T2 / ACR2])
```

---

## Path B — Direct passkey authentication

A visitor who has already enrolled a passkey (on any device) can authenticate
directly without going through OTP first. This is a **user-initiated** login —
the visitor chooses "sign in with passkey" and completes the biometric ceremony.
Using a passkey as a *silent, automatic* re-auth on page load (no user action) is
a separate, deferred capability — see "Persistent Silent Re-Auth" in
`auth-flows.md`.

```mermaid
flowchart TD
    A([Visitor — T0, passkey already enrolled]) --> B

    B["**1. Initiate passkey authentication**
    UI → BFF → VPS → EDI
    EDI starts WebAuthn assertion ceremony with Auth0
    Returns: publicKey challenge + authSession"]

    B --> C["**2. Device ceremony**
    Browser: navigator.credentials.get(publicKey)
    User approves — Face ID / Touch ID / PIN
    Returns: assertion"]

    C --> D["**3. Complete passkey authentication**
    UI → BFF → VPS → EDI
    EDI verifies assertion, resolves identity, upserts session-token row (acr: 2fa:phr)
    VPS updates tier T2 + auth-metadata
    Same edi-session-id cookie, higher ACR"]

    D --> E([Visitor — T2 / ACR2])
```

> Path B skips OTP entirely. The passkey is already bound to a real identity from
> a prior OTP verify on another device, so EDI can resolve the profile directly.

---

## Update customer name

Available at T1 or above. Sets the OAuth 2.0 `name` claim on the identity profile.

- `PUT /api/v1/auth/name` — UI → BFF → VPS → EDI
- EDI updates the Auth0 user's `name` attribute via the Management API.
- VPS reflects the updated name in auth-metadata.

---

## Session & ACR enforcement

All auth and sensitive traffic passes through an API Gateway with a Lambda Authorizer that mints the `edi-session-id` on first contact, reads the session row, and enforces the route's required ACR (allow with injected identity headers, or 403). The session-token lifecycle, refresh model, and the full sequence diagrams live in [`auth-integration.md`](./auth-integration.md).

---

## Logout & session teardown

Signing out invalidates the auth token and the gateway clears the `edi-session-id` cookie; EDI's logout response returns the current ACR, which VPS maps to `deviceSessionTier` (now T0). The device's `metadata.auth` is retained, so the device stays known for a fast return (flow (m)).

**Forget me completely** is the shared/public-device variant: logout plus VPS unlinking the device from the visitor and the client clearing everything it controls — cookies, localStorage, and cached data. This is not account deletion (flow (n)).

The session-invalidation primitive is reused in two more places: changing the primary identifier invalidates the identity's other sessions as a safety step (flow (o)), and account deletion (a future flow) would invalidate all of them. The EDI logout/invalidate endpoint and the gateway cookie-clear are pending capabilities — see Open Questions in `auth-flows.md`.

---

## Future Optimizations

### Auto-Trigger OTP (`contactPointToken` from EDI)

**Status:** Pending EDI support. This is the EDI capability behind `metadata.auth.contacts[].contactPointToken`; the field is specified in the API, but EDI does not yet return or accept the token.

**Concept:** After OTP verification, EDI returns an opaque token for the verified contact (`contactPointToken`). On a later auth requirement (e.g., session expired), VPS sends that token back to EDI's `/passwordless/start` to re-send a code without the user re-typing their phone or email.

**Why deferred:** EDI's `/passwordless/verify` returns only `verified`/`expiresIn`/`scope` today (no recipient or token), and `GET /profile` returns the full contact value which cannot be used as a send target without the user's explicit action. Viable once EDI supports a tokenized contact reference.

### Persistent Silent Re-Auth (Passkey as 1FA)

**Status:** Explicitly v2 per progressive-identity.md. Not in v1.

**Concept:** Use the passkey as the primary silent re-auth on returning visits: a user with an enrolled passkey is authenticated by biometric on page load, without seeing an OTP prompt. This extends the passkey's role from 2FA step-up for pre-qual into everyday sign-in.

---

## Open / pending

- [ ] Passkey step-up validity: how long ACR2 holds before re-verification is
  required.
- [ ] `contactPointToken`: confirm EDI returns it on OTP verify and that it can be
  passed back to `/passwordless/start` to re-send a code (see EDI open questions
  in `auth-flows.md`).
