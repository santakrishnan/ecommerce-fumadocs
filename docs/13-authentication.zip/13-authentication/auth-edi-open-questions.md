# EDI, Auth0 & Gateway Open Questions

The authentication design depends on capabilities owned by EDI, Auth0, the API gateway, and VPS infrastructure. This document consolidates every such ask in one place, so the EDI and platform teams have a single list to work from. Ecom-internal design questions stay in [`auth-flows.md`](./auth-flows.md) Open Questions.

Each item names the flow or feature it unblocks and what ecom does in the interim.

---

## Passkey detection & labeling

The [passkey detection model](./auth-flows.md#passkey-detection-model) routes step-up with browser capabilities alone, so it works with EDI as it stands today. The asks below enrich the manage-passkeys screen and analytics; none of them gate the step-up decision.

| # | Ask | Context | Status |
|---|-----|---------|--------|
| 1 | **Synced vs. device-bound signal (`BE`/`BS`)** | WebAuthn records this in the authenticator data at register and authenticate: `BE=1` means the credential can sync across the user's devices, `BE=0` means it is bound to one device; `BS` reports whether it is currently backed up. Auth0 runs the ceremony, so ecom never sees the raw authenticator data. Can EDI surface `BE`/`BS` (or a derived `synced` flag) per passkey on the list and on register/authenticate complete, so VPS can store it on `passkeys[]`? Payoff: label a credential as "syncs across your devices" vs "this device only" on the manage screen. | Needs Auth0/EDI confirmation |
| 2 | **Authenticator label (AAGUID)** | The passkey list (`GET /passkeys`) returns `id`, `credentialType`, timestamps, and `userAgent` — no AAGUID and no friendly label. A reliable name ("iCloud Keychain", "Google Password Manager", "1Password", "Windows Hello") comes from the credential's AAGUID mapped through a public registry ([passkey-authenticator-aaguids explorer](https://passkeydeveloper.github.io/passkey-authenticator-aaguids/explorer)). Can EDI return the AAGUID (or the resolved name) per passkey on the list and on register/authenticate complete? Interim: VPS derives a coarse label from `userAgent` and `authenticatorAttachment`. | Needs EDI confirmation |
| 3 | **Passkey ↔ device association** | EDI holds device fingerprint hashes at the profile level (`GET /profile` → `deviceHashes[]`, tagged `AUTHENTICATION_DEVICE`, `FINGERPRINT_WEBHOOK`, `RECOVERY_CHECK`, `INTERNAL`), but the passkey list carries no link from a passkey to a `deviceHash`. Can EDI associate a passkey with the `deviceHash` it was enrolled on? Interim: VPS owns the linkage by recording `device_id` when its session drives the ceremony, and corroborates against `deviceHashes[]` to power `passkeys[].isThisDevice`. | Needs EDI confirmation |
| 4 | **`userAgent` coverage and stability** | VPS uses `userAgent` from the passkey list as a device hint for `deviceLabel` and device matching. Is `userAgent` populated on both `credentials[]` (native passkeys) and `authenticators[]` (Guardian), and captured at enrollment (stable) rather than last use (changes)? | Needs EDI confirmation |
| 5 | **Enrollment options EDI sends to Auth0** | Auth0 returns WebAuthn `authenticatorSelection` on register (`authenticatorAttachment`, `residentKey`/`requireResidentKey`, `userVerification`) plus the RP ID. Which values does EDI send, and can ecom influence them? Ecom wants platform, discoverable (syncable), user-verified passkeys. The UI passes whatever EDI relays into `navigator.credentials.create()`, so the behavior is EDI-driven. | Needs EDI confirmation |

---

## Session lifecycle & logout

These back flows (m) logout, (n) forget-me, and (o) primary-identifier change. See [`auth-integration.md`](./auth-integration.md#session-teardown--logout).

| # | Ask | Context | Status |
|---|-----|---------|--------|
| 6 | **Single-session logout / invalidation** | Flows (m)/(n)/(o) need EDI to invalidate the auth token for one `edi-session-id` on demand, plus a bulk variant to invalidate an identity's *other* sessions (used by (o)'s safety step). EDI has no logout or invalidate endpoint. | Needs EDI capability |
| 7 | **Device unlink for "forget me"** | Flow (n) needs VPS to drop the `device_id` ↔ `visitor_id` association server-side, so a shared or public device becomes a fresh anonymous visitor next time. Confirm the VPS/Postgres mechanics and that it composes with logout while leaving customer data and the platform passkey intact. | Needs VPS design |
| 8 | **Gateway cookie-clear on logout** | Logout enters through the private gateway (UI → BFF → VPS), but the `edi-session-id` cookie was set by the enterprise gateway. Will the gateway stamp `Set-Cookie: edi-session-id=; Max-Age=0` on the logout response, on the same path and domain it was set, so the browser copy is cleared and not only the server row invalidated? | Needs gateway confirmation |

---

## Identity & account management

| # | Ask | Context | Status |
|---|-----|---------|--------|
| 9 | **Primary-identifier swap at the Auth0 level** | Flow (o) is defined, and its interim (swap at the VPS `contacts[]` layer) is buildable. The target — EDI updating the *registered* identifier on the Auth0 user (verify-old → verify-new → swap → demote old) — depends on EDI. Auth0 allows it via the Management API with strict E.164/geographic validation and re-verification. Residual: will EDI expose the swap, and in the interim does OTP reliably initiate against the new primary rather than the old registered identifier? | Needs EDI + Auth0 confirmation |
| 10 | **Account delete / deactivate** | EDI can delete individual or all passkeys, but has no endpoint to delete or deactivate an identity profile. Will EDI expose account deletion, and is it a hard delete or a reversible deactivation? What happens to linked contacts, the Auth0 user, and active sessions, and what re-verification gates it? | Needs EDI + product input |
| 11 | **Auth0 identity linking limits** | Is there a maximum number of phone/email channels per Auth0 identity? No documented limit found. | Needs Auth0/EDI confirmation |

---

## Contract & platform

| # | Ask | Context | Status |
|---|-----|---------|--------|
| 12 | **EDI 429/503 spec-vs-impl mismatch** | The OpenAPI spec documents 429 for rate limits; the Java handler returns 503. Align the two so ecom can handle rate-limit responses reliably. | Needs EDI team fix |
