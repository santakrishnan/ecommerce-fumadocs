# Authentication Flows

The flow catalog for authentication on the ecommerce platform — every auth flow, recovery path, and edge case as a state diagram. Based on the progressive-identity PRD.

- The step-up trigger model (hard/soft requirements), visitor tiers, and the auth-metadata summary live in [`auth-overview.md`](./auth-overview.md).
- OTP constraints, session/token lifecycle, and auth-metadata storage live in [`auth-integration.md`](./auth-integration.md).
- The plain-English, non-technical journeys live in [`auth-user-journeys.md`](./auth-user-journeys.md).

---

## Flow Summary

| # | Flow | Description |
|---|------|-------------|
| [(a)](#a-otp-authentication) | OTP Authentication | First-time or returning sign-in via one-time passcode (phone or email) |
| [(b)](#b-passkey-enrollment) | Passkey Enrollment | Registering a new WebAuthn credential on a device |
| [(c)](#c-passkey-step-up-authentication) | Passkey Step-Up Auth | Authenticating with an existing passkey for 2FA |
| [(d)](#d-channel-lost--changed) | Channel Lost / Changed | Recover when phone or email is unavailable |
| [(e)](#e-new-device--same-identity-merge--recovery) | New Device (Merge) | New fingerprint → OTP with existing identity → merge profiles |
| [(f)](#f-passkey-failed--corrupted) | Passkey Failed / Corrupted | Credential missing or platform unavailable |
| [(g)](#g-all-passkeys-deleted) | All Passkeys Deleted | No passkeys registered anywhere |
| [(h)](#h-session-timeout--re-authentication) | Session Timeout | Ecom session (Redis) expired, user returns |
| [(i)](#i-edi-session-expired-edi-session-id-cookie) | EDI Session Expired | Enterprise auth cookie expired, ecom auth still valid |
| [(j)](#j-passkey-management) | Passkey Management | List, add, revoke passkeys from settings |
| [(k)](#k-soft-step-up-activity-triggered-prompt) | Soft Step-Up | Activity-triggered, dismissable prompts |
| [(l)](#l-add-contact-channel-settings) | Add Contact Channel | Add additional phone/email from settings |
| [(m)](#m-logout-this-device) | Logout | Sign out on this device — session ended, device stays known |
| [(n)](#n-forget-me-completely-shared-or-public-device) | Forget Me Completely | Shared/public device — sign out, unlink device, clear client |
| [(o)](#o-update-primary-identifier-change-the-phone-or-email-used-for-otp) | Update Primary Identifier | Change the primary phone/email used for OTP |


**Recovery priority order (flow d):** Passkey (fastest, strongest) → Alternate channel OTP → Call support

---


## (a) OTP Authentication

First-time or returning sign-in via one-time passcode. Covers both phone and email channels.

```mermaid
stateDiagram-v2
    [*] --> Unauthenticated

    state "OTP Authentication" as OTPFlow {
        [*] --> SelectChannel

        state SelectChannel <<choice>>
        SelectChannel --> EnterPhone : user picks Phone
        SelectChannel --> EnterEmail : user picks Email

        EnterPhone --> OTPSent : submit phone number
        EnterEmail --> OTPSent : submit email address

        note right of OTPSent
            VPS → EDI: POST /passwordless/start
            [ channel: SMS|EMAIL, recipient ]
            If recipient is unrecognized by EDI,
            a new identity is created.

            Constraints (Auth0-enforced):
            - 50 sends/hr per IP
            - OTP valid for 3 minutes
            - Only latest code is valid
        end note

        OTPSent --> AwaitingCode : code delivered

        state AwaitingCode {
            [*] --> EnterOTPCode

            EnterOTPCode --> CodeValid : correct & not expired
            EnterOTPCode --> CodeInvalid : wrong code
            EnterOTPCode --> CodeExpired : TTL elapsed — 3 min

            note right of CodeInvalid
                Auth0 hard limit: 3 failed attempts
                per code (not configurable).
                10 failed attempts per hour total.
                UI tracks attempts client-side for UX.
            end note

            CodeInvalid --> EnterOTPCode : retry while under 3 attempts
            CodeExpired --> OTPSent : resend requested — invalidates previous code
            CodeInvalid --> MaxAttemptsReached : 3 failed attempts on this code
        }

        MaxAttemptsReached --> UserChoice

        note right of MaxAttemptsReached
            Code invalidated after 3 wrong attempts.
            After 10 failed attempts/hr → EDI-TES-204
            (auto-resets after cooldown ~15 min).
        end note

        state "User Choice" as UserChoice <<choice>>
        UserChoice --> OTPSent : request new code — retry
        UserChoice --> AlternateChannelRecovery : try alternate channel

        state AlternateChannelRecovery <<choice>>
        AlternateChannelRecovery --> SelectChannel : alternate channel available
        AlternateChannelRecovery --> CallSupport : no alternate channel available
    }

    note right of CallSupport
        Future: manual identity verification.
        "Call in to restore access"
        See flow (d) for recovery details.
    end note

    Unauthenticated --> OTPFlow : auth required — hard or soft trigger

    OTPFlow --> Authenticated : CodeValid

    note left of Authenticated
        UI → BFF → VPS: PUT /api/v1/auth/otp (verify)
        VPS orchestrates EDI verify + profile, then
        persists auth-metadata [ otpVerified, otpChannel ],
        refreshes deviceSessionExpiresAt (single backend token)
        VPS: merge under customerId
        Set-Cookie: edi-session-id
    end note

    CallSupport --> [*] : exits digital flow

    Authenticated --> [*]
```

---

## (b) Passkey Enrollment

Registering a new passkey (WebAuthn credential) on a device. Requires 1FA (OTP verified) first.

```mermaid
stateDiagram-v2
    [*] --> OTPVerified

    note right of OTPVerified
        Prerequisite: user has completed
        OTP authentication (flow a).
        EDI enforces: EDI-TES-103 if no OTP session.
    end note

    state "Passkey Enrollment" as Enrollment {
        [*] --> StartRegistration

        note right of StartRegistration
            VPS → EDI: POST /passkeys/register
            Returns: authnParamsPublicKey, authSession
        end note

        StartRegistration --> CredentialCreationOptions : EDI returns challenge

        CredentialCreationOptions --> BiometricPrompt : browser calls navigator.credentials.create

        BiometricPrompt --> CredentialSaved : user approves — biometric/PIN
        BiometricPrompt --> EnrollmentFailed_UserCancelled : user cancelled
        BiometricPrompt --> EnrollmentFailed_PlatformError : device/OS rejected

        note right of CredentialSaved
            UI → BFF → VPS: PUT /api/v1/auth/passkey (action: register)
            [ authSession, response ]
            VPS persists auth-metadata [ passkeyEnrolled: true, passkeyVerified: false ]
            (Enrollment only — not yet authenticated via passkey)
        end note

        EnrollmentFailed_UserCancelled --> BiometricPrompt : retry
        EnrollmentFailed_PlatformError --> CannotEnroll : device cannot support passkeys
    }

    OTPVerified --> Enrollment : user initiates or system prompts enrollment

    Enrollment --> PasskeyRegistered : CredentialSaved
    CannotEnroll --> PasskeyEducation_Enroll : hard stop

    note right of PasskeyEducation_Enroll
        "This device does not support passkeys. Try another device or a newer browser."
        No fallback 2FA mechanism.
    end note

    PasskeyRegistered --> [*]
    PasskeyEducation_Enroll --> [*]
```

---

## Passkey detection model

Before any step-up, the UI decides how to offer the passkey: use one on this device, reach one held on another device by QR, or set a new one up. That decision is **client-first**. Two questions drive it, and they live in different layers:

1. **Can a passkey be used on this device right now?** Only the browser knows. Sync state and credential presence are facts held by the client and its passkey provider, never by the server.
2. **Does the user have any passkey at all?** The server knows, from the VPS `passkeys[]` list (sourced from EDI `GET /passkeys`).

The browser answers the first question through `PublicKeyCredential.getClientCapabilities()`:

| Capability | Meaning | Drives |
|-----------|---------|--------|
| `userVerifyingPlatformAuthenticator` | A platform passkey can be used locally on this device. | Use a passkey here |
| `hybridTransport` | The browser can show a QR code to use a passkey held on a nearby phone. | Use another device by QR |
| `passkeyPlatformAuthenticator` | Shorthand for `hybridTransport OR userVerifyingPlatformAuthenticator` — some passkey path exists. | Any passkey path at all |

Use `passkeyPlatformAuthenticator` as the quick gate: if it is false, no passkey path exists on this device and the only option is enrollment. When it is true, the two component signals decide between "use here" and "use another device."

Browser support for `getClientCapabilities()`: Chrome and Edge 133, Firefox 135, Safari 17.4. Where it is absent, map the older APIs onto the same signals: `isUserVerifyingPlatformAuthenticatorAvailable()` stands in for `userVerifyingPlatformAuthenticator`. There is no older feature-detection API for hybrid (QR) availability, so on those browsers treat the QR branch as unavailable and route a user with no local authenticator to enrollment.

### Decision table

The UI combines the server list with the browser capabilities to pick one branch:

| `passkeys[]` (server) | Local platform authenticator | Hybrid (QR) available | Branch | What the UI offers |
|-----------------------|------------------------------|-----------------------|--------|--------------------|
| One or more | Yes | — | **Use here** | Biometric prompt on this device |
| One or more | No | Yes | **Use another device** | QR code to verify with the phone that holds the passkey |
| One or more | No | No | **Enroll here** | Set up a new passkey on this device |
| None | — | — | **First passkey** | Set up the first passkey |

### Where server-side signals fit

`getClientCapabilities()` reports that a capability *exists*, not that *this user's* credential sits on the local authenticator. A synced passkey (present in the user's provider) is still absent on a device the user has never signed into. So the table is **pre-flight routing**, and the authentication attempt itself is the **definitive check**: `navigator.credentials.get()` run without a visible prompt (silent or conditional mediation — the browser surfaces a credential only if one is actually present) confirms a usable local credential.

When the two disagree — the table routed to "use here" but the silent `get()` finds no local credential — fall back to the next branch: offer the QR path if hybrid is available, otherwise offer enrollment. The table optimizes the common case; the `get()` result is authoritative.

Server-side credential nature — whether a passkey is synced or device-bound (WebAuthn `BE`/`BS`), and its authenticator label (AAGUID) — does not gate this decision. It enriches the manage-passkeys screen and analytics. EDI exposes none of it today; the enrichment asks and their UX payoff are tracked in [`auth-edi-open-questions.md`](./auth-edi-open-questions.md).

---

## (c) Passkey Step-Up Authentication

Authenticating with an existing passkey for 2FA step-up (required for pre-qualification). It applies the [passkey detection model](#passkey-detection-model) to route the user, validates the credential server-side, and reconciles the client credential list through the WebAuthn Signal API.

```mermaid
stateDiagram-v2
    [*] --> OTPVerified_NeedsStepUp

    note right of OTPVerified_NeedsStepUp
        User is 1FA authenticated.
        Action requires 2FA (e.g., pre-qual).
        UI checks: does device have a registered passkey?
    end note

    state "Detect Passkey Availability" as ValidatePasskeys {
        [*] --> FetchPasskeysFromEDI

        note right of FetchPasskeysFromEDI
            Server list: VPS to EDI GET /passkeys tells us whether the user has any passkey.
            Browser capabilities: getClientCapabilities returns userVerifyingPlatformAuthenticator and hybridTransport.
            Also reconcile the client list via Signal API signalAllAcceptedCredentials with rpId userId and acceptedCredentialIds.
        end note

        FetchPasskeysFromEDI --> [*]
    }

    OTPVerified_NeedsStepUp --> ValidatePasskeys
    ValidatePasskeys --> DeviceCheck

    state "Route by detection model" as DeviceCheck <<choice>>

    note right of DeviceCheck
        See the passkey detection model above.
        Usable here then biometric prompt.
        Another device with hybrid available then QR to that device.
        Has a passkey but no local authenticator and no hybrid then enroll here.
        No passkey then enroll the first one.
    end note

    DeviceCheck --> PasskeyChallenge : usable here
    DeviceCheck --> CrossDeviceQR : another device (QR)
    DeviceCheck --> InlineEnrollment : none usable — see flow b

    state "Cross-Device (QR hybrid)" as CrossDeviceQR {
        [*] --> ShowQR
        note right of ShowQR
            Browser shows a QR code (hybrid transport).
            User scans with the phone that holds the passkey and approves the biometric there.
            The passkey stays on that phone.
        end note
        ShowQR --> [*] : approved on phone
    }

    CrossDeviceQR --> PasskeyChallenge : assertion returned

    state "Passkey Challenge" as PasskeyChallenge {
        [*] --> StartAuthentication

        note right of StartAuthentication
            VPS → EDI: POST /passkeys/authenticate/start
            Returns: authnParamsPublicKey, authSession
        end note

        StartAuthentication --> BiometricPrompt : browser calls navigator.credentials.get

        BiometricPrompt --> PasskeyVerified : user approves — biometric/PIN
        BiometricPrompt --> FailedRetryable : user cancelled / timeout
        BiometricPrompt --> FailedUnrecoverable : credential not found / platform unavailable

        FailedRetryable --> BiometricPrompt : retry while under 3 attempts
        FailedRetryable --> FailedUnrecoverable : max retries exceeded
    }

    note right of PasskeyVerified
        UI → BFF → VPS: PUT /api/v1/auth/passkey (action: login)
        VPS orchestrates EDI authenticate/complete
        Returns: [ verified, identity: [ acr: "2fa:phr" ] ]
        VPS persists auth-metadata [ passkeyVerified: true ],
        refreshes deviceSessionExpiresAt (single backend token)
    end note

    state FailedUnrecoverable_Decision <<choice>>
    FailedUnrecoverable --> FailedUnrecoverable_Decision

    note right of FailedUnrecoverable
        If credential not found by OS but server says
        it exists → zombie passkey. Signal removal:
        PublicKeyCredential.signalUnknownCredential([
          rpId, credentialId
        ]);
    end note

    FailedUnrecoverable_Decision --> InlineEnrollment : credential missing — re-enroll
    FailedUnrecoverable_Decision --> CannotProceed : platform cannot do WebAuthn

    InlineEnrollment --> PasskeyVerified : enrollment + immediate auth — flow b then c

    PasskeyChallenge --> ElevatedSession : PasskeyVerified
    ElevatedSession --> [*] : proceed to pre-qual

    CannotProceed --> PasskeyEducation
    note right of PasskeyEducation
        "This device does not support passkeys.
        Try another device or a newer browser."
        No fallback 2FA.
    end note
    PasskeyEducation --> [*]
```

---

## (d) Channel Lost / Changed

User cannot access one of their verified channels (phone or email). The other channel is the alternate. Recovery priority: passkey (if available) → alternate channel OTP → call support.

```mermaid
stateDiagram-v2
    [*] --> ChannelUnavailable

    note right of ChannelUnavailable
        User's verified phone OR email is lost,
        changed, or no longer accessible.
        If phone lost → email is alternate channel.
        If email lost → phone is alternate channel.
    end note

    ChannelUnavailable --> CheckPasskey

    state "Check Passkey on Device" as CheckPasskey <<choice>>

    CheckPasskey --> PasskeyRecovery : passkey available on this device
    CheckPasskey --> CheckAlternateChannel : no passkey on this device

    %% ─── PATH 1: Passkey proves identity (fastest, strongest) ───

    state "Passkey Identity Proof" as PasskeyRecovery {
        [*] --> PasskeyPrompt

        note right of PasskeyPrompt
            UI auto-detects passkey via metadata.auth.passkeys[] or
            WebAuthn discovery. Presents as primary option:
            "Verify with your passkey"
            Secondary: "Use [alternate channel] instead" link.
        end note

        PasskeyPrompt --> BiometricChallenge : user taps "Verify with passkey"
        PasskeyPrompt --> CheckAlternateChannel : user taps alternate channel

        BiometricChallenge --> PasskeyVerified : biometric approved

        note right of PasskeyVerified
            VPS → EDI: POST /passkeys/authenticate/start
            Browser: navigator.credentials.get()
            VPS → EDI: POST /passkeys/authenticate/complete
            Enterprise gateway provides fresh edi-session-id.
            Identity proven at 2FA level (acr: 2fa:phr).
        end note

        BiometricChallenge --> PasskeyFailed : cancelled / credential missing
        PasskeyFailed --> BiometricChallenge : retry
        PasskeyFailed --> CheckAlternateChannel : give up on passkey
    }

    PasskeyVerified --> BindNewChannel : identity proven, proceed to bind

    %% ─── PATH 2: Alternate channel OTP proves identity ───

    state "Check Alternate Channel" as CheckAlternateChannel <<choice>>

    CheckAlternateChannel --> AlternateOTPFlow : alternate channel on file
    CheckAlternateChannel --> CheckPasskeyFallback : no alternate channel on file

    state "Check Passkey Fallback" as CheckPasskeyFallback <<choice>>
    CheckPasskeyFallback --> PasskeyRecovery : passkey available — haven't tried yet
    CheckPasskeyFallback --> CallSupport : no passkey, no alternate channel

    state "Alternate Channel OTP" as AlternateOTPFlow {
        [*] --> EnterAlternate

        note right of EnterAlternate
            If phone lost → user enters email.
            If email lost → user enters phone.
        end note

        EnterAlternate --> AlternateOTPSent : submit alternate channel

        note right of AlternateOTPSent
            VPS → EDI: POST /passwordless/start
            [ channel: [alternate], recipient ]
        end note

        AlternateOTPSent --> EnterAlternateCode

        EnterAlternateCode --> AlternateVerified : correct code
        EnterAlternateCode --> AlternateCodeInvalid : wrong code
        AlternateCodeInvalid --> EnterAlternateCode : retry
        AlternateCodeInvalid --> AlternateLocked : max attempts
    }

    AlternateVerified --> IdentityRestoredViaAlternate

    note right of IdentityRestoredViaAlternate
        VPS → EDI: POST /passwordless/verify
        VPS → EDI: GET /profile → same identityProfileId
        EDI session restored via edi-session-id cookie.
    end note

    IdentityRestoredViaAlternate --> BindNewChannel : identity proven, proceed to bind

    %% ─── BIND NEW CHANNEL (common exit for all identity-proof paths) ───

    state "Bind New Channel" as BindNewChannel {
        [*] --> EnterNewRecipient

        note right of EnterNewRecipient
            User enters the NEW phone number or email
            to replace the lost channel.
        end note

        EnterNewRecipient --> NewChannelOTPSent : submit new recipient

        note right of NewChannelOTPSent
            VPS → EDI: POST /passwordless/start
            [ channel: [lost channel type], recipient: newRecipient ]
            OTP verifies ownership of the NEW channel.
        end note

        NewChannelOTPSent --> VerifyNewChannel
        VerifyNewChannel --> NewChannelBound : correct code
        VerifyNewChannel --> NewChannelInvalid : wrong code
        NewChannelInvalid --> VerifyNewChannel : retry
    }

    note right of NewChannelBound
        VPS persists auth-metadata (during /api/v1/auth/otp verify)
        [ otpVerified: true, otpChannel: [new] ],
        deviceSessionExpiresAt refreshed
    end note

    BindNewChannel --> Done : NewChannelBound

    %% ─── PATH 3: No channels, no passkey → support ───

    CallSupport --> SupportUnlocked : identity verified by agent

    note right of CallSupport
        Future: manual identity verification.
        "Call in to restore access."
        Support verifies identity → unlocks account
        → user can bind a new channel.
    end note

    SupportUnlocked --> BindNewChannel : account unlocked, bind new channel

    AlternateLocked --> CallSupport : all channels exhausted

    Done --> [*]
```

---

## (e) New Device — Same Identity (Merge / Recovery)

User opens the site on a new device (new fingerprint) and recovers their existing profile via OTP.

```mermaid
stateDiagram-v2
    [*] --> NewDeviceDetected

    note right of NewDeviceDetected
        Unknown device_fingerprint_hash.
        VPS: POST /resolve creates new visitor_id (T0).
        Returns: [ visitorId: NEW, isNew: true, deviceSessionTier: T0 ]
    end note

    NewDeviceDetected --> Anonymous_T0 : new visitor created

    state "OTP on Same Identity" as OTPSameIdentity {
        [*] --> SelectChannel

        state SelectChannel <<choice>>
        SelectChannel --> EnterPhone : picks phone
        SelectChannel --> EnterEmail : picks email

        EnterPhone --> OTPSent : submit existing phone
        EnterEmail --> OTPSent : submit existing email

        note right of OTPSent
            VPS → EDI: POST /passwordless/start
            Recipient recognized → existing identity.
            Recipient unrecognized → new identity created
            (no merge occurs; user is now T1 on new account).
        end note

        OTPSent --> EnterCode
        EnterCode --> Verified : correct code
        EnterCode --> Failed : wrong code
        Failed --> EnterCode : retry
    }

    Anonymous_T0 --> OTPSameIdentity : user initiates auth — hard/soft trigger

    state "Identity Recognized?" as IdentityCheck <<choice>>
    Verified --> IdentityCheck

    IdentityCheck --> MergeFlow : EDI returns existing identityProfileId
    IdentityCheck --> NewAccount : EDI created new identity — unrecognized recipient

    state "Merge" as MergeFlow {
        [*] --> WritingAuthMetadata

        note right of WritingAuthMetadata
            VPS persists auth-metadata (during /api/v1/auth/* orchestration)
            VPS: merge under customerId
        end note

        WritingAuthMetadata --> MergeExecuted

        note right of MergeExecuted
            VPS merge logic:
            - Finds canonical visitor with same customerId
            - Repoints new device to canonical visitor
            - Merges stats
            - Soft-deletes temporary visitor
            - Async: merges preferences, watchlist
        end note

        MergeExecuted --> [*]
    }

    MergeFlow --> ProfileRecovered

    note right of ProfileRecovered
        Next /resolve returns:
        [ visitorId: CANONICAL, customerId, deviceSessionTier, customerTier, metadata.auth,
          preferences (merged), watchlist (merged) ]
        Passkeys are per-device: passkeyVerified=false
        on new device unless a synced passkey is present. Prompt enrollment if needed.
    end note

    NewAccount --> NewProfile_T1 : fresh T1 profile on this device

    ProfileRecovered --> [*]
    NewProfile_T1 --> [*]
```

**Second device, same identity (merge).** When a signed-in customer verifies the same phone/email on a new device, VPS resolves the existing `identityProfileId`, repoints the new device to the canonical visitor, and merges stats/preferences/watchlist. The original device is unaffected — each device keeps its own device-scoped `deviceSessionTier`. On the new device, `passkeys[]` has no `isThisDevice` entry unless the passkey was synced (see [`auth-user-journeys.md`](./auth-user-journeys.md) "Passkey Already Synced to This Device").

**Multi-identity conflict on a shared device (409).** If a *different* person verifies on a device already linked to another customer, VPS returns **HTTP 409 Conflict** on `PUT /api/v1/auth/otp` (`{ conflict: true, existingCustomerId }`) — it never re-links a visitor to a new customer. The UI then asks "shopping together, or your own account?": *shopping together* gives person B a persona slot under the same visitor (no ecom merge); *own account* forks a new visitor for B on the device, and `/resolve` returns the most-recently-authenticated visitor. The multi-visitor-per-device implementation is deferred (see Open Questions #1).

**Phone-only recovery via pre-collected email.** A phone-only customer has no recovery channel if they lose the phone. Mitigation: when they enter an email during pre-qual (or elsewhere), VPS verifies it via the normal OTP flow so it links to the existing `identityProfileId` and becomes a recovery channel — done after submission, non-blocking, and skippable. Recovery itself then follows flow (d) (alternate channel).

---

## (f) Passkey Failed / Corrupted

Passkey credential is missing from the OS keychain, corrupted, or the platform authenticator is unavailable.

```mermaid
stateDiagram-v2
    [*] --> TwoFARequired

    note right of TwoFARequired
        User hit a 2FA-required action (pre-qual).
        Device previously had a passkey registered.
    end note

    TwoFARequired --> AttemptPasskeyAuth : initiate passkey challenge

    state "Passkey Attempt" as AttemptPasskeyAuth {
        [*] --> BiometricPrompt

        BiometricPrompt --> PasskeyVerified : success
        BiometricPrompt --> CredentialNotFound : OS reports no matching credential
        BiometricPrompt --> PlatformUnavailable : TPM/authenticator failure
        BiometricPrompt --> UserCancelled : user hit cancel
    }

    UserCancelled --> AttemptPasskeyAuth : retry

    state "Failure Classification" as FailureClassify <<choice>>
    CredentialNotFound --> FailureClassify
    PlatformUnavailable --> FailureClassify

    FailureClassify --> ReEnrollInline : credential missing — can re-enroll
    FailureClassify --> PasskeyEducation : platform cannot do WebAuthn

    state "Re-Enrollment" as ReEnrollInline {
        [*] --> StartNewRegistration

        note right of StartNewRegistration
            Same as flow (b): Passkey Enrollment.
            VPS → EDI: POST /passkeys/register
            Browser: navigator.credentials.create()
            VPS → EDI: POST /passkeys/register/complete
        end note

        StartNewRegistration --> NewCredentialCreated : enrollment succeeds
        StartNewRegistration --> EnrollmentFailed : device rejected again
    }

    ReEnrollInline --> ImmediateAuth : NewCredentialCreated

    state "Immediate Auth" as ImmediateAuth {
        [*] --> AuthWithNewPasskey

        note right of AuthWithNewPasskey
            VPS → EDI: POST /passkeys/authenticate/start
            Browser: navigator.credentials.get()
            VPS → EDI: POST /passkeys/authenticate/complete
        end note

        AuthWithNewPasskey --> [*] : verified
    }

    ImmediateAuth --> ElevatedSession
    ElevatedSession --> [*] : proceed to pre-qual

    EnrollmentFailed --> PasskeyEducation

    note right of PasskeyEducation
        "This device does not support passkeys. Try another device or a newer browser."
        Cannot proceed with pre-qual on this device.
    end note

    PasskeyEducation --> [*]
    PasskeyVerified --> ElevatedSession
```

---

## (g) All Passkeys Deleted

User has revoked all passkeys (or lost all devices with passkeys). Functionally identical to "no passkey on device."

```mermaid
stateDiagram-v2
    [*] --> AllPasskeysRevoked

    note right of AllPasskeysRevoked
        User deleted all passkeys via management (flow k),
        or lost all devices that had enrolled passkeys.
        EDI: GET /passkeys returns empty list.
        metadata.auth: no passkeys[] entry on any device.
    end note

    AllPasskeysRevoked --> TwoFARequired : user hits pre-qual or 2FA-gated action

    state "No Passkey Available" as NoPasskey <<choice>>
    TwoFARequired --> NoPasskey

    NoPasskey --> InlineEnrollment : device supports WebAuthn
    NoPasskey --> PasskeyEducation : device cannot do WebAuthn

    state "Inline Enrollment + Auth" as InlineEnrollment {
        [*] --> RegisterNewPasskey

        note right of RegisterNewPasskey
            Identical to flow (b) + (c):
            1. VPS → EDI: POST /passkeys/register
            2. Browser: navigator.credentials.create()
            3. VPS → EDI: POST /passkeys/register/complete
            4. VPS → EDI: POST /passkeys/authenticate/start
            5. Browser: navigator.credentials.get()
            6. VPS → EDI: POST /passkeys/authenticate/complete
        end note

        RegisterNewPasskey --> PasskeyEnrolledAndVerified : success
        RegisterNewPasskey --> EnrollmentFailed : device rejected
    }

    InlineEnrollment --> ElevatedSession : PasskeyEnrolledAndVerified
    EnrollmentFailed --> PasskeyEducation

    note right of ElevatedSession
        VPS persists auth-metadata (during /api/v1/auth/passkey login)
        [ passkeyVerified: true ], refreshes deviceSessionExpiresAt
    end note

    ElevatedSession --> [*] : proceed to pre-qual

    note right of PasskeyEducation
        "This device does not support passkeys. Try another device or a newer browser."
    end note

    PasskeyEducation --> [*]
```

---

## (h) Session Timeout → Re-Authentication

User returns after ecom session (Redis 30-min TTL) has expired. Auth profile may or may not still be valid.

```mermaid
stateDiagram-v2
    [*] --> UserReturns

    note right of UserReturns
        User was idle > 30 minutes.
        Redis session keys have expired.
        Browser makes a new page load.
    end note

    UserReturns --> Resolve

    state "POST /resolve" as Resolve {
        [*] --> CheckDeviceFingerprint

        note right of CheckDeviceFingerprint
            VPS: device_fingerprint_hash found in Postgres
            (device table persists beyond session).
            Redis session gone → session rotation.
        end note

        CheckDeviceFingerprint --> SessionRotation : device recognized, session expired

        state "Session Rotation" as SessionRotation {
            [*] --> CreateNewSession

            note right of CreateNewSession
                VPS → Session Mgmt Service: create_session
                New session_id generated.
                Same visitor_id, same device_id.
                auth-metadata loaded from Postgres (durable).
            end note

            CreateNewSession --> [*]
        }

        SessionRotation --> ReturnResolveResponse
    }

    Resolve --> CheckAuthMetadata

    state "Auth Profile Check" as CheckAuthMetadata <<choice>>

    CheckAuthMetadata --> SeamlessResume : deviceSessionExpiresAt in the future — auth still valid
    CheckAuthMetadata --> AuthExpired : deviceSessionExpiresAt in the past — auth expired

    note right of SeamlessResume
        User sees no interruption.
        Profile page, watchlist, etc. all accessible.
        New session_id, same visitor, same auth state.
    end note

    SeamlessResume --> FullyAuthenticated

    note right of AuthExpired
        deviceSessionTier dropped to T0 (OTP session expired).
        User must re-authenticate via OTP (flow a).
    end note

    AuthExpired --> OTPRequired : next action requires auth

    OTPRequired --> [*] : enters OTP flow — a
    FullyAuthenticated --> [*] : continues seamlessly
```

---

## (i) EDI Session Expired (edi-session-id cookie)

The EDI auth session has expired independently of the ecom auth metadata. User may still be considered authenticated for ecom-only actions. Ecom does NOT call EDI unless auth is absolutely required for the action.

```mermaid
stateDiagram-v2
    [*] --> EdiSessionExpired

    note right of EdiSessionExpired
        edi-session-id cookie has expired or been cleared.
        deviceSessionTier still >= T1 (deviceSessionExpiresAt valid in Postgres).
        User is still "authenticated" for ecom purposes.
        Ecom does NOT proactively re-auth with EDI.
    end note

    EdiSessionExpired --> WhatDoesUserNeed

    state "Action Classification" as WhatDoesUserNeed <<choice>>

    WhatDoesUserNeed --> EcomOnlyAction : profile page, watchlist, preferences
    WhatDoesUserNeed --> EnterpriseGatewayAction : pre-qual, originations, enterprise-gated flows

    EcomOnlyAction --> NoReAuthNeeded

    note right of NoReAuthNeeded
        deviceSessionTier still >= T1 (deviceSessionExpiresAt valid).
        Ecom actions proceed normally.
        VPS does NOT call EDI for ecom-only actions.
        No re-auth triggered.
    end note

    NoReAuthNeeded --> [*] : continues without interruption

    EnterpriseGatewayAction --> CheckPasskey

    state "Check Passkey" as CheckPasskey <<choice>>

    CheckPasskey --> PasskeyReAuth : passkey available on device
    CheckPasskey --> OTPReAuth : no passkey available

    state "Passkey Re-Auth" as PasskeyReAuth {
        [*] --> PasskeyChallenge

        note right of PasskeyChallenge
            VPS → EDI: POST /passkeys/authenticate/start
            Browser: navigator.credentials.get()
            VPS → EDI: POST /passkeys/authenticate/complete
            Enterprise gateway provides fresh edi-session-id.
            Also satisfies 2FA if action requires it.
        end note

        PasskeyChallenge --> PasskeyVerified : biometric approved
        PasskeyChallenge --> PasskeyFailed : cancelled / failed
        PasskeyFailed --> PasskeyChallenge : retry
        PasskeyFailed --> OTPReAuth : give up on passkey
    }

    PasskeyVerified --> EdiSessionRestored

    state "OTP Re-Auth" as OTPReAuth {
        [*] --> SelectChannel

        state SelectChannel <<choice>>
        SelectChannel --> EnterPhone : picks phone
        SelectChannel --> EnterEmail : picks email

        EnterPhone --> OTPSent : submit
        EnterEmail --> OTPSent : submit

        OTPSent --> EnterCode
        EnterCode --> OTPVerified : correct
        EnterCode --> Failed : wrong
        Failed --> EnterCode : retry
    }

    note right of OTPVerified
        UI → BFF → VPS: PUT /api/v1/auth/otp (verify)
        VPS orchestrates EDI verify; new edi-session-id cookie set.
        VPS refreshes deviceSessionExpiresAt (single backend token)
    end note

    OTPVerified --> EdiSessionRestored

    EdiSessionRestored --> [*] : enterprise action can proceed
```

---

## (j) Passkey Management

Listing, adding, and revoking passkeys from the profile/settings page. Requires 1FA (OTP verified). Uses the WebAuthn Signal API to sync server-side passkey state with the client authenticator.

```mermaid
stateDiagram-v2
    [*] --> OTPVerified_Profile

    note right of OTPVerified_Profile
        User is on profile/settings page.
        Requires 1FA (OTP verified, deviceSessionExpiresAt valid).
        Does NOT require 2FA to manage passkeys.
    end note

    OTPVerified_Profile --> PasskeyManagement

    state "Passkey Management" as PasskeyManagement {
        [*] --> SyncPasskeyState

        state "Sync Passkey State" as SyncPasskeyState {
            [*] --> FetchServerPasskeys

            note right of FetchServerPasskeys
                VPS → EDI: GET /passkeys
                Returns: list of registered credentials
                with metadata (id, type, createdAt).
            end note

            FetchServerPasskeys --> SignalBrowser

            note right of SignalBrowser
                UI calls WebAuthn Signal API to sync
                client-side authenticator with server state:

                PublicKeyCredential.signalAllAcceptedCredentials([
                  rpId: configured relying-party ID,
                  userId: base64url(identityProfileId),
                  allAcceptedCredentialIds: [credIds from GET /passkeys]
                ]);

                This removes any locally-stored passkeys
                that have been revoked server-side (zombie passkeys).
                Chrome 132+, Safari 26+.
            end note

            SignalBrowser --> [*] : sync complete
        }

        SyncPasskeyState --> ManageOptions

        ManageOptions --> ListPasskeys : view registered passkeys
        ManageOptions --> AddPasskey : register passkey on this device
        ManageOptions --> RevokePasskey : remove a specific passkey
        ManageOptions --> RevokeAll : remove all passkeys

        state "List Passkeys" as ListPasskeys {
            [*] --> DisplayList

            note right of DisplayList
                Display each passkey with:
                - Device name / authenticator type
                - Created date (from registration)
                - "This device" indicator (match device_fingerprint_hash
                  with EDI deviceHashes[])
                - "Remove" button
            end note

            DisplayList --> [*]
        }

        state "Add Passkey" as AddPasskey {
            [*] --> StartEnrollment

            note right of StartEnrollment
                Same as flow (b): Passkey Enrollment.
                VPS → EDI: POST /passkeys/register
                Browser: navigator.credentials.create()
                VPS → EDI: POST /passkeys/register/complete
            end note

            StartEnrollment --> EnrollSuccess : credential saved
            StartEnrollment --> EnrollFailed : device rejected

            EnrollSuccess --> [*]
            EnrollFailed --> [*] : show error, return to options
        }

        state "Revoke Passkey" as RevokePasskey {
            [*] --> ConfirmRevoke

            ConfirmRevoke --> RevokeConfirmed : user confirms
            ConfirmRevoke --> RevokeCancelled : user cancels

            note right of RevokeConfirmed
                UI → BFF → VPS: DELETE /api/v1/auth/passkey
                [ authenticationMethodId ]  (VPS → EDI: DELETE /passkeys/[id])
                Then signal client-side removal:
                PublicKeyCredential.signalUnknownCredential([
                  rpId: configured relying-party ID,
                  credentialId: revokedCredId
                ]);
                VPS updates auth-metadata: removes the passkeys[] entry;
                deviceSessionTier drops if this was the active credential.
            end note

            RevokeConfirmed --> [*]
            RevokeCancelled --> [*]
        }

        state "Revoke All Passkeys" as RevokeAll {
            [*] --> ConfirmRevokeAll

            ConfirmRevokeAll --> RevokeAllConfirmed : user confirms
            ConfirmRevokeAll --> RevokeAllCancelled : user cancels

            note right of RevokeAllConfirmed
                UI → BFF → VPS: DELETE /api/v1/auth/passkey (clear all)
                (VPS → EDI: DELETE /passkeys)
                Then signal client-side removal:
                PublicKeyCredential.signalAllAcceptedCredentials([
                  rpId: "...",
                  userId: "...",
                  allAcceptedCredentialIds: [] // empty = remove all
                ]);
                VPS updates auth-metadata: clears passkeys[];
                deviceSessionTier drops below T2.
            end note

            RevokeAllConfirmed --> [*]
            RevokeAllCancelled --> [*]
        }

        ListPasskeys --> ManageOptions
        AddPasskey --> ManageOptions
        RevokePasskey --> ManageOptions
        RevokeAll --> ManageOptions

        ManageOptions --> [*] : done / navigate away
    }

    PasskeyManagement --> [*]
```

---

## (k) Soft Step-Up (Activity-Triggered Prompt)

Proactive, dismissable prompts triggered by meaningful activity. User can accept (enter OTP flow) or dismiss.

```mermaid
stateDiagram-v2
    [*] --> Anonymous_Browsing

    state "Activity Monitoring" as ActivityMonitoring {
        [*] --> TrackingActivity

        note right of TrackingActivity
            UI tracks engagement signals:
            - totalVehicleViews (VDPs opened)
            - totalSearches
            - watchlist count
            - saved searches count
        end note

        TrackingActivity --> CheckThreshold : new activity event

        state CheckThreshold <<choice>>
        CheckThreshold --> TrackingActivity : threshold not met
        CheckThreshold --> ShowPrompt : threshold met
    }

    Anonymous_Browsing --> ActivityMonitoring

    state "Step-Up Prompt" as ShowPrompt {
        [*] --> DisplayPrompt

        note right of DisplayPrompt
            UI shows dismissable modal/toast/agent message.
            Examples:
            - "Save across devices?" (2nd watchlist add)
            - "Keep hunting and text you?" (save search)
            - "Send this to your phone?" (exit intent)
        end note

        DisplayPrompt --> UserAccepts : user engages with CTA
        DisplayPrompt --> UserDismisses : user dismisses
    }

    UserAccepts --> OTPFlow : enters OTP authentication — flow a

    UserDismisses --> TrackingActivity : resume monitoring

    note right of UserDismisses
        Prompts resume ONLY when NEW meaningful
        activity is detected. Old signals are not replayed.
        Hard-requirement flows (profile, pre-qual, booking)
        are non-dismissable.
    end note

    OTPFlow --> Authenticated_T1 : OTP verified — flow a
    Authenticated_T1 --> [*] : soft step-up complete
```

---

## (l) Add Contact Channel (Settings)

User is already authenticated and wants to add an additional phone number or email to their identity. This is not a recovery flow — it's about adding a new channel alongside the existing one.

```mermaid
stateDiagram-v2
    [*] --> Authenticated_Settings

    note right of Authenticated_Settings
        User is on profile/settings page.
        Already authenticated (1FA or 2FA session active).
        Identity proof is satisfied by current session.
        This is NOT a recovery or replacement flow.
    end note

    Authenticated_Settings --> SelectChannelToAdd

    state SelectChannelToAdd <<choice>>
    SelectChannelToAdd --> AddPhone : add phone number
    SelectChannelToAdd --> AddEmail : add email address

    %% ─── ADD PHONE ───

    state "Add Phone Number" as AddPhone {
        [*] --> EnterNewPhone

        EnterNewPhone --> NewPhoneOTPSent : submit new phone number

        note right of NewPhoneOTPSent
            VPS → EDI: POST /passwordless/start
            [ channel: SMS, recipient: newNumber ]
            Verifies the user owns the new number.
            This links the new phone to the existing
            identity — it does not replace the old one.
        end note

        NewPhoneOTPSent --> EnterPhoneCode

        EnterPhoneCode --> PhoneVerified : correct code
        EnterPhoneCode --> PhoneInvalid : wrong code
        PhoneInvalid --> EnterPhoneCode : retry
    }

    PhoneVerified --> PhoneAdded

    note right of PhoneAdded
        VPS → EDI: POST /passwordless/verify
        New phone linked to existing identityProfileId.
        VPS adds it to metadata.auth.contacts[]:
        Both channels now available for future OTP.
    end note

    %% ─── ADD EMAIL ───

    state "Add Email Address" as AddEmail {
        [*] --> EnterNewEmail

        EnterNewEmail --> NewEmailOTPSent : submit new email address

        note right of NewEmailOTPSent
            VPS → EDI: POST /passwordless/start
            [ channel: EMAIL, recipient: newEmail ]
            Verifies the user owns the new email.
            This links the new email to the existing
            identity — it does not replace the old one.
        end note

        NewEmailOTPSent --> EnterEmailCode

        EnterEmailCode --> EmailVerified : correct code
        EnterEmailCode --> EmailInvalid : wrong code
        EmailInvalid --> EnterEmailCode : retry
    }

    EmailVerified --> EmailAdded

    note right of EmailAdded
        VPS → EDI: POST /passwordless/verify
        New email linked to existing identityProfileId.
        VPS adds it to metadata.auth.contacts[].
        Both channels now available for future OTP.
    end note

    PhoneAdded --> [*] : return to settings
    EmailAdded --> [*] : return to settings
```

---

## (m) Logout (this device)

The user signs out on this device. EDI invalidates the auth token and clears the cookie, and its logout response carries the current ACR, which VPS maps to `deviceSessionTier` (now T0). The device's `metadata.auth` is retained, so the device stays known for a fast return sign-in.

```mermaid
stateDiagram-v2
    [*] --> Authenticated

    Authenticated --> LogoutRequested : user taps sign out

    LogoutRequested --> EdiInvalidate
    EdiInvalidate --> DeviceReset
    DeviceReset --> LoggedOut

    LoggedOut --> [*]

    note right of LogoutRequested
        UI to BFF to VPS to EDI POST auth logout (new EDI capability).
    end note

    note right of EdiInvalidate
        EDI invalidates the auth token for this edi-session-id
        and returns an expiring Set-Cookie that the gateway stamps.
    end note

    note right of DeviceReset
        EDI's logout response carries the current ACR. VPS maps it
        to deviceSessionTier (now T0). The device metadata.auth is retained.
    end note

    note right of LoggedOut
        Next resolve returns deviceSessionTier T0 with customerTier
        and metadata.auth still populated. The device is anonymous
        but known so re-auth is fast (a known contact, or a passkey
        the device offers).
    end note
```

---

## (n) Forget Me Completely (shared or public device)

The strong exit for a shared or public device. This is logout plus a local reset — VPS unlinks this device from the visitor and the client clears everything it controls (cookies, localStorage, cached data). This is not account deletion — the customer's account and their other devices are untouched.

```mermaid
stateDiagram-v2
    [*] --> Authenticated

    Authenticated --> ForgetRequested : user taps forget me on this device
    ForgetRequested --> Confirm : show confirmation

    Confirm --> DoForget : user confirms
    Confirm --> Authenticated : user cancels

    DoForget --> EdiInvalidate
    EdiInvalidate --> DeviceUnlink
    DeviceUnlink --> ClientClear
    ClientClear --> Forgotten

    Forgotten --> [*]

    note right of Confirm
        Plain confirmation. No re-auth. This only removes access
        on this device and cannot be used to attack the account.
    end note

    note right of EdiInvalidate
        Logout first (flow m) - EDI invalidates the auth token
        and the gateway clears the cookie.
    end note

    note right of DeviceUnlink
        VPS unlinks this device from the visitor
        (drops the device to visitor association server-side).
    end note

    note right of ClientClear
        Client clears everything it controls - cookies
        localStorage and cached resolve data.
    end note

    note right of Forgotten
        Next visit is a brand-new anonymous visitor with no surfaced
        hints. The customer account and other devices are unaffected.
    end note
```

---

## (o) Update Primary Identifier (change the phone or email used for OTP)

The customer replaces the primary phone or email their account signs in with — not adding a second channel (that is flow (l)) but changing the primary. Entry requires a passkey (T2) when one is enrolled, otherwise T1. Control of both channels is proven — an OTP on the old channel, then an OTP on the new one — before the swap. The new channel becomes primary and the old is demoted to a recovery contact rather than deleted.

```mermaid
stateDiagram-v2
    [*] --> StepUp

    StepUp --> VerifyOld : T2 if a passkey is enrolled otherwise T1
    VerifyOld --> OldOtpSent : send code to current primary
    OldOtpSent --> OldVerified : correct code
    OldOtpSent --> OldFailed : wrong code
    OldFailed --> OldOtpSent : retry

    OldVerified --> EnterNew : enter new phone or email
    EnterNew --> NewOtpSent : send code to new channel
    NewOtpSent --> NewVerified : correct code
    NewOtpSent --> NewFailed : wrong code
    NewFailed --> NewOtpSent : retry

    NewVerified --> Swap
    Swap --> InvalidateOthers
    InvalidateOthers --> Done

    Done --> [*]

    note right of StepUp
        Changing the sign-in identifier is high value so it uses the
        strongest factor available - passkey when enrolled else OTP.
    end note

    note right of OldVerified
        Proving control of the outgoing channel guards against takeover.
        If the old channel is lost this is recovery (flow d) not this flow.
    end note

    note right of Swap
        New channel becomes contactRole primary (OTP-preferred).
        Old channel is demoted to contactRole recovery not deleted.
        Interim - VPS swaps at the contacts layer and initiates OTP
        against the new primary. Target - EDI swaps the registered
        identifier on the Auth0 user (pending EDI capability).
    end note

    note right of InvalidateOthers
        Passkeys persist (bound to the identity not the number).
        Other active sessions for the identity are invalidated as a
        safety step (reuses the logout invalidation primitive).
    end note
```

---

## Summary: Flow Cross-References

| When you're in... | You may enter... |
|-------------------|-----------------|
| (a) OTP Auth — lockout | (d) for alternate channel recovery |
| (b) Passkey Enrollment | Called from (c), (f), (g), (j) |
| (c) Passkey Step-Up | Calls (b) for inline enrollment |
| (d) Channel Lost | Passkey-first, then alternate OTP, then support. Calls (a) mechanics for OTP sub-flow |
| (e) New Device | Calls (a) for OTP, then merge |
| (f) Passkey Failed | Calls (b) for re-enrollment, then (c) for auth |
| (g) All Passkeys Deleted | Calls (b) + (c) inline |
| (h) Session Timeout | May enter (a) if auth expired |
| (i) EDI Session Expired | Passkey-first, then OTP for re-auth |
| (j) Passkey Management | Calls (b) for add, Signal API for sync |
| (k) Soft Step-Up | Enters (a) on acceptance |
| (l) Add Contact Channel | OTP to new channel (identity already proven by session) |
| (m) Logout | Ends session on this device; next visit re-auths via (a) or (c) |
| (n) Forget Me Completely | Logout (m) plus device unlink and client clear |
| (o) Update Primary Identifier | Uses (l) mechanics to add-and-verify the new channel, then swaps primary and invalidates other sessions via (m) primitive |

---

## Future / Not-Yet-Supported Flows

These flows are anticipated but not buildable today because EDI does not yet expose the needed capability. They are captured here so the design accounts for them; the specific unknowns are tracked in Open Questions. No endpoints are specced until EDI supports them.

### Delete / deactivate account

A signed-in customer asks to delete or deactivate their account — removing their identity, contacts, and enrolled passkeys, and ending all sessions. Today EDI only supports deleting individual passkeys (`DELETE /passkeys/{id}`) and clearing all passkeys (`DELETE /passkeys`); it has no endpoint to delete or deactivate the identity profile itself. A full flow will need EDI to expose account deletion (hard delete vs. reversible deactivation), define what happens to linked contacts and the Auth0 user, and specify session teardown. The UI would gate this behind a strong re-verification (T2 where available) and a clear confirmation, given it is irreversible. See Open Questions.

### Passkey enrollment options that drive browser behavior

When EDI starts a passkey ceremony it relays WebAuthn options from Auth0, and some of those options directly shape the browser prompt and the resulting credential. The relevant ones are the WebAuthn `authenticatorSelection` settings: `authenticatorAttachment` (steer toward a platform authenticator like Face ID/Touch ID/Windows Hello, or a cross-platform/roaming one), `residentKey` / `requireResidentKey` (whether a discoverable, syncable passkey is created), and `userVerification` (`required` / `preferred` / `discouraged`), alongside the relying-party ID that scopes the credential. Auth0 can return these on register; the open question is which values EDI should send for our use case (we want platform, discoverable, user-verified passkeys) and whether EDI lets us influence them or fixes them server-side. The UI simply passes whatever options EDI relays into `navigator.credentials.create()`, so the behavior is driven by what EDI chooses. See Open Questions.

> Changing the primary phone or email is now a defined flow — see (o) Update Primary Identifier above. Its target (EDI swapping the registered identifier on the Auth0 user) is still a pending EDI capability, tracked in Open Questions; the interim swaps at the VPS contacts layer.

---

> Companion docs carry the supporting detail: the EDI session-timeout model,
> session/token lifecycle, OTP constraints, E2E testing strategy, and
> auth-metadata storage live in [`auth-integration.md`](./auth-integration.md);
> the step-up trigger model, tiers, auth-metadata summary, and future
> optimizations (auto-trigger OTP, passkey-as-1FA) live in
> [`auth-overview.md`](./auth-overview.md). EDI, Auth0, gateway, and
> VPS-infrastructure asks live in [`auth-edi-open-questions.md`](./auth-edi-open-questions.md).

---

## Open Questions

These are ecom-internal design questions. Asks that depend on EDI, Auth0, the gateway, or VPS infrastructure live in [`auth-edi-open-questions.md`](./auth-edi-open-questions.md).

| # | Question | Context | Status |
|---|----------|---------|--------|
| 1 | **Multi-visitor-per-device VPS implementation** | When two users fork on 409, how does `/resolve` handle multiple visitors for one fingerprint? How does "last-authenticated wins" work in Postgres? Unique constraint change needed. | Deferred — needs design spec |
| 2 | **Passkey-only recovery and fraud risk** | Stolen device with enrolled passkey could bind attacker's phone. Cooling period? Notifications to other devices? | Pending infosec feedback |
| 3 | **Device trust scoring for passkey recovery** | Should passkey-based recovery be limited to recently-active devices? | Pending infosec feedback |
| 4 | **Email verification skip during pre-qual** | If user skips email verification after pre-qual, should we re-prompt on next visit? How often? | Needs product input |
| 5 | **Activity-signal tracking for soft step-ups** | How to track watchlist count and saved-searches count to drive activity-triggered prompts (thresholds). | Needs design |
| 6 | **OTP attempt tracking** | Auth0 enforces send/attempt limits but EDI does not surface counters. How should ecom track attempts for UX (e.g., resend cooldown)? | Needs approach |
| 7 | **OTP lockout cooldown duration** | Currently modeled as ~15 minutes (EDI-TES-204 enforced). Is this correct? Should it scale with repeated lockouts (progressive backoff)? Affects flows (a), (d). | Needs product input |

**Decided:** EDI session TTL — ecom does not attempt to anticipate the cookie's `max-age`; a reactive 401 on enterprise-gated calls is sufficient (see "EDI Session Timeout" above).
