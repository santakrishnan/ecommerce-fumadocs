# Authentication Flows — User Experience

Overall view of authentication flows, with user choices, branching paths, and outcomes. For the technical flow diagrams (state charts, endpoints, service calls), see [`auth-flows.md`](./auth-flows.md); the flow letters (a–o) referenced here map to that document (see the cross-reference table at the end).

---

## Journey Summary

| Journey | What the user is trying to do |
|---------|------------------------------|
| **Sign-In** | |
| [Signing In](#signing-in) | Verify their identity for the first time or after expiry |
| **Passkeys** | |
| [Setting Up a Passkey](#setting-up-a-passkey) | Enroll biometric authentication for elevated flows |
| [Accessing Elevated Flows](#accessing-elevated-flows) | Step up to 2FA to enter sensitive flows (pre-qual, financial offers) |
| [Using a Passkey From Another Device](#using-a-passkey-from-another-device) | Sign in on this device using a passkey held on their phone or another device |
| [Passkey Already Synced to This Device](#passkey-already-synced-to-this-device) | A synced passkey is already available on a new device |
| [Passkey Not Working](#passkey-not-working) | Passkey fails — deleted, corrupted, or device can't support it |
| [All Passkeys Removed](#all-passkeys-removed) | User removed all passkeys and now needs elevated access |
| [Managing Passkeys](#managing-passkeys) | View, add, or remove passkeys from settings |
| **Account & Session** | |
| [Signing Out](#signing-out) | End the session on this device |
| [Forget Me on This Device](#forget-me-on-this-device) | Fully reset a shared or public device |
| [Changing Your Sign-In Phone or Email](#changing-your-sign-in-phone-or-email) | Replace the primary phone or email used to sign in |
| **Recovery & Edge Cases** | |
| [Recovering Access](#recovering-access) | Regain access after losing phone, email, or device |
| [Returning After Inactivity](#returning-after-inactivity) | Come back after being away (session or auth expired) |
| [Shared Device](#shared-device) | Two people using the same device |

---

## Signing In

The user verifies their identity with a one-time code sent to their phone or email.

1. When an action prompts them to verify, the user chooses a channel — phone or email — and enters it.
2. A code is sent (SMS or email) and the user enters it.
3. A correct code signs them in and continues them to whatever they were doing.
4. A wrong code lets them try again (up to 3 attempts per code). Too many wrong attempts invalidates the code.
5. With an invalidated or expired code, they can request a fresh one, or switch to the other channel if they have one.
6. If they have no other channel and no passkey, the only path left is calling support to restore access.

Maps to flow **(a)**.

---

## Setting Up a Passkey

A signed-in user enrolls a passkey (Face ID, fingerprint, or device PIN) so future elevated flows are fast.

1. The user must already be signed in with a one-time code before a passkey can be set up.
2. The system prompts (or the user initiates) with a benefit-led message like "Set up a passkey for faster verification."
3. Approving the device's biometric prompt creates the passkey, ready for future use.
4. Cancelling lets them try again or skip for now — it never blocks the rest of the site.
5. If the device can't do passkeys, they see "This device doesn't support passkeys. Try another device or a newer browser."

Maps to flow **(b)**.

---

## Accessing Elevated Flows

The user wants to enter a sensitive flow (pre-qualification, financial offers) that requires a passkey (2FA).

1. If they aren't signed in yet, they complete one-time code sign-in first (see Signing In).
2. The UI then routes to one of four outcomes (the detection logic is in [`auth-flows.md`](./auth-flows.md) "Passkey detection model"):
   - **Usable on this device** (local or synced here) → show the biometric prompt.
   - **On another device, reachable here** → offer to verify with that device by QR (see Using a Passkey From Another Device).
   - **On another device, not reachable here** → prompt them to set one up on this device.
   - **No passkey yet** → prompt them to set up their first one ("Set up passkey to continue"), then verify with it.
3. Approving the biometric completes 2FA and the elevated flow begins.
4. Cancelling lets them try again.
5. If a passkey attempt fails, they can set up a new one and verify with it (see Passkey Not Working). If the device can't support passkeys at all, they see the "not supported" message and cannot proceed on this device.

Maps to flow **(c)**.

---

## Using a Passkey From Another Device

The user has no passkey on the device they're using now, but they do have one on another device (typically their phone). This is the path when the passkey is device-bound, or when a synced passkey's provider is not signed in on the current machine. Rather than enroll a fresh passkey here, they verify with the one on the other device. The browser shows a QR code the other device scans, and the passkey stays on the device that holds it.

1. When a passkey is needed here and none is available, the UI offers two options: "Use a passkey from another device" or "Set up a passkey on this device instead."
2. Choosing another device shows a QR code with "Scan with the phone that has your passkey."
3. The user scans it and approves the biometric prompt **on the other device**.
4. That approval confirms their identity on the current device and the elevated flow proceeds. No passkey is stored on the current device; the UI may offer to set one up here too for faster future sign-ins.
5. If the attempt is cancelled or times out, they can retry, or fall back to setting one up here.

Maps to flow **(c)** (cross-device / hybrid transport).

---

## Passkey Already Synced to This Device

A passkey comes in one of two forms, and the difference decides where the user can use it:

- **Synced passkey.** Stored in a cloud keychain (iCloud Keychain, Google Password Manager, Bitwarden, 1Password). The provider copies it to every device the user signs into with that provider, so a device they have never used before can already hold their passkey with no setup.
- **Device-bound passkey.** Held on one device only (for example, a hardware security key, or a platform passkey the operating system keeps local). It works on that device, and on any other machine the user reaches it by scanning a QR code from the device that holds it (see Using a Passkey From Another Device).

On a new device, when the user reaches an elevated flow the browser checks for an available passkey:

1. **A synced passkey is present** — the browser offers it directly. The user approves the biometric, with no setup step, and 2FA completes.
2. **None here** — they use a passkey from another device, sign in with a one-time code, or set one up on this device.

When a passkey is already available through sync, the UI offers it directly rather than prompting for setup.

Maps to flow **(c)** (synced credential). Telling a synced passkey from a device-bound one at runtime depends on an EDI signal — see [`auth-edi-open-questions.md`](./auth-edi-open-questions.md).

---

## Passkey Not Working

The user tries to use their passkey but it fails — deleted from the device, corrupted, or the device can no longer support it.

1. The UI classifies the failure:
   - **Credential missing or deleted** → offer to set up a new one: "Your passkey isn't available. Set up a new one?" On approval, the new passkey is created and immediately verified, continuing them into the elevated flow.
   - **Device/browser can't do passkeys** → show "This device doesn't support passkeys. Try another device or a newer browser." and stop; they cannot proceed on this device.
2. If re-enrollment itself is rejected by the device, it collapses to the "device can't support passkeys" outcome.

Maps to flow **(f)**.

---

## All Passkeys Removed

The user removed all their passkeys (from settings, or lost every device that had one) and then tries to enter an elevated flow.

1. This is treated the same as "no passkey on this device."
2. **If the device supports passkeys**, the user is prompted to set one up inline — without leaving the flow — and verify with it, then continues. Declining re-prompts them ("You'll need a passkey to continue").
3. **If the device doesn't support passkeys**, they see the "not supported" message and cannot proceed on this device.

Maps to flow **(g)**.

---

## Managing Passkeys

A signed-in user views and manages their passkeys from the profile/settings page. Requires a one-time code, not a passkey.

1. The user opens "Manage Passkeys" and sees each registered passkey with its device/browser name (e.g., "MacBook — Chrome"), when it was created, when it was last used, and a "This device" badge where applicable.
2. From the list they can:
   - **Add a passkey** on the current device — approving the biometric adds it and refreshes the list; if the device can't do passkeys, an error is shown.
   - **Remove a specific passkey** — with a confirmation prompt; the list refreshes after.
   - **Remove all passkeys** — with a confirmation prompt; the list refreshes after.

Maps to flow **(j)**.

---

## Signing Out

A signed-in user ends their session on the device they're using.

1. The user taps "Sign out." The session ends on this device — they drop back to browsing as anonymous.
2. Their account is untouched: watchlist, saved searches, preferences, and verified contacts all remain.
3. Because the device is still recognized, the next visit offers a fast return — a code sent to their known number without re-typing it, or a passkey the device offers.

Signing out only ends the current session; it doesn't delete anything. Maps to flow **(m)**.

---

## Forget Me on This Device

The strong reset for a shared or public device (a library computer, a kiosk, a borrowed phone).

1. The user chooses "Forget me on this device" and confirms.
2. This signs them out, removes this device from their account, and clears everything this browser stored — cookies, local data, and cached information — so the next person starts completely fresh with no trace of the previous user.
3. Their account stays intact and their other devices keep working; they can sign in again normally anywhere.

This resets the device, and leaves the account whole. Maps to flow **(n)**.

---

## Changing Your Sign-In Phone or Email

The user wants to change the primary phone or email they sign in with — for example, they got a new number. This is different from adding a second contact (that is just adding a channel) and different from recovery (which is for when the old channel is already lost).

1. Because this is a high-value change, the user verifies with their strongest available method first — their passkey if they have one, otherwise a one-time code.
2. They verify the current number with a one-time code (proving they still control it), then enter and verify the new number with its own code.
3. The new number becomes their primary sign-in channel, and the old one becomes a recovery option, so they keep a way back in.
4. Their passkeys keep working (they're tied to the account, not the number), and for safety they may be signed out on their other devices.

Maps to flow **(o)**.

---

## Recovering Access

The user lost access to their phone or email and needs back in.

1. The UI offers the fastest available way to prove identity, in order:
   - **Passkey on this device** (fastest) → approving the biometric proves identity.
   - **Another verified channel** → a code is sent to the alternate (email if the phone was lost, phone if the email was lost) and verified. (A passkey attempt that fails falls back to this.)
   - **Neither** → "Call us to restore your access," where support verifies identity manually.
2. Once identity is proven by any path, the user enters a new phone or email and verifies it with a code before it's saved.
3. When the new channel is verified, access is restored.

Maps to flow **(d)**.

---

## Returning After Inactivity

The user comes back after being away. What they see depends on whether their verification is still valid and what they want to do.

1. **Verification still valid** → they continue with no interruption; watchlist, searches, and preferences are all intact.
2. **Verification expired, but they only want to browse** (watchlist, searches, preferences) → no sign-in needed; those are always available.
3. **Verification expired and they want account info, an elevated flow, or an enterprise action** → they re-verify:
   - **Has a passkey** → offered the passkey first (fastest); a failed passkey falls back to a code.
   - **No passkey** → standard one-time code sign-in.

Maps to flows **(h)** and **(i)**.

---

## Shared Device

Two different people authenticate on the same device (e.g., household members sharing a tablet).

1. Person A is already signed in; their watchlist and preferences are active.
2. Person B enters their own phone/email and verifies — the system detects a different account.
3. The UI asks: "Are you shopping together, or do you need your own account?"
   - **Shopping together** → Person B gets their own shopper persona under the shared device, with browsing and preferences tracked separately from Person A. (Household persona model — deferred; see the open questions in [`auth-flows.md`](./auth-flows.md).)
   - **Need my own account** → Person B gets their own independent profile; the device remembers the last person who signed in, so when Person A signs in again their profile becomes active.

The UI never silently merges two people's activity or lets one person's verification take over the other's account. Maps to flow **(e)** ("Multi-identity conflict (409)").

---

## Cross-Reference to Technical Flows

The technical flows referenced above (a–o) are defined in [`auth-flows.md`](./auth-flows.md).

| UX Journey | Technical Flow(s) |
|------------|------------------|
| Signing In | (a) OTP Authentication |
| Setting Up a Passkey | (b) Passkey Enrollment |
| Accessing Elevated Flows | (c) Passkey Step-Up Authentication |
| Using a Passkey From Another Device | (c) Passkey Step-Up Authentication (cross-device / hybrid transport) |
| Passkey Already Synced to This Device | (c) Passkey Step-Up Authentication (synced credential) |
| Recovering Access | (d) Channel Lost / Changed |
| Returning After Inactivity | (h) Session Timeout, (i) EDI Session Expired |
| Shared Device | (e) New Device / Merge — "Multi-identity conflict (409)" in auth-flows.md |
| Passkey Not Working | (f) Passkey Failed / Corrupted |
| All Passkeys Removed | (g) All Passkeys Deleted |
| Managing Passkeys | (j) Passkey Management |
| Signing Out | (m) Logout |
| Forget Me on This Device | (n) Forget Me Completely |
| Changing Your Sign-In Phone or Email | (o) Update Primary Identifier |
