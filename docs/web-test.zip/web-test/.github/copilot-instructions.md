# Copilot Instructions — UCMP Monorepo

Reusable Next.js 16 + Turborepo monorepo scaffolding with shadcn/ui on Base UI, multi-brand theming via Tailwind v4, and React Compiler.

## Project context

- **Stack:** Next.js 16, React 19, TypeScript 5.9, Tailwind 4 (CSS-first), shadcn/ui (new-york) on `@base-ui/react`, Biome 2 (via Ultracite), Vitest 4, pnpm 11, Turborepo
- **Forms:** react-hook-form + Zod (`@hookform/resolvers`)
- **Icons:** lucide-react · **Theme switching:** next-themes · **Feature flags:** Vercel `flags` SDK · **Toasts:** Sonner
- **App Router only** (no `pages/`)
- **React Compiler is ON** — auto-memoization
- **OKLCH colors only** (no HSL/hex in tokens)
- **No `tailwind.config.ts`** — Tailwind v4 is CSS-first via `@theme`

## Do / Don't

### React & components
- **Do** write Server Components by default — only add `"use client"` for state, effects, or browser APIs. Push it to the smallest leaf.
- **Don't** use `useMemo`, `useCallback`, or `React.memo` — React Compiler handles memoization.
- **Don't** use `useEffect` for derived state — compute inline during render.
- **Do** use `<Context value={...}>` and `use(Context)` — **don't** use `<Context.Provider>` or `useContext()`.
- **Do** pass `ref` as a regular prop via `React.ComponentProps<...>` — **don't** use `forwardRef`.
- **Do** use Base UI's `render` prop (`<Button render={<Link />}>`) — **don't** use `asChild`.
- **Do** use composition and compound components — **don't** use boolean props to toggle behavior.
- **Do** keep `page.tsx` exports **synchronous** — pass Promises (`params`, fetches) down to async leaf components wrapped in `<Suspense>`. **Don't** make page functions `async` and `await` at the top (blocks the static shell from streaming).

### Imports & module boundaries
- **Do** use path aliases: `@features/*`, `@shared/*`, `@config/*`, `@layout/*`, `~/*`, `@/*` (UI), `utils`.
- **Don't** use `../../` to escape module boundaries.
- **Do** use `import type` for type-only imports.
- **Don't** import internals across features — only consume from `features/<name>/index.ts`.
- **Do** check `packages/ui` first — install with `pnpm ui:add <name>`.

### Styling & theming
- **Do** use semantic tokens from `@ucmp/ui-theme` (`bg-primary`, `text-muted`).
- **Don't** hardcode colors or magic values (`#3b82f6`, `rounded-[8px]`).
- **Don't** use `@apply`, inline `style={...}`, CSS modules, or styled-components.
- **Do** use `cn()` from `utils` for conditional classes; **don't** concatenate class strings with template literals.
- **Do** use CVA (`class-variance-authority`) for component variants.
- **Do** use `next-themes` (`useTheme()`) for light/dark switching.
- **Do** keep `data-slot` attributes on shadcn primitives — styling hooks.
- **Do** use Tailwind's spacing scale (`p-4`, `gap-6`, `text-sm`) — rem-based, scales with user font-size.
- **Don't** use arbitrary px values (`p-[14px]`, `text-[15px]`, `gap-[10px]`).
- **Do** use `px` only for borders, hairlines, focus rings, and breakpoints.
- **Do** use `em` for letter-spacing (`tracking-*`); **don't** use `em` for spacing or sizes.

### Forms & validation
- **Do** use `react-hook-form` with `zodResolver`.
- **Do** define a Zod schema once and reuse it on client (RHF) and server (Server Action).
- **Do** submit via Server Actions; **don't** `fetch()` POST from `onSubmit`.
- **Do** use `useFormStatus` from `react-dom` for submit-button pending state.
- **Do** return `{ success, error?, data? }` from Server Actions — never throw.

### Icons & UI helpers
- **Do** use `lucide-react` icons only.
- **Do** size icons with Tailwind `size-4`/`size-5` (rem-based) — **don't** use `width`/`height` props.
- **Do** wrap interactive icons in a `Button` or accessible element with `aria-label`.
- **Do** use `inline-flex` + token sizing for icons-beside-text alignment.

### Data, caching & state
- **Do** use `"use cache"` with `cacheLife("landing"|"profile"|"detail"|"search")`.
- **Don't** use `unstable_cache` (deprecated) or rely on implicit `fetch()` caching (deprecated in Next.js 16).
- **Don't** call `cookies()`, `headers()`, or read `searchParams` inside a `"use cache"` scope — pass them in as arguments.
- **Do** use Server Actions for mutations — **don't** `fetch()` POST from Client Components.
- **Do** use TanStack React Query for client-side server reads — **don't** add Redux, Zustand, Jotai, Recoil, or MobX.
- **Do** use the Vercel `flags` SDK for feature flags — **don't** read `process.env.NEXT_PUBLIC_FLAG_*` directly.
- **Do** import server env vars via `env` from `src/config/env.ts` — **don't** read `process.env.VAR` directly in server code.
- **Do** import client env vars via `clientEnv` from `src/config/client-env.ts` — **don't** read `process.env.NEXT_PUBLIC_VAR` directly.
- **Do** validate every API input with Zod.

### Routing, loading & error handling
- **Do** add `loading.tsx` for each route segment with async data.
- **Do** wrap async children in `<Suspense fallback={<Skeleton />}>` — **don't** use `fallback={null}` on route-level Suspense (kills scroll anchor under PPR).
- **Do** add `error.tsx` and `not-found.tsx` per segment; call `notFound()` from a Server Component for 404s.
- **Do** use route groups `(group)` for organisational nesting.
- **Do** use `redirect()` from `next/navigation` in Server Components — **don't** use `router.push()` in `useEffect`.

### Images & fonts
- **Do** use `next/image` with explicit `width`/`height` (or `fill` + sized parent) — **don't** use bare `<img>` tags.
- **Do** add `priority` to the LCP image only.
- **Do** load fonts via `next/font/google` or `next/font/local` with `display: "swap"`.
- **Do** expose fonts as CSS variables and wire via `@theme inline`.

### Code quality
- **Do** use `for...of` — **don't** use `.forEach()` (Biome enforces `noForEach`).
- **Do** use early returns for guard clauses — **don't** nest deeply.
- **Do** keep files under ~300 lines and function complexity under 10.
- **Do** co-locate tests as `*.test.tsx` under `__tests__/`, fixtures under `__fixtures__/`.
- **Don't** hardcode mock data inline in tests — reference fixtures.
- **Do** use Conventional Commits: `feat(web):`, `fix(ui):`, `refactor(ui-theme):`, `test(web):`, `chore(monorepo):`.
- **Do** run `pnpm lint && pnpm type-check && pnpm test` before committing.

### Security
- **Don't** use `dangerouslySetInnerHTML`.
- **Don't** store auth tokens in `localStorage` — use `httpOnly` cookies.
- **Don't** hardcode secrets or put sensitive values in `NEXT_PUBLIC_*` env vars (they're bundled into the client).
- **Do** import server vars via `env` from `src/config/env.ts` and client vars via `clientEnv` from `src/config/client-env.ts` — **don't** read `process.env.*` directly (`FEATURE_FLAG_*` is the only accepted exception).
- **Do** validate all Server Action and route handler inputs with Zod.
- **Do** add `import "server-only"` to modules that read server secrets.

## Next 16 / React 19 / Tailwind 4 specifics

- **PPR (Partial Prerendering)** — everything outside `<Suspense>` becomes the static shell; wrap per-request data in `<Suspense fallback={<Skeleton />}>` to mark it as a dynamic hole.
- **Streaming via promise-passing** — pass a promise from a Server Component to a Client Component and unwrap with `use(promise)`.
- **`proxy.ts`, not `middleware.ts`** — Next.js 16 renamed the file convention. Use `apps/web/proxy.ts` exporting `proxy(request)` (formerly `middleware(request)`) for auth, redirects, and rewrites only.
- **Metadata API** — export `const metadata` or `async function generateMetadata()` from a `page.tsx`/`layout.tsx`. Don't render `<title>` or `<meta>` tags manually.
- **Tailwind 4 container queries** — use `@container` and `@sm:`/`@md:` variants when a component's layout should respond to its own width, not the viewport.

## Key architecture

- **React Compiler ON** — Biome's `useExhaustiveDependencies` is off.
- **shadcn on Base UI** — `@ucmp/ui` uses `@base-ui/react`. Installed via shadcn CLI (`new-york` style).
- **Multi-brand theming** — `@ucmp/ui-theme/base` tokens + per-brand overrides. Apps import `@ucmp/ui-theme/themes/default`.
- **Screaming architecture** — each `features/<name>/` is self-contained with `components/`, `hooks/`, `services/`, `data/`, `lib/`, `__fixtures__/`, `__tests__/`, `index.ts`.
- **Provider hierarchy** — `ThemeProvider → QueryProvider → {children}` via `composeProviders()`.
- **Env vars** — server vars via `env` from `src/config/env.ts`; `NEXT_PUBLIC_*` vars via `clientEnv` from `src/config/client-env.ts`. Never read `process.env.*` directly (`FEATURE_FLAG_*` is the only accepted exception). `NEXT_PUBLIC_*` for non-sensitive only; server-only vars need `import "server-only"`.

## Naming & commits

- **Files & folders**: kebab-case (`landing.tsx`, `use-debounce.ts`, `features/vehicle-card/`)
- **Components**: PascalCase exports (`Landing`, `AlertDialog`)
- **Hooks**: `use-*.ts` files with `useFoo` exports
- **Utilities, services, Server Actions**: camelCase (`formatPrice`, `getVehicle`, `submitFormAction`)
- **Types**: PascalCase (`Vehicle`); **Zod schemas**: camelCase + `Schema` suffix (`vehicleSchema`)
- **Constants**: UPPER_SNAKE_CASE (`API_BASE_URL`)
- **Next.js reserved files**: lowercase (`page.tsx`, `layout.tsx`, `proxy.ts`, …)
- **Commits**: Conventional Commits — `feat(web):`, `fix(ui):`, `refactor(ui-theme):`, `test(web):`, `chore(monorepo):`. Scopes: `web`, `ui`, `ui-theme`, `shared`, `config`, `monorepo`.

Full file-kind table, 17 reserved Next.js file names, and route segment patterns live in `docs/NAMING.md`.

## Code style (auto-enforced)

- 2-space indent, 100-char lines, LF endings, double quotes, always semicolons — enforced by Biome via Ultracite (`pnpm fix` auto-corrects)
- `packages/ui` is excluded from Biome — don't fight its formatting

## Monorepo structure

```
apps/web/                     # Next.js 16 app
packages/ui/                  # @ucmp/ui — shadcn on Base UI
packages/ui-theme/            # @ucmp/ui-theme — Tailwind v4 tokens
packages/shared/              # @ucmp/shared — providers, hooks
packages/utils/               # Pure utilities (cn, slugify, formatters)
packages/config/typescript/   # Shared tsconfigs
packages/config/vitest/       # Shared vitest configs
```

## Reference

- `AGENTS.md` — full agent instructions (canonical source)
- `docs/WORKFLOW.md` — implementation order
- `docs/THEMING.md` — theme system + unit rules (rem/px/em)
- `docs/PERFORMANCE.md` — Core Web Vital targets and bundle budgets
- `docs/SECURITY.md` — security rules
- `.github/PULL_REQUEST_TEMPLATE.md` — PR template (Return Contract)
