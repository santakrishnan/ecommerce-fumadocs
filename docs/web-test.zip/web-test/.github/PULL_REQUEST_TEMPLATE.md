## Summary
<!-- 1–2 sentences on what this PR does and why. -->

## Story

<!-- Auto-filled from branch name when using <type>/[ISSUE-KEY]-[issue-description] -->
<!-- Allowed branch types: feature, bug, hotfix, fix, chore, refactor, docs, test -->
<!-- Primary ticket reference for this repo. The issue key must also appear in the PR title, e.g. `feat(web): PEDX01-123 add settings panel` -->
Jira story: <!-- auto-filled -->

## Details

<!-- Guidelines for capturing details -->
<!-- Include Why and How for each distinct feature implemented in the PR -->
<!-- Deep dive on any controversial or complex pieces -->
<!-- Don't overwhelm the reviewer with too much text, the code should be self-explanatory -->

## Testing

<!-- How did you manually verify this works? Describe the actual scenarios you ran through, not the commands you ran. -->
<!-- "Ran pnpm test" tells the reviewer nothing on its own — name the specific flows/inputs covered, automated or manual. -->
<!-- Setup steps: anything a reviewer needs to reproduce your testing (env vars, feature flags, seed data, accounts, etc). Skip this if there's nothing beyond a normal checkout. -->
<!-- Edge cases: what did you deliberately check at the boundaries (empty states, errors, race conditions, permissions, etc)? -->

## Visual QA

<!-- For UI changes only. Delete this section for non-UI work. -->
<!--
Let the reviewer see how your feature works in realtime, and see design vs implementation side by side easily.

If applicable:
1. Attach the Figma screenshot (if there's no Figma, use the existing UI)
2. Attach the screenshot of your implemented UI
3. Capture and attach a video

| Figma (or Before) | Implemented UI |
| --- | --- |
| [screenshot] | [screenshot] |

Video:
-->

## Checklist Pre-Review

- [ ] PR title uses Conventional Commits format and includes the Jira issue key (`feat(web): PEDX01-123 ...`, `fix(ui): PEDX01-456 ...`)
- [ ] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]` (example: `feature/PEDX01-123-fix-card-spacing`)
- [ ] `pnpm type-check` passes - validated local due to CI blockers
- [ ] `pnpm lint` passes - validated local due to CI blockers
- [ ] `pnpm test` passes - validated local due to CI blockers
- [x] ~~`pnpm build` passes~~ — currently disabled due to CI blockers
- [ ] [Code Review Checklist](https://github.com/TMCC-Project-Arrow/ecommerce-web/blob/develop/docs/CONTRIBUTING.md#code-review-checklist) validated
- [ ] [Pull Request Guidelines](https://github.com/TMCC-Project-Arrow/ecommerce-web/blob/develop/docs/CONTRIBUTING.md#github-pull-request-best-practices) met
