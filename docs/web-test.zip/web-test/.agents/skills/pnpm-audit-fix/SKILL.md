---
name: pnpm-audit-fix
description: >
  Workflow for triaging and resolving `pnpm audit` vulnerabilities one at a
  time in a pnpm workspace. Covers severity/scope prompts, root-dependency
  identification via `pnpm why`, an unused/misplaced-dependency check, the
  patch -> minor -> major update ladder with changelog review (including
  walking down intermediate dependencies when the top-level root has no
  slack), scoped `overrides` in pnpm-workspace.yaml as a fallback,
  removal/replacement consideration, native `pnpm patch` /
  `pnpm patch-commit`, and a justified `auditConfig.ignoreGhsas` /
  `audit.ignore` exception as the final option when the vulnerable code
  path is confirmed unreachable. Every exception is documented inline as a
  terse (2-4 line), self-contained YAML comment directly above its entry
  in pnpm-workspace.yaml (no separate log file), with staleness auditing
  on every pass. Use when the user asks to fix, triage, or review npm/pnpm
  security audit findings.
---

# pnpm Audit Fix

A disciplined, one-vulnerability-at-a-time workflow for resolving
`pnpm audit` findings. Priority order is always: **confirm the root
dependency is actually needed**, then **update the root dependency** before
reaching for overrides, and **override** before removing/replacing a
package or patching it directly.

This skill does not auto-fix anything silently. Every risky step (minor
bump with breaking changes, major bump, override, removal, patch) requires
explicit user confirmation with reasoning presented first.

## Tooling: pnpm only

Every command in this workflow — installing, updating, inspecting registry
metadata, patching — goes through `pnpm`. Never shell out to `npm` or `npx`
during this process (e.g. `npm view`, `npm info`, `npx <pkg>`), even for
read-only lookups. Use the pnpm equivalents instead:

| Instead of | Use |
| --- | --- |
| `npm view <pkg> versions` | `pnpm view <pkg> versions --json` |
| `npm view <pkg> dist-tags` | `pnpm view <pkg> dist-tags --json` |
| `npm view <pkg>@<v> dependencies` | `pnpm view <pkg>@<v> dependencies --json` |
| `npx <pkg>` | `pnpm dlx <pkg>` |
| `npm ls` / `npm why` | `pnpm why <pkg>` |

The only exception is a tool whose own official docs explicitly require
`npm`/`npx` for a specific operation pnpm has no equivalent for — call that
out explicitly if it comes up, don't silently fall back to it.

## Exception Documentation: Inline in pnpm-workspace.yaml

Every `overrides` entry added (Step 8) and every `auditConfig.ignoreGhsas`/
`audit.ignore` entry added (see "If Nothing Above Resolves It") gets its
justification written as a comment block directly above it in
`pnpm-workspace.yaml` — there is no separate log file. The override/ignore
line and its explanation live in the same place, so they can never drift
apart (an earlier version of this skill used a sibling `DEPENDENCIES.md`
file with matching rows; that was retired because every entry ended up
duplicated in two places with no way to guarantee they stayed in sync —
inline comments make divergence structurally impossible, since deleting
the entry deletes its justification in the same edit).

Each comment block must be self-contained enough that someone reading only
`pnpm-workspace.yaml` — never having seen the investigation — understands
why the exception exists. **Terseness is mandatory**: 2-4 lines total
(~80 chars each), not a paragraph. Compress the investigation down to its
conclusion — don't narrate the steps taken to reach it. For an
**override**, cover in that space:

- The GHSA/CVE id(s), the vulnerable package, and the root that pins it.
- Why the root can't be updated (no newer release moves the pin — assert
  this, don't walk through the version-by-version check).
- An `Added: YYYY-MM-DD` line.

Only spend a line on scoping rationale or changelog/breaking-change
findings if they're non-obvious or there's something a future reader
needs to watch for. "No breaking changes" is not worth a line — omit it
if the answer is the boring default. If a fact doesn't change what the
next reader does, cut it.

For an **audit ignore**, additionally include the reachability conclusion
(see "Justifying an Audit Ignore" below) in one line: what API surface the
advisory needs and why this dependency tree never calls it. State the
conclusion, not the trace that produced it.

Example shape (see `pnpm-workspace.yaml` in this repo for real entries):

```yaml
overrides:
  # GHSA-xxxx-xxxx-xxxx: <one-line vuln description>. <pkg> pinned at
  # <version> by <root>, no newer <root> release moves it. <target>
  # tracks future patches in this line.
  # Added: YYYY-MM-DD
  '<pkg>@<version>': '<target>'
```

Because the skill re-reads `pnpm-workspace.yaml` at the start of every
pass (see Step 11's staleness check), keeping comments here — rather than
in a file the skill has no other reason to open — is what makes the audit
trail self-auditing rather than something that has to be remembered. A
terse entry is also cheaper to re-read on every pass, which is the point.

## When to Use This Skill

- User asks to run or fix a `pnpm audit`
- User asks to triage/review dependency vulnerabilities
- User references a specific GHSA/advisory and wants it resolved
- User asks "why is package X vulnerable" in a pnpm workspace

## Step 0: Scope the Run

Before running anything, prompt the user for two settings (don't assume):

1. **Severity threshold** — `low`, `moderate`, `high`, or `critical`.
   Default: **high** (i.e. only act on `high` and `critical` findings).
2. **Audit scope** — full dependency tree, or production-only (`--prod`).
   Default: **full** (includes devDependencies).

Map these to the command:

```bash
pnpm audit --audit-level=<threshold>          # full (default)
pnpm audit --audit-level=<threshold> --prod   # production-only
```

Confirm the resolved command with the user before running it if either
answer deviates from the defaults, otherwise just state the defaults being
used and proceed.

## Step 1: Run the Audit

```bash
pnpm audit --audit-level=<threshold>
```

Note: `pnpm audit --fix` exists natively (and `--fix=update` / `--interactive`)
and will add overrides or bump the lockfile automatically. **Do not use it as
the primary mechanism for this skill** — it skips the changelog review and
confirmation gates this workflow requires. It's fine to mention as a
possibility, but the manual ladder below (steps 2-10) is the default path.

## Step 2: Select One Vulnerable Package

Do not batch. Pick exactly one advisory to work per pass:

- If the user pointed at a specific package/GHSA, use that.
- Otherwise pick the highest-severity finding (critical > high > moderate > low,
  respecting the threshold from Step 0). If tied, pick the one with the most
  affected paths (likely the highest-impact fix).

State which package + advisory you're working before proceeding.

## Step 3: Identify the Root Dependency

The vulnerable package is very often a transitive dependency. Find the
direct (root) dependency that pulls it in:

```bash
pnpm why <vulnerable-package>
```

This prints the dependency chain(s). The "root" is the topmost package
listed in `dependencies`/`devDependencies` of a workspace `package.json`
that (transitively) requires the vulnerable package. If multiple unrelated
roots pull in the same vulnerable package, note all of them — a single
update may not clear every path.

**Important:** because one root often has several vulnerable children, a
single root update can resolve multiple audit findings at once. Keep this
in mind when picking which advisory to start with, and always re-run the
audit after any change (see Step 11) rather than assuming only the
targeted advisory was affected.

**Also note:** "the root" as defined here is the top of the dependency
chain, but the fix in Steps 5-7 sometimes needs to target a package
*partway down* that chain instead — see "If Updating the Root Doesn't Move
the Vulnerable Package" under Step 5.

## Step 4: Validate the Root Is Actually Needed

Before attempting any update, override, or patch, check whether the root
dependency identified in Step 3 should even be a project dependency. Don't
default to "it's declared, so it's needed" — dependency drift and
misplaced installs are common, and removing an unnecessary dependency is a
cleaner fix than chasing it through the update ladder.

Check, in order:

1. **Is it actually used in the codebase?** Grep for imports, requires,
   CLI invocations in `package.json` scripts, CI workflows, and Husky
   hooks. A `devDependency` with zero references outside its own
   manifest entry is a strong removal candidate.
2. **Is it a CLI tool that shouldn't be a project dependency at all?**
   Some tools (e.g. `vercel`, framework CLIs) are designed to be installed
   globally or run ad-hoc, and only need to be a project dependency if the
   project pins an exact version for reproducible CI runs. Check the
   tool's own docs/README for its recommended install method
   (`pnpm add -g <pkg>` vs. project dependency vs. `pnpm dlx <pkg>`).
3. **Is there a reason it must stay a pinned project dependency anyway?**
   e.g. CI needs a reproducible version, multiple contributors need the
   same version without relying on global installs, or a script in
   `package.json` invokes it directly and depends on workspace resolution.

If the package looks unused or better suited to a global/one-off install,
**stop here and prompt the user** before touching the update ladder.
Present the evidence (what you checked, what you found or didn't find) and
ask whether to remove it from the workspace instead. Do not remove it
unilaterally — this is a scope-affecting change requiring confirmation,
same as Step 9.

If the user confirms removal:

```bash
pnpm remove <root-package> --filter <workspace-package-if-applicable>
```

Re-run the audit (Step 11). If resolved, commit (Step 12) as
`chore(deps): remove unused <pkg>`, noting the advisory it incidentally
clears in the commit body — this is a cleanup, not a vulnerability patch,
so the commit type reflects that.

If the user confirms it should stay (a legitimate reason surfaced in check
3, or removal changes behavior they want to keep), proceed to Step 5.

## Step 5: Try a Patch Update of the Root

Patch-level bumps (`x.y.Z`) are same-behavior by semver contract — no
changelog review required, no confirmation gate needed.

```bash
pnpm update <root-package> --filter <workspace-package-if-applicable>
```

This respects the existing semver range in `package.json`, so it will only
move within the already-declared range. If the currently declared range
doesn't include a patched patch version, bump the declared range explicitly
(e.g. `pnpm add <root-package>@^x.y.z`) — this still counts as "patch" as
long as the major.minor stays the same.

### If Updating the Root Doesn't Move the Vulnerable Package

`pnpm update <root-package>` can succeed (exit 0, no errors) while the
vulnerable package's *resolved version* doesn't change at all. This
happens when the root already has no slack in its own declared range for
the intermediate package that carries the vulnerability — the root itself
isn't what needs to move.

After every update attempt in Steps 5-7, confirm the vulnerable package's
resolution actually changed:

```bash
pnpm why <vulnerable-package>
```

If it's still resolving to the same vulnerable version, don't stop at the
literal root and jump to overrides (Step 8) — walk one level down the
dependency chain first:

1. Look at the chain `pnpm why <vulnerable-package>` printed in Step 3.
   Identify the package sitting immediately *above* the vulnerable
   package (its direct parent), not the top-level root.
2. Check that intermediate package's own declared dependency range on the
   vulnerable package: `pnpm view <intermediate-pkg>@<resolved-version>
   dependencies.<vulnerable-package> --json`.
3. Check whether a newer version of the intermediate package (still
   within the *root's* declared range for it) declares a higher range for
   the vulnerable package: `pnpm view <intermediate-pkg> versions --json`,
   then check `dependencies.<vulnerable-package>` on the next few
   versions up.
4. If a newer intermediate version has more slack, update the
   intermediate package directly — `pnpm update <intermediate-pkg>
   --filter <workspace-package-if-applicable>` (or `--recursive` if it's
   not a direct dependency of any workspace package). Apply the same
   patch/minor/major confirmation rules from Steps 5-7 to *this* update
   based on the intermediate package's own version jump, not the root's.
5. Repeat this walk-down if the intermediate package also turns out to
   have no slack — keep descending the chain until either the vulnerable
   package's resolution moves, or you reach a package with an exact pin
   and no newer release changes it (that's the signal to move to Step 8).

This is the same investigation used for `tar` (via `@vercel/fun`, which
turned out to be an exact pin — no slack anywhere, straight to override)
and for `brace-expansion` (via `minimatch`, which *did* have slack one
level down — updating `minimatch` directly resolved it without ever
touching an override). Don't assume the top-level root is the only lever;
confirm with `pnpm why` after every attempt.

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 6: Try a Minor Update of the Root

If the patch update didn't clear the advisory, attempt minor bumps within
the same major version, walking toward latest-minor-in-major if needed:

```bash
pnpm update <root-package> --filter <workspace-package-if-applicable>
# or, to move the declared range forward within the same major:
pnpm add <root-package>@^x.<next-minor>.0
```

Before applying:

1. Check available versions with `pnpm view <root-package> versions --json`
   and fetch the changelog/release notes for every minor version between
   current and target (GitHub releases, CHANGELOG.md, or the package's npm
   registry page).
2. Identify any breaking changes called out (minors can have deprecations
   or documented behavior changes even under semver).
3. If breaking changes exist, grep the codebase for usage of the affected
   API/behavior to assess real impact.
4. **If no breaking changes affect this codebase**, proceed without asking.
5. **If small-scope changes are required to accommodate the update**,
   present the diff/plan and reasoning, then ask for confirmation before
   applying.
6. **If the required changes are large in scope**, stop and report back —
   don't attempt a large refactor inline as part of an audit fix pass.

Attempt to reach the latest minor within the current major band if the
first minor bump doesn't resolve the advisory (loop within this step,
re-checking changelogs incrementally).

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 7: Try a Major Update of the Root

Only if Step 6 didn't resolve it. Same changelog discipline as Step 6, but
**always require confirmation** before applying, since major bumps carry
breaking changes by definition:

1. Use `pnpm view <root-package> dist-tags --json` and
   `pnpm view <root-package> versions --json` to confirm the target major
   version, then fetch its migration guide / changelog.
2. List concrete breaking changes and cross-reference against actual usage
   in the codebase (grep for imports, APIs, config keys mentioned).
3. Present findings to the user: what breaks, what needs to change, how
   risky the change is, and the exact version target.
4. Wait for explicit confirmation before running the update.

```bash
pnpm add <root-package>@<target-major>
```

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 8: Scoped Override (If the Root Can't Be Updated)

Use this when the root dependency itself can't move (e.g. it pins the
vulnerable package internally, or updating the root isn't possible for
other reasons uncovered in Steps 5-7).

Rules, in order of acceptability:

- **Patch-level override**: always acceptable, no changelog review needed.
- **Minor-level override**: requires the same changelog review as Step 6.
- **Major-level override**: **not acceptable**. Do not propose one. If only
  a major-version override would fix it, stop and escalate (see "If Nothing
  Works" below) instead of applying it.

**Overrides must always be scoped as tightly as possible** — never override
a bare package name to a fixed version without a range restricting which
existing version(s) it applies to. This repo's convention is to place
overrides under `pnpm.overrides` in the root `package.json` (check
`package.json` and `pnpm-workspace.yaml` first — as of pnpm v11 the
canonical location is `overrides` in `pnpm-workspace.yaml`, but follow
whichever this repo is already using for consistency).

Correct scoping example — fixing `pkg` from `5.0.1` to `5.2.2` must only
affect the `5.x` line, not all versions ever resolved in the graph:

```yaml
# pnpm-workspace.yaml
overrides:
  "pkg@>=5.0.0 <5.3.0": "5.2.2"
```

or, if the existing repo convention is `package.json`:

```json
{
  "pnpm": {
    "overrides": {
      "pkg@>=5.0.0 <5.3.0": "5.2.2"
    }
  }
}
```

Never write a blanket override like `"pkg": "5.2.2"` — that silently forces
every consumer of `pkg`, at any version, to `5.2.2`, including ranges that
were never audited for compatibility.

Prefer expressing the target as the latest available version within the
same major.minor band the graph already resolves to (e.g. `^5.2.2` rather
than a pin to exactly `5.2.2`), so the override also picks up future
patches in that band automatically instead of going stale. Use
`pnpm view <pkg> versions --json` to confirm what that band's latest patch
actually is before writing the range.

Always present the proposed override (exact scoped range + reasoning) and
get confirmation before writing it.

**Write the justification comment directly above the override entry in the
same edit that adds it** — not as a follow-up, and not skipped. An
override line in `pnpm-workspace.yaml` without a comment block explaining
it (see "Exception Documentation" above) is an incomplete fix.

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 9: Remove or Replace the Package

If no update or override path works, and the root (or the vulnerable leaf)
can be removed or swapped for an alternative package with equivalent
functionality, consider this next — before patching.

This is distinct from Step 4: Step 4 catches dependencies that were never
actually needed as a project dependency in the first place. This step is
for a dependency that *is* legitimately needed, but where the specific
vulnerable version/package can be dropped or substituted.

- Confirm the package is actually removable (check for usages across the
  codebase, not just the manifest).
- If a replacement library is proposed, it must be well-known and actively
  maintained (per this repo's dependency-adding standards) — flag anything
  unusual.
- Always present the removal/replacement plan and reasoning, and get
  confirmation before applying. This is a scope-affecting change and must
  never be done silently.

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 10: Native `pnpm patch` (Last Resort)

If a community-provided patch exists for the vulnerable package (or one
needs to be authored), use pnpm's native patching — not the third-party
`patch-package` library:

```bash
pnpm patch <package>@<version>
# edit the extracted files in the temp dir pnpm prints
pnpm patch-commit <temp-dir>
```

This registers the patch under `patchedDependencies` in
`pnpm-workspace.yaml` (or `package.json`, matching existing repo
convention). Scope the patch entry as tightly as possible using the same
exact-version > version-range > name-only priority pnpm applies:

```yaml
patchedDependencies:
  "pkg@5.2.2": patches/pkg@5.2.2.patch
```

Avoid name-only or overly broad range patches unless the fix is verified
safe across that whole range. Present the patch contents and source (link
to the community patch, if applicable) and get confirmation before
committing it.

Re-run the audit (Step 11). If resolved, stop here and commit (Step 12).

## Step 11: Re-run the Audit After Every Change

After *any* applied fix (removal, patch/minor/major update, override, or
patch-commit), re-run the same `pnpm audit --audit-level=<threshold>`
command from Step 0/1 before moving on:

- A root update frequently resolves multiple advisories at once (many
  vulnerable children can share one root). Check whether other findings
  from the original report were also cleared — don't re-do work for
  advisories that are already gone.
- If the targeted advisory is gone, proceed to commit (Step 12) and, if
  there are remaining in-scope advisories, return to Step 2 for the next
  one (in a new pass — still one at a time).
- If the targeted advisory is still present, proceed to the next step in
  the ladder (Step 5 → 6 → 7 → 8 → 9 → 10, starting from wherever you left
  off).

### Audit `pnpm-workspace.yaml` for Stale Exceptions

Whenever the `overrides` or `auditConfig.ignoreGhsas`/`audit.ignore` block
changed in this pass (an entry was added, or a root update elsewhere made
an existing entry unnecessary), re-read the whole block before moving on
and check for staleness — there's no second file to cross-reference
anymore, but entries can still go stale on their own:

1. **Every entry just added has its justification comment.** If Step 8 or
   the audit-ignore flow was just run, confirm the comment block was
   actually written above the new line — don't assume.
2. **Every override still resolves to a version that clears its documented
   advisory.** If a prior override's target version is now itself flagged
   by a newer advisory (check the current audit output against the GHSA
   ID in each override's comment), that override needs to be revisited —
   treat it like a fresh finding, re-enter the ladder from Step 3 for that
   package, and update the comment (not duplicate it) when resolved.
3. **Every override is still necessary.** If a root update elsewhere in
   this pass happened to also update the package an existing override
   targets (dedup/convergence can do this), the override may now be
   redundant — check with `pnpm why <pkg>` whether the vulnerable version
   the override targets even still resolves anywhere. If not, remove the
   stale override and its comment in the same pass.
4. **Every ignored advisory should be re-checked for a now-available fix.**
   If a `pnpm audit` re-run shows an ignored GHSA no longer appears in the
   report at all (rather than appearing with the ignored count), the
   underlying package may have changed such that the advisory doesn't
   apply anymore, or a new patched version might already be resolvable —
   don't assume the ignore is still necessary forever; if in doubt, try
   removing the ignore and see if the advisory resurfaces as fixable
   through the normal ladder.

This check costs little (a read of one file section) and prevents
exceptions from silently drifting out of sync with reality — the exact
gap this section exists to close.

## Step 12: Commit the Fix

Once an advisory is resolved, commit it as its own change before starting
the next one:

- Stage only the files touched by this fix (lockfile, manifest, and
  `pnpm-workspace.yaml` if an override or ignore was added/edited/removed
  this pass) — never a broad `git add`.
- Conventional Commits format: `fix(deps): <what changed> (GHSA-xxxx)`,
  e.g. `fix(deps): bump lodash to 4.17.21 (GHSA-xxxx-xxxx-xxxx)`. For a
  Step 4 removal, use `chore(deps): remove unused <pkg> (GHSA-xxxx)`
  instead, since it's a cleanup rather than a version fix. For an audit
  ignore, use `chore(deps): ignore <pkg> advisory (GHSA-xxxx) [reason]`
  or similar — not `fix`, since nothing was actually fixed. Scope should
  match the monorepo scope conventions already in use (`web`, `ui`,
  `shared`, `config`, `monorepo`) if the fix is workspace-package-specific,
  otherwise omit or use the closest fit.
- Never batch multiple advisory fixes into one commit, even if they were
  resolved by the same root update — split by advisory if practical, or
  note in the commit body which advisories were cleared incidentally if
  they came from the same single change.
- Never include unrelated changes in the commit (e.g. a dead-end update
  attempt from an earlier step that got reverted) — verify the diff only
  contains the change that actually fixed the advisory before staging.
- Never amend or force-push.

## If Nothing Above Resolves It

If the removal check, patch/minor/major updates, scoped overrides,
removal/replacement, and native patching all fail to clear the advisory
(or aren't applicable), stop and report back to the user rather than
improvising further. State explicitly, for each option:

- **Removal (Step 4)**: why the package is genuinely needed as a project
  dependency (e.g. confirmed usage found, or a documented reason it can't
  be global-only).
- **Patch/minor/major update**: why it didn't fix it or wasn't possible
  (e.g. no patched version exists upstream yet, root is unmaintained).
- **Override**: why it wasn't viable (e.g. would require a major-version
  override, which is disallowed).
- **Removal/replacement (Step 9)**: why it wasn't viable (e.g. no
  equivalent library, too deeply used across the codebase).
- **Native patch**: why it wasn't applied (e.g. no known community patch,
  or authoring one is out of scope without upstream guidance).

At this point there are two remaining avenues before handing the decision
back to the user: check for an upstream fix in progress, and check whether
the vulnerability is actually reachable in this codebase's usage. Do both
before concluding nothing more can be done.

### Check for an Upstream Issue

Search for an existing issue or PR against the root package's repository
tracking this specific advisory or dependency pin (e.g.
`site:github.com <root-repo> <vulnerable-package> security` or searching
the advisory's GHSA ID directly). This tells the user whether a fix is
already in progress upstream, and gives them something to subscribe to
or link against instead of re-investigating later. Report what you find
(or that you found nothing) — don't silently skip this.

### Justifying an Audit Ignore

If no upstream fix is in progress, evaluate whether the advisory actually
applies to how this codebase uses the vulnerable package. An advisory
being unfixable does not automatically mean it's safe to ignore — it must
be justified with concrete evidence, not assumed:

1. **Read the advisory in detail** (not just the one-line title from
   `pnpm audit` output) — fetch the GHSA/CVE page. Identify the exact
   preconditions required to trigger it: what API/code path must be
   called, what input or actor must control what, what execution context
   is required (e.g. "acting as a WebSocket client connecting to an
   attacker-controlled server" is a very different exposure than "parsing
   any untrusted string").
2. **Trace every place the vulnerable package is actually imported** in
   the dependency chain identified in Step 3 — read the source of the
   root/intermediate packages (not just their `package.json`) to see
   which exports of the vulnerable package they use. Use
   `grep`/`grep_search` against the installed package's dist files for
   `require`/`import` of the vulnerable package, then check which
   functions/classes from it are actually called.
3. **Confirm the vulnerable code path is not reached.** If the advisory
   requires API surface X (e.g. a specific class, method, or option) and
   nothing in the reachable code imports or calls X, the vulnerability
   cannot be triggered through this dependency tree's usage. If it's
   unclear or the vulnerable surface *is* reached (even indirectly), do
   **not** propose an ignore — report back to the user that the exception
   isn't justified and the risk needs to be accepted consciously or
   revisited later.
4. **Only if unreachability is confirmed**, propose adding the GHSA ID(s)
   to `auditConfig.ignoreGhsas` in `pnpm-workspace.yaml` (the setting name
   for pnpm < 11.16 — use `audit.ignore` if this workspace is on a newer
   pnpm; check the installed `pnpm --version` and pnpm's own changelog/docs
   before picking the key name). Present the full trace (what you read,
   what you checked, why it's unreachable) and get explicit confirmation
   before applying — this is not a silent step.

```yaml
# pnpm-workspace.yaml (pnpm < 11.16)
auditConfig:
  ignoreGhsas:
    - GHSA-xxxx-xxxx-xxxx
```

```yaml
# pnpm-workspace.yaml (pnpm >= 11.16)
audit:
  ignore:
    - GHSA-xxxx-xxxx-xxxx
```

**Write the reachability conclusion as the comment directly above the
ignore entry in the same step** — per the terseness rule in "Exception
Documentation," one line stating what was checked and why it's
unreachable, not just "not applicable." The investigation above (steps
1-4) must still be done in full; only the written comment is compressed
to its conclusion. Verify with a re-run of `pnpm audit` (Step 11) that
the count of ignored findings matches what was just added — pnpm reports
ignored counts alongside severity totals (e.g. `10 high (3 ignored)`).

If reachability can't be confidently ruled out, don't add an ignore. Tell
the user this is the signal that deeper investigation (accepting the risk
consciously without an ignore entry, a larger refactor to avoid the
package, or simply waiting on an upstream fix) is warranted, and that
decision belongs to them.

## Quick Reference

| Step | Action | Confirmation required? |
| --- | --- | --- |
| 0 | Scope the run (severity threshold, prod-only) | No — confirm only if defaults are overridden |
| 1 | Run `pnpm audit` | No |
| 2 | Select one advisory to work | No |
| 3 | Identify the root dependency (`pnpm why`) | No |
| 4 | Remove unused/misplaced root dependency | Always |
| 5 | Patch update of root | No |
| 6 | Minor update of root | Only if changes needed to accommodate |
| 7 | Major update of root | Always |
| 8 | Scoped override (patch) | Yes (still show reasoning) |
| 8 | Scoped override (minor) | Yes, with changelog review |
| 8 | Scoped override (major) | Never — disallowed |
| 9 | Remove/replace package (in-use dependency) | Always |
| 10 | Native `pnpm patch` | Always |
| — | Audit ignore (unreachable vulnerability, last resort) | Always, with reachability evidence |
| 11 | Re-run audit; check for staleness in existing exceptions | No |
| 12 | Commit the fix | No |
