---
name: jira-stories
description: Guidelines for implementing Jira stories. Covers clarification questions, assumption validation, incremental commits, and the overall workflow from story intake to delivery. Also covers authoring new stories collaboratively. Use when a user provides a Jira story, ticket, or feature description for implementation, or asks to create/write a new story.
---

# Jira Stories

Two paths:

- **Implementing** a story the user has provided → read [`implementing.md`](implementing.md)
- **Authoring** a new story collaboratively → read [`authoring.md`](authoring.md)

The principles below apply to both.

## Core Principles

- **Clarify before coding** — ask questions to confirm assumptions, scope boundaries, and design decisions before writing any implementation code.
- **Small, stable commits** — commit each logical unit as it's completed. Never batch an entire story into one commit.
- **Validate assumptions explicitly** — if the story makes claims about existing behavior, verify them in the codebase before proceeding.
- **Scope awareness** — identify what's in scope and what's explicitly out of scope. Don't implement out-of-scope items.
- **"Is this valid?" means actually check** — when asked to validate a story against the codebase, that's a request to grep/read/trace, not to restate the story's claims back with confidence. Confirm each factual claim (file counts, which files, what a comment says, whether a code path is reachable) against what's actually there before agreeing it's accurate.
- **A violation existing doesn't mean the story's prescribed fix is correct** — a story can correctly identify a problem while prescribing the wrong remedy. Validate the diagnosis and the prescription separately.
- **Don't cite a rule you haven't read** — if a story or your own review invokes a named principle (screaming architecture, a lint rule, a documented convention), find and read the actual source before asserting what it requires or forbids. If no documented rule exists, say so.
- **Don't invent dependencies** — don't name a specific library or tool that isn't already used in the codebase, even as neutral "absence" evidence. Describe the current codebase's actual state in its own terms and leave naming specific technologies to the implementer's own research.

## Anti-Patterns

| Don't | Do |
|-------|-----|
| Jump straight into coding without asking questions | Pause, ask, confirm, then implement |
| Make one giant commit at the end | Commit each logical unit as you go |
| Assume the story's description of existing behavior is correct | Verify claims against the actual codebase |
| Implement out-of-scope items because they seem related | Stay within stated scope; raise concerns if scope seems insufficient |
| Guess at open design decisions | Ask the user to decide |
| Skip the plan and just start writing | Outline the approach, confirm, then execute |
| Implement directly on `develop`/`main` | Create a ticket-named feature branch first, then implement |
| Treat "validate this story" as a request to agree with it | Actually trace the claims in code — grep for the imports, read the flagged files, confirm counts |
| Assert an architectural rule from memory | Read the actual doc/AGENTS.md/ADR first; quote what it really says, or say no such rule exists |
| Recommend a fix because it's the common pattern for the violation type | Check whether that specific fix is actually necessary here |
