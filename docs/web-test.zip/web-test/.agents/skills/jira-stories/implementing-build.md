# Implementing a Jira Story — Build

This file covers turning a confirmed plan into code: branching, committing, and verifying. It assumes [`implementing-plan.md`](implementing-plan.md) is already done and the user has confirmed the approach.

**This file is instructions for whoever is actually writing the code.** If you are coordinating other agents rather than writing code yourself, do not follow these steps directly — hand them to the implementing agent along with the confirmed plan.

## Branch First, Then Small Commits

### Branch — non-negotiable first step

Before touching any file, create and check out a feature branch off the latest default branch (e.g. `develop`) — never implement directly on `develop`/`main`. Name the branch after the ticket key (e.g. `PEDX01-3011-vdp-skeleton-suspense-fix`). If a branch for this ticket already exists locally or on the remote, check it out instead of creating a new one; ask the user if it's unclear which to use.

**This applies even during design iteration.** If the user asks to "show me code" or "prototype this" before the approach is fully confirmed, that code still goes on a branch. There is no design-mode exception. The first file write must be preceded by a `git checkout -b` — if it isn't, stop and create the branch before continuing.

### Commits — one logical unit at a time

Implement in small, stable increments. Each commit should:

- Do one thing (schema change, new hook, orchestrator integration, etc.).
- Build successfully on its own (no broken intermediate states).
- Follow Conventional Commits format.
- Be committed immediately when the unit is complete — don't accumulate.

**Never retroactively split changes into multiple commits.** If changes are already intertwined across files, commit them together as one unit. The value is in stable checkpoints, not post-hoc categorisation.

The `todo_list complete` call for a task only happens after the commit for that task succeeds — not after the file edits alone.

Typical commit sequence for a feature:

```
chore(web): add autoSubmitted field to AgentSearchTurn schema
feat(web): create useAutoSubmitTurn hook
feat(web): integrate auto-submit in SearchResultsOrchestrator
feat(web): extend EditorialCardData with autoSubmit payload
feat(web): update personalized search cards with auto-submit hrefs
```

## Verification

After all commits:

- Run the full validation suite (`pnpm build`, `pnpm lint`, `pnpm type-check`).
- Confirm each acceptance criterion is addressed.
- Note any ACs that require manual testing or cannot be verified in CI.

## When to Re-Clarify

If during implementation you discover:

- The codebase doesn't match what the story describes.
- A design decision has implications the story didn't anticipate.
- An acceptance criterion conflicts with another.
- The scope is larger than initially apparent.

Stop and ask. Don't make assumptions to keep moving — the cost of rework exceeds the cost of a question.
