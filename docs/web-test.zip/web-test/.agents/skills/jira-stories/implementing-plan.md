# Implementing a Jira Story — Plan

This file covers understanding a story and producing a confirmed implementation plan. It involves no file writes, no branching, no commits — it ends with a plan the user has signed off on. Anyone can follow this file: a solo agent about to write code, or a coordinator preparing a brief for an implementing agent.

## 1. Story Intake — Read and Understand

Read the full story: summary, user stories, background, scope, constraints, acceptance criteria, and out-of-scope items. Identify:

- What the feature actually does (the user-visible behavior change).
- What existing code is affected.
- What assumptions the story makes about current behavior.
- What design decisions are left open (the story may say "Decide on X").

## 2. Clarifying Questions — Ask Before Building

Before any implementation, ask the user clarifying questions. Focus on:

| Category | Example Questions |
|----------|-------------------|
| **Assumptions** | "The story assumes X works this way — I've verified it does / doesn't. Should I proceed as written or adjust?" |
| **Open design decisions** | "The story says 'Decide on data transport mechanism' — do you have a preference between query params, route state, or IDB pre-seed?" |
| **Scope boundaries** | "AC #3 mentions a placeholder turn — should it be a real API call or a local-only optimistic insert?" |
| **Edge cases** | "What should happen if the user navigates back during auto-submit — abort the request or let it complete in background?" |
| **Dependencies** | "This touches EditorialCard which is shared — are other consumers affected? Should I guard the new behavior behind a prop?" |

Do not proceed until the user confirms or provides direction on open questions. Batch questions into a single message.

## 3. Planning — Outline the Approach

After clarification, outline the implementation plan:

- List the files that will be created or modified.
- Describe the approach at a high level (data flow, hook placement, state management).
- Identify the commit boundaries — what constitutes a logical unit of work.
- Flag any risks or tradeoffs.

Present this to the user for confirmation. A brief outline is sufficient — not a full design doc.

## Next Step

Once the plan is confirmed:

- **Solo agent, writing the code yourself** → continue to [`implementing-build.md`](implementing-build.md).
- **Coordinating other agents rather than writing code yourself** → hand this confirmed plan to the implementing agent as its brief. `implementing-build.md`'s instructions belong to that agent, not to you.

## When to Re-Clarify

If during planning or implementation you discover:

- The codebase doesn't match what the story describes.
- A design decision has implications the story didn't anticipate.
- An acceptance criterion conflicts with another.
- The scope is larger than initially apparent.

Stop and ask. Don't make assumptions to keep moving — the cost of rework exceeds the cost of a question.
