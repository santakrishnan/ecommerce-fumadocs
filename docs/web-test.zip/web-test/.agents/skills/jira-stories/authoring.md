# Authoring a Jira Story

## 1. Gather Context

Before drafting, investigate the codebase and any referenced specs (OpenAPI, schemas repos, etc.) to understand:

- Existing patterns and past examples relevant to the feature.
- Data contracts and API shapes that will drive the implementation.
- What already works and should remain unchanged.

## 2. Ask Clarifying Questions

Present focused questions about scope, behavior, and design intent. Batch them into a single message. Do not draft the story until the user provides direction.

## 3. Draft the Story — Keep It Proportional

The story's word count should be proportional to the size of the change. A small feature gets a short story. Do not pad with analysis, option comparisons, or exhaustive context the implementer can discover themselves.

Structure (include only sections that add value — omit the rest):

- **Summary** — one paragraph. What this does and why.
- **User Stories** — "As a [role]…" format, focused on user-visible outcomes. Skip if the summary already makes the user value obvious.
- **Technical Guidance** — only when it genuinely helps: point at an existing utility to reuse, name a data contract, or clarify a non-obvious mechanism. Do NOT present design options/decisions, prescribe architecture, or list file paths the implementer will discover naturally.
- **Dependencies** — external blockers or prerequisites. Only if they exist.
- **Acceptance Criteria** — numbered, testable, behavioral. What the user experiences, not how the code is structured. Always the last section — this Jira setup treats AC as a separate field from the description, so it must be the final block in the draft, cleanly separable from everything above it.

## 4. What to Leave Out

- **Out-of-scope sections** — define what to do, not what not to do. If the scope is clear from the ACs, an explicit scope section is noise.
- **Background sections** — skip unless the implementer genuinely wouldn't have the context (e.g. cross-team dependency, external system behavior). If the codebase tells the story, don't repeat it.
- **Design decision analysis** — do not present "Option A vs Option B" comparisons. If there's a clear answer, state it as fact in Technical Guidance. If it's genuinely ambiguous, ask the user during clarification — don't punt it into the story text.
- **Notes sections** — remove-after-ship reminders, philosophy, and "consider whether…" suggestions are noise. If it matters, make it an AC.
- **Mock data guidance** — only mention if the fixture situation is non-obvious.
- **Named tools/libraries not already in the codebase** — don't cite a specific unused library (even as "X is not installed" evidence of a gap) unless the user has already named it. It reads as an implicit recommendation and forecloses the implementer's own evaluation. Describe the gap in the codebase's own terms instead.
- **Esoteric jargon** — write in plain language. Avoid terms like "prior art," "vis-à-vis," or other business/legal/academic jargon when a plain phrase says the same thing (e.g. "two other tests already mock this" instead of "the package has prior art for this"). If a technical term is standard for this codebase/stack (e.g. "hydration," "memoization," "race condition"), it's fine — the bar is plain English, not dumbing down real technical vocabulary.

## 5. Don't Leak Steering Guidance Into Story Text

Guidance the user gives you about *how to draft* (e.g. "don't pre-select T3 as the answer," "keep the proposal's own bias out of the AC framing," "these are suggestions, not hard requirements") is an instruction to you, not content for the story. Before adding a line to the summary, guidance, or AC, ask whether a consumer of the story — someone who never saw the drafting conversation — would find it meaningful. "The recommendation is not predetermined" or "this comparison is not limited to a fixed list" reads as a non-sequitur to that reader: it responds to a bias only the drafting conversation raised, not something the implementer would otherwise assume. Comply with steering guidance by *omitting* the biased framing in the first place, rather than adding a line that explicitly disclaims it.

## 6. Keep Acceptance Criteria at User-Story Level

Do not prescribe specific technical constructs (hook names, file paths, component names) in acceptance criteria. Keep them behavioral. Technical guidance goes in its own section only if it adds value beyond what the implementer would discover by reading the code.

This applies to tech-debt/refactor stories too. When the story's problem is a code-structure issue (e.g. a boundary violation, a circular dependency) and the right remedy is genuinely open-ended, write the AC as the outcome ("the circular dependency no longer exists", "no import reaches into another feature's internal path") rather than dictating the mechanism ("move X to `@shared`"). Prescribing a specific relocation forecloses on options — a missing barrel export, redrawn ownership, or dependency inversion may be the better fix, and the implementer is better positioned to make that call once they're in the code. Reserve a "Technical Guidance" callout to flag traps (e.g. "don't default to shared for every item") without dictating the answer.

## 7. Don't Lose Specifics When Tightening Prose

De-duplicating a draft means removing repeated *statements* of the same fact, not removing the fact's supporting specifics. If the narrative says "six files violate X" or "these paths do Y," the six files and the paths must still be enumerated somewhere in the story (a table, a list) — referencing a count or "these files" without ever listing them is an omission, not a trim. Read back a de-duplicated draft and confirm every claim that names a quantity or set of items still has that set spelled out somewhere in the document.

## 8. Emit as HTML for Jira Copy-Paste

This Jira setup has **Acceptance Criteria as a separate field from Description**. The HTML output must make the two blocks independently copyable — never interleave AC back into the description body.

When the story is finalized:

1. Write the story as a styled HTML file to the `tmp/` workspace folder (or another temp location per workspace rules).
2. Structure the file as two distinct blocks in this order:
   - **Description block** — Summary, User Stories, Technical Guidance, Dependencies (everything except AC).
   - **Acceptance Criteria block** — placed after the description block, separated by a plain `<hr>` followed by a plain "Acceptance Criteria" heading and the numbered list. No boxed callout, background shading, or border around this section — same plain styling as every other heading/list in the document. The `<hr>` plus heading is enough to signal "copy from here down into the AC field."
3. Use clean, semantic HTML with inline or `<style>` block styling — tables, code blocks, lists, and headings should render well when pasted into Jira's rich text editor.
4. Open the file in the user's default browser via `open <path>` (macOS).
5. The user will select-all → copy → paste the description block into Jira's Description field, then separately select and copy the AC block into the Acceptance Criteria field. This preserves formatting that raw markdown does not.

Do **not** emit raw markdown for Jira copy-paste — it does not render correctly when pasted into Jira's fields.
