# Implementing a Jira Story

## 1. Story Intake — Read and Understand

Read the full story: summary, user stories, background, scope, constraints, acceptance criteria, and out-of-scope items. Identify:

- What the feature actually does (the user-visible behavior change).
- What existing code is affected.
- What assumptions the story makes about current behavior.
- What design decisions are left open (the story may say "Decide on X").

## 2. Clarifying Questions — Ask Before Building

Before any implementation, ask the user clarifying questions. Focus on:

| Category | Example Questions |
|----------|-------------------|
| **Assumptions** | "The story assumes X works this way — I've verified it does / doesn't. Should I proceed as written or adjust?" |
| **Open design decisions** | "The story says 'Decide on data transport mechanism' — do you have a preference between query params, route state, or IDB pre-seed?" |
| **Scope boundaries** | "AC #3 mentions a placeholder turn — should it be a real API call or a local-only optimistic insert?" |
| **Edge cases** | "What should happen if the user navigates back during auto-submit — abort the request or let it complete in background?" |
| **Dependencies** | "This touches EditorialCard which is shared — are other consumers affected? Should I guard the new behavior behind a prop?" |

Do not proceed until the user confirms or provides direction on open questions. Batch questions into a single message.

## 3. Planning — Outline the Approach

After clarification, outline the implementation plan:

- List the files that will be created or modified.
- Describe the approach at a high level (data flow, hook placement, state management).
- Identify the commit boundaries — what constitutes a logical unit of work.
- Flag any risks or tradeoffs.

Present this to the user for confirmation. A brief outline is sufficient — not a full design doc.

## 4. Implementation — Branch First, Then Small Commits

### Branch — non-negotiable first step

Before touching any file, create and check out a feature branch off the latest default branch (e.g. `develop`) — never implement directly on `develop`/`main`. Name the branch after the ticket key (e.g. `PEDX01-3011-vdp-skeleton-suspense-fix`). If a branch for this ticket already exists locally or on the remote, check it out instead of creating a new one; ask the user if it's unclear which to use.

**This applies even during design iteration.** If the user asks to "show me code" or "prototype this" before the approach is fully confirmed, that code still goes on a branch. There is no design-mode exception. The first file write must be preceded by a `git checkout -b` — if it isn't, stop and create the branch before continuing.

### Commits — one logical unit at a time

Implement in small, stable increments. Each commit should:

- Do one thing (schema change, new hook, orchestrator integration, etc.).
- Build successfully on its own (no broken intermediate states).
- Follow Conventional Commits format.
- Be committed immediately when the unit is complete — don't accumulate.

**Never retroactively split changes into multiple commits.** If changes are already intertwined across files, commit them together as one unit. The value is in stable checkpoints, not post-hoc categorisation.

The `todo_list complete` call for a task only happens after the commit for that task succeeds — not after the file edits alone.

Typical commit sequence for a feature:

```
chore(web): add autoSubmitted field to AgentSearchTurn schema
feat(web): create useAutoSubmitTurn hook
feat(web): integrate auto-submit in SearchResultsOrchestrator
feat(web): extend EditorialCardData with autoSubmit payload
feat(web): update personalized search cards with auto-submit hrefs
```

## 5. Verification

After all commits:

- Run the full validation suite (`pnpm build`, `pnpm lint`, `pnpm type-check`).
- Confirm each acceptance criterion is addressed.
- Note any ACs that require manual testing or cannot be verified in CI.

## When to Re-Clarify

If during implementation you discover:

- The codebase doesn't match what the story describes.
- A design decision has implications the story didn't anticipate.
- An acceptance criterion conflicts with another.
- The scope is larger than initially apparent.

Stop and ask. Don't make assumptions to keep moving — the cost of rework exceeds the cost of a question.
