---
name: ecommerce-schemas-upgrade
description: >-
  Adopt the latest ecommerce-schemas SDK releases into the ecommerce-web repo.
  Use this whenever the user wants to check for, review, or pull in new
  @ucmp/sdk-* releases (search, visitor-profile, geo, image-processing,
  carcutter, feed-*), upgrade the generated OpenAPI clients ecommerce-web
  depends on, resolve drift between the schemas contract registry and the web
  app, or asks things like "is there a new schemas release?", "bump the search
  SDK", or "sync web with the latest specs". The skill diffs the OpenAPI spec
  between the consumed and latest tags, classifies the change, PAUSES to notify
  the developer when it finds breaking, architectural, or pattern changes, and
  otherwise upgrades the dependency and applies the required code changes so
  ecommerce-web builds and type-checks against the new contract.
---

# Adopting ecommerce-schemas SDK releases into ecommerce-web

## What this does and why

`ecommerce-schemas` is the contract registry: OpenAPI specs live in `specs/`,
and each spec is code-generated (via kubb) into a versioned npm package under
the `@ucmp` scope (e.g. `@ucmp/sdk-search-api`). Releases are cut as git tags of
the form `<packageDir>@<semver>` (e.g. `sdk-search-api@0.5.9`).

`ecommerce-web` consumes those packages from Artifactory and pins version ranges
in its workspace `package.json` files. It mostly imports **types and enums** from
the SDKs across its BFF contracts, mappers, and fixtures, so a contract change in
schemas ripples into web as type errors.

The job of this skill is to close the gap safely: find releases web hasn't
adopted, understand exactly what changed in the contract, and either apply a
clean upgrade or stop and involve the developer when the change needs a human
decision. The guiding principle is **no silent breaking changes** — an additive
field bump can proceed autonomously, but a renamed field, a reshaped envelope, or
a new auth pattern is a design decision the developer must see first.

## The repositories

Both repos are normally sibling checkouts. Default locations:

- schemas: `~/projects/ecommerce-schemas`
- web:     `~/projects/ecommerce-web`

If they aren't there, locate them (`git remote -v` should show
`TMCC-Project-Arrow/ecommerce-schemas` and `.../ecommerce-web`) or ask the user.
Read `references/repo-map.md` for the full layout, conventions, registry, and
verification commands — consult it before running commands you're unsure about.

## Workflow

Work through these steps in order. Don't skip the diff-and-classify step even if
the version bump looks small — the whole point is to see the contract change
before touching web.

### 1. Detect what's outdated

Fetch tags first (releases are tags, and a stale checkout will hide new ones),
then run the bundled detector. It's read-only and never mutates either repo:

```bash
git -C <schemas> fetch --tags -q
python3 scripts/check_sdk_releases.py --schemas <schemas> --web <web>
```

This prints, per consumed SDK, the version web declares, the exact installed
version (from `pnpm-lock.yaml`), the latest released version, and the baseline →
target tags to diff. Add `--json` for a machine-readable version you can act on.

If nothing is outdated, report that and stop — there's nothing to adopt.

If the user named a specific SDK ("bump the search SDK"), focus on that one.
Otherwise handle every outdated SDK, one at a time.

### 2. Diff the OpenAPI spec for each outdated SDK

For each outdated package, look at what actually changed in the contract between
the version web consumes and the latest release:

```bash
python3 scripts/check_sdk_releases.py --schemas <schemas> --web <web> \
  --diff <packageName> --stat        # overview first
python3 scripts/check_sdk_releases.py --schemas <schemas> --web <web> \
  --diff <packageName>               # full spec diff
```

This diffs the spec at the git tags for the baseline and target versions, so
you're comparing the exact contracts behind the two SDK builds — not the current
working tree. If the diff touches `$ref`'d shared files (e.g.
`specs/_shared/envelope.json`, pagination, error models), inspect those too, as
changes there fan out across every operation.

### 3. Classify the change — this decides everything

Read `references/change-classification.md` and categorize the diff. The category
determines whether you proceed or pause:

- **Additive / non-breaking** (new optional fields, new endpoints, new optional
  params, additive enum values, doc-only changes): safe to adopt autonomously.
- **Breaking** (removed/renamed fields, tightened types, new required fields,
  removed endpoints/operations, changed enum semantics): the developer must
  approve — these will break web's types or runtime behavior.
- **Architectural / pattern** (changes to the shared response envelope,
  pagination model, error model, auth scheme, client `configure*` signature, an
  `@ucmp/sdk-runtime` bump, or a wholesale restructuring of a resource): always
  pause and notify the developer before changing anything.

When in doubt, treat it as breaking. A false pause costs a message; a false
"proceed" ships a broken contract adoption.

### 4a. If breaking, architectural, or pattern changes — NOTIFY, then wait

Do **not** edit web yet. Present the developer with a concise report so they can
make the call. Use this structure:

```
## Schemas upgrade review: <packageName> <baseline> -> <latest>

**Classification:** <breaking | architectural/pattern>

**What changed in the contract:**
- <bullet per meaningful change, referencing the spec path/field>

**Why this needs your decision:**
- <the architectural/pattern/breaking implication>

**Impact on ecommerce-web:**
- <files/types/usages that would need to change — cite paths from step 5's scan>

**Proposed approach if you want me to proceed:**
- <the changes you'd make>

Want me to proceed with this plan, adjust it, or hold off?
```

Then stop and wait for the developer's decision. Only continue once they
confirm. If they adjust the plan, follow their direction.

### 4b. If purely additive / non-breaking — proceed

Adopt the release:

1. **Bump the version** in the workspace `package.json`(s) that declare the SDK
   (the detector's `consumedIn` / `--json` output tells you which). Preserve the
   existing range style (e.g. `^0.5.7` → `^0.5.9`). Also bump any transitively
   pinned peer like `@ucmp/sdk-runtime` if the new SDK requires it.
2. **Install** from the workspace root so the lockfile updates:
   ```bash
   pnpm install
   ```
   (web pulls `@ucmp` packages from Artifactory — see `references/repo-map.md` if
   install fails on registry/auth.)
3. **Apply required code changes.** Even additive changes may let you remove
   local workarounds — search for TODO markers that reference the SDK (e.g.
   `TODO(@ucmp/sdk-search-api)`) and for local "extension" types that patched in
   fields the SDK now ships. New optional fields rarely force changes but often
   let you delete a shim.

### 5. Find the impact surface in web

Before editing (and to populate the impact section of a notify report), map
where web touches the SDK's types:

```bash
grep -rn --include='*.ts' --include='*.tsx' "<packageName>" \
  <web>/apps <web>/packages | grep -v -e /node_modules -e /.next
```

Look especially at BFF contract schemas, mappers, and fixtures under
`apps/web/src/features/**/bff/`, plus `apps/web/src/config/`. These are where
SDK type changes surface as compile errors.

### 6. Verify

Run web's checks from the web repo root and fix anything the upgrade broke. Match
the project's own pre-commit expectation (`pnpm lint && pnpm type-check &&
pnpm test`), then build:

```bash
pnpm type-check
pnpm lint
pnpm test
pnpm build
```

`pnpm type-check` is the most important signal for a contract change — it's what
catches a field that moved or a type that tightened. If type errors appear that
stem from a genuine contract change you didn't anticipate, re-classify: a change
that forces non-trivial edits is really a breaking change, so pause per step 4a
rather than forcing web to compile.

### 7. Report

Summarize what you did: which SDK(s) went from which version to which, the
classification, the files you changed, and the verification results. Do **not**
commit or push unless the user explicitly asks — leave the change staged for
their review.

## Guardrails

- Never push, force-push, or amend. Only commit if the user asks.
- Never adopt a breaking/architectural change without explicit developer sign-off,
  even if you could make web compile — compiling is not the same as correct.
- Keep the two repos straight: you *read* from schemas (tags, specs) and *write*
  to web. Do not modify schemas.
- Treat the OpenAPI spec as the source of truth for the contract; treat the tags
  as the source of truth for what was released (the working-tree `package.json`
  version in schemas can lag the latest tag).

## Reference files

- `references/repo-map.md` — repo layout, tag/version conventions, the
  package↔spec mapping, npm registry, and verification commands.
- `references/change-classification.md` — how to categorize an OpenAPI diff as
  additive, breaking, or architectural, with concrete examples.
