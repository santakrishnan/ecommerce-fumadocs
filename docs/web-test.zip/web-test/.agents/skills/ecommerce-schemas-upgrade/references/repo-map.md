# Repo map: ecommerce-schemas & ecommerce-web

Concrete facts about both repos. The bundled detector reads most of this
dynamically, but this file is the ground truth when you need to reason by hand.

## ecommerce-schemas (the contract registry — read only)

- Remote: `git@github.com:TMCC-Project-Arrow/ecommerce-schemas.git`
- Default local path: `~/projects/ecommerce-schemas`
- OpenAPI specs live under `specs/<area>/openapi/*.yml` (carcutter is `.json`).
  Shared building blocks are `$ref`'d from `specs/_shared/` (envelope, error,
  pagination, sort-order, filter-key) — a change there affects many operations.
- Each spec is code-generated into a package under `packages/` via kubb
  (`pnpm codegen`). Packages publish to Artifactory under the `@ucmp` scope.

### Releases are git tags, not the working tree

Released versions are tags shaped `<packageDir>@<semver>`:

```
sdk-search-api@0.5.9
sdk-visitor-profile-api@0.1.8
sdk-runtime@0.1.2
event-types@0.2.6
```

The `version` field in a package's `package.json` in the working tree can lag
the newest tag — **trust the tags** for "what has been released." Always
`git fetch --tags` before comparing, or a stale checkout hides new releases.

### The authoritative mapping: `sdk.config.ts`

`sdk.config.ts` at the repo root maps everything together. Each entry has:

- `specPath` — OpenAPI spec relative to repo root (e.g.
  `./specs/search/openapi/search-api.yml`)
- `packageDir` — directory under `packages/` and the **tag prefix**
  (e.g. `sdk-search-api`)
- `packageName` — the npm name (e.g. `@ucmp/sdk-search-api`)
- `configureFnName` — the client configure function the SDK exports
  (e.g. `configureSearchApiClient`)

Current entries (verify by reading the file — it changes as SDKs are added):

| packageName | packageDir | specPath |
|---|---|---|
| @ucmp/sdk-feed-management-api | sdk-feed-management-api | specs/dfp/openapi/feed-management-api.yml |
| @ucmp/sdk-search-api | sdk-search-api | specs/search/openapi/search-api.yml |
| @ucmp/sdk-visitor-profile-api | sdk-visitor-profile-api | specs/visitor/openapi/visitor-profile-api.yml |
| @ucmp/sdk-geo-api | sdk-geo-api | specs/geo/openapi/geo-api.yml |
| @ucmp/sdk-feed-ingestion-webhook | sdk-feed-ingestion-webhook | specs/dfp/openapi/feed-ingestion-webhook.yml |
| @ucmp/sdk-feed-observability-api | sdk-feed-observability-api | specs/dfp/openapi/feed-observability-api.yml |
| @ucmp/sdk-carcutter-api | sdk-carcutter-api | specs/image-processing/openapi/carcutter-vendor-api.json |
| @ucmp/sdk-image-processing-api | sdk-image-processing-api | specs/image-processing/openapi/image-processing-api.yml |

All SDK clients depend on `@ucmp/sdk-runtime`; a runtime bump often accompanies
an SDK release and is itself a pattern-level change (see change-classification).

## ecommerce-web (the consumer — this is what you change)

- Remote: `git@github.com:TMCC-Project-Arrow/ecommerce-web.git`
- Default local path: `~/projects/ecommerce-web`
- pnpm + Turborepo monorepo. Node >= 20, pnpm 11.0.9 (pinned via `packageManager`;
  `corepack prepare pnpm@11.0.9 --activate` if needed).
- SDK dependencies are declared in workspace `package.json` files — today in
  `apps/web/package.json` (`@ucmp/sdk-search-api`, `@ucmp/sdk-visitor-profile-api`).
  New SDKs may be added in other workspace packages; the detector scans them all.

### How web consumes the SDKs

Predominantly **type and enum imports**, concentrated in:

- `apps/web/src/features/**/bff/contracts/*.schema.ts` — BFF contract schemas
  that build on SDK types (e.g. `VehicleDetail`, `DealerInfo`, `MediaItem`).
- `apps/web/src/features/**/bff/mappers/*.ts` — map SDK shapes to view models.
- `apps/web/src/features/**/__fixtures__/*.ts` — fixtures typed against SDK types.
- `apps/web/src/config/*.ts` — e.g. `agent-backend.ts` re-exports SDK enums.

Watch for two web-side patterns that a contract change interacts with:

- **Local extension types** that add fields the SDK doesn't ship yet
  (e.g. `vehicle-detail-with-sold-at.ts`). When the SDK starts shipping such a
  field, the local override can often be removed.
- **`TODO(@ucmp/sdk-...)` markers** that flag a workaround to delete once the SDK
  ships something. Grep for these when adopting a release.

### Registry / install

- `@ucmp` packages resolve from Artifactory, configured in web's `.npmrc`:
  `@ucmp:registry=https://artifactory.tfs.toyota.com/.../project-arrow-npm-dev-virtual/`
- Install from the repo root: `pnpm install`. If it fails with 401/403 or
  "package not found", it's an Artifactory auth/network issue (VPN / token), not
  a code problem — surface that to the user rather than editing code around it.

### Verification commands (run from web repo root)

| Command | Purpose |
|---|---|
| `pnpm install` | Resolve the bumped dependency, update `pnpm-lock.yaml` |
| `pnpm type-check` | **Primary signal** for contract changes (turbo → tsc) |
| `pnpm lint` | Biome lint |
| `pnpm check` / `pnpm fix` | Ultracite format check / auto-fix |
| `pnpm test` | Vitest suite |
| `pnpm build` | Full production build (all packages) |

The repo's own pre-commit expectation is
`pnpm lint && pnpm type-check && pnpm test`; do not bypass hooks with
`--no-verify`.
