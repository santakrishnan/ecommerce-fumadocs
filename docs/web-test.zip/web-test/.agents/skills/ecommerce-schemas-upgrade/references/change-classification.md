# Classifying an OpenAPI spec diff

The category of a contract change decides whether the skill proceeds on its own
or stops to involve the developer. The three categories, from safest to most
sensitive, are **additive**, **breaking**, and **architectural/pattern**. When a
diff spans several categories, the most sensitive one wins.

The reason this matters: ecommerce-web consumes the SDK mostly as TypeScript
types. An additive change to the contract is backward-compatible — old code still
compiles and behaves the same. A breaking change silently invalidates
assumptions web already encoded. An architectural change alters a pattern that
web has built structure around (envelopes, pagination, errors, auth, client
wiring), so adopting it blind can compile yet be wrong. Compiling is necessary
but not sufficient; correctness against the new contract is the real bar.

## Additive / non-breaking — safe to adopt autonomously

The existing web code remains valid; the change only adds capability.

- New **optional** property on a schema.
- New endpoint / operation / path.
- New **optional** request parameter (query, header, body field).
- New value added to an enum *when web treats the enum openly* (a new sort order
  it doesn't switch-exhaustively on).
- New response field that web will simply ignore until used.
- Description, example, `summary`, or tag changes; formatting-only edits.
- Loosening a constraint (e.g. `maxLength` raised, a required field made optional
  on a **response** you read — you already handle the value).

Action: bump the version, `pnpm install`, remove any now-obsolete local shim or
`TODO(@ucmp/...)` workaround, and verify.

## Breaking — developer must approve

Existing web code becomes wrong or won't compile.

- Removed or **renamed** property, endpoint, operation, or parameter.
- A field's **type changed** (string → object, scalar → array, widened/narrowed
  union) or an enum value **removed or renamed**.
- A previously optional field made **required** on a request web sends (web now
  must supply it), or a required field **dropped** from a response web relies on.
- Tightened validation that can reject payloads web currently produces
  (new `pattern`, lower `maxLength`, new `required` entry).
- Changed enum **semantics** (same value, different meaning).
- Changed `operationId`s or response status codes web branches on.

Action: do **not** edit web. Notify the developer per SKILL.md step 4a, describe
the impact (cite the web files from the impact scan), propose a plan, and wait.

## Architectural / pattern — always pause and notify

The change alters a cross-cutting pattern many operations or the whole client
depend on. Even if only one field appears in the diff, the blast radius is wide.

- Changes to the **shared response envelope** (`specs/_shared/envelope.json`) —
  e.g. `data`/`meta`/`error` wrapper reshaped. Every response type shifts.
- Changes to the **pagination** model (`specs/_shared/pagination.yaml`) — cursor
  vs offset, renamed page fields.
- Changes to the **error** model (`specs/_shared/error*.json|yaml`) — web's error
  handling and `*-error-response` types are built on this.
- Changes to **auth / security schemes** (new `securitySchemes`, required scopes,
  a header the client must now send).
- A changed **client `configure*` signature** or a bump to `@ucmp/sdk-runtime`
  (base URL, fetch, interceptor, or client-construction contract) — this is how
  every SDK is wired into web.
- Wholesale **restructuring of a resource** (splitting one schema into several,
  moving fields between objects, renaming a top-level resource).
- A **major version** bump (`x` in `x.y.z`) — signals intentional breakage.

Action: always stop and notify per SKILL.md step 4a before any change, and lay
out the migration approach for the developer to approve.

## How to read the diff efficiently

1. Start with `--diff <pkg> --stat` for scope, then the full `--diff`.
2. If the diff shows or `$ref`s a `_shared/*` file, open that file at both tags —
   shared changes are almost always architectural.
3. Compare the `x.y.z` bump against the change: a patch bump claiming only additive
   changes but showing renames/removals is a red flag — trust the diff, not the
   version number, and classify by what actually changed.
4. For enums, check whether web switches exhaustively on the values (a
   `switch`/`satisfies never`): additive values are breaking for exhaustive
   consumers.
5. When genuinely unsure, classify **up** (toward breaking/architectural). A
   needless pause is cheap; a wrong autonomous adoption is expensive.
