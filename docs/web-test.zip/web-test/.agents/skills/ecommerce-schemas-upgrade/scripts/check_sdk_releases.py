#!/usr/bin/env python3
"""Detect ecommerce-schemas SDK releases that ecommerce-web has not yet adopted.

This script is read-only. It never mutates either repository.

What it does:
  1. Reads the package -> OpenAPI-spec mapping from `sdk.config.ts` in the
     schemas repo (the authoritative source of truth for what maps to what).
  2. Enumerates released versions from git tags in the schemas repo. Releases
     are tagged as `<packageDir>@<semver>`, e.g. `sdk-search-api@0.5.9`.
  3. Reads the versions ecommerce-web currently consumes from every workspace
     `package.json` (dependencies / devDependencies / peerDependencies), and the
     exact installed version from `pnpm-lock.yaml` when available.
  4. Prints, per SDK, the consumed version, the latest released version, whether
     web is behind, and the git tags to diff between.

Usage:
  check_sdk_releases.py --schemas <path> --web <path>
  check_sdk_releases.py --schemas <path> --web <path> --json
  check_sdk_releases.py --schemas <path> --web <path> --diff <packageName>
  check_sdk_releases.py --schemas <path> --web <path> --diff <packageName> --stat

`--diff` prints the git diff of the SDK's OpenAPI spec between the tag matching
the consumed version and the latest released tag. Add `--stat` for a summary.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field


def die(msg: str) -> None:
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(1)


def git(repo: str, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", repo, *args],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        die(f"git {' '.join(args)} failed in {repo}:\n{result.stderr.strip()}")
    return result.stdout


# ---------------------------------------------------------------------------
# semver (lenient: numeric core, prerelease sorts below its release)
# ---------------------------------------------------------------------------

def parse_semver(v: str):
    v = v.strip().lstrip("v")
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?", v)
    if not m:
        return None
    major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
    pre = m.group(4)
    # A release (no prerelease) outranks any prerelease of the same core.
    pre_key = (1,) if pre is None else (0, pre)
    return (major, minor, patch, pre_key)


def clean_range(spec: str) -> str:
    """Turn a package.json range (^0.5.7, ~1.2.0, >=1.0.0) into a base version."""
    m = re.search(r"(\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)", spec)
    return m.group(1) if m else spec.strip()


# ---------------------------------------------------------------------------
# sdk.config.ts -> mapping of packageName / packageDir / specPath
# ---------------------------------------------------------------------------

@dataclass
class Sdk:
    package_name: str
    package_dir: str
    spec_path: str
    configure_fn: str = ""
    consumed: str | None = None          # base version web declares
    installed: str | None = None         # exact version from lockfile
    latest: str | None = None            # highest released tag
    consumed_files: list[str] = field(default_factory=list)


def load_sdk_config(schemas: str) -> list[Sdk]:
    path = os.path.join(schemas, "sdk.config.ts")
    if not os.path.isfile(path):
        die(f"sdk.config.ts not found at {path}")
    text = open(path, encoding="utf-8").read()

    sdks: list[Sdk] = []
    # Each entry is an object literal with the four fields we care about.
    for block in re.finditer(r"\{([^{}]*?)\}", text, re.DOTALL):
        body = block.group(1)
        pn = re.search(r"packageName:\s*'([^']+)'", body) or re.search(r'packageName:\s*"([^"]+)"', body)
        pd = re.search(r"packageDir:\s*'([^']+)'", body) or re.search(r'packageDir:\s*"([^"]+)"', body)
        sp = re.search(r"specPath:\s*'([^']+)'", body) or re.search(r'specPath:\s*"([^"]+)"', body)
        cf = re.search(r"configureFnName:\s*'([^']+)'", body) or re.search(r'configureFnName:\s*"([^"]+)"', body)
        if pn and pd and sp:
            sdks.append(Sdk(
                package_name=pn.group(1),
                package_dir=pd.group(1),
                spec_path=re.sub(r"^\./", "", sp.group(1)),
                configure_fn=cf.group(1) if cf else "",
            ))
    if not sdks:
        die("could not parse any SDK entries from sdk.config.ts")
    return sdks


# ---------------------------------------------------------------------------
# git tags -> latest released version per packageDir
# ---------------------------------------------------------------------------

def latest_tags(schemas: str) -> dict[str, str]:
    """Map packageDir -> highest released semver string (from `<dir>@<semver>` tags)."""
    latest: dict[str, tuple] = {}
    latest_str: dict[str, str] = {}
    for line in git(schemas, "tag").splitlines():
        line = line.strip()
        if "@" not in line:
            continue
        name, _, ver = line.rpartition("@")
        key = parse_semver(ver)
        if key is None:
            continue
        if name not in latest or key > latest[name]:
            latest[name] = key
            latest_str[name] = ver
    return latest_str


def tag_exists(schemas: str, tag: str) -> bool:
    result = subprocess.run(
        ["git", "-C", schemas, "rev-parse", "-q", "--verify", f"refs/tags/{tag}"],
        capture_output=True, text=True,
    )
    return result.returncode == 0


# ---------------------------------------------------------------------------
# ecommerce-web -> consumed versions
# ---------------------------------------------------------------------------

def find_package_jsons(web: str) -> list[str]:
    out: list[str] = []
    skip = {"node_modules", ".next", ".turbo", ".git", "dist", "build"}
    for root, dirs, files in os.walk(web):
        dirs[:] = [d for d in dirs if d not in skip]
        if "package.json" in files:
            out.append(os.path.join(root, "package.json"))
    return out


def read_consumed(web: str, sdks: list[Sdk]) -> None:
    by_name = {s.package_name: s for s in sdks}
    for pj in find_package_jsons(web):
        try:
            data = json.load(open(pj, encoding="utf-8"))
        except (ValueError, OSError):
            continue
        for section in ("dependencies", "devDependencies", "peerDependencies"):
            for dep, ver in (data.get(section) or {}).items():
                sdk = by_name.get(dep)
                if sdk is None:
                    continue
                sdk.consumed = clean_range(ver)
                rel = os.path.relpath(pj, web)
                if rel not in sdk.consumed_files:
                    sdk.consumed_files.append(rel)


def read_installed(web: str, sdks: list[Sdk]) -> None:
    lock = os.path.join(web, "pnpm-lock.yaml")
    if not os.path.isfile(lock):
        return
    text = open(lock, encoding="utf-8").read()
    for sdk in sdks:
        # Matches keys like `@ucmp/sdk-search-api@0.5.7` in the lockfile.
        esc = re.escape(sdk.package_name)
        found = re.findall(rf"{esc}@(\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)", text)
        if found:
            best = max(found, key=lambda v: parse_semver(v) or (0, 0, 0, (0,)))
            sdk.installed = best


# ---------------------------------------------------------------------------
# reporting
# ---------------------------------------------------------------------------

def build_report(schemas: str, web: str) -> list[Sdk]:
    sdks = load_sdk_config(schemas)
    latest = latest_tags(schemas)
    read_consumed(web, sdks)
    read_installed(web, sdks)
    for s in sdks:
        s.latest = latest.get(s.package_dir)
    return sdks


def is_outdated(s: Sdk) -> bool:
    baseline = s.installed or s.consumed
    if not baseline or not s.latest:
        return False
    lk, bk = parse_semver(s.latest), parse_semver(baseline)
    return bool(lk and bk and lk > bk)


def baseline_tag(s: Sdk) -> str | None:
    ver = s.installed or s.consumed
    return f"{s.package_dir}@{ver}" if ver else None


def target_tag(s: Sdk) -> str | None:
    return f"{s.package_dir}@{s.latest}" if s.latest else None


def cmd_diff(schemas: str, web: str, package_name: str, stat: bool) -> None:
    sdks = build_report(schemas, web)
    sdk = next((s for s in sdks if s.package_name == package_name or s.package_dir == package_name), None)
    if sdk is None:
        die(f"unknown package: {package_name}")
    base, target = baseline_tag(sdk), target_tag(sdk)
    if not base or not target:
        die(f"cannot determine baseline/target tags for {package_name} "
            f"(consumed={sdk.consumed}, installed={sdk.installed}, latest={sdk.latest})")
    for t in (base, target):
        if not tag_exists(schemas, t):
            die(f"tag {t} does not exist in the schemas repo. "
                f"Run `git -C {schemas} fetch --tags` and retry.")
    args = ["diff"]
    if stat:
        args.append("--stat")
    args += [base, target, "--", sdk.spec_path]
    print(f"# git diff {base}..{target} -- {sdk.spec_path}\n")
    sys.stdout.write(git(schemas, *args))


def cmd_report(schemas: str, web: str, as_json: bool) -> None:
    sdks = build_report(schemas, web)
    consumed = [s for s in sdks if s.consumed or s.installed]

    if as_json:
        payload = [{
            "packageName": s.package_name,
            "packageDir": s.package_dir,
            "specPath": s.spec_path,
            "configureFn": s.configure_fn,
            "consumed": s.consumed,
            "installed": s.installed,
            "latest": s.latest,
            "outdated": is_outdated(s),
            "baselineTag": baseline_tag(s),
            "targetTag": target_tag(s),
            "consumedIn": s.consumed_files,
        } for s in consumed]
        print(json.dumps(payload, indent=2))
        return

    if not consumed:
        print("No @ucmp SDKs from sdk.config.ts are consumed by the web repo.")
        return

    print(f"{'PACKAGE':<34} {'CONSUMED':<12} {'INSTALLED':<12} {'LATEST':<10} STATUS")
    print("-" * 82)
    outdated = []
    for s in sorted(consumed, key=lambda x: x.package_name):
        status = "OUTDATED" if is_outdated(s) else "up-to-date"
        if is_outdated(s):
            outdated.append(s)
        print(f"{s.package_name:<34} {str(s.consumed):<12} {str(s.installed or '-'):<12} {str(s.latest or '-'):<10} {status}")

    if outdated:
        print("\nOutdated SDKs — diff each spec, then decide whether to adopt:")
        for s in outdated:
            print(f"  {s.package_name}: {baseline_tag(s)} -> {target_tag(s)}")
            print(f"    spec:      {s.spec_path}")
            print(f"    consumedIn: {', '.join(s.consumed_files) or '(range only)'}")
            print(f"    diff:      --diff {s.package_name}")
    else:
        print("\nAll consumed SDKs are up to date. Nothing to adopt.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--schemas", required=True, help="path to the ecommerce-schemas repo")
    ap.add_argument("--web", required=True, help="path to the ecommerce-web repo")
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON report")
    ap.add_argument("--diff", metavar="PACKAGE", help="print the OpenAPI spec diff for one package")
    ap.add_argument("--stat", action="store_true", help="with --diff, show a diffstat summary only")
    args = ap.parse_args()

    schemas = os.path.abspath(os.path.expanduser(args.schemas))
    web = os.path.abspath(os.path.expanduser(args.web))
    for label, path in (("schemas", schemas), ("web", web)):
        if not os.path.isdir(path):
            die(f"{label} path is not a directory: {path}")

    if args.diff:
        cmd_diff(schemas, web, args.diff, args.stat)
    else:
        cmd_report(schemas, web, args.json)


if __name__ == "__main__":
    main()
