# BFF Boundaries

Keep generated backend SDKs behind the app's BFF boundary.

## SDK imports

- Import `@ucmp/sdk-search-api` and `@ucmp/sdk-visitor-profile-api` only from BFF contracts, upstream services, use cases, and dedicated BFF adapter modules under `apps/web/src/**/bff/`.
- Do not import these SDKs from pages, layouts, route consumers, components, hooks, client services, or other UI-facing modules.
- UI-facing code should consume local BFF-owned contracts and view models. Define or infer those contracts at the BFF boundary rather than re-exporting generated SDK types through feature UI code.
- When an SDK exposes one function per route, wrap the route function in the owning BFF service and translate its request, response, and error shape there.
- Runtime SDK values such as enums should be translated to local contract values when they cross the BFF boundary; do not make generated enum names part of the UI contract.

## Existing code

Existing direct imports outside `bff/` are migration targets, not a reason to add new ones. When touching such a module, move the SDK dependency into the nearest BFF contract or adapter and update the consumer to use the local contract.

Exceptions should be limited to SDK integration tests or package/tooling code that directly verifies the generated client.
