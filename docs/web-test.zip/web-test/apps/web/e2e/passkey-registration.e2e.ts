import { type CDPSession, expect, type Page, test } from "@playwright/test";

/**
 * Real-browser passkey registration against the mock BFF, using Chromium's
 * CDP virtual authenticator (no Touch ID / Windows Hello needed).
 * Requires USE_AUTH_MOCKS=true and a local target (the harness page 404s otherwise).
 *
 *   pnpm --filter web e2e passkey-registration
 */

test.skip(
  ({ browserName }) => browserName !== "chromium",
  "CDP virtual authenticator is Chromium-only"
);

async function addVirtualAuthenticator(page: Page): Promise<CDPSession> {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("WebAuthn.enable");
  await cdp.send("WebAuthn.addVirtualAuthenticator", {
    options: {
      protocol: "ctap2",
      transport: "internal",
      hasResidentKey: true,
      hasUserVerification: true,
      isUserVerified: true,
      automaticPresenceSimulation: true,
    },
  });
  return cdp;
}

/** Unique shopper per test so runs never share mock state. */
async function signInFreshShopper(page: Page) {
  await page.getByLabel("Email").fill(`e2e-${crypto.randomUUID()}@example.test`);
  await page.getByRole("button", { name: "1. Mock sign-in (T1)" }).click();
  await expect(page.getByText("mock sign-in → HTTP 200")).toBeVisible();
}

async function readProfile(page: Page) {
  return await page.evaluate(async () => {
    const response = await fetch("/api/v1/auth/profile", { credentials: "same-origin" });
    return (await response.json()) as {
      data: { tier: string; metadata: { auth: { passkeys: unknown[] } } };
    };
  });
}

test("OTP-equivalent sign-in → create passkey → listed, still T1", async ({ page }) => {
  await addVirtualAuthenticator(page);
  await page.goto("/demo/passkey-bff");

  await signInFreshShopper(page);

  await page.getByRole("button", { name: "2. Create passkey" }).click();
  await expect(page.getByText("registered ✓ — tier still T1")).toBeVisible();

  const profile = await readProfile(page);
  expect(profile.data.tier).toBe("T1");
  expect(profile.data.metadata.auth.passkeys).toHaveLength(1);
});

test("the same authenticator cannot register twice (excludeCredentials)", async ({ page }) => {
  await addVirtualAuthenticator(page);
  await page.goto("/demo/passkey-bff");

  await signInFreshShopper(page);
  await page.getByRole("button", { name: "2. Create passkey" }).click();
  await expect(page.getByText("registered ✓ — tier still T1")).toBeVisible();

  await page.getByRole("button", { name: "2. Create passkey" }).click();
  await expect(
    page.getByText(/register failed: (AUTHENTICATOR_ALREADY_REGISTERED|CANCELLED)/)
  ).toBeVisible();
  expect((await readProfile(page)).data.metadata.auth.passkeys).toHaveLength(1);
});

test("registration without a session is rejected", async ({ page }) => {
  await addVirtualAuthenticator(page);
  await page.goto("/demo/passkey-bff");
  await page.getByRole("button", { name: "2. Create passkey" }).click();
  await expect(page.getByText("register failed: UNAUTHENTICATED")).toBeVisible();
});
