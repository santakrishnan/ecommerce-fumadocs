import * as React from "react"
import { mergeProps } from "@base-ui/react/merge-props"
import { useRender } from "@base-ui/react/use-render"

import { cn } from "@/lib/utils"

export type CardSize = "lg" | "md" | "sm"

/** Shared base classes for Card and PolyCard surfaces. */
const cardClasses = "group/card flex flex-col overflow-clip rounded-xl bg-card text-sm text-card-foreground has-[>img:first-child]:pt-0 has-[>img:last-child]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl"

// Vertical padding on the Card/PolyCard root, keyed by size (read from the
// element's own data-size).
const CARD_PY =
  "data-[size=lg]:py-8 data-[size=lg]:lg:py-10 data-[size=lg]:xl:py-14 " +
  "data-[size=md]:py-8 data-[size=md]:lg:py-8 data-[size=md]:xl:py-10 " +
  "data-[size=sm]:py-5 data-[size=sm]:xl:py-8"

// Horizontal padding on subcomponents (CardHeader, CardContent, CardFooter),
// read from the ancestor Card's data-size via group-data-[size=]/card.
const CONTENT_PX =
  "group-data-[size=lg]/card:px-6 group-data-[size=lg]/card:lg:px-8 group-data-[size=lg]/card:xl:px-10 " +
  "group-data-[size=md]/card:px-6 group-data-[size=md]/card:lg:px-6 group-data-[size=md]/card:xl:px-8 " +
  "group-data-[size=sm]/card:px-4 group-data-[size=sm]/card:xl:px-6"

// ─── Card (static div) ──────────────────────────────────────────────

interface CardProps extends React.ComponentProps<"div"> {
  /**
   * Selects the built-in responsive padding scale (`"sm" | "md" | "lg"`).
   * Prefer this over hand-rolled padding classes. Defaults to `"lg"`.
   */
  size?: CardSize
  /**
   * Opt out of the default vertical (top/bottom) padding, leaving the card
   * with none.
   *
   * To apply custom padding instead, pass your own `py-*` / `p-*` classes
   * alongside it — `disablePadding` clears the default scale so your classes
   * apply cleanly, and you own every breakpoint from there.
   *
   * Full-bleed or image-only cards can set this alone on the `Card` and skip
   * subcomponents entirely rather than zeroing padding on each one.
   */
  disablePadding?: boolean
}

/**
 * Card — a static surface container. Renders a plain `<div>`.
 *
 * Use this for non-interactive cards. For cards that need to render as a
 * link or button, use `PolyCard` with the `render` prop instead.
 */
function Card({ className, size = "lg", disablePadding = false, ...props }: CardProps) {
  return (
    <div
      data-slot="card"
      data-size={size}
      className={cn(cardClasses, !disablePadding && CARD_PY, className)}
      {...props}
    />
  )
}

// ─── PolyCard (polymorphic card) ────────────────────────────────────

interface PolyCardProps extends useRender.ComponentProps<"div"> {
  /**
   * Selects the built-in responsive padding scale (`"sm" | "md" | "lg"`).
   * Prefer this over hand-rolled padding classes. Defaults to `"lg"`.
   */
  size?: CardSize
  /**
   * Opt out of the default vertical (top/bottom) padding, leaving the card
   * with none.
   *
   * To apply custom padding instead, pass your own `py-*` / `p-*` classes
   * alongside it — `disablePadding` clears the default scale so your classes
   * apply cleanly, and you own every breakpoint from there.
   *
   * Full-bleed or image-only cards can set this alone on the `Card` and skip
   * subcomponents entirely rather than zeroing padding on each one.
   */
  disablePadding?: boolean
}

/**
 * PolyCard — a polymorphic card surface via Base UI's `useRender`.
 *
 * Renders with the shared card classes and emits `data-slot="card"`.
 * Pass a `render` prop to change the underlying element (link, button, etc.).
 * When no `render` is provided, behaves identically to `Card` (static div).
 *
 * No wrapper div, no adornments slot — consumers compose their own DOM
 * structure around it as needed.
 *
 * @example
 * // As a navigable link
 * <PolyCard render={<a href="/detail" aria-label="View details" />} className="p-6">
 *   <CardContent>...</CardContent>
 * </PolyCard>
 *
 * @example
 * // As a button
 * <PolyCard render={<button type="button" onClick={handleClick} />} className="text-left">
 *   <CardContent>...</CardContent>
 * </PolyCard>
 */
function PolyCard({
  className,
  size = "lg",
  disablePadding = false,
  render,
  children,
  ...props
}: PolyCardProps) {
  return useRender({
    render,
    props: mergeProps<"div">(
      {
        ...{ "data-size": size },
        className: cn(cardClasses, !disablePadding && CARD_PY, className),
        children,
      },
      props
    ),
    defaultTagName: "div",
    state: { slot: "card", size },
  })
}

// ─── Subcomponents (shared by both) ─────────────────────────────────

interface CardHeaderProps extends React.ComponentProps<"div"> {
  /**
   * Opt out of the default horizontal (left/right) padding for this section,
   * leaving it with none.
   *
   * To apply custom padding instead, pass your own `px-*` / `p-*` classes
   * alongside it — `disablePadding` clears the default scale so your classes
   * apply cleanly, and you own every breakpoint from there.
   */
  disablePadding?: boolean
}

function CardHeader({ className, disablePadding = false, ...props }: CardHeaderProps) {
  return (
    <div
      data-slot="card-header"
      className={cn(
        "group/card-header @container/card-header grid auto-rows-min items-start gap-1 rounded-t-xl",
        !disablePadding && CONTENT_PX,
        "has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto]",
        "[.border-b]:pb-6",
        className
      )}
      {...props}
    />
  )
}

function CardTitle({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="card-title"
      className={cn(
        "text-sm leading-heading font-bold tracking-tightest md:text-sm lg:text-base xl:text-base",
        className
      )}
      {...props}
    />
  )
}

function CardDescription({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="card-description"
      className={cn(
        "text-xs leading-body tracking-tighter text-muted-foreground md:text-xs lg:text-xs xl:text-xs",
        className
      )}
      {...props}
    />
  )
}

function CardAction({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="card-action"
      className={cn(
        "col-start-2 row-span-2 row-start-1 self-start justify-self-end",
        className
      )}
      {...props}
    />
  )
}

interface CardContentProps extends React.ComponentProps<"div"> {
  /**
   * Opt out of the default horizontal (left/right) padding for this section,
   * leaving it with none.
   *
   * To apply custom padding instead, pass your own `px-*` / `p-*` classes
   * alongside it — `disablePadding` clears the default scale so your classes
   * apply cleanly, and you own every breakpoint from there.
   */
  disablePadding?: boolean
}

function CardContent({ className, disablePadding = false, ...props }: CardContentProps) {
  return (
    <div
      data-slot="card-content"
      className={cn(!disablePadding && CONTENT_PX, className)}
      {...props}
    />
  )
}

interface CardFooterProps extends React.ComponentProps<"div"> {
  /**
   * Opt out of the default horizontal (left/right) padding for this section,
   * leaving it with none.
   *
   * To apply custom padding instead, pass your own `px-*` / `p-*` classes
   * alongside it — `disablePadding` clears the default scale so your classes
   * apply cleanly, and you own every breakpoint from there.
   */
  disablePadding?: boolean
}

function CardFooter({ className, disablePadding = false, ...props }: CardFooterProps) {
  return (
    <div
      data-slot="card-footer"
      className={cn(
        "flex items-center rounded-b-xl",
        !disablePadding && CONTENT_PX,
        "[.border-t]:pt-6",
        className
      )}
      {...props}
    />
  )
}

export {
  Card,
  PolyCard,
  CardHeader,
  CardFooter,
  CardTitle,
  CardAction,
  CardDescription,
  CardContent,
}
export type {
  CardProps,
  PolyCardProps,
  CardHeaderProps,
  CardContentProps,
  CardFooterProps,
}
