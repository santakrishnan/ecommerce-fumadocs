"use client"

import { useMemo } from "react"
import type { ComponentProps, MouseEventHandler } from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { Label } from "@/components/label"
import { Separator } from "@/components/separator"
import { IconExclamation } from "@/icons/exclamation"

interface FieldSetProps extends React.ComponentProps<"fieldset"> {}

function FieldSet({ className, ...props }: FieldSetProps) {
  return (
    <fieldset
      data-slot="field-set"
      className={cn(
        // Layout
        "flex flex-col gap-6",

        // Gap override for choice-control groups
        "has-[>[data-slot=checkbox-group]]:gap-3 has-[>[data-slot=radio-group]]:gap-3",

        // Gap override for choice cards (FieldChoice or FieldLabel children wrapping a Field)
        "has-[>[data-slot=field-choice]]:gap-2 has-[>[data-slot=field-label]]:gap-2",

        className
      )}
      {...props}
    />
  )
}

interface FieldLegendProps extends React.ComponentProps<"legend"> {
  variant?: "legend" | "label"
}

function FieldLegend({
  className,
  variant = "legend",
  ...props
}: FieldLegendProps) {
  return (
    <legend
      data-slot="field-legend"
      data-variant={variant}
      className={cn(
        // Layout and typography
        "mb-3 font-semibold text-text-primary",

        // Variant sizing
        "data-[variant=label]:text-sm data-[variant=legend]:text-base",

        className
      )}
      {...props}
    />
  )
}

const fieldGroupVariants = cva(
  [
    "group/field-group @container/field-group flex w-full",

    // Gap overrides for choice-control groups and nested groups.
    "data-[slot=checkbox-group]:gap-3 *:data-[slot=field-group]:gap-4",
  ].join(" "),
  {
    variants: {
      orientation: {
        vertical: "flex-col gap-6",
        horizontal: "flex-row flex-wrap gap-2",
      },
    },
    defaultVariants: {
      orientation: "vertical",
    },
  }
)

interface FieldGroupProps
  extends React.ComponentProps<"div">,
    VariantProps<typeof fieldGroupVariants> {}

function FieldGroup({
  className,
  orientation = "vertical",
  ...props
}: FieldGroupProps) {
  return (
    <div
      data-slot="field-group"
      data-orientation={orientation}
      className={cn(
        fieldGroupVariants({ orientation }),

        className
      )}
      {...props}
    />
  )
}

const fieldVariants = cva(
  "group/field @container/field flex w-full gap-3 has-[>[role=checkbox],[role=radio]]:gap-2 data-[invalid=true]:text-destructive",
  {
    variants: {
      orientation: {
        vertical: "flex-col *:w-full [&>.sr-only]:w-auto",
        horizontal:
          "flex-row items-center has-[>[data-slot=field-content]]:items-start *:data-[slot=field-label]:flex-auto has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
        responsive:
          "flex-col *:w-full @md/field-group:flex-row @md/field-group:items-center @md/field-group:*:w-auto @md/field-group:has-[>[data-slot=field-content]]:items-start @md/field-group:*:data-[slot=field-label]:flex-auto [&>.sr-only]:w-auto @md/field-group:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
      },
    },
    defaultVariants: {
      orientation: "vertical",
    },
  }
)

interface FieldProps extends React.ComponentProps<"div">, VariantProps<typeof fieldVariants> {}

function Field({
  className,
  orientation = "vertical",
  ...props
}: FieldProps) {
  return (
    <div
      role="group"
      data-slot="field"
      data-orientation={orientation}
      className={cn(
        fieldVariants({ orientation }),
        "transition-colors has-[>[data-slot=floating-label]]:relative",
        className
      )}
      {...props}
    />
  )
}

interface FieldContentProps extends React.ComponentProps<"div"> {}

function FieldContent({ className, ...props }: FieldContentProps) {
  return (
    <div
      data-slot="field-content"
      className={cn(
        // Layout and typography
        "group/field-content flex flex-1 flex-col gap-1.5 leading-snug",

        // Disabled state
        "group-data-[disabled=true]/field:pointer-events-none",

        className
      )}
      {...props}
    />
  )
}

// Choice-card container styles
const fieldChoiceCardStyles = [
    "has-[>[data-slot=field]]:rounded-lg has-[>[data-slot=field]]:border has-[>[data-slot=field]]:border-transparent has-[>[data-slot=field]]:bg-neutral-50",
    "has-[>[data-slot=field]]:transition-colors has-[>[data-slot=field]]:w-full has-[>[data-slot=field]]:flex has-[>[data-slot=field]]:flex-col",
    "has-[>[data-slot=field]]:px-6 has-[>[data-slot=field]]:py-8",
    "lg:has-[>[data-slot=field]]:px-8 lg:has-[>[data-slot=field]]:py-10",
    "xl:has-[>[data-slot=field]]:px-10 xl:has-[>[data-slot=field]]:py-14",

    // Cursor: the whole card surface is clickable, except when its Field (or a
    // descendant of it) is disabled. Shared by both the label and div surfaces.
    "has-[>[data-slot=field]]:cursor-pointer",
    "has-[>[data-slot=field][data-disabled]]:cursor-default",
    "[&>[data-slot=field][data-disabled]_*]:cursor-default"
].join(" ")

const fieldLabelVariants = cva(
  [
    // Layout and base
    "group/field-label peer/field-label flex w-fit gap-2 leading-snug",

    // Transitions
    "transition-[color,opacity]",

    // Disabled state
    "group-data-[disabled=true]/field:pointer-events-none group-data-[disabled=true]/field:text-text-inactive",

    // Invalid state
    "group-data-[invalid=true]/field:text-destructive",

    // Choice-card container (wrapping a nested Field) — includes card cursor rules
    fieldChoiceCardStyles
  ].join(" "),
  {
    variants: {
      variant: {
        default: "font-semibold",
        sublabel: "text-xs font-normal",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

interface FieldLabelProps
  extends React.ComponentProps<typeof Label>,
    VariantProps<typeof fieldLabelVariants> {}

/**
 * Label for a `Field`. Also doubles as a choice-card container when it wraps a
 * nested `Field` (styled via `fieldChoiceCardStyles`).
 *
 * @remarks
 * In choice-card mode the whole surface is a native `<label>`, so a click
 * anywhere inside it activates the associated control. That makes it unsuitable
 * for cards that need additional independent interactive elements (a `Select`,
 * `Button`, extra links, etc.) — those clicks would be swallowed by the label.
 *
 * For that case use {@link FieldChoice} in `activatesId` (div) mode instead: it
 * renders a plain container that only activates the control from the card
 * surface and lets nested interactive elements work on their own.
 */
function FieldLabel({
  className,
  variant = "default",
  ...props
}: FieldLabelProps) {
  return (
    <Label
      data-slot="field-label"
      className={cn(fieldLabelVariants({ variant }), className)}
      {...props}
    />
  )
}

// Elements that already produce their own activation when clicked, so the card
/**
/**
 * Whether a div-mode card click should forward to the main control. Skips the
 * control itself and its associated `<label>` (both toggle it natively — avoids
 * double-toggle) and any additional `Field`. Other opt-outs are the consumer's
 * job via `stopPropagation`/`preventDefault`.
 */
function shouldForwardFieldChoiceClick(
  target: EventTarget | null,
  currentTarget: HTMLElement,
  control: HTMLElement | null,
  activatesId: string
): boolean {
  if (!(target instanceof Element) || !currentTarget.contains(target)) {
    return false
  }

  // (1) The main control itself — let its native click toggle it, don't double-fire.
  if (control && control.contains(target)) {
    return false
  }

  // (1b) A `<label>` associated with the control — it forwards natively too.
  const label = target.closest("label")

  if (label instanceof HTMLLabelElement && label.htmlFor === activatesId) {
    return false
  }

  // (2) Additional Fields — a nested Field that doesn't contain the main control.
  const nearestField = target.closest("[data-slot='field']")

  if (nearestField === null) {
    return true
  }

  return control !== null && nearestField.contains(control)
}

interface FieldChoiceLabelProps
  extends Omit<FieldLabelProps, "htmlFor" | "onClick"> {
  htmlFor: string
  activatesId?: never
  onClick?: MouseEventHandler<HTMLElement>
}

interface FieldChoiceActivatesProps
  extends Omit<ComponentProps<"div">, "onClick"> {
  activatesId: string
  htmlFor?: never
  onClick?: MouseEventHandler<HTMLElement>
}

type FieldChoiceProps = FieldChoiceLabelProps | FieldChoiceActivatesProps

/**
 * Clickable choice card — activates a control when the card surface is clicked.
 *
 * **Two rendering modes:**
 * - `htmlFor` (label mode): Delegates to `<FieldLabel>` for native semantics. Clicking
 *   the card or any child activates the associated control.
 * - `activatesId` (div mode): Clicking the card surface activates the control.
 *   The control itself and any additional `Field` (e.g. an extra `Select`) are
 *   left alone. For other interactive children, call `event.stopPropagation()`
 *   to opt out. Requires a separate `<FieldLabel htmlFor="...">` for the label.
 *
 * @example
 * // Label mode: simple pattern
 * <FieldChoice htmlFor="checkbox-id">
 *   <Field><Checkbox id="checkbox-id" /></Field>
 * </FieldChoice>
 *
 * @example
 * // Div mode: multi-field card with independent `select`s
 * <FieldChoice activatesId="primary-control-id">
 *   <Field>
 *     <FieldLabel htmlFor="primary-control-id"><FieldTitle>Primary</FieldTitle></FieldLabel>
 *     <Checkbox id="primary-control-id" />
 *   </Field>
 *   <Field><Select>...</Select></Field>
 * </FieldChoice>
 */
function FieldChoice(props: FieldChoiceProps) {
  if ("activatesId" in props) {
    const {
      className,
      activatesId,
      onClick,
      children,
      ...divProps
    } = props as FieldChoiceActivatesProps

    // Div mode with click interception (for complex multi-field choices)
    return (
      <div
        data-slot="field-choice"
        className={cn("gap-y-6", fieldChoiceCardStyles, className)}
        onClick={(event) => {
          onClick?.(event)

          // Bail if a consumer's handler already handled the event.
          if (event.defaultPrevented) {
            return
          }

          const control = event.currentTarget.ownerDocument.getElementById(activatesId) as HTMLElement | null

          // Only forward card-surface clicks to the main control — not clicks on
          // the control itself or inside an additional Field.
          if (!shouldForwardFieldChoiceClick(event.target, event.currentTarget, control, activatesId)) {
            return
          }

          if (
            control &&
            !control.matches(":disabled, [aria-disabled=true], [data-disabled=true]")
          ) {
            control.click()
          }
        }}
        {...divProps}
      >
        {children}
      </div>
    )
  }

  const {
    className,
    variant = "default",
    htmlFor,
    onClick,
    children,
    ...labelProps
  } = props as FieldChoiceLabelProps

  // Delegate to FieldLabel for native label mode
  return (
    <FieldLabel
      data-slot="field-choice"
      htmlFor={htmlFor}
      variant={variant}
      className={className}
      onClick={onClick as MouseEventHandler<HTMLLabelElement>}
      {...labelProps}
    >
      {children}
    </FieldLabel>
  )
}


interface FieldTitleProps extends React.ComponentProps<"div"> {}

function FieldTitle({ className, ...props }: FieldTitleProps) {
  return (
    <div
      data-slot="field-label"
      className={cn(
        // Layout and typography
        "flex w-fit items-center gap-2 subhead-lg text-text-primary",

        // Disabled state
        "group-data-[disabled=true]/field:text-text-inactive",

        // Choice card
        "in-data-[slot=field-label]:text-text-primary-light",
        "in-data-[slot=field-label]:group-data-[disabled=true]/field:text-text-inactive-light",
        "group-data-[invalid=true]/field:text-destructive",

        className
      )}
      {...props}
    />
  )
}

interface FieldDescriptionProps extends React.ComponentProps<"p"> {}

function FieldDescription({ className, ...props }: FieldDescriptionProps) {
  return (
    <p
      data-slot="field-description"
      className={cn(
        // Typography and layout
        "text-left body-sm text-text-tertiary",

        // Context-aware adjustments
        "group-has-data-horizontal/field:text-balance [[data-variant=legend]+&]:-mt-1.5",

        // Sibling spacing
        "last:mt-0 nth-last-2:-mt-1",

        // Link styling
        "[&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-text-primary",

        // Choice card
        "in-data-[slot=field-label]:text-text-tertiary-light",
        "in-data-[slot=field-label]:group-data-[disabled=true]/field:text-text-inactive-light",
        "in-data-[slot=field-label]:group-data-[invalid=true]/field:text-destructive",


        className
      )}
      {...props}
    />
  )
}

interface FieldSeparatorProps extends React.ComponentProps<"div"> {
  children?: React.ReactNode
}

function FieldSeparator({
  children,
  className,
  ...props
}: FieldSeparatorProps) {
  return (
    <div
      data-slot="field-separator"
      data-content={!!children}
      className={cn(
        // Layout
        "relative -my-2 h-5 text-sm",

        // Outline variant adjustment
        "group-data-[variant=outline]/field-group:-mb-2",

        className
      )}
      {...props}
    >
      <Separator className="absolute inset-x-0 top-1/2" />
      {children && (
        <span
          className="relative mx-auto block w-fit bg-background px-2 text-text-secondary"
          data-slot="field-separator-content"
        >
          {children}
        </span>
      )}
    </div>
  )
}

const fieldErrorVariants = cva("text-left", {
  variants: {
    variant: {
      inline: "text-sm font-normal text-destructive",
      banner: [
        "flex items-start gap-1 rounded-md py-3 pr-4 pl-3",
        "bg-destructive body-md text-destructive-foreground",
        "[&>svg]:pointer-events-none [&>svg]:size-5",
      ].join(" "),
    },
  },
  defaultVariants: {
    variant: "inline",
  },
})

interface FieldErrorProps
  extends React.ComponentProps<"div">,
    VariantProps<typeof fieldErrorVariants> {
  errors?: Array<{ message?: string } | undefined>
}

/**
 * Validation message for a `Field` (`role="alert"`). Pass `children` for a
 * single message or `errors` for a deduped list. The `banner` variant expects a
 * single message — use `inline` (default) for the multi-error list.
 */
function FieldError({
  className,
  children,
  errors,
  variant = "inline",
  ...props
}: FieldErrorProps) {
  const content = useMemo(() => {
    if (children) {
      return children
    }

    if (!errors?.length) {
      return null
    }

    const uniqueErrors = [
      ...new Map(errors.map((error) => [error?.message, error])).values(),
    ]

    if (uniqueErrors?.length == 1) {
      return uniqueErrors[0]?.message
    }

    return (
      <ul className="ml-4 flex list-disc flex-col gap-1">
        {uniqueErrors.map(
          (error, index) =>
            error?.message && <li key={index}>{error.message}</li>
        )}
      </ul>
    )
  }, [children, errors])

  if (!content) {
    return null
  }

  return (
    <div
      role="alert"
      data-slot="field-error"
      data-variant={variant}
      className={cn(fieldErrorVariants({ variant }), className)}
      {...props}
    >
      {variant === "banner" && <IconExclamation />}
      {content}
    </div>
  )
}

interface FloatingLabelProps extends Omit<FieldLabelProps, "variant"> {}

/**
 * Floating label for text field composition.
 *
 * Animates between resting (centered, full-size) and floating (top, scaled-down)
 * positions using pure CSS peer selectors. No JavaScript state is involved.
 *
 * @remarks
 * - Must be rendered immediately after the field surface in DOM order
 * - Parent `Field` must have `className="relative"` for absolute positioning
 * - `htmlFor` is required for accessibility when used with `FloatingInput`
 * - When used with `Select`, the `Select` component renders the peer wrapper
 *   needed for the label to read trigger focus/open/value state via CSS
 *
 * @example
 * ```tsx
 * <Field className="relative">
 *   <FloatingInput id="name" />
 *   <FloatingLabel htmlFor="name">Full Name</FloatingLabel>
 * </Field>
 * ```
 */
function FloatingLabel({
  className,
  children,
  ...props
}: FloatingLabelProps) {
  return (
    <Label
      data-slot="floating-label"
      className={cn(
        // positioning — centered vertically in the input/trigger at rest
        "absolute left-5 pr-10 top-9 -translate-y-1/2",

        // resting state typography: 14px, weight 400, secondary color
        "text-sm font-normal text-text-secondary-light",

        // animation
        "transition-all duration-200 ease-out",
        "pointer-events-none select-none origin-left",

        // lifted: input focused — shrinks to 12px, centered group with 4px gap above value
        "peer-focus:top-4 peer-focus:translate-y-0 peer-focus:text-xs",

        // lifted: input has a value (placeholder no longer shown)
        "peer-not-placeholder-shown:top-4",
        "peer-not-placeholder-shown:translate-y-0",
        "peer-not-placeholder-shown:text-xs",

        // Select wrapper: reserve space for the chevron and float when focused,
        // open, or once a value is selected.
        "peer-data-[slot=select]/select:pr-15",
        "peer-has-[>[data-slot=select-trigger]:focus-visible]/select:top-4",
        "peer-has-[>[data-slot=select-trigger]:focus-visible]/select:translate-y-0",
        "peer-has-[>[data-slot=select-trigger]:focus-visible]/select:text-xs",
        "peer-has-[>[data-slot=select-trigger][data-popup-open]]/select:top-4",
        "peer-has-[>[data-slot=select-trigger][data-popup-open]]/select:translate-y-0",
        "peer-has-[>[data-slot=select-trigger][data-popup-open]]/select:text-xs",
        "peer-has-[>[data-slot=select-trigger]:not([data-placeholder])]/select:top-4",
        "peer-has-[>[data-slot=select-trigger]:not([data-placeholder])]/select:translate-y-0",
        "peer-has-[>[data-slot=select-trigger]:not([data-placeholder])]/select:text-xs",

        // error state — from parent Field
        "group-data-[invalid=true]/field:text-destructive",
        "group-data-[invalid=true]/field:peer-focus:text-destructive",

        // disabled state
        "peer-disabled:text-text-inactive-light",
        "peer-has-[>[data-slot=select-trigger]:disabled]/select:text-text-inactive-light",

        className
      )}
      {...props}
    >
      <span className="truncate">{children}</span>
    </Label>
  )
}

export {
  Field,
  FieldLabel,
  FieldChoice,
  FieldDescription,
  FieldError,
  FieldGroup,
  FloatingLabel,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldContent,
  FieldTitle,
}

export type {
  FieldProps,
  FieldLabelProps,
  FieldChoiceProps,
  FieldDescriptionProps,
  FieldErrorProps,
  FieldGroupProps,
  FloatingLabelProps,
  FieldLegendProps,
  FieldSeparatorProps,
  FieldSetProps,
  FieldContentProps,
  FieldTitleProps,
}
