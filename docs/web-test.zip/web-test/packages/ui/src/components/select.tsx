"use client"

import * as React from "react"
import {
  Select as SelectPrimitive,
  type SelectRootProps,
} from "@base-ui/react/select"
import { cva } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { IconCaretDown, IconCaretUp } from "@/icons"

type SelectVariant = "default" | "outlined"

const SelectContext = React.createContext<SelectVariant>("default")

interface SelectProps<Value = string, Multiple extends boolean = false>
  extends SelectRootProps<Value, Multiple> {
  variant?: SelectVariant
}

function Select<Value = string, Multiple extends boolean = false>({
  variant = "default",
  children,
  ...props
}: SelectProps<Value, Multiple>) {
  return (
    <SelectContext value={variant}>
      <div data-slot="select" className="peer/select relative w-full">
        <SelectPrimitive.Root {...props}>{children}</SelectPrimitive.Root>
      </div>
    </SelectContext>
  )
}

interface SelectGroupProps extends SelectPrimitive.Group.Props {}

function SelectGroup({ className, ...props }: SelectGroupProps) {
  return (
    <SelectPrimitive.Group
      data-slot="select-group"
      className={cn("scroll-my-1 p-1", className)}
      {...props}
    />
  )
}

interface SelectValueProps extends SelectPrimitive.Value.Props {}

function SelectValue({ className, ...props }: SelectValueProps) {
  return (
    <SelectPrimitive.Value
      data-slot="select-value"
      className={cn("flex flex-1 text-left", className)}
      {...props}
    />
  )
}

interface BaseSelectTriggerProps extends SelectPrimitive.Trigger.Props {}

/**
 * The base (unstyled-label) select trigger built directly on Base UI's
 * `Select.Trigger`. {@link SelectTrigger} composes this with the floating-label
 * behavior; use `BaseSelectTrigger` directly only when you need a plain trigger
 * without the floating label.
 */
function BaseSelectTrigger({
  className,
  children,
  ...props
}: BaseSelectTriggerProps) {
  return (
    <SelectPrimitive.Trigger
      data-slot="select-trigger"
      className={cn(
        // Layout
        "flex w-full items-center justify-between gap-1.5",
        // Size & shape
        "h-9 rounded-lg border border-input bg-neutral-50 px-5 py-2 body-sm text-text-primary-light",
        // Behavior
        "shadow-none transition-[color,box-shadow] outline-none whitespace-nowrap",
        // Focus
        "focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50",
        "focus-visible:border-b-transparent",
        // Open
        "data-popup-open:border-b-transparent",
        // Disabled
        "disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-surface-inactive disabled:text-text-inactive-light",
        // Invalid
        "aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20",
        // Placeholder
        "data-placeholder:text-text-secondary-light disabled:data-placeholder:text-text-inactive-light",
        "data-popup-open:data-placeholder:text-text-secondary-light",
        // Value display
        "*:data-[slot=select-value]:flex",
        "*:data-[slot=select-value]:items-center",
        "*:data-[slot=select-value]:gap-1.5",
        "*:data-[slot=select-value]:flex-1",
        "*:data-[slot=select-value]:text-left",
        // Dark mode
        "dark:bg-input/30",
        "dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40",
        // Icon
        "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg]:text-text-primary-light",
        "disabled:[&_svg]:text-text-inactive-light [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <span data-slot="select-trigger-value" className="line-clamp-1 w-full">
        {children}
      </span>
      <SelectPrimitive.Icon
        render={
          <span>
            <IconCaretDown className="size-4" />
          </span>
        }
      />
    </SelectPrimitive.Trigger>
  )
}

interface SelectTriggerProps extends SelectPrimitive.Trigger.Props {}

const selectTriggerVariants = cva(
  [
    // Override height/padding for floating label
    "relative h-18 pt-8.5 pb-4 rounded-xl pr-9",
    // When open, merge with the flush popup below by squaring the adjacent corners
    "data-popup-open:data-[popup-side=bottom]:rounded-b-none",
    "data-popup-open:data-[popup-side=top]:rounded-t-none",
    // Hide placeholder at rest, show when floating
    "data-placeholder:text-transparent disabled:data-placeholder:text-transparent",
    "data-popup-open:data-placeholder:text-text-secondary-light",
    // Reposition chevron to vertical center (asymmetric padding breaks flex centering)
    "[&_svg]:absolute [&_svg]:top-1/2 [&_svg]:right-5 [&_svg]:-translate-y-1/2",
  ],
  {
    variants: {
      variant: {
        default: "border-neutral-50 disabled:border-surface-inactive",
        outlined: [
          "border-surface-secondary bg-surface-primary",
          "disabled:border-surface-secondary",
        ],
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

/**
 * The default select trigger: a {@link BaseSelectTrigger} composed with the
 * floating-label behavior (the label lifts on open or when a value is present).
 * This is the trigger most consumers should use; reach for
 * {@link BaseSelectTrigger} only when a plain, non-floating trigger is needed.
 */
function SelectTrigger({
  className,
  children,
  ...props
}: SelectTriggerProps) {
  const variant = React.use(SelectContext)

  return (
    <BaseSelectTrigger
      className={cn(
        selectTriggerVariants({ variant }),
        className
      )}
      {...props}
    >
      {children}
    </BaseSelectTrigger>
  )
}

interface SelectContentProps extends SelectPrimitive.Popup.Props,
  Pick<
    SelectPrimitive.Positioner.Props,
    "align" | "alignOffset" | "side" | "sideOffset" | "alignItemWithTrigger"
  > {}

/**
 * The dropdown popup for a Select.
 *
 * The popup stays fully delegated to Base UI portal/positioner behavior. The
 * floating-label pattern only affects the trigger surface and the sibling label.
 */
function SelectContent({
  className,
  children,
  side = "bottom",
  sideOffset,
  align = "center",
  alignOffset = 0,
  alignItemWithTrigger = false,
  ...props
}: SelectContentProps) {
  const variant = React.use(SelectContext)

  return (
    <SelectPrimitive.Portal>
      <SelectPrimitive.Positioner
        side={side}
        align={align}
        alignOffset={alignOffset}
        alignItemWithTrigger={alignItemWithTrigger}
        className="isolate z-50"
      >
        <SelectPrimitive.Popup
          data-slot="select-content"
          data-variant={variant}
          data-align-trigger={alignItemWithTrigger}
          className={cn(
            // Layout & sizing
            "relative isolate z-50 max-h-(--available-height) w-(--anchor-width) origin-(--transform-origin) overflow-x-hidden overflow-y-auto",
            // Surface
            "bg-popover text-popover-foreground",
            // Padding & surface
            "rounded-xl border border-neutral-200 border-x-0 px-2 pt-1 pb-2",
            "data-[side=bottom]:rounded-t-none data-[side=bottom]:border-t-0",
            "data-[side=top]:rounded-b-none data-[side=top]:border-b-0",
            // Outlined select: derive surface styling from the trigger variant via context.
            variant === "outlined" && "border-surface-secondary bg-surface-primary border-b border-x",
            variant === "outlined" && "data-[side=bottom]:border-t-0 data-[side=top]:border-b-0",
            // Animation
            "duration-100 data-[align-trigger=true]:animate-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",
            className
          )}
          {...props}
        >
          <SelectScrollUpButton />
          <SelectPrimitive.List>{children}</SelectPrimitive.List>
          <SelectScrollDownButton />
        </SelectPrimitive.Popup>
      </SelectPrimitive.Positioner>
    </SelectPrimitive.Portal>
  )
}

interface SelectLabelProps extends SelectPrimitive.GroupLabel.Props {}

/**
 * A group label rendered above a set of {@link SelectItem}s.
 *
 * Uses the Figma group-label spec (Body - Small, secondary text color) with a
 * bottom inset for separation.
 */
function SelectLabel({
  className,
  ...props
}: SelectLabelProps) {
  return (
    <SelectPrimitive.GroupLabel
      data-slot="select-label"
      className={cn(
        "body-sm text-text-secondary-light pb-3",
        "px-2 pt-1.5",
        className
      )}
      {...props}
    />
  )
}

interface SelectItemProps extends SelectPrimitive.Item.Props {}

/**
 * A selectable row within {@link SelectContent}.
 *
 * Uses the shared Base UI popup styling and does not depend on extra select
 * state plumbing.
 */
function SelectItem({
  className,
  children,
  ...props
}: SelectItemProps) {
  return (
    <SelectPrimitive.Item
      data-slot="select-item"
      className={cn(
        // Layout
        "relative flex w-full cursor-default items-center gap-2 outline-hidden select-none",
        // Typography (Figma: Body - Medium)
        "body-md text-text-primary-light",
        // Resting background (unselected)
        "bg-transparent",
        // Hover / keyboard focus — Figma Neutral/100
        "data-highlighted:bg-neutral-100 data-highlighted:text-text-primary-light",
        // Selected (current value) — Figma Neutral/100
        "data-selected:bg-neutral-100 data-selected:text-text-primary-light",
        // Disabled
        "data-disabled:pointer-events-none data-disabled:opacity-50",
        // Icons
        "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        "*:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2",
        // Padding & shape
        "min-h-12 rounded-md px-4 py-3 [[data-slot=select-item]+&]:mt-0.5",
        className
      )}
      {...props}
    >
      <SelectPrimitive.ItemText className="flex flex-1 shrink-0 gap-2 whitespace-nowrap">
        {children}
      </SelectPrimitive.ItemText>
    </SelectPrimitive.Item>
  )
}

interface SelectSeparatorProps extends SelectPrimitive.Separator.Props {}

/**
 * A divider between groups of items.
 *
 * Renders a 1px hairline in the Figma divider token. It no longer uses a
 * negative horizontal margin — the inset provided by {@link SelectContent}
 * padding keeps it from spanning the full popup width.
 */
function SelectSeparator({
  className,
  ...props
}: SelectSeparatorProps) {
  return (
    <SelectPrimitive.Separator
      data-slot="select-separator"
      className={cn("pointer-events-none my-1 h-px bg-divider-light", className)}
      {...props}
    />
  )
}

interface SelectScrollUpButtonProps extends React.ComponentProps<typeof SelectPrimitive.ScrollUpArrow> {}

function SelectScrollUpButton({
  className,
  ...props
}: SelectScrollUpButtonProps) {
  return (
    <SelectPrimitive.ScrollUpArrow
      data-slot="select-scroll-up-button"
      className={cn(
        "top-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <IconCaretUp className="text-primary-light"/>
    </SelectPrimitive.ScrollUpArrow>
  )
}

interface SelectScrollDownButtonProps extends React.ComponentProps<typeof SelectPrimitive.ScrollDownArrow> {}

function SelectScrollDownButton({
  className,
  ...props
}: SelectScrollDownButtonProps) {
  return (
    <SelectPrimitive.ScrollDownArrow
      data-slot="select-scroll-down-button"
      className={cn(
        "bottom-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <IconCaretDown className="text-primary-light"/>
    </SelectPrimitive.ScrollDownArrow>
  )
}

export {
  BaseSelectTrigger,
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectScrollDownButton,
  SelectScrollUpButton,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
}

export type {
  SelectProps,
  BaseSelectTriggerProps,
  SelectTriggerProps,
  SelectContentProps,
  SelectGroupProps,
  SelectValueProps,
  SelectLabelProps,
  SelectItemProps,
  SelectSeparatorProps,
  SelectScrollUpButtonProps,
  SelectScrollDownButtonProps,
}
