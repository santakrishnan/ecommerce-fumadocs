"use client"

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { Button } from "@/components/button"
import { FloatingInput, Input, type FloatingInputProps } from "@/components/input"
import {
  FloatingTextarea,
  Textarea,
  type FloatingTextareaProps,
} from "@/components/textarea"

export interface InputGroupProps extends React.ComponentProps<"div"> {}

function InputGroup({ className, ...props }: InputGroupProps) {
  return (
    <div
      data-slot="input-group"
      role="group"
      className={cn(
        "group/input-group relative flex gap-1 h-9 w-full min-w-0 items-center rounded-md border border-input bg-neutral-50 transition-colors outline-none in-data-[slot=combobox-content]:focus-within:border-inherit in-data-[slot=combobox-content]:focus-within:ring-0 has-[[data-slot=input-group-control]:focus-visible]:border-ring has-[[data-slot=input-group-control]:focus-visible]:ring-3 has-[[data-slot=input-group-control]:focus-visible]:ring-ring/50 has-[[data-slot][aria-invalid=true]]:border-destructive has-[[data-slot][aria-invalid=true]]:ring-3 has-[[data-slot][aria-invalid=true]]:ring-destructive/20 has-[>[data-align=block-end]]:h-auto has-[>[data-align=block-end]]:flex-col has-[>[data-align=block-start]]:h-auto has-[>[data-align=block-start]]:flex-col has-[>textarea]:h-auto dark:bg-input/30 dark:has-[[data-slot][aria-invalid=true]]:ring-destructive/40 has-[>[data-align=block-end]]:[&>input]:pt-3 has-[>[data-align=block-start]]:[&>input]:pb-3 has-[>[data-align=inline-end]]:[&>input]:pr-1.5 has-[>[data-align=inline-start]]:[&>input]:pl-1.5 data-[disabled=true]:pointer-events-none data-[disabled=true]:cursor-not-allowed data-[disabled=true]:bg-surface-inactive data-[disabled=true]:text-text-inactive-light",
        // Floating: grow to floating height/radius; default keeps the neutral fill, outlined uses a bordered white surface.
        "has-[[data-floating-variant]]:h-auto has-[[data-floating-variant]]:min-h-18 has-[[data-floating-variant]]:items-stretch has-[[data-floating-variant]]:rounded-xl",
        "has-[[data-floating-variant=default]]:border-neutral-50 has-[[data-floating-variant=default]]:data-[disabled=true]:border-surface-inactive",
        "has-[[data-floating-variant=outlined]]:border-surface-secondary has-[[data-floating-variant=outlined]]:bg-surface-primary has-[[data-floating-variant=outlined]]:data-[disabled=true]:border-surface-secondary",
        // Keep the control's px-5 text inset, then drop the padding on a revealed addon's side (gap comes from gap-1).
        "has-[[data-floating-variant]]:[&>[data-slot=input-group-control]]:px-5",
        "has-[>[data-align=inline-start]]:has-[[data-floating-variant]]:[&>[data-slot=input-group-control]]:pl-0",
        "has-[>[data-align=inline-end]]:has-[[data-floating-variant]]:[&>[data-slot=input-group-control]]:pr-0",
        // Auto-hide non-button inline addons at rest (floating + not focused + empty); focus or a value reveals them.
        "has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-start]:not(:has(>button))]:pointer-events-none has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-start]:not(:has(>button))]:w-0 has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-start]:not(:has(>button))]:overflow-hidden has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-start]:not(:has(>button))]:p-0 has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-start]:not(:has(>button))]:opacity-0",
        "has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-end]:not(:has(>button))]:pointer-events-none has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-end]:not(:has(>button))]:w-0 has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-end]:not(:has(>button))]:overflow-hidden has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-end]:not(:has(>button))]:p-0 has-[[data-floating-variant]]:not-focus-within:has-[[data-slot=input-group-control]:placeholder-shown]:[&_[data-align=inline-end]:not(:has(>button))]:opacity-0",
        className
      )}
      {...props}
    />
  )
}

// Fades the addon in on reveal (opacity only; the collapse is applied from the root).
const floatingAddonReveal =
  "transition-opacity duration-200 ease-out"

const inputGroupAddonVariants = cva(
  "flex h-auto cursor-text items-center justify-center gap-1 py-1.5 body-sm text-text-secondary-light select-none group-data-[disabled=true]/input-group:text-text-inactive-light [&>kbd]:rounded-[calc(var(--radius-md)-5px)] [&>svg:not([class*='size-'])]:size-4",
  {
    variants: {
      align: {
        // Floating: non-button addons adopt the control's pt-8.5 pb-4 band and align
        // to the value's line (pl-5); a button keeps its default full-height centering.
        "inline-start": cn(
          "order-first pl-2 has-[>button]:-ml-1 has-[>kbd]:ml-[-0.15rem]",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:items-center",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pl-5",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pt-8.5",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pb-4",
          floatingAddonReveal
        ),
        // pr-5 aligns any trailing addon to the control's inset; non-button addons
        // also adopt the text band (pl-1 leaves the gap to the value).
        "inline-end": cn(
          "order-last pr-2 has-[>button]:-mr-1 has-[>kbd]:mr-[-0.15rem]",
          "group-has-[[data-floating-variant]]/input-group:pr-5",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:items-center",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pl-1",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pt-8.5",
          "group-has-[[data-floating-variant]]/input-group:not-has-[>button]:pb-4",
          floatingAddonReveal
        ),
        "block-start":
          "order-first w-full justify-start px-2.5 pt-2 group-has-[>input]/input-group:pt-2 [.border-b]:pb-2",
        "block-end":
          "order-last w-full justify-start px-2.5 pb-2 group-has-[>input]/input-group:pb-2 [.border-t]:pt-2",
      },
    },
    defaultVariants: {
      align: "inline-start",
    },
  }
)

export interface InputGroupAddonProps extends React.ComponentProps<"div">, VariantProps<typeof inputGroupAddonVariants> {}

function InputGroupAddon({
  className,
  align = "inline-start",
  ...props
}: InputGroupAddonProps) {
  return (
    <div
      role="group"
      data-slot="input-group-addon"
      data-align={align}
      className={cn(inputGroupAddonVariants({ align }), className)}
      onClick={(e) => {
        // A button addon keeps its own action; any other addon click focuses the
        // grouped control (:enabled skips disabled controls).
        if ((e.target as HTMLElement).closest("button")) {
          return
        }
        const group = e.currentTarget.parentElement
        const control = group?.querySelector<HTMLElement>(
          "input:enabled, textarea:enabled"
        )
        control?.focus()
      }}
      {...props}
    />
  )
}

const inputGroupButtonVariants = cva(
  "flex items-center gap-2 shadow-none",
  {
    variants: {
     size: {
        xs: "h-6 gap-1 rounded-md px-1.5 py-0 [&>svg:not([class*='size-'])]:size-3.5 min-h-auto",
        sm: "",
        "icon-xs":
          "size-6 min-h-0 min-w-0 rounded-full p-0 has-[>svg]:p-0 [&_svg:not([class*='size-'])]:size-4",
        "icon-sm": "size-8 min-h-0 min-w-0 p-0 has-[>svg]:p-0 [&_svg:not([class*='size-'])]:size-5",
      },
    },
    defaultVariants: {
      size: "xs",
    },
  }
)

export interface InputGroupButtonProps extends Omit<React.ComponentProps<typeof Button>, "size" | "type">,
  VariantProps<typeof inputGroupButtonVariants> {
    type?: "button" | "submit" | "reset"
  }

function InputGroupButton({
  className,
  type = "button",
  variant = "secondary",
  surface ="light",
  size = "xs",
  ...props
}: InputGroupButtonProps) {
  return (
    <Button
      type={type}
      data-size={size}
      variant={variant}
      surface={surface}
      className={cn(inputGroupButtonVariants({ size }), className)}
      {...props}
    />
  )
}

export interface InputGroupTextProps extends React.ComponentProps<"span"> {}

function InputGroupText({ className, ...props }: InputGroupTextProps) {
  return (
    <span
      className={cn(
        "flex items-center gap-1 body-sm text-text-secondary-light group-data-[disabled=true]/input-group:text-text-inactive-light [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    />
  )
}

export interface BaseInputGroupInputProps extends React.ComponentProps<"input"> {}

function BaseInputGroupInput({
  className,
  ...props
}: BaseInputGroupInputProps) {
  return (
    <Input
      data-slot="input-group-control"
      className={cn(
        "flex-1 rounded-none border-0 bg-transparent shadow-none ring-0 focus-visible:ring-0 aria-invalid:ring-0 disabled:bg-transparent dark:bg-transparent",
        className
      )}
      {...props}
    />
  )
}

export interface BaseInputGroupTextareaProps extends React.ComponentProps<"textarea"> {}

function BaseInputGroupTextarea({
  className,
  ...props
}: BaseInputGroupTextareaProps) {
  return (
    <Textarea
      data-slot="input-group-control"
      className={cn(
        "flex-1 resize-none rounded-none border-0 bg-transparent py-2 shadow-none ring-0 focus-visible:ring-0 aria-invalid:ring-0 dark:bg-transparent",
        className
      )}
      {...props}
    />
  )
}

// Sits the reused floating control in the group's flex row and goes borderless so
// the shared InputGroup surface owns the border, focus ring, and invalid state.
const floatingInputGroupOverrides = cn(
  "flex-1 min-w-0",
  "border-0 bg-transparent shadow-none ring-0 focus-visible:ring-0 aria-invalid:ring-0 disabled:bg-transparent dark:bg-transparent"
)

export interface InputGroupInputProps extends FloatingInputProps {}

/**
 * Floating-label input for `InputGroup`. Wraps `FloatingInput`; compose with a
 * sibling `FloatingLabel` and any `InputGroupAddon`.
 *
 * @example
 * ```tsx
 * <InputGroup>
 *   <InputGroupAddon>
 *     <InputGroupText>https://</InputGroupText>
 *   </InputGroupAddon>
 *   <InputGroupInput id="site" />
 *   <FloatingLabel htmlFor="site">Website</FloatingLabel>
 * </InputGroup>
 * ```
 */
function InputGroupInput({
  className,
  variant,
  ...props
}: InputGroupInputProps) {
  return (
    <FloatingInput
      variant={variant}
      data-slot="input-group-control"
      data-floating-variant={variant ?? "default"}
      className={cn(floatingInputGroupOverrides, className)}
      {...props}
    />
  )
}

export interface InputGroupTextareaProps extends FloatingTextareaProps {}

/**
 * Floating-label textarea for `InputGroup`. Wraps `FloatingTextarea`; compose like
 * `InputGroupInput` but for multi-line input.
 *
 * @example
 * ```tsx
 * <InputGroup>
 *   <InputGroupTextarea id="note" />
 *   <FloatingLabel htmlFor="note">Add note</FloatingLabel>
 *   <InputGroupAddon align="block-end">
 *     <InputGroupButton size="sm" className="ml-auto">Post</InputGroupButton>
 *   </InputGroupAddon>
 * </InputGroup>
 * ```
 */
function InputGroupTextarea({
  className,
  variant,
  ...props
}: InputGroupTextareaProps) {
  return (
    <FloatingTextarea
      variant={variant}
      data-slot="input-group-control"
      data-floating-variant={variant ?? "default"}
      className={cn(floatingInputGroupOverrides, className)}
      {...props}
    />
  )
}

export {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupText,
  BaseInputGroupInput,
  BaseInputGroupTextarea,
  InputGroupInput,
  InputGroupTextarea,
}
