import{j as zn}from"./jsx-runtime-D_zvdyIk.js";import{_ as Gn,I as Rn,a as Ln,b as jn,c as Wn,d as Fn,e as J,f as Un,g as Mn,h as On,i as $n,j as qn,k as Kn,l as Hn,m as Xn,n as Yn,o as Zn,p as Jn,q as Qn,r as et,s as I,t as nt,u as tt,v as rt,w as at,x as ot,y as st,z as it,A as ct,B as lt,C as ut,D as dt,E as ft,F as mt,G as pt,H as gt,J as bt,K as It,L as vt,M as yt,N as ht,O as St,P as En,Q as xt,R as Ct,S as zt,T as Et,U as wt,V as Bt,W as Pt,X as Tt,Y as Vt,Z as kt}from"./tool-BVs5PFqG.js";import{H as f,a as _t}from"./iframe-7lYonMLZ.js";const Dt=Object.freeze(Object.defineProperty({__proto__:null,IconAdd:Rn,IconAiStar:Ln,IconArrowDown:jn,IconArrowLeft:Wn,IconArrowReturnRight:Fn,IconArrowRight:J,IconArrowUp:Un,IconBinocular:Mn,IconBrain:On,IconCalendar:$n,IconCamera:qn,IconCar:Kn,IconCarSide:Hn,IconCaretDown:Xn,IconCaretLeft:Yn,IconCaretRight:Zn,IconCaretUp:Jn,IconCheckCircle:Qn,IconCheckmark:et,IconClose:I,IconCompare:nt,IconContract:tt,IconDocument:rt,IconDocumentFilled:at,IconFilter:ot,IconGrid:st,IconHeart:it,IconHeartFilled:ct,IconHome:lt,IconHomeFilled:ut,IconLocation:dt,IconMic:ft,IconPause:mt,IconPhotos:pt,IconPlay:gt,IconPreferences:bt,IconPriceTag:It,IconPriceTagFilled:vt,IconProfile:yt,IconProfileFilled:ht,IconSaveAdd:St,IconSaved:En,IconSavedFilled:xt,IconScreencast:Ct,IconSearch:zt,IconSearchContext:Et,IconSend:wt,IconSquaresFour:Bt,IconSwitch:Pt,IconTool:Tt,createIcon:Gn},Symbol.toStringTag,{value:"Module"}));function Nt(){return typeof window<"u"}function At(e){var n;return(e==null||(n=e.ownerDocument)==null?void 0:n.defaultView)||window}function Gt(e){return Nt()?e instanceof HTMLElement||e instanceof At(e).HTMLElement:!1}const le={};function Q(e,n){const t=f.useRef(le);return t.current===le&&(t.current=e(n)),t}const H=_t[`useInsertionEffect${Math.random().toFixed(1)}`.slice(0,-3)],Rt=H&&H!==f.useLayoutEffect?H:e=>e();function Lt(e){const n=Q(jt).current;return n.next=e,Rt(n.effect),n.trampoline}function jt(){const e={next:void 0,callback:Wt,trampoline:(...n)=>{var t;return(t=e.callback)==null?void 0:t.call(e,...n)},effect:()=>{e.callback=e.next}};return e}function Wt(){}const Ft=()=>{},Ut=typeof document<"u"?f.useLayoutEffect:Ft;function Y(e,n){if(e&&!n)return e;if(!e&&n)return n;if(e||n)return{...e,...n}}const ee={};function ne(e,n,t,r,o){if(!t&&!r&&!e)return O(n);let a=O(e);return n&&(a=M(a,n)),t&&(a=M(a,t)),r&&(a=M(a,r)),a}function Mt(e){if(e.length===0)return ee;if(e.length===1)return O(e[0]);let n=O(e[0]);for(let t=1;t<e.length;t+=1)n=M(n,e[t]);return n}function O(e){return te(e)?{...Bn(e,ee)}:Ot(e)}function M(e,n){return te(n)?Bn(n,e):$t(e,n)}function Ot(e){const n={...e};for(const t in n){const r=n[t];wn(t,r)&&(n[t]=Pn(r))}return n}function $t(e,n){if(!n)return e;for(const t in n){const r=n[t];switch(t){case"style":{e[t]=Y(e.style,r);break}case"className":{e[t]=Tn(e.className,r);break}default:wn(t,r)?e[t]=qt(e[t],r):e[t]=r}}return e}function wn(e,n){const t=e.charCodeAt(0),r=e.charCodeAt(1),o=e.charCodeAt(2);return t===111&&r===110&&o>=65&&o<=90&&(typeof n=="function"||typeof n>"u")}function te(e){return typeof e=="function"}function Bn(e,n){return te(e)?e(n):e??ee}function qt(e,n){return n?e?(...t)=>{const r=t[0];if(Vn(r)){const a=r;$(a);const c=n(...t);return a.baseUIHandlerPrevented||e==null||e(...t),c}const o=n(...t);return e==null||e(...t),o}:Pn(n):e}function Pn(e){return e&&((...n)=>{const t=n[0];return Vn(t)&&$(t),e(...n)})}function $(e){return e.preventBaseUIHandler=()=>{e.baseUIHandlerPrevented=!0},e}function Tn(e,n){return n?e?n+" "+e:n:e}function Vn(e){return e!=null&&typeof e=="object"&&"nativeEvent"in e}function Kt(e,n){return function(r,...o){const a=new URL(e);return a.searchParams.set("code",r.toString()),o.forEach(c=>a.searchParams.append("args[]",c)),`${n} error #${r}; visit ${a} for the full message.`}}const Ht=Kt("https://base-ui.com/production-error","Base UI"),Xt=f.createContext(void 0);function Yt(e=!1){const n=f.useContext(Xt);if(n===void 0&&!e)throw new Error(Ht(16));return n}function Zt(e){const{focusableWhenDisabled:n,disabled:t,composite:r=!1,tabIndex:o=0,isNativeButton:a}=e,c=r&&n!==!1,m=r&&n===!1;return{props:f.useMemo(()=>{const i={onKeyDown(u){t&&n&&u.key!=="Tab"&&u.preventDefault()}};return r||(i.tabIndex=o,!a&&t&&(i.tabIndex=n?o:-1)),(a&&(n||c)||!a&&t)&&(i["aria-disabled"]=t),a&&(!n||m)&&(i.disabled=t),i},[r,t,n,c,m,a,o])}}function Jt(e={}){const{disabled:n=!1,focusableWhenDisabled:t,tabIndex:r=0,native:o=!0,composite:a}=e,c=f.useRef(null),m=Yt(!0),d=a??m!==void 0,{props:i}=Zt({focusableWhenDisabled:t,disabled:n,composite:d,tabIndex:r,isNativeButton:o}),u=f.useCallback(()=>{const b=c.current;X(b)&&d&&n&&i.disabled===void 0&&b.disabled&&(b.disabled=!1)},[n,i.disabled,d]);Ut(u,[u]);const p=f.useCallback((b={})=>{const{onClick:l,onMouseDown:y,onKeyUp:v,onKeyDown:q,onPointerDown:K,...Nn}=b;return ne({type:o?"button":void 0,onClick(s){if(n){s.preventDefault();return}l==null||l(s)},onMouseDown(s){n||y==null||y(s)},onKeyDown(s){if(n||($(s),q==null||q(s),s.baseUIHandlerPrevented))return;const re=s.target===s.currentTarget,U=s.currentTarget,ae=X(U),oe=!o&&Qt(U),se=re&&(o?ae:!oe),ie=s.key==="Enter",ce=s.key===" ",h=U.getAttribute("role"),An=(h==null?void 0:h.startsWith("menuitem"))||h==="option"||h==="gridcell";if(re&&d&&ce){if(s.defaultPrevented&&An)return;s.preventDefault(),oe||o&&ae?(U.click(),s.preventBaseUIHandler()):se&&(l==null||l(s),s.preventBaseUIHandler());return}se&&(!o&&(ce||ie)&&s.preventDefault(),!o&&ie&&(l==null||l(s)))},onKeyUp(s){if(!n){if($(s),v==null||v(s),s.target===s.currentTarget&&o&&d&&X(s.currentTarget)&&s.key===" "){s.preventDefault();return}s.baseUIHandlerPrevented||s.target===s.currentTarget&&!o&&!d&&s.key===" "&&(l==null||l(s))}},onPointerDown(s){if(n){s.preventDefault();return}K==null||K(s)}},o?void 0:{role:"button"},i,Nn)},[n,i,d,o]),g=Lt(b=>{c.current=b,u()});return{getButtonProps:p,buttonRef:g}}function X(e){return Gt(e)&&e.tagName==="BUTTON"}function Qt(e){return!!((e==null?void 0:e.tagName)==="A"&&(e!=null&&e.href))}function ue(e,n,t,r){const o=Q(kn).current;return nr(o,e,n,t,r)&&_n(o,[e,n,t,r]),o.callback}function er(e){const n=Q(kn).current;return tr(n,e)&&_n(n,e),n.callback}function kn(){return{callback:null,cleanup:null,refs:[]}}function nr(e,n,t,r,o){return e.refs[0]!==n||e.refs[1]!==t||e.refs[2]!==r||e.refs[3]!==o}function tr(e,n){return e.refs.length!==n.length||e.refs.some((t,r)=>t!==n[r])}function _n(e,n){if(e.refs=n,n.every(t=>t==null)){e.callback=null;return}e.callback=t=>{if(e.cleanup&&(e.cleanup(),e.cleanup=null),t!=null){const r=Array(n.length).fill(null);for(let o=0;o<n.length;o+=1){const a=n[o];if(a!=null)switch(typeof a){case"function":{const c=a(t);typeof c=="function"&&(r[o]=c);break}case"object":{a.current=t;break}}}e.cleanup=()=>{for(let o=0;o<n.length;o+=1){const a=n[o];if(a!=null)switch(typeof a){case"function":{const c=r[o];typeof c=="function"?c():a(null);break}case"object":{a.current=null;break}}}}}}}const rr=parseInt(f.version,10);function ar(e){return rr>=e}function de(e){if(!f.isValidElement(e))return null;const n=e,t=n.props;return(ar(19)?t==null?void 0:t.ref:n.ref)??null}const S=Object.freeze({});function or(e,n){const t={};for(const r in e){const o=e[r];if(n!=null&&n.hasOwnProperty(r)){const a=n[r](o);a!=null&&Object.assign(t,a);continue}o===!0?t[`data-${r.toLowerCase()}`]="":o&&(t[`data-${r.toLowerCase()}`]=o.toString())}return t}function sr(e,n){return typeof e=="function"?e(n):e}function ir(e,n){return typeof e=="function"?e(n):e}function cr(e,n,t={}){const r=n.render,o=lr(n,t);if(t.enabled===!1)return null;const a=t.state??S;return fr(e,r,o,a)}function lr(e,n={}){const{className:t,style:r,render:o}=e,{state:a=S,ref:c,props:m,stateAttributesMapping:d,enabled:i=!0}=n,u=i?sr(t,a):void 0,p=i?ir(r,a):void 0,g=i?or(a,d):S,b=i&&m?ur(m):void 0,l=i?Y(g,b)??{}:S;return typeof document<"u"&&(i?Array.isArray(c)?l.ref=er([l.ref,de(o),...c]):l.ref=ue(l.ref,de(o),c):ue(null,null)),i?(u!==void 0&&(l.className=Tn(l.className,u)),p!==void 0&&(l.style=Y(l.style,p)),l):S}function ur(e){return Array.isArray(e)?Mt(e):ne(void 0,e)}const dr=Symbol.for("react.lazy");function fr(e,n,t,r){if(n){if(typeof n=="function")return n(t,r);const o=ne(t,n.props);o.ref=t.ref;let a=n;return(a==null?void 0:a.$$typeof)===dr&&(a=f.Children.toArray(n)[0]),f.cloneElement(a,o)}return mr(e,t)}function mr(e,n){return f.createElement("button",{type:"button",...n,key:n.key})}const pr=f.forwardRef(function(n,t){const{render:r,className:o,disabled:a=!1,focusableWhenDisabled:c=!1,nativeButton:m=!0,style:d,...i}=n,{getButtonProps:u,buttonRef:p}=Jt({disabled:a,focusableWhenDisabled:c,native:m});return cr("button",n,{state:{disabled:a},ref:[t,p],props:[i,u]})}),fe=e=>typeof e=="boolean"?`${e}`:e===0?"0":e,me=Vt,gr=(e,n)=>t=>{var r;if((n==null?void 0:n.variants)==null)return me(e,t==null?void 0:t.class,t==null?void 0:t.className);const{variants:o,defaultVariants:a}=n,c=Object.keys(o).map(i=>{const u=t==null?void 0:t[i],p=a==null?void 0:a[i];if(u===null)return null;const g=fe(u)||fe(p);return o[i][g]}),m=t&&Object.entries(t).reduce((i,u)=>{let[p,g]=u;return g===void 0||(i[p]=g),i},{}),d=n==null||(r=n.compoundVariants)===null||r===void 0?void 0:r.reduce((i,u)=>{let{class:p,className:g,...b}=u;return Object.entries(b).every(l=>{let[y,v]=l;return Array.isArray(v)?v.includes({...a,...m}[y]):{...a,...m}[y]===v})?[...i,p,g]:i},[]);return me(e,c,d,t==null?void 0:t.class,t==null?void 0:t.className)},br=gr("group/button inline-flex shrink-0 items-center justify-center rounded-full border border-transparent bg-clip-padding text-sm font-semibold leading-heading tracking-tightest whitespace-nowrap transition-colors duration-200 motion-reduce:transition-none outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none aria-disabled:pointer-events-none aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",{variants:{variant:{primary:"bg-surface-dark text-text-inverse hover:bg-neutral-700 disabled:bg-surface-secondary disabled:text-text-muted disabled:border-transparent",secondary:"bg-surface-secondary text-text-primary hover:bg-neutral-300 disabled:bg-surface-secondary disabled:text-text-muted",tertiary:"border-neutral-300 bg-transparent text-text-primary hover:text-text-muted disabled:bg-transparent disabled:text-text-muted disabled:border-neutral-200",neutral:"bg-transparent text-text-primary hover:bg-neutral-100 disabled:bg-transparent disabled:text-text-muted",text:"text-text-primary underline-offset-4 hover:text-text-muted hover:no-underline disabled:text-text-muted disabled:no-underline aria-disabled:text-text-muted aria-disabled:no-underline"},size:{default:"gap-1.5 px-4 py-2 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",xs:"gap-1 px-3 py-1 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",sm:"min-h-11 gap-1 px-6 py-3 in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-4 has-data-[icon=inline-start]:pl-4",lg:"min-h-11 gap-2 px-6 py-5 has-data-[icon=inline-end]:pr-4 has-data-[icon=inline-start]:pl-4",icon:"size-14 min-h-0 [&_svg:not([class*='size-'])]:size-5","icon-xs":"size-6 min-h-0 in-data-[slot=button-group]:rounded-md [&_svg:not([class*='size-'])]:size-3","icon-sm":"size-10 min-h-0 in-data-[slot=button-group]:rounded-md [&_svg:not([class*='size-'])]:size-4","icon-lg":"size-16 min-h-0 [&_svg:not([class*='size-'])]:size-6","icon-xl":"size-12 min-h-0 [&_svg:not([class*='size-'])]:size-5","icon-2xl":"size-14 min-h-0 [&_svg:not([class*='size-'])]:size-5"}},defaultVariants:{variant:"primary",size:"default"}});function pe(e,n){const t=e;return zn.jsx(t,{"data-icon":n})}function Dn({className:e,variant:n="primary",size:t="default",fullWidth:r,nativeButton:o=!0,leadingIcon:a,trailingIcon:c,children:m,...d}){return zn.jsxs(pr,{"data-slot":"button",nativeButton:o,className:kt(br({variant:n,size:t,className:e}),r&&"w-full"),...d,children:[a&&pe(a,"inline-start"),m,c&&pe(c,"inline-end")]})}Dn.__docgenInfo={description:"",methods:[],displayName:"Button",props:{fullWidth:{required:!1,tsType:{name:"boolean"},description:""},nativeButton:{required:!1,tsType:{name:"boolean"},description:"",defaultValue:{value:"true",computed:!1}},leadingIcon:{required:!1,tsType:{name:"ComponentType",elements:[{name:"intersection",raw:'SVGProps<SVGSVGElement> & { "data-icon"?: string }',elements:[{name:"SVGProps",elements:[{name:"SVGSVGElement"}],raw:"SVGProps<SVGSVGElement>"},{name:"signature",type:"object",raw:'{ "data-icon"?: string }',signature:{properties:[{key:"data-icon",value:{name:"string",required:!1}}]}}]}],raw:'ComponentType<SVGProps<SVGSVGElement> & { "data-icon"?: string }>'},description:""},trailingIcon:{required:!1,tsType:{name:"ComponentType",elements:[{name:"intersection",raw:'SVGProps<SVGSVGElement> & { "data-icon"?: string }',elements:[{name:"SVGProps",elements:[{name:"SVGSVGElement"}],raw:"SVGProps<SVGSVGElement>"},{name:"signature",type:"object",raw:'{ "data-icon"?: string }',signature:{properties:[{key:"data-icon",value:{name:"string",required:!1}}]}}]}],raw:'ComponentType<SVGProps<SVGSVGElement> & { "data-icon"?: string }>'},description:""},variant:{defaultValue:{value:'"primary"',computed:!1},required:!1},size:{defaultValue:{value:'"default"',computed:!1},required:!1}}};const{expect:ge,fn:Ir,userEvent:vr,within:yr}=__STORYBOOK_MODULE_TEST__,{createIcon:Br,...hr}=Dt,Z={None:void 0,...hr},be=Object.keys(Z),Sr={title:"Components/Button",component:Dn,parameters:{layout:"padded"},tags:["autodocs"],argTypes:{variant:{control:"select",options:["primary","secondary","tertiary","neutral","text"]},size:{control:"select",options:["default","xs","sm","lg","icon","icon-xs","icon-sm","icon-lg","icon-xl","icon-2xl"]},leadingIcon:{control:"select",options:be,mapping:Z},trailingIcon:{control:"select",options:be,mapping:Z}},args:{children:"Button",variant:"primary",size:"default",fullWidth:!1,nativeButton:!0}},x={args:{onClick:Ir()},play:async({args:e,canvasElement:n})=>{const r=yr(n).getByRole("button",{name:"Button"});await ge(r).toBeInTheDocument(),await vr.click(r),await ge(e.onClick).toHaveBeenCalledOnce()}},C={args:{variant:"secondary"}},z={args:{variant:"tertiary"}},E={args:{variant:"neutral"}},w={args:{variant:"text"}},B={args:{size:"default"}},P={args:{size:"xs"}},T={args:{size:"sm"}},V={args:{size:"lg"}},k={args:{size:"icon",children:void 0,leadingIcon:I,"aria-label":"Close"}},_={args:{size:"icon-xs",children:void 0,leadingIcon:I,"aria-label":"Close"}},D={args:{size:"icon-sm",children:void 0,leadingIcon:I,"aria-label":"Close"}},N={args:{size:"icon-lg",children:void 0,leadingIcon:I,"aria-label":"Close"}},A={args:{size:"icon-xl",children:void 0,leadingIcon:I,"aria-label":"Close"}},G={args:{size:"icon-2xl",children:void 0,leadingIcon:I,"aria-label":"Close"}},R={args:{leadingIcon:I}},L={args:{trailingIcon:J}},j={args:{leadingIcon:En,trailingIcon:J}},W={args:{fullWidth:!0},parameters:{layout:"padded"}},F={args:{disabled:!0}};var Ie,ve,ye;x.parameters={...x.parameters,docs:{...(Ie=x.parameters)==null?void 0:Ie.docs,source:{originalSource:`{
  args: {
    onClick: fn()
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole("button", {
      name: "Button"
    });
    await expect(button).toBeInTheDocument();
    await userEvent.click(button);
    await expect(args.onClick).toHaveBeenCalledOnce();
  }
}`,...(ye=(ve=x.parameters)==null?void 0:ve.docs)==null?void 0:ye.source}}};var he,Se,xe;C.parameters={...C.parameters,docs:{...(he=C.parameters)==null?void 0:he.docs,source:{originalSource:`{
  args: {
    variant: "secondary"
  }
}`,...(xe=(Se=C.parameters)==null?void 0:Se.docs)==null?void 0:xe.source}}};var Ce,ze,Ee;z.parameters={...z.parameters,docs:{...(Ce=z.parameters)==null?void 0:Ce.docs,source:{originalSource:`{
  args: {
    variant: "tertiary"
  }
}`,...(Ee=(ze=z.parameters)==null?void 0:ze.docs)==null?void 0:Ee.source}}};var we,Be,Pe;E.parameters={...E.parameters,docs:{...(we=E.parameters)==null?void 0:we.docs,source:{originalSource:`{
  args: {
    variant: "neutral"
  }
}`,...(Pe=(Be=E.parameters)==null?void 0:Be.docs)==null?void 0:Pe.source}}};var Te,Ve,ke;w.parameters={...w.parameters,docs:{...(Te=w.parameters)==null?void 0:Te.docs,source:{originalSource:`{
  args: {
    variant: "text"
  }
}`,...(ke=(Ve=w.parameters)==null?void 0:Ve.docs)==null?void 0:ke.source}}};var _e,De,Ne;B.parameters={...B.parameters,docs:{...(_e=B.parameters)==null?void 0:_e.docs,source:{originalSource:`{
  args: {
    size: "default"
  }
}`,...(Ne=(De=B.parameters)==null?void 0:De.docs)==null?void 0:Ne.source}}};var Ae,Ge,Re;P.parameters={...P.parameters,docs:{...(Ae=P.parameters)==null?void 0:Ae.docs,source:{originalSource:`{
  args: {
    size: "xs"
  }
}`,...(Re=(Ge=P.parameters)==null?void 0:Ge.docs)==null?void 0:Re.source}}};var Le,je,We;T.parameters={...T.parameters,docs:{...(Le=T.parameters)==null?void 0:Le.docs,source:{originalSource:`{
  args: {
    size: "sm"
  }
}`,...(We=(je=T.parameters)==null?void 0:je.docs)==null?void 0:We.source}}};var Fe,Ue,Me;V.parameters={...V.parameters,docs:{...(Fe=V.parameters)==null?void 0:Fe.docs,source:{originalSource:`{
  args: {
    size: "lg"
  }
}`,...(Me=(Ue=V.parameters)==null?void 0:Ue.docs)==null?void 0:Me.source}}};var Oe,$e,qe;k.parameters={...k.parameters,docs:{...(Oe=k.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  args: {
    size: "icon",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(qe=($e=k.parameters)==null?void 0:$e.docs)==null?void 0:qe.source}}};var Ke,He,Xe;_.parameters={..._.parameters,docs:{...(Ke=_.parameters)==null?void 0:Ke.docs,source:{originalSource:`{
  args: {
    size: "icon-xs",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(Xe=(He=_.parameters)==null?void 0:He.docs)==null?void 0:Xe.source}}};var Ye,Ze,Je;D.parameters={...D.parameters,docs:{...(Ye=D.parameters)==null?void 0:Ye.docs,source:{originalSource:`{
  args: {
    size: "icon-sm",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(Je=(Ze=D.parameters)==null?void 0:Ze.docs)==null?void 0:Je.source}}};var Qe,en,nn;N.parameters={...N.parameters,docs:{...(Qe=N.parameters)==null?void 0:Qe.docs,source:{originalSource:`{
  args: {
    size: "icon-lg",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(nn=(en=N.parameters)==null?void 0:en.docs)==null?void 0:nn.source}}};var tn,rn,an;A.parameters={...A.parameters,docs:{...(tn=A.parameters)==null?void 0:tn.docs,source:{originalSource:`{
  args: {
    size: "icon-xl",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(an=(rn=A.parameters)==null?void 0:rn.docs)==null?void 0:an.source}}};var on,sn,cn;G.parameters={...G.parameters,docs:{...(on=G.parameters)==null?void 0:on.docs,source:{originalSource:`{
  args: {
    size: "icon-2xl",
    children: undefined,
    leadingIcon: BrandIcons.IconClose,
    "aria-label": "Close"
  }
}`,...(cn=(sn=G.parameters)==null?void 0:sn.docs)==null?void 0:cn.source}}};var ln,un,dn;R.parameters={...R.parameters,docs:{...(ln=R.parameters)==null?void 0:ln.docs,source:{originalSource:`{
  args: {
    leadingIcon: BrandIcons.IconClose
  }
}`,...(dn=(un=R.parameters)==null?void 0:un.docs)==null?void 0:dn.source}}};var fn,mn,pn;L.parameters={...L.parameters,docs:{...(fn=L.parameters)==null?void 0:fn.docs,source:{originalSource:`{
  args: {
    trailingIcon: BrandIcons.IconArrowRight
  }
}`,...(pn=(mn=L.parameters)==null?void 0:mn.docs)==null?void 0:pn.source}}};var gn,bn,In;j.parameters={...j.parameters,docs:{...(gn=j.parameters)==null?void 0:gn.docs,source:{originalSource:`{
  args: {
    leadingIcon: BrandIcons.IconSaved,
    trailingIcon: BrandIcons.IconArrowRight
  }
}`,...(In=(bn=j.parameters)==null?void 0:bn.docs)==null?void 0:In.source}}};var vn,yn,hn;W.parameters={...W.parameters,docs:{...(vn=W.parameters)==null?void 0:vn.docs,source:{originalSource:`{
  args: {
    fullWidth: true
  },
  parameters: {
    layout: "padded"
  }
}`,...(hn=(yn=W.parameters)==null?void 0:yn.docs)==null?void 0:hn.source}}};var Sn,xn,Cn;F.parameters={...F.parameters,docs:{...(Sn=F.parameters)==null?void 0:Sn.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...(Cn=(xn=F.parameters)==null?void 0:xn.docs)==null?void 0:Cn.source}}};const xr=["Primary","Secondary","Tertiary","Neutral","Text","SizeDefault","SizeXs","SizeSm","SizeLg","SizeIcon","SizeIconXs","SizeIconSm","SizeIconLg","SizeIconXl","SizeIcon2xl","WithLeadingIcon","WithTrailingIcon","WithBothIcons","FullWidth","Disabled"],Pr=Object.freeze(Object.defineProperty({__proto__:null,Disabled:F,FullWidth:W,Neutral:E,Primary:x,Secondary:C,SizeDefault:B,SizeIcon:k,SizeIcon2xl:G,SizeIconLg:N,SizeIconSm:D,SizeIconXl:A,SizeIconXs:_,SizeLg:V,SizeSm:T,SizeXs:P,Tertiary:z,Text:w,WithBothIcons:j,WithLeadingIcon:R,WithTrailingIcon:L,__namedExportsOrder:xr,default:Sr},Symbol.toStringTag,{value:"Module"}));export{Dn as B,Pr as a};
