import{j as e}from"./jsx-runtime-D_zvdyIk.js";import{u as g,e as C}from"./blocks-DcxtZ0Rz.js";import{a as w,B as a}from"./button.stories-Bvah-qEZ.js";import{H as o}from"./iframe-7lYonMLZ.js";import"./preload-helper-Dp1pzeXC.js";import"./index-_Xv051_I.js";import"./tool-BVs5PFqG.js";/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=(...n)=>n.filter((i,r,s)=>!!i&&i.trim()!==""&&s.indexOf(i)===r).join(" ").trim();/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=n=>n.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=n=>n.replace(/^([A-Z])|[\s-_]+(\w)/g,(i,r,s)=>s?s.toUpperCase():r.toLowerCase());/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=n=>{const i=S(n);return i.charAt(0).toUpperCase()+i.slice(1)};/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var x={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=n=>{for(const i in n)if(i.startsWith("aria-")||i==="role"||i==="title")return!0;return!1},M=o.createContext({}),L=()=>o.useContext(M),W=o.forwardRef(({color:n,size:i,strokeWidth:r,absoluteStrokeWidth:s,className:d="",children:l,iconNode:z,...u},p)=>{const{size:c=24,strokeWidth:j=2,absoluteStrokeWidth:y=!1,color:b="currentColor",className:A=""}=L()??{},I=s??y?Number(r??j)*24/Number(i??c):r??j;return o.createElement("svg",{ref:p,...x,width:i??c??x.width,height:i??c??x.height,stroke:n??b,strokeWidth:I,className:v("lucide",A,d),...!l&&!k(u)&&{"aria-hidden":"true"},...u},[...z.map(([f,B])=>o.createElement(f,B)),...Array.isArray(l)?l:[l]])});/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=(n,i)=>{const r=o.forwardRef(({className:s,...d},l)=>o.createElement(W,{ref:l,iconNode:i,className:v(`lucide-${N(h(n))}`,`lucide-${n}`,s),...d}));return r.displayName=h(n),r};/**
 * @license lucide-react v1.16.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],t=_("plus",E);function m(n){const i={h1:"h1",h2:"h2",p:"p",...g(),...n.components};return e.jsxs(e.Fragment,{children:[e.jsx(C,{of:w,name:"Matrix"}),`
`,e.jsx(i.h1,{id:"button--variant--size-matrix",children:"Button — Variant × Size Matrix"}),`
`,e.jsx(i.p,{children:"A side-by-side overview of all variant and size combinations."}),`
`,e.jsx(i.h2,{id:"text-sizes",children:"Text Sizes"}),`
`,e.jsxs("div",{className:"grid grid-cols-[auto_repeat(5,1fr)] gap-3 items-center justify-items-center p-8",children:[e.jsx("div",{}),e.jsx("strong",{children:"Primary"}),e.jsx("strong",{children:"Secondary"}),e.jsx("strong",{children:"Tertiary"}),e.jsx("strong",{children:"Neutral"}),e.jsx("strong",{children:"Text"}),e.jsx("strong",{children:"XS"}),e.jsx(a,{variant:"primary",size:"xs",children:"Button"}),e.jsx(a,{variant:"secondary",size:"xs",children:"Button"}),e.jsx(a,{variant:"tertiary",size:"xs",children:"Button"}),e.jsx(a,{variant:"neutral",size:"xs",children:"Button"}),e.jsx(a,{variant:"text",size:"xs",children:"Button"}),e.jsx("strong",{children:"Default"}),e.jsx(a,{variant:"primary",size:"default",children:"Button"}),e.jsx(a,{variant:"secondary",size:"default",children:"Button"}),e.jsx(a,{variant:"tertiary",size:"default",children:"Button"}),e.jsx(a,{variant:"neutral",size:"default",children:"Button"}),e.jsx(a,{variant:"text",size:"default",children:"Button"}),e.jsx("strong",{children:"SM"}),e.jsx(a,{variant:"primary",size:"sm",children:"Button"}),e.jsx(a,{variant:"secondary",size:"sm",children:"Button"}),e.jsx(a,{variant:"tertiary",size:"sm",children:"Button"}),e.jsx(a,{variant:"neutral",size:"sm",children:"Button"}),e.jsx(a,{variant:"text",size:"sm",children:"Button"}),e.jsx("strong",{children:"LG"}),e.jsx(a,{variant:"primary",size:"lg",children:"Button"}),e.jsx(a,{variant:"secondary",size:"lg",children:"Button"}),e.jsx(a,{variant:"tertiary",size:"lg",children:"Button"}),e.jsx(a,{variant:"neutral",size:"lg",children:"Button"}),e.jsx(a,{variant:"text",size:"lg",children:"Button"})]}),`
`,e.jsx(i.h2,{id:"icon-sizes",children:"Icon Sizes"}),`
`,e.jsxs("div",{className:"grid grid-cols-[auto_repeat(5,1fr)] gap-3 items-center justify-items-center p-8",children:[e.jsx("div",{}),e.jsx("strong",{children:"Primary"}),e.jsx("strong",{children:"Secondary"}),e.jsx("strong",{children:"Tertiary"}),e.jsx("strong",{children:"Neutral"}),e.jsx("strong",{children:"Text"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon-xs"}),e.jsx(a,{variant:"primary",size:"icon-xs",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon-xs",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon-xs",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon-xs",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon-xs",leadingIcon:t,"aria-label":"Add"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon-sm"}),e.jsx(a,{variant:"primary",size:"icon-sm",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon-sm",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon-sm",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon-sm",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon-sm",leadingIcon:t,"aria-label":"Add"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon"}),e.jsx(a,{variant:"primary",size:"icon",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon",leadingIcon:t,"aria-label":"Add"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon-lg"}),e.jsx(a,{variant:"primary",size:"icon-lg",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon-lg",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon-lg",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon-lg",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon-lg",leadingIcon:t,"aria-label":"Add"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon-xl"}),e.jsx(a,{variant:"primary",size:"icon-xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon-xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon-xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon-xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon-xl",leadingIcon:t,"aria-label":"Add"}),e.jsx("span",{className:"text-xs text-text-muted",children:"icon-2xl"}),e.jsx(a,{variant:"primary",size:"icon-2xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"secondary",size:"icon-2xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"tertiary",size:"icon-2xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"neutral",size:"icon-2xl",leadingIcon:t,"aria-label":"Add"}),e.jsx(a,{variant:"text",size:"icon-2xl",leadingIcon:t,"aria-label":"Add"})]})]})}function Z(n={}){const{wrapper:i}={...g(),...n.components};return i?e.jsx(i,{...n,children:e.jsx(m,{...n})}):m(n)}export{Z as default};
