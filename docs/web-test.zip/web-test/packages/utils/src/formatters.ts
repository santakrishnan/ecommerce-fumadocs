export function formatCurrency(amount: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
  }).format(amount);
}

/**
 * Format a price as USD with no decimal places.
 * Use for displayed monetary values in the UI.
 */
export function formatPrice(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Format date to readable string
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(d);
}

/** Parts of a US mailing address, in display order. */
export interface AddressParts {
  city: string;
  line1: string;
  line2?: string;
  state: string;
  zipCode: string;
}

export function formatAddress(address: AddressParts): string {
  const streetLine = address.line2 ? `${address.line1}, ${address.line2}` : address.line1;
  return `${streetLine}, ${address.city}, ${address.state} ${address.zipCode}`;
}

export function truncate(text: string, length: number): string {
  if (text.length <= length) {
    return text;
  }
  return `${text.slice(0, length)}...`;
}

export function formatMileage(mileage: number): string {
  return `${new Intl.NumberFormat("en-US").format(mileage)} mi`;
}
