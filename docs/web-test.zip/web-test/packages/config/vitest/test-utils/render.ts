import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  type RenderHookOptions,
  type RenderHookResult,
  type RenderOptions,
  type RenderResult,
  render as rtlRender,
  renderHook as rtlRenderHook,
} from "@testing-library/react";
import { createElement, type JSXElementConstructor, type ReactNode } from "react";

type UserWrapper = JSXElementConstructor<{ children: ReactNode }> | undefined;

/** A `QueryClient` for tests: no retries, no lingering gc timers. */
export function createTestQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: false, gcTime: 0 },
    },
  });
}

/** A caller's wrapper nests inside, so their own client still wins for its subtree. */
function withProviders(client: QueryClient, Wrapped: UserWrapper) {
  return function Providers({ children }: { children: ReactNode }) {
    const inner = Wrapped ? createElement(Wrapped, null, children) : children;
    return createElement(QueryClientProvider, { client }, inner);
  };
}

/** RTL `render` inside a fresh `QueryClientProvider`, for components that need TanStack Query. */
export function renderWithProviders(ui: ReactNode, options?: RenderOptions): RenderResult {
  const client = createTestQueryClient();
  return rtlRender(ui, { ...options, wrapper: withProviders(client, options?.wrapper) });
}

/** `renderHook` counterpart of {@link renderWithProviders}. */
export function renderHookWithProviders<Result, Props>(
  callback: (initialProps: Props) => Result,
  options?: RenderHookOptions<Props>
): RenderHookResult<Result, Props> {
  const client = createTestQueryClient();
  return rtlRenderHook(callback, { ...options, wrapper: withProviders(client, options?.wrapper) });
}
