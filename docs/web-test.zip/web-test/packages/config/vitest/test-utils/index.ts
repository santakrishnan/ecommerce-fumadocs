export * from "@testing-library/react";
export { default as userEvent } from "@testing-library/user-event";
export { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, test, vi } from "vitest";
export { createLocalStorageMock } from "./local-storage-mock";
// Re-exported for backward compatibility — prefer importing `firstOf` from
// `@ucmp/vitest-config/test-utils/pure` in pure-node test files, since this
// barrel also pulls in RTL/user-event's DOM-dependent global hooks.
export { firstOf } from "./pure";
// Explicit QueryClient-wrapped variants; plain `render`/`renderHook` come from the `export *` above.
export { createTestQueryClient, renderHookWithProviders, renderWithProviders } from "./render";
