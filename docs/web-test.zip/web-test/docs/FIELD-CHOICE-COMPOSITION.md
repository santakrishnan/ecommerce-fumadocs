# Field Choice Composition Pattern

This document defines the field choice composition pattern used in this monorepo.

It describes when to use `FieldLabel` vs `FieldChoice`, and how to compose radio,
checkbox, and switch choice cards with accessible behavior.

## Simple option: `FieldLabel`

`FieldLabel` is a valid option for a simple single interactive element pattern.

- Use `FieldLabel htmlFor="..."` when you only need native label behavior.
- Use `FieldChoice` when you want the full card surface to be clickable.

## Why this pattern exists

Choice cards need two things at once:

- A large, clickable surface.
- Correct native form semantics and accessibility.

`FieldChoice` gives both, with two explicit modes:

- `htmlFor` mode for simple single-control cards.
- `activatesId` mode for complex cards that include additional interactive children.

## Core building blocks

- `FieldSet`, `FieldLegend`: group semantics.
- `Field`: horizontal or vertical field layout.
- `FieldContent`, `FieldTitle`, `FieldDescription`: card text content.
- `FieldLabel`: native label wrapper.
- `FieldChoice`: choice-card wrapper with click-to-activate behavior.

Primary implementation lives in:

- `packages/ui/src/components/field.tsx`
- `packages/ui/src/components/radio-group.tsx`
- `packages/ui/src/components/checkbox.tsx`
- `packages/ui/src/components/switch.tsx`

Reference story examples:

- `packages/ui/src/components/__stories__/field-choice-card.stories.tsx`

## Decision table

Use these options based on interaction needs:

- `FieldLabel htmlFor` for a simple single interactive element.
- `FieldChoice htmlFor` for a clickable card around one control (radio, checkbox, switch).
- `FieldChoice activatesId` when the card also contains independent controls (for example
  a nested `Select`); pair with nested `FieldLabel htmlFor` for the primary control.

| Scenario | Pattern | Why |
| --- | --- | --- |
| Simple single interactive element | `FieldLabel htmlFor="..."` | Minimal native label pattern |
| Single control card | `FieldChoice htmlFor="..."` | Native label semantics; entire card activates control |
| Card with nested interactive elements | `FieldChoice activatesId="..."` | Card surface activates primary control; additional `Field`s stay independent, other children opt out via `stopPropagation` |

## Pattern A: simple choice card (`htmlFor`)

```tsx
<FieldChoice htmlFor="shipping-express">
  <Field orientation="horizontal">
    <FieldContent>
      <FieldTitle>Express Shipping</FieldTitle>
      <FieldDescription>2-3 business days.</FieldDescription>
    </FieldContent>
    <RadioGroupItem id="shipping-express" value="express" />
  </Field>
</FieldChoice>
```

Use this for most radio/checkbox/switch cards.

## Pattern B: complex choice card (`activatesId`)

```tsx
<FieldChoice activatesId="vsa-cb">
  <Field orientation="horizontal">
    <FieldContent>
      <FieldLabel htmlFor="vsa-cb">
        <FieldTitle>Vehicle Service Agreement</FieldTitle>
      </FieldLabel>
      <FieldDescription>Protect eligible repairs and parts.</FieldDescription>
    </FieldContent>
    <Checkbox id="vsa-cb" />
  </Field>

  <Field>
    <Select variant="outlined">
      <SelectTrigger id="vsa-coverage-term">
        <SelectValue placeholder="Select coverage" />
      </SelectTrigger>
      <SelectContent alignItemWithTrigger={false}>{/* options */}</SelectContent>
    </Select>
    <FloatingLabel htmlFor="vsa-coverage-term">Length of coverage</FloatingLabel>
  </Field>
</FieldChoice>
```

In `activatesId` mode, clicking the card surface activates the primary control. Two
things are skipped automatically:

- The primary control itself (so it isn't double-toggled).
- Any additional `Field` and everything inside it (e.g. the nested `Select` above).

Any other interactive child in the primary content (an extra `button`, link, etc.)
is **not** auto-detected. To stop it from activating the card, opt out with the
standard event methods:

```tsx
<button onClick={(e) => e.stopPropagation()}>Details</button>
```

You can also call `event.preventDefault()` in the card's own `onClick` to skip
activation entirely.

## Accessibility requirements

- Always provide a matching `id` on the primary control.
- In `htmlFor` mode, `FieldChoice htmlFor` must target that `id`.
- In `activatesId` mode, include a nested `FieldLabel htmlFor` for the primary control name.
- Keep grouped choices inside `FieldSet` + `FieldLegend`.
- Use native disabled/invalid attributes and mirrored data attributes when needed
  (`disabled`, `aria-invalid`, `data-disabled`, `data-invalid`).

## Related conventions

- Base UI composition prefers `render` props over Radix `asChild` patterns.
- Keep `data-slot` attributes on primitives; styling hooks rely on them.
- Prefer semantic tokens and existing component variants over custom one-off styles.

See:

- `AGENTS.md`
- `packages/ui/AGENTS.md`




