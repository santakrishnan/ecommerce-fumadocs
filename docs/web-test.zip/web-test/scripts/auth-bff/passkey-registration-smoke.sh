#!/usr/bin/env bash
# Smoke-test the passkey registration BFF over HTTP (mock mode).
#
#   pnpm dev                                   # with USE_AUTH_MOCKS=true
#   ./scripts/auth-bff/passkey-registration-smoke.sh [base-url]
#
# Signs in through the real OTP route (mock code 000000), which sets the
# HttpOnly EDI session cookie, then checks register-options and the error
# paths. curl can't produce a signed attestation, so a successful
# `PUT register` is covered by Vitest and /demo/passkey-bff.
set -euo pipefail

BASE="${1:-http://localhost:3000}"
JAR="$(mktemp)"
OTHER_JAR="$(mktemp)"
trap 'rm -f "$JAR" "$OTHER_JAR"' EXIT

pass=0
fail=0
LAST_BODY=""

# check <label> <expected-status> <curl args...>
check() {
  local label="$1" expected="$2"
  shift 2
  local body status
  body="$(mktemp)"
  status="$(curl -sS -o "$body" -w '%{http_code}' "$@")"
  if [[ "$status" == "$expected" ]]; then
    pass=$((pass + 1))
    printf '  ok   %-50s %s\n' "$label" "$status"
  else
    fail=$((fail + 1))
    printf '  FAIL %-50s got %s, want %s\n' "$label" "$status" "$expected"
  fi
  LAST_BODY="$(cat "$body")"
  rm -f "$body"
}

json=(-H 'Content-Type: application/json')
contact='"channel":"email","recipient":"smoke@example.test"'

echo "Passkey registration BFF smoke test → $BASE"

check "profile, signed out → T0" 200 -b "$JAR" -c "$JAR" "$BASE/api/v1/auth/profile"
check "register-options without EDI cookie → 401" 401 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"

edi_value() { awk '$6 ~ /edi-session-id$/ { print $7 }' "$JAR"; }

check "OTP send (first time) → gateway sets EDI cookie" 200 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data "{$contact}" "$BASE/api/v1/auth/otp"
FROM_SEND="$(edi_value)"
if [[ -n "$FROM_SEND" ]]; then
  pass=$((pass + 1)); echo "  ok   EDI cookie issued on OTP send"
else
  fail=$((fail + 1)); echo "  FAIL no EDI cookie after OTP send"
fi
check "OTP verify (000000) → same EDI cookie, now T1" 200 -b "$JAR" -c "$JAR" -X PUT "${json[@]}" \
  --data "{$contact,\"code\":\"000000\"}" "$BASE/api/v1/auth/otp"
VERIFY_BODY="$LAST_BODY"
if [[ -n "$FROM_SEND" && "$(edi_value)" == "$FROM_SEND" ]]; then
  pass=$((pass + 1)); echo "  ok   verify kept the session id from send"
else
  fail=$((fail + 1)); echo "  FAIL verify changed or dropped the session id from send"
fi
if grep -q 'edi-session-id' "$JAR" && grep -q '#HttpOnly_' "$JAR"; then
  pass=$((pass + 1)); echo "  ok   EDI session cookie present and HttpOnly"
else
  fail=$((fail + 1)); echo "  FAIL EDI session cookie missing or not HttpOnly"
fi
if grep -q 'mock-edi\.' <<<"$VERIFY_BODY"; then
  fail=$((fail + 1)); echo "  FAIL EDI session value leaked into the response body"
else
  pass=$((pass + 1)); echo "  ok   EDI session value not in the response body"
fi

check "profile, signed in → T1" 200 -b "$JAR" -c "$JAR" "$BASE/api/v1/auth/profile"
grep -q '"tier":"T1"' <<<"$LAST_BODY" && echo "       tier T1 confirmed"

check "register-options → options + authSession" 200 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"
AUTH_SESSION="$(sed -n 's/.*"authSession":"\([^"]*\)".*/\1/p' <<<"$LAST_BODY")"
echo "       authSession=${AUTH_SESSION:0:12}…"

check "register-options as text/plain → 400" 400 -b "$JAR" -c "$JAR" \
  -H 'Content-Type: text/plain' --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"
check "unknown action → 400" 400 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data '{"action":"nope"}' "$BASE/api/v1/auth/passkey"
check "login-options (not built yet) → 501" 501 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data '{"action":"login-options"}' "$BASE/api/v1/auth/passkey"

FAKE='{"id":"AAAA","rawId":"AAAA","type":"public-key","response":{"clientDataJSON":"AAAA","attestationObject":"AAAA"},"clientExtensionResults":{}}'
check "fabricated attestation → 400" 400 -b "$JAR" -c "$JAR" -X PUT "${json[@]}" \
  --data "{\"action\":\"register\",\"authSession\":\"$AUTH_SESSION\",\"response\":$FAKE}" \
  "$BASE/api/v1/auth/passkey"
check "replay of the consumed authSession → 400" 400 -b "$JAR" -c "$JAR" -X PUT "${json[@]}" \
  --data "{\"action\":\"register\",\"authSession\":\"$AUTH_SESSION\",\"response\":$FAKE}" \
  "$BASE/api/v1/auth/passkey"

check "second browser (separate jar) → T0" 200 -b "$OTHER_JAR" -c "$OTHER_JAR" "$BASE/api/v1/auth/profile"
grep -q '"tier":"T0"' <<<"$LAST_BODY" && echo "       isolation confirmed"

check "forged EDI cookie → 401" 401 -b "edi-session-id=mock-edi.forged" "${json[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"

echo
echo "passed: $pass  failed: $fail"
[[ "$fail" -eq 0 ]]
