#!/usr/bin/env bash
# Smoke-test the mock passkey-registration BFF over HTTP.
#
#   pnpm dev                                   # with USE_AUTH_MOCKS=true
#   ./scripts/auth-bff/passkey-registration-smoke.sh [base-url]
#
# Covers: mock T1 sign-in, profile, register-options, and the main error
# paths. curl cannot produce a signed attestation, so a successful
# `PUT register` is covered by the Vitest suite and /demo/passkey-bff.
set -euo pipefail

BASE="${1:-http://localhost:3000}"
ORIGIN="${ORIGIN:-$BASE}"
JAR="$(mktemp)"
OTHER_JAR="$(mktemp)"
trap 'rm -f "$JAR" "$OTHER_JAR"' EXIT

pass=0
fail=0

# check <label> <expected-status> <curl args...>
check() {
  local label="$1" expected="$2"
  shift 2
  local body status
  body="$(mktemp)"
  status="$(curl -sS -o "$body" -w '%{http_code}' "$@")"
  if [[ "$status" == "$expected" ]]; then
    pass=$((pass + 1))
    printf '  ok   %-48s %s\n' "$label" "$status"
  else
    fail=$((fail + 1))
    printf '  FAIL %-48s got %s, want %s\n' "$label" "$status" "$expected"
  fi
  LAST_BODY="$(cat "$body")"
  rm -f "$body"
}

json=(-H 'Content-Type: application/json')
origin=(-H "Origin: $ORIGIN")

echo "Passkey registration BFF smoke test → $BASE"

check "profile, signed out → T0" 200 -b "$JAR" -c "$JAR" "$BASE/api/v1/auth/profile"
check "register-options without session → 401" 401 -b "$JAR" -c "$JAR" "${json[@]}" "${origin[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"

check "mock sign-in (T1)" 200 -b "$JAR" -c "$JAR" "${json[@]}" "${origin[@]}" \
  --data '{"channel":"email","recipient":"smoke@example.test"}' "$BASE/api/v1/auth/mock-session"
if grep -q 'mock-edi\.' <<<"$LAST_BODY" || grep -q 'mock-edi\.' "$JAR"; then
  fail=$((fail + 1)); echo "  FAIL EDI session value leaked to the browser"
else
  pass=$((pass + 1)); echo "  ok   EDI session value not exposed"
fi

check "profile, signed in → T1" 200 -b "$JAR" -c "$JAR" "$BASE/api/v1/auth/profile"
grep -q '"tier":"T1"' <<<"$LAST_BODY" && echo "       tier T1 confirmed"

check "register-options → options + authSession" 200 -b "$JAR" -c "$JAR" "${json[@]}" "${origin[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"
AUTH_SESSION="$(sed -n 's/.*"authSession":"\([^"]*\)".*/\1/p' <<<"$LAST_BODY")"
echo "       authSession=${AUTH_SESSION:0:12}…"

check "register-options, foreign Origin → 403" 403 -b "$JAR" -c "$JAR" "${json[@]}" \
  -H 'Origin: https://evil.example' --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"
check "register-options, no Origin → 403" 403 -b "$JAR" -c "$JAR" "${json[@]}" \
  --data '{"action":"register-options"}' "$BASE/api/v1/auth/passkey"
check "unknown action → 400" 400 -b "$JAR" -c "$JAR" "${json[@]}" "${origin[@]}" \
  --data '{"action":"nope"}' "$BASE/api/v1/auth/passkey"
check "login-options (not built yet) → 501" 501 -b "$JAR" -c "$JAR" "${json[@]}" "${origin[@]}" \
  --data '{"action":"login-options"}' "$BASE/api/v1/auth/passkey"

FAKE_RESPONSE='{"id":"AAAA","rawId":"AAAA","type":"public-key","response":{"clientDataJSON":"AAAA","attestationObject":"AAAA"},"clientExtensionResults":{}}'
check "fabricated attestation → 400 (rejected)" 400 -b "$JAR" -c "$JAR" -X PUT "${json[@]}" "${origin[@]}" \
  --data "{\"action\":\"register\",\"authSession\":\"$AUTH_SESSION\",\"response\":$FAKE_RESPONSE}" \
  "$BASE/api/v1/auth/passkey"
check "replay of consumed authSession → 400" 400 -b "$JAR" -c "$JAR" -X PUT "${json[@]}" "${origin[@]}" \
  --data "{\"action\":\"register\",\"authSession\":\"$AUTH_SESSION\",\"response\":$FAKE_RESPONSE}" \
  "$BASE/api/v1/auth/passkey"

check "second shopper sees T0 (separate jar)" 200 -b "$OTHER_JAR" -c "$OTHER_JAR" "$BASE/api/v1/auth/profile"
grep -q '"tier":"T0"' <<<"$LAST_BODY" && echo "       isolation confirmed"

check "mock sign-out → 204" 204 -b "$JAR" -c "$JAR" -X DELETE "${origin[@]}" "$BASE/api/v1/auth/mock-session"
check "profile after sign-out → 200" 200 -b "$JAR" -c "$JAR" "$BASE/api/v1/auth/profile"
grep -q '"tier":"T0"' <<<"$LAST_BODY" && echo "       back to T0"

echo
echo "passed: $pass  failed: $fail"
[[ "$fail" -eq 0 ]]
