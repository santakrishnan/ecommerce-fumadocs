# Pull Request

## Summary

Fixes the Personalized Search Recommendation cards on the welcome-back page: updates card images to new editorial assets, enriches "Saved search" fallback headlines from IDB agent turns, caps results at 3, and forces all cards to dark surface. Includes documentation for the media sort utility design and visitor identity reset procedure.

## Jira

Jira story: PEDX01-2838

## Changes

### Personalized Search Carousel — IDB headline enrichment

| File | Change |
|---|---|
| `personalized-search-carousel.tsx` | When a card's headline is "Saved search" (API returned no name/query), queries IDB `agent-search-turns` collection for the matching `searchId` and replaces the headline with the user's original query text. Uses `useLiveQuery` with `mounted` gate to avoid SSR issues. |

### Service — image + card cap

| File | Change |
|---|---|
| `get-personalized-search-cards.ts` | Updated card image pool to new editorial assets (`editorial_card_ev.png`, `editorial_card_trunk.png`, `editorial_fuel.png`). Set all card surfaces to `"dark"`. Added `MAX_CARDS = 3` slice before mapping. |

### New assets

| File |
|---|
| `public/editorial-card/editorial_card_ev.png` |
| `public/editorial-card/editorial_card_trunk.png` |
| `public/editorial-card/editorial_fuel.png` |

### Documentation

| File | Purpose |
|---|---|
| `docs/create-media-sort-utility.md` | Design doc for the filename-prefix-based image sort utility (future ticket) |
| `docs/demo-visitor-identity-reset.md` | Guide for resetting visitor identity during demos/testing |

## Visual QA

Before: Cards showed old placeholder images (`img-one.png`, `card-demo.png`), some with light surface. Fallback headlines stuck at "Saved search" even when the user had queried.

After: Cards use new high-quality editorial images, all dark surface, and headlines enriched from IDB when the API doesn't return a name/query.

## Checklist

- [x] PR title uses Conventional Commits format (`fix(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` passes
- [x] `pnpm test` passes
- [x] No hydration mismatch — `useLiveQuery` gated behind `mounted` state
- [x] No breaking changes
- [x] No hardcoded colors

## Out-of-scope items observed

- The IDB enrichment only fires for cards with `headline === "Saved search"` — if the API returns a partial name, it's not enriched
- The `or()` query from `@tanstack/react-db` is used for multi-searchId lookup — verify performance with many cards
- The media sort utility design doc is reference only — implementation is a separate ticket

## Reviewer focus

- **IDB enrichment pattern** — `useLiveQuery` is gated by `mounted` state (avoids SSR `getServerSnapshot` error) + checks `collection` and `searchIdsNeedingEnrichment.length`. Verify this doesn't cause a render loop with the `useMemo` dependencies.
- **`or()` usage** — for multiple `eq(t.searchId, id)` conditions. Confirm this is the correct TanStack DB API for OR queries.
- **`enrichedCards` memoization** — depends on `cards` (server prop) + `idbQueryMap` (client state). Cards prop is stable per render; map changes when IDB resolves. Should trigger exactly one re-render after IDB loads.
- **Image assets** — 3 new PNGs (~390–490KB each). Verify they're optimized for web (these will be served via `next/image` which converts to avif/webp).
- **`MAX_CARDS = 3`** — slices before mapping. Confirm this matches the carousel layout (3 large cards fit at `colSpan={{ sm: 4, lg: 4 }}`).

## Commit message

```
fix(web): personalized search cards — new images, IDB headline enrichment, 3-card cap [PEDX01-2838]

- Replace card image pool with new editorial assets (ev, trunk, fuel)
- Force all card surfaces to "dark" for visual consistency
- Cap results at MAX_CARDS (3) before mapping
- Enrich "Saved search" fallback headlines from IDB agent-search-turns:
  query the collection for matching searchIds, replace headline with the
  user's original query text when available
- Gate useLiveQuery behind mounted state to avoid SSR getServerSnapshot error
- Add design doc for media sort utility (future ticket)
- Add visitor identity reset guide for demos
```
