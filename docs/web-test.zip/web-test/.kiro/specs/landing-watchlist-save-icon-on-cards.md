# Jira Story: Restore bookmark/watchlist save icon on landing and welcome-back inventory cards

## Summary

The bookmark (save/heart) icon is missing on inventory cards in multiple sections on the landing and welcome-back pages: New Today, Rare Finds, Continue Shopping, and "Based on Your Search" (Search Recommendations). Restore the save icon on all these carousels so users can bookmark vehicles directly from the homepage.

## User Story

As a visitor browsing the landing or welcome-back page, I want to see a save/bookmark icon on each vehicle card across all inventory carousels — so that I can quickly save vehicles to my watchlist without navigating to the VDP.

## Background

The `InventoryCardCarousel` component accepts a `showSaveIcon` prop which passes through to `LinkInventoryCard` as `showSaveButton`. The save button renders a client-island (`SaveButtonClient`) that calls `useBookmarkedVehicle(vin)` from the watchlist feature to toggle IDB + server sync.

**Current state per section:**

| Section | Component | showSaveIcon/showSaveButton | Result |
|---|---|---|---|
| New Today | `FeaturedVehiclesSection` | `showSaveIcon={true}` on carousel | Works IF `vehicle.vin` is truthy |
| Rare Finds | `RareFindsWrapper` → `RareFindsSection` | Default `false`, not overridden in layouts | **Icon missing** |
| Continue Shopping | `ContinueShoppingCarousel` → `LinkInventoryCard` | Neither `showSaveButton` nor `showSaveIcon` passed | **Icon missing** |
| Search Recommendations | `SearchRecommendationsSection` → `LinkInventoryCard` | `showSaveButton` passed ✓ | Works IF `vehicle.vin` is truthy |

**The save button only renders when BOTH conditions are true:**
```ts
const shouldShowSaveButton = (showSaveButton ?? vehicle.showBadge ?? false) && Boolean(vehicle.vin);
```
So even with `showSaveIcon={true}`, the button won't appear if `vehicle.vin` is falsy.

## Problem Statement

1. **Rare Finds:** `showSaveIcon` is never set to `true` in `landing-body.tsx` or `welcome-body.tsx` — the icon is completely missing.
2. **Continue Shopping:** `ContinueShoppingCarousel` renders `LinkInventoryCard` without `showSaveButton` — the icon is completely missing.
3. **New Today:** `showSaveIcon` is set to `true` in the carousel BUT if the upstream vehicle data is missing the `vin` field (or it's an empty string), the save button won't render due to the `Boolean(vehicle.vin)` guard.
4. **Search Recommendations ("Based on Your Search"):** `showSaveButton` IS passed to `LinkInventoryCard` but the icon won't render if `vehicle.vin` is missing from the recommendations response.
5. All sections previously showed the save icon (per the user's report) — this is a regression.

## Scope

- Pass `showSaveIcon={true}` to `<RareFindsWrapper />` in both `landing-body.tsx` and `welcome-body.tsx` (or change the default to `true`)
- Add `showSaveButton` to `<LinkInventoryCard>` inside `ContinueShoppingCarousel`
- Verify that `SearchRecommendationsSection` vehicles have `vin` populated from the recommendations response (already passes `showSaveButton` — just needs VIN data)
- Verify that vehicles in the New Today section have `vin` populated from the upstream response
- Verify that vehicles in the Rare Finds section have `vin` populated (current fixture data already includes VINs)
- Verify that vehicles in the Continue Shopping carousel (recently viewed + new today) have `vin`
- Confirm the `SaveButtonClient` renders correctly as a client island inside all Server Component sections

## Dependencies / Constraints

- The save button requires `vehicle.vin` to be a truthy 17-character string — vehicles without VINs cannot be bookmarked
- `SaveButtonClient` uses `next/dynamic` with `ssr: false` — it renders `null` during SSR and hydrates on the client. No layout shift expected since it's absolutely positioned (top-right adornment).
- The bookmarked vehicle collection (`bookmarkedVehiclesCollection`) must be initialized (requires resolved visitor identity) — if the visitor hasn't resolved yet, the button may show but toggles won't persist until identity resolves

## Design References

- `apps/web/src/features/landing/components/featured-vehicles-section.tsx` — New Today section
- `apps/web/src/features/landing/components/rare-finds/rare-finds-section.tsx` — Rare Finds section
- `apps/web/src/features/landing/components/rare-finds/rare-finds-wrapper.tsx` — Rare Finds wrapper
- `apps/web/src/features/landing/components/home-experience/landing-body.tsx` — Landing page layout
- `apps/web/src/features/landing/components/home-experience/welcome-body.tsx` — Welcome-back layout
- `apps/web/src/shared/components/inventory-card/link-inventory-card.tsx` — Save button rendering logic
- `apps/web/src/shared/components/inventory-card/inventory-card-carousel.tsx` — Carousel showSaveIcon prop
- `apps/web/src/shared/components/inventory-card/save-button-client.tsx` — Client-only dynamic import
- `apps/web/src/features/landing/services/inventory-vehicles-service.ts` — `toVehicle` mapper (New Today)

## Acceptance Criteria

1. The save/bookmark icon is visible on **every vehicle card** in the **New Today** section on both the landing page and welcome-back page.
2. The save/bookmark icon is visible on **every vehicle card** in the **Rare Finds** section on both the landing page and welcome-back page.
3. The save/bookmark icon is visible on **every vehicle card** in the **Continue Shopping** carousel (both "Recently Viewed" and "New Today" groups) on the welcome-back page.
4. The save/bookmark icon is visible on **every vehicle card** in the **"Based on Your Search"** (Search Recommendations) section on the welcome-back page.
5. Clicking the save icon toggles the vehicle's bookmarked state (heart fills/unfills).
6. The bookmarked state persists in IndexedDB and syncs with the server watchlist.
7. The save icon is positioned top-right of the card image (existing `badgePosition="top-2 right-2"`).
8. Cards that genuinely have no VIN (edge case) do NOT show the save icon — this is correct behavior, not a bug.
9. The save button renders as a client island — no SSR hydration mismatch.
10. No layout shift when the save button hydrates on the client.

## QA Notes

- Verify save icon appears on all New Today cards (landing + welcome-back)
- Verify save icon appears on all Rare Finds cards (landing + welcome-back)
- Verify save icon appears on all Continue Shopping cards (welcome-back)
- Verify save icon appears on all Search Recommendations cards (welcome-back)
- Click save icon → verify heart fills and vehicle appears in watchlist
- Click again → verify heart unfills and vehicle is removed from watchlist
- Refresh page → verify saved state persists (bookmarked vehicles still show filled heart)
- Test with a new visitor (no identity resolved) → save icon should appear but verify behavior on click
- Inspect network tab → confirm watchlist POST/DELETE fires on toggle

## Non-Functional Requirements

- **Accessibility:** Save button must be keyboard-focusable and have an accessible label (e.g., "Save 2024 Toyota Supra" / "Remove 2024 Toyota Supra from saved").
- **Performance:** `SaveButtonClient` is dynamically imported with `ssr: false` — no server bundle impact. No additional data fetching added.
- **Reliability:** Save icon visibility is deterministic (`showSaveIcon && vin` truthy). No flicker.

## Out of Scope

- Changing the save icon design/animation
- Watchlist sync or server-side persistence bugs (separate tickets)
- Save icon on search results page cards (already handled separately)

## Files to Change

| File | Change |
|---|---|
| `landing-body.tsx` | Pass `showSaveIcon` to `<RareFindsWrapper />` |
| `welcome-body.tsx` | Pass `showSaveIcon` to `<RareFindsWrapper />` |
| `rare-finds-wrapper.tsx` | Change default from `false` to `true` (or leave as prop) |
| `continue-shopping-carousel.tsx` | Add `showSaveButton` to `<LinkInventoryCard>` |
| `search-recommendations-section.tsx` | Already passes `showSaveButton` — verify vehicles have `vin` from upstream |
| `inventory-vehicles-service.ts` | Verify `toVehicle` includes `vin` from upstream response (already present — confirm) |
| `get-search-recommendations.ts` | Verify `toVehicle` mapper populates `vin` from recommendations response |

## Suggested File Name

landing-watchlist-save-icon-on-cards.md
