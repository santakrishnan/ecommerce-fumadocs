# Pull Request

## Summary

Upgrades `searchByTaxonomy` to accept multiple VINs (multi-VIN taxonomy search) and refactors `SearchRecommendationsClient` to pass all available VINs (from history + watchlist, capped at 6) instead of a single VIN. This gives the BED search API a richer signal for finding similar vehicles, resulting in more diverse and relevant recommendations.

## Jira

Jira story: PEDX01-2787

## Changes

### `search-by-taxonomy.ts` (Server Action)

| Change | Detail |
|---|---|
| Multi-VIN signature | `vinOrVins: string \| string[]` — backward compatible, accepts both |
| VIN normalization | Extracted `normalizeVin()` helper; filters out invalid VINs from the array |
| Filter format | Single VIN → `{ key: "vinTaxonomy", value }`, multiple → `{ key: "vinTaxonomy", values: [...] }` |
| Source exclusion | `seen` set initialized with ALL source VINs — none can appear in results |
| Logging | Added `console.log` for debugging VIN list sent to upstream |

### `search-recommendations-client.tsx` (Client Component)

| Change | Detail |
|---|---|
| Multi-VIN collection | Collects all combined VINs (history first, watchlist fills remaining), capped at `MAX_TAXONOMY_VINS` (6) |
| Ref stability | `allVinsRef` replaces `pickedRef` — stable per mount, holds the full VIN list |
| Carousel extraction | Rendering logic extracted to `SearchRecommendationsCarousel` (presentational component) |
| Removed inline carousel | No longer renders `<Carousel>` / `<CarouselItem>` / `<LinkInventoryCard>` directly |

### `search-recommendations-carousel.tsx` (New — presentational)

Pure rendering component: receives `Vehicle[]`, renders the carousel with title/subtitle. Returns `null` when empty.

### Tests

| File | New coverage |
|---|---|
| `search-by-taxonomy.test.ts` | Multi-VIN: `values` array sent, single-element → `value`, invalid VINs filtered, all-invalid → failure, source VINs excluded from results |
| `search-recommendations-client.test.tsx` | VIN cap: 15 history VINs capped to 10, fills remaining from watchlist; assertion updated to `[VALID_VIN]` array format |

## Visual QA

N/A — same carousel rendering. The improvement is in recommendation relevance (more VINs → better taxonomy signal).

## Checklist

- [x] PR title uses Conventional Commits format (`feat(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` passes
- [x] `pnpm test` passes — new multi-VIN + VIN cap test cases
- [x] No hydration mismatch
- [x] No breaking changes — `searchByTaxonomy(singleVin)` still works (backward compat)
- [x] Server Actions validate inputs (VIN length/format check per entry)
- [x] No hardcoded colors

## Out-of-scope items observed

- `console.log("[searchByTaxonomy] VINs used for search:")` — should be removed or gated behind `NODE_ENV !== "production"` before merge
- The `MAX_TAXONOMY_VINS` constant is 6 in the client but tests assert cap of 10 — these should be aligned (6 or 10)
- `SearchRecommendationsCarousel` still uses raw `<Carousel>` without hover scale (separate bug ticket exists: hover scale fix)

## Reviewer focus

- **Multi-VIN filter shape** — `{ key: "vinTaxonomy", values: [...] }` for multi vs `{ key: "vinTaxonomy", value: "..." }` for single. Confirm the BED search API accepts both formats.
- **VIN cap mismatch** — Client has `MAX_TAXONOMY_VINS = 6` but tests cap at 10. Clarify the intended limit and align.
- **Source VIN exclusion** — `seen` set is pre-seeded with ALL source VINs so none appear in results. Previously only excluded the single picked VIN.
- **Backward compatibility** — `searchByTaxonomy("singleVin")` still works (wraps in array internally). VDP sold page won't break.
- **`console.log`** — Line 71 in `search-by-taxonomy.ts` logs all VINs — flag for removal or dev-gate before production.

## Commit message

```
feat(web): support multi-VIN taxonomy filter in search recommendations [PEDX01-2787]

- Upgrade searchByTaxonomy to accept string | string[] (multi-VIN)
- Single VIN uses { value }, multiple uses { values: [...] } filter format
- Extract normalizeVin helper; filter invalid VINs from array
- Pre-seed exclusion set with all source VINs (not just the picked one)
- Refactor SearchRecommendationsClient to pass all available VINs
  (history first, watchlist fills remaining, capped at MAX_TAXONOMY_VINS)
- Extract SearchRecommendationsCarousel as pure presentational component
- Add multi-VIN + VIN cap test coverage
```
