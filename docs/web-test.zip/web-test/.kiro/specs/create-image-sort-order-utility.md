# Jira Story: Create shared image sort utility using filename prefix instead of displayOrder

## Summary

Create a shared utility (`resolveHeroPhotoUrl`) that sorts vehicle photos by extracting the numeric prefix from the filename in the `url` field (e.g., `011` from `public/.../011-cfa6d5528918.jpg`) and returns the photo with the lowest prefix. Replace all existing `displayOrder`-based sorting across the codebase. The `displayOrder` field is unreliable — multiple photos share the same value (e.g., all front shots have `displayOrder: 11`), making the sort non-deterministic.

## Problem

The BED API returns photos with a `displayOrder` field, but:
- Multiple photos share the **same** `displayOrder` (e.g., 10 photos all with `displayOrder: 11`)
- Different capture sessions produce duplicate photos at the same `displayOrder`
- Sorting by `displayOrder` alone is non-deterministic — the "hero" image varies between renders

The **filename prefix** (first 3 characters before the dash) is the true canonical order:
```
"url": "public/81bd5696291952c3a98a6932b349f735/011-cfa6d5528918.jpg"
                                                ^^^
                                                This is the sort key
```

Prefix `011` = front, `012` = front-left, `013` = side-left, `014` = rear-left, etc.

## Utility Design

```ts
// shared/lib/media/resolve-hero-photo.ts

/**
 * Extracts the numeric sort prefix from a media URL filename.
 * e.g., "public/hash/011-abc123.jpg" → 11
 *       "public/hash/035-xyz789.jpg" → 35
 * Returns Infinity for URLs without a parseable prefix.
 */
export function extractPhotoSortOrder(url: string): number {
  const filename = url.split("/").pop() ?? "";
  const prefix = filename.slice(0, 3);
  const num = Number.parseInt(prefix, 10);
  return Number.isFinite(num) ? num : Infinity;
}

/**
 * Sorts photos by filename prefix (ascending) and returns the sorted array.
 * The first item is the hero image (lowest prefix = front-facing shot).
 */
export function sortPhotosByFilename<T extends { url: string }>(photos: T[]): T[] {
  return [...photos].sort(
    (a, b) => extractPhotoSortOrder(a.url) - extractPhotoSortOrder(b.url)
  );
}

/**
 * Returns the hero photo URL (lowest filename prefix) from a photos array.
 * Returns undefined if the array is empty.
 */
export function resolveHeroPhotoUrl(photos: Array<{ url: string }>): string | undefined {
  if (photos.length === 0) return undefined;
  let best = photos[0]!;
  let bestOrder = extractPhotoSortOrder(best.url);
  for (const photo of photos) {
    const order = extractPhotoSortOrder(photo.url);
    if (order < bestOrder) {
      best = photo;
      bestOrder = order;
    }
  }
  return best.url;
}
```

## Files to Update

| File | Current sort logic | New logic |
|---|---|---|
| `search/bff/mappers/search.mapper.ts` | `.sort((a, b) => a.displayOrder - b.displayOrder)[0]?.url` | `resolveHeroPhotoUrl(photos)` |
| `search/lib/card-mappers/map-sdk-inventory-card-to-vehicle.ts` | `card.media?.photos?.[0]?.url` (no sort at all) | `resolveHeroPhotoUrl(photos)` |
| `search/lib/card-mappers/map-inventory-card-to-inventory-card.ts` | `card.media?.primaryImageUrl ?? card.media?.photos?.[0]?.url` | `card.media?.primaryImageUrl ?? resolveHeroPhotoUrl(photos)` |
| `search/lib/card-mappers/map-v3-card-to-result-item.ts` | `media?.primaryImageUrl ?? media?.photos?.[0]?.url` | `media?.primaryImageUrl ?? resolveHeroPhotoUrl(photos)` |
| `landing/services/inventory-vehicles-service.ts` | `.sort((a, b) => a.displayOrder - b.displayOrder)` → first photo | `resolveHeroPhotoUrl(photos)` |
| `vehicle-detail/bff/utils/gallery-utils.ts` | `.sort((a, b) => a.displayOrder - b.displayOrder)` for gallery | `sortPhotosByFilename(photos)` |
| VDP `page.tsx` | `sortedPhotos.find(p => p.displayOrder === 1) ?? sortedPhotos[0]` | `resolveHeroPhotoUrl(photos)` |

## Acceptance Criteria

1. A shared utility `resolveHeroPhotoUrl` exists in `shared/lib/media/` (or `shared/lib/pricing/` sibling).
2. The utility extracts the 3-digit numeric prefix from the filename portion of the `url` field.
3. The photo with the **lowest numeric prefix** is selected as the hero image.
4. All 7 mappers/pages listed above use the shared utility instead of `displayOrder` sorting.
5. Non-parseable URLs (no numeric prefix) sort to the end (Infinity).
6. The utility handles `primaryImageUrl` fallback — if present, it takes priority over sorted photos.
7. Unit tests cover: normal sorting, duplicate prefixes (stable), non-parseable URLs, empty array.

## QA Notes

- Verify inventory cards on landing (New Today), search results, and VDP all show the front-facing (011) image as the hero
- Compare with the `thumbnailUrl` field in the API response — it should match the utility's selection (both point to the 011 prefix image)
- Verify VDP gallery shows images in correct angle order (011 → 012 → 013 → ...)

## Out of Scope

- Changing the API to fix `displayOrder` upstream
- Deduplicating photos (same prefix from different capture sessions)
- Filtering non-vehicle images (displayOrder 900+ = non-car photos) — separate concern

## Suggested File Name

create-image-sort-order-utility.md
