# Jira Story: Clean up stale and unused files in features/landing

## Summary

Remove 9 unused/stale files and clean up barrel exports in the landing feature module

## User Story

As a developer working in the landing feature, I want dead code removed so that the module is easier to navigate, imports resolve faster, and bundle analysis isn't polluted by unreachable code.

## Background

An audit of `apps/web/src/features/landing/` identified 9 files that are either never rendered, superseded by newer implementations, or only consumed by their own tests. Several barrel exports in `index.ts` also surface symbols with zero external consumers. These accumulated during iterative feature work and are now safe to remove.

## Problem Statement

The landing feature contains dead code that:
- Inflates the module surface area and confuses onboarding developers
- May trigger unused-export lint warnings in future stricter configs
- Adds unnecessary weight to IDE indexing and type-checking time
- Creates false positives when searching for component usage patterns

## Scope

### Files to delete

| # | File | Reason |
|---|------|--------|
| 1 | `components/dealer-offers-section.tsx` | Exported from barrel but never rendered by any page or layout |
| 2 | `components/dealer-offers-skeleton.tsx` | Exported from barrel but never rendered anywhere |
| 3 | `components/search-prompt/search-prompt-link.tsx` | Only referenced in its own test, never rendered |
| 4 | `components/search-prompt/search-prompt-wrapper.tsx` | Exported from barrel, never imported by any consumer |
| 5 | `components/search-prompt/search-prompt-client.stories.tsx` | Orphaned Storybook story (no active Storybook config) |
| 6 | `services/landing-page-data-service.ts` | Superseded by individual per-section services (`get-dealer-offers.ts`, `get-editorial-cards.ts`, `get-rare-finds.ts`, `get-search-recommendations.ts`) |
| 7 | `services/mock-autocomplete-service.ts` | Only consumer is the orphaned stories file (#5) |
| 8 | `services/submit-vehicle-action.ts` | Never called from any component, route handler, or form action |
| 9 | `data/mock-vehicle-dataset.ts` | Re-exports from search feature but nothing imports it |

### Tests to delete (paired with removed files)

- Any `__tests__/` files that only test the removed modules (e.g. `landing-page-data-service.test.ts`, `submit-vehicle-action.test.ts`)

### Barrel export cleanup (`index.ts`)

Remove these exports from the landing feature barrel:
- `DealerOffersSection`, `DealerOffersSkeleton`
- `SearchPromptLink`, `SearchPromptWrapper`
- `getCategories`, `getDealerOffers`, `getEditorialContent`, `getRareFinds`, `ServiceResult`
- `DEALER_OFFERS` (only consumed internally by `get-dealer-offers.ts` which can use a direct import)
- `categorySchema`, `dealerOfferSchema`, `editorialContentSchema`, `vehicleCardSchema` (no external consumers)

### Validation

- `pnpm type-check` passes after all deletions
- `pnpm lint` passes with no new warnings
- `pnpm test` passes (removed test files won't cause failures)
- `pnpm build` succeeds with no missing module errors

## Dependencies / Constraints

- No external features import the files being removed (verified via grep audit)
- The `dealer-offers-copy.ts` data file is NOT removed — it's used by `get-dealer-offers.ts`
- The `dealer-cards.ts` data file is NOT removed — it's used by `get-dealer-offers.ts`
- `search-prompt/` folder retains all other files (action-buttons, image-preview, recording-bar, search-overlay, search-preferences-*, suggestion-item, waveform-visualizer)

## Acceptance Criteria

1. All 9 listed files are deleted from the repository.
2. Associated test files for the removed modules are deleted.
3. The `index.ts` barrel no longer exports the listed symbols.
4. `pnpm type-check` passes — no "cannot find module" or missing import errors.
5. `pnpm lint` passes — no new warnings introduced.
6. `pnpm test` passes — no test failures from the cleanup.
7. `pnpm build` succeeds — no route-level or chunk-level regressions.
8. No remaining imports reference the deleted files (verified via project-wide search).

## QA Notes

- This is a code cleanup with no user-facing changes
- Verify the welcome-back page and landing page render correctly after cleanup (dealer deal, editorial cards, budget calculator, search prompt all still function)
- No visual regression expected

## Non-Functional Requirements

- **Accessibility:** N/A — no UI changes
- **Performance:** Minor positive impact — fewer modules for bundler to process
- **Observability:** N/A
- **Compatibility:** No breaking changes — removed code had zero consumers

## Out of Scope

- Refactoring the remaining services or components
- Adding new tests for surviving code
- Restructuring the landing feature folder hierarchy
- Removing the `data/dealer-offers-copy.ts` or `data/dealer-cards.ts` (still actively used)

## Suggested File Name

chore-landing-feature-cleanup.md
