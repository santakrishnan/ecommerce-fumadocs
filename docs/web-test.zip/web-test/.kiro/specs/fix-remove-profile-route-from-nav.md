# Jira Bug: Remove /profile link from navigation header profile icon

## Summary

The profile icon in the navigation header links to `/profile` which is a non-existent route (returns 404). Remove the navigation link — the icon should be a non-navigating button until the profile page is implemented.

## Bug Description

**Steps to reproduce:**
1. Click the Profile icon (person icon) in the bottom navigation bar
2. Browser navigates to `/profile`
3. 404 page is shown

**Expected:** The profile icon should not navigate anywhere since the `/profile` route doesn't exist yet.

## Root Cause

In `apps/web/src/shared/components/navigation-bar/navigation-bar.tsx`, the profile nav item is configured with `href: ROUTES.PROFILE` (`"/profile"`):

```tsx
// navigation-bar.tsx — line ~49
{
  href: ROUTES.PROFILE,          // → "/profile" (route doesn't exist)
  Icon: IconProfile,
  IconActive: IconProfileFilled,
  isActive: (p) => p.startsWith(ROUTES.PROFILE),
  key: "profile",
  label: "Profile",
},
```

The route `ROUTES.PROFILE = "/profile"` is defined in `apps/web/src/config/routes/constants.ts` (line 97) but no corresponding `app/(shop)/profile/page.tsx` exists.

## Files to Fix

| File | Change |
|---|---|
| `apps/web/src/shared/components/navigation-bar/navigation-bar.tsx` | Change the profile nav item from a navigating `<Link>` to a non-navigating `<Button>` (or remove `href`, use `onClick` stub) |
| `apps/web/src/shared/components/navigation-bar/__tests__/navigation-bar.test.tsx` | Update test assertion — currently expects `href="/profile"` on the profile button |

## Recommended Fix

Option A — Remove `href` and make it a no-op button:

```diff
  {
-   href: ROUTES.PROFILE,
+   href: "#",
    Icon: IconProfile,
    IconActive: IconProfileFilled,
-   isActive: (p) => p.startsWith(ROUTES.PROFILE),
+   isActive: () => false,
    key: "profile",
    label: "Profile",
  },
```

Option B — Remove the profile item entirely from `DEFAULT_NAV_ITEMS` until the route exists (reduces confusion, but changes the nav layout from 3 to 2 icons).

**Recommended: Option A** — keep the icon for visual consistency, just prevent navigation.

## Acceptance Criteria

1. Clicking the profile icon in the navigation bar does NOT navigate to `/profile`.
2. No 404 page is triggered.
3. The profile icon remains visually present in the navigation bar.
4. The icon is still keyboard-focusable (accessible).
5. Test assertion updated to match new behaviour.

## QA Notes

- Click profile icon → verify no navigation occurs
- Verify icon still appears in the nav bar (3 icons: Home, Search, Profile)
- Verify keyboard Tab reaches the profile icon

## Suggested File Name

fix-remove-profile-route-from-nav.md
