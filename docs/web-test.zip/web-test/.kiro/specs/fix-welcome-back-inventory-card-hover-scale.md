# Jira Bug: Restore hover scale effect on welcome-back landing page inventory cards

## Summary

Inventory cards in the welcome-back landing page "Because You Viewed" (Search Recommendations) and "Continue Shopping" sections are missing the hover scale effect. The cards should lift/scale on hover like they do in the New Today and Rare Finds sections.

## Bug Description

**Current:** Hovering over a card in the "Because You Viewed" or "Continue Shopping" sections produces no visual feedback (no scale, no shadow lift). Other inventory card carousels on the same page (New Today, Rare Finds) have the hover effect.

**Expected:** Cards should scale up slightly on hover with a shadow lift, matching the New Today and Rare Finds carousels.

## Root Cause

Both `SearchRecommendationsClient` and `ContinueShoppingCarousel` render `LinkInventoryCard` items directly inside a raw `<Carousel>` / `<CarouselContent>` / `<CarouselItem>` structure. This bypasses the `InventoryCardCarousel` (or `CardCarousel`) wrapper which applies:
- `INVENTORY_CARD_HOVER_SCALE` — per-size scale ratio (CSS custom property)
- `hover:scale-[var(--carousel-hover-scale-ratio,1)]` class on each card
- `transition-[transform,box-shadow]` + `hover:shadow-hover`

**Working sections (use `InventoryCardCarousel`):**
- New Today (`FeaturedVehiclesSection`) — uses `<InventoryCardCarousel>` ✓
- Rare Finds (`RareFindsSection`) — uses `<InventoryCardCarousel>` ✓

**Broken sections (raw Carousel, no hover):**
- Search Recommendations (`SearchRecommendationsClient`) — uses raw `<Carousel>` without hover scale
- Continue Shopping (`ContinueShoppingCarousel`) — uses raw `<Carousel>` without hover scale

## Files to Fix

| File | Fix |
|---|---|
| `features/landing/components/search-recommendations-client.tsx` | Replace raw `<Carousel>` with `<InventoryCardCarousel>` — OR — add hover scale classes to `<CarouselItem>` wrappers |
| `features/landing/components/continue-shopping/continue-shopping-carousel.tsx` | Add hover scale classes to the `VehicleItems` component's `<CarouselItem>` wrappers — OR — use `InventoryCardCarousel` per group |

## Recommended Fix

### Option A: Use `InventoryCardCarousel` (SearchRecommendationsClient)

```diff
- <Carousel>
-   <CarouselContent>
-     {vehicles.map((vehicle) => (
-       <CarouselItem colSpan={{ sm: 2, md: 2, lg: 2 }} key={vehicle.id}>
-         <LinkInventoryCard showSaveButton size="small" variant="gradient" vehicle={vehicle} />
-       </CarouselItem>
-     ))}
-   </CarouselContent>
- </Carousel>
+ <InventoryCardCarousel
+   colSpan={{ sm: 2, md: 2, lg: 2 }}
+   showSaveIcon
+   size="small"
+   variant="gradient"
+   vehicles={vehicles}
+ />
```

### Option B: Add hover classes manually (ContinueShoppingCarousel)

The Continue Shopping carousel uses `CarouselGroup` with sticky headers — it can't easily switch to `InventoryCardCarousel` without losing the grouped layout. Instead, add hover classes to each card wrapper:

```diff
+ import { INVENTORY_CARD_HOVER_SCALE } from "@shared/components/inventory-card/inventory-card-size";
+
+ const CARD_HOVER = cn(
+   "transition-[transform,box-shadow] duration-200 ease-out",
+   "hover:z-10 hover:scale-[var(--carousel-hover-scale-ratio,1)] hover:shadow-hover",
+   "has-[a:focus-visible]:z-10 has-[a:focus-visible]:scale-[var(--carousel-hover-scale-ratio,1)]",
+   "motion-reduce:transform-none motion-reduce:transition-none"
+ );

  function VehicleItems({ vehicles }: { vehicles: Vehicle[] }) {
    return (
      <>
        {vehicles.map((vehicle) => (
-         <CarouselItem colSpan={{ sm: 2, md: 2, lg: 2 }} key={vehicle.id}>
+         <CarouselItem className={CARD_HOVER} colSpan={{ sm: 2, md: 2, lg: 2 }} key={vehicle.id}>
            <LinkInventoryCard ... />
          </CarouselItem>
        ))}
      </>
    );
  }
```

And set `--carousel-hover-scale-ratio` on the carousel viewport via `style={{ '--carousel-hover-scale-ratio': INVENTORY_CARD_HOVER_SCALE.sm }}`.

## Acceptance Criteria

1. Inventory cards in the "Because You Viewed" section scale up on hover with a shadow lift.
2. Inventory cards in the "Continue Shopping" section (both "Recently Viewed" and "New Today" groups) scale up on hover with a shadow lift.
3. The hover effect matches the scale ratio used in the New Today and Rare Finds sections (size "small" → same ratio).
4. Keyboard focus produces the same visual lift as mouse hover.
5. No layout shift when hovering (cards scale within their allocated space).
6. `motion-reduce` media query disables the transform for accessibility.

## QA Notes

- Hover over cards in "Because You Viewed" section → verify scale + shadow
- Hover over cards in "Continue Shopping" section (both groups) → verify scale + shadow
- Compare visually with the New Today / Rare Finds sections on the same page
- Test keyboard tab through cards → verify focus ring + lift
- Test with `prefers-reduced-motion: reduce` → verify no scale animation
- Verify no clip overflow issues when cards scale (carousel `overflow-x-clip` should allow Y-axis overflow for the transform)

## Suggested File Name

fix-welcome-back-inventory-card-hover-scale.md
