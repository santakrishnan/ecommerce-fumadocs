# Jira Story: Dealer Deal card background image not loading

## Summary

Fix DealerDealCard hero image failing to load due to absolute URL in vehicle-lookup fixture

## User Story

As a returning user on the welcome-back page, I want to see the Dealer Deal card with its vehicle image, so that the financing offer is visually compelling and I can identify the vehicle at a glance.

## Background

The `DealerDealCard` component renders a hero vehicle image using `next/image` with the `fill` prop. The image URL is sourced from the vehicle-lookup fixture used by the `getDealerDeal` use-case. The fixture was constructing absolute URLs (`http://localhost:3000/images/deal/...`) using a `NEXT_PUBLIC_IMAGE_BASE_URL` env var. Next.js treats absolute URLs as remote images requiring explicit `remotePatterns` configuration — since `localhost` wasn't registered, the image request was blocked.

## Problem Statement

The Dealer Deal card on the welcome-back page renders with a grey placeholder where the vehicle image should be. The `next/image` component silently fails because the absolute URL (`http://localhost:3000/images/deal/four-runner-img.png`) is treated as a remote image without a matching `remotePatterns` entry in `next.config.ts`.

## Root Cause

`apps/web/src/features/landing/bff/__fixtures__/vehicle-lookup.fixture.ts` used:
```ts
const IMAGE_BASE_URL = process.env.NEXT_PUBLIC_IMAGE_BASE_URL ?? "http://localhost:3000";
// ...
photos: [{ url: `${IMAGE_BASE_URL}/images/deal/four-runner-img.png`, displayOrder: 1 }]
```

This produced an absolute URL that `next/image` rejects as an unconfigured remote source. The image file exists at `apps/web/public/images/deal/four-runner-img.png` and should be referenced with a relative path.

## Scope

- Remove `IMAGE_BASE_URL` constant from `vehicle-lookup.fixture.ts`
- Change photo URLs to relative paths: `/images/deal/four-runner-img.png`
- Verify the image renders on the welcome-back page

## Acceptance Criteria

1. The Dealer Deal card on `/welcome-back` renders the vehicle hero image (no grey/empty placeholder).
2. No `next/image` console warnings about unconfigured remote patterns.
3. The `vehicle-lookup.fixture.ts` uses relative paths (`/images/...`) for all photo URLs.
4. `NEXT_PUBLIC_IMAGE_BASE_URL` env var is no longer referenced in the fixture.
5. The fix works in both dev (`pnpm dev`) and production build (`pnpm build && pnpm start`).

## QA Notes

- Navigate to `http://localhost:3000/welcome-back`
- Verify the Dealer Deal section shows the 4Runner image (not a grey box)
- Check browser DevTools console for any image-related errors
- Verify the image loads with proper Next.js optimisation (inspect the `<img>` src — should be `/_next/image?url=...`)

## Design References

- `apps/web/src/features/landing/bff/__fixtures__/vehicle-lookup.fixture.ts`
- `apps/web/src/features/landing/components/dealer-deal/dealer-deal-card.tsx`
- `apps/web/public/images/deal/four-runner-img.png`

## Non-Functional Requirements

- **Accessibility:** Image has `alt` text derived from vehicle year/make/model/trim.
- **Performance:** Image uses `next/image` with `fill` and appropriate `sizes` hint for responsive loading.

## Out of Scope

- Adding `remotePatterns` for a CDN (that's for when real upstream image URLs land)
- Changing other fixtures that may use the same `IMAGE_BASE_URL` pattern

## Suggested File Name

bug-dealer-deal-card-image-not-loading.md
