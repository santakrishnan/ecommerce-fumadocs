# Pull Request

## Summary

Introduces a shared `resolveDisplayPrice` utility and migrates all inventory card price resolution to use it. Adds `computed.effectivePrice` to the BFF search response schema. Fixes the "price shows $0" bug across all search surfaces by using `||` (treats API `0` as "not set") with a consistent precedence: `effectivePrice → finalPrice → sellingPrice → listPrice → msrp → 0`.

## Jira

Jira story: PEDX01-2722

## Changes

### New shared utility

| File | Purpose |
|---|---|
| `shared/lib/pricing/resolve-display-price.ts` | Single source of truth for price precedence. Accepts a `VehiclePricing` object, returns the display price. |
| `shared/lib/pricing/index.ts` | Public barrel export |

### Schema update

| File | Change |
|---|---|
| `search/bff/contracts/search-response.schema.ts` | Added `InventoryCardSchemaInferred` type + `InventoryCardResponse` intersection type with `computed?: { effectivePrice?: number }` |

### Mapper migrations (4 files)

| File | Before | After |
|---|---|---|
| `search/bff/mappers/search.mapper.ts` | Inline `effectivePrice \|\| sellingPrice \|\| listPrice` | `resolveDisplayPrice({ effectivePrice, sellingPrice, listPrice })` |
| `search/lib/card-mappers/map-sdk-inventory-card-to-vehicle.ts` | `sellingPrice \|\| listPrice \|\| msrp \|\| 0` | `resolveDisplayPrice(card.pricing)` |
| `search/lib/card-mappers/map-inventory-card-to-inventory-card.ts` | `listPrice ?? sellingPrice ?? msrp ?? 0` (bug: `??` kept `0`) | `resolveDisplayPrice(card.pricing)` |
| `search/lib/card-mappers/map-v3-card-to-result-item.ts` | `listPrice ?? sellingPrice ?? msrp ?? 0` (bug: `??` kept `0`) | `resolveDisplayPrice(pricing)` |

## Visual QA

Before: Inventory cards on `/search/[id]` and `/search/[id]/results` showed "$0" when the API returned `listPrice: 0` with a valid `sellingPrice`.

After: Cards correctly display the selling price (or effective price when available).

## Checklist

- [x] PR title uses Conventional Commits format (`fix(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` / `pnpm check` passes — no undeclared variables
- [x] `pnpm test` passes
- [x] No hydration mismatch
- [x] No breaking changes — same prices rendered, just correctly
- [x] No hardcoded colors

## Out-of-scope items observed

- `features/landing/bff/mappers/map-to-dealer-deal.ts` uses `pricing.sellingPrice ?? pricing.listPrice` — different context (dealer deal card, not inventory card). Could adopt `resolveDisplayPrice` in a follow-up.
- `features/vehicle-detail/mappers/select-vehicle.ts` has its own `sellingPrice ?? listPrice` for VDP purchase card — separate concern (uses `listPrice` for struck-through "was" price). May warrant a separate `resolveVdpPricing()` utility.
- The `VehiclePricing` interface intentionally uses `number | null` (not `number | undefined`) for fields — allows passing SDK types directly without optional-to-null coercion.

## Reviewer focus

- **`resolveDisplayPrice` uses `||` not `??`** — This is intentional. The BED API returns `0` when a price tier doesn't apply (not `null`). `||` treats `0` as falsy and falls through. `??` would stop at `0`. This is the root cause of the "$0 price" bug.
- **Precedence order** — `effectivePrice → finalPrice → sellingPrice → listPrice → msrp → 0`. The backend computes `effectivePrice`/`finalPrice` from dealer rules; when present it always wins. Verify this matches business intent.
- **`InventoryCardResponse` type** — Uses intersection (`SchemaInferred & { computed? }`) rather than extending the Zod schema because `computed` comes through `.passthrough()` and isn't validated by Zod. This keeps the schema strict while allowing typed access to passthrough fields.
- **V3 mapper** — passes `pricing as Record<string, unknown>` because the V3 stream vehicle data is untyped (`Record<string, unknown>`). The utility's interface uses optional fields so this is safe — missing fields are `undefined` and skip.

## Commit message

```
fix(web): unify inventory card pricing via resolveDisplayPrice utility [PEDX01-2722]

- Add shared/lib/pricing/resolve-display-price.ts — single source of truth
  for price precedence: effectivePrice → finalPrice → sellingPrice →
  listPrice → msrp → 0
- Add computed.effectivePrice to InventoryCardResponse type (search schema)
- Migrate all 4 inventory card mappers to use resolveDisplayPrice:
  - search.mapper.ts (BFF /results page)
  - map-sdk-inventory-card-to-vehicle.ts (paginated results)
  - map-inventory-card-to-inventory-card.ts (agent InventoryCards stream)
  - map-v3-card-to-result-item.ts (agent V3 stream)
- Fix $0 price bug: use || (not ??) so API's listPrice:0 falls through
  to sellingPrice/msrp
- Fix undeclared msrp variable in map-sdk-inventory-card-to-vehicle.ts
```
