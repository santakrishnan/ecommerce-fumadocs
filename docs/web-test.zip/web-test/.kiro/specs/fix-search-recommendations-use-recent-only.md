# Jira Story: SearchRecommendationsConnected — use only top 3 most recent viewed vehicles for taxonomy query

## Summary

The `SearchRecommendationsClient` currently collects VINs from both vehicle history (recently viewed) AND watchlist (bookmarks), then sends up to 6 to the taxonomy search. Change the logic to use **only** recently viewed vehicles (from IDB history), take the **top 3 sorted by `viewedAt` descending** (most recent first), and remove the watchlist as a VIN source.

## User Story

As a returning visitor, I want the "Because You Viewed" recommendations to be based strictly on my most recent 3 vehicle views — so that the suggestions feel relevant to what I was just looking at, not diluted by older saved vehicles.

## Background

Current logic in `SearchRecommendationsClient`:
1. Reads VINs from `bookmarkedVehiclesCollection` (watchlist) 
2. Reads VINs from `vehicleHistoryCollection` (recently viewed)
3. Combines both, deduplicates (history first, watchlist fills remaining)
4. Caps at `MAX_TAXONOMY_VINS` (6)
5. Sends all to `searchByTaxonomy(vins, { limit })`

**New requirement:**
1. Read VINs from `vehicleHistoryCollection` ONLY
2. Sort by `viewedAt` descending (most recent first)
3. Take top 3
4. Send those 3 to `searchByTaxonomy(vins, { limit })`
5. Remove watchlist collection read entirely

## File to Fix

`apps/web/src/features/landing/components/search-recommendations-client.tsx`

## Changes Required

1. **Remove** `useBookmarkedVehiclesCollection` import and usage
2. **Remove** the `useLiveQuery` call for bookmarked VINs
3. **Remove** the `combinedVins` merge logic that combines history + watchlist
4. **Change** `MAX_TAXONOMY_VINS` from 6 to 3
5. **Simplify** to: read history → sort by `viewedAt` desc → take top 3 → send to taxonomy

## Recommended Implementation

```tsx
const MAX_TAXONOMY_VINS = 3;

// Only read from vehicle history (recently viewed)
const historyCollection = useVehicleHistoryCollection();
const { data: historyItems = [], isLoading } = useLiveQuery(
  (q) => {
    if (!historyCollection) return;
    return q
      .from({ h: historyCollection })
      .orderBy(({ h }) => h.viewedAt, "desc")
      .limit(MAX_TAXONOMY_VINS)
      .select(({ h }) => ({ vin: h.vin, title: h.title }));
  },
  [historyCollection]
);

// No watchlist, no combining, no dedup needed
const selectedVins = historyItems
  .map(item => item.vin)
  .filter(Boolean)
  .slice(0, MAX_TAXONOMY_VINS);
```

## Acceptance Criteria

1. The taxonomy search query uses **only** VINs from recently viewed vehicles (IDB history).
2. VINs are sorted by `viewedAt` descending — the 3 most recently viewed are used.
3. Maximum 3 VINs are sent to `searchByTaxonomy`.
4. The watchlist/bookmarks collection is NOT read by this component.
5. If the visitor has viewed fewer than 3 vehicles, send however many exist (1 or 2).
6. If the visitor has viewed 0 vehicles, the section renders `null` (hidden).
7. The section title remains "Because You Viewed".

## QA Notes

- View 5 vehicles on VDP → return to welcome-back → verify recommendations are based on the 3 most recent
- View 1 vehicle → verify recommendations still show (1 VIN sent)
- New visitor (no history) → verify section is hidden
- Add vehicles to watchlist but don't view any VDPs → verify section is hidden (watchlist no longer triggers it)

## Out of Scope

- Changing the taxonomy API limit (still controlled by `NEXT_PUBLIC_SEARCH_RECS_LIMIT`)
- Changing the carousel rendering or card count
- Using watchlist as a fallback when history is empty (explicitly removed per requirement)

## Suggested File Name

fix-search-recommendations-use-recent-only.md
