# Pull Request

## Summary

Implements the visitor preferences BFF proxy — adds route handlers for lifetime preferences (`GET/PATCH /api/v1/profile/preferences`) and search-scoped preferences (`GET/PATCH /api/v1/profile/preferences/search/{searchId}`). Introduces the `features/profile/preferences/bff` module following the established screaming architecture pattern. Also includes minor UI polish on color swatches (model card + attribute stat list).

## Jira

Jira story: PEDX01-2749

## Changes

### New files (`features/profile/preferences/bff/`)

| File | Purpose |
|---|---|
| `contracts/preferences.schema.ts` | Zod schema for preferences validation |
| `errors/preferences.errors.ts` | Error factory + typed error response helper |
| `services/preferences-client.ts` | Creates a BED client for the visitors/preferences upstream |
| `services/preferences-upstream.ts` | Calls GET/PATCH on the visitors service preferences endpoints |
| `use-cases/preferences.ts` | Use case: mock vs upstream routing |
| `bff/index.ts` | Public barrel for the BFF layer |
| `index.ts` | Feature barrel |

### New route handlers

| File | Purpose |
|---|---|
| `app/api/v1/profile/preferences/route.ts` | GET/PATCH lifetime preferences |
| `app/api/v1/profile/preferences/search/[searchId]/route.ts` | GET/PATCH search-scoped preferences |

### Modified files

| File | Change |
|---|---|
| `config/bed-services.ts` | Added `PREFERENCES_ENDPOINTS` — versioned paths for lifetime + search-scoped preferences |
| `config/routes/constants.ts` | Added `API_ROUTES.PREFERENCES` and `API_ROUTES.preferencesBySearchId()` |
| `shared/components/card/attribute-stat-list.tsx` | Simplified swatch style (removed gradient overlay), added `border-white/25`, removed extra `gap-2` |
| `shared/components/model-card/model-card-colors.tsx` | Simplified color swatch to plain `<Image>` (removed gradient span overlay), adjusted size 16→13, removed flex gap |

## Visual QA

**Color swatches:** Before — gradient overlay on each swatch making colors appear washed out. After — clean flat color circle with subtle white border for contrast on dark surfaces.

## Checklist

- [x] PR title uses Conventional Commits format (`feat(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` passes
- [x] `pnpm test` passes
- [x] No hydration mismatch
- [x] No breaking changes — new endpoints only, swatch visual is a polish fix
- [x] Server route handlers validate inputs with Zod
- [x] `import "server-only"` on all BFF modules
- [x] No hardcoded colors (swatches use dynamic `backgroundColor` from data)

## Out-of-scope items observed

- Client-side hooks for reading/updating preferences are not included — separate ticket for `usePreferences` integration
- Default preference values (budget range, location radius, etc.) are defined server-side — confirm with product
- The `VISITORS_PREFERENCES_VERSION` env var defaults via `VISITORS_API_VERSION` fallback — verify in deploy config

## Reviewer focus

- **Two route files** — `preferences/route.ts` handles lifetime (no route param), `preferences/search/[searchId]/route.ts` handles search-scoped. Both support GET + PATCH.
- **PREFERENCES_ENDPOINTS** — `lifetime` is the base path, `bySearchId(id)` appends `/search/{id}`. Verify the visitors service accepts this path structure.
- **Color swatch simplification** — Removed the `linear-gradient(to bottom, rgba(255,255,255,0.20), transparent)` overlay from both `model-card-colors.tsx` and `attribute-stat-list.tsx`. Added a `border border-white/25` instead for edge definition. Confirm this matches the Figma spec.
- **Image size change** — Model card color swatches reduced from `size-4` (16px) to `13px` via explicit `height/width` props on `<Image>`. Verify this matches the design token.

## Commit message

```
feat(web): implement visitor preferences BFF proxy + polish color swatches [PEDX01-2749]

- Add features/profile/preferences/bff module (schema, errors, client,
  upstream service, use case) following watchlist/searches/activities pattern
- Add route handlers: GET/PATCH /api/v1/profile/preferences (lifetime)
  and GET/PATCH /api/v1/profile/preferences/search/{searchId} (scoped)
- Add PREFERENCES_ENDPOINTS to bed-services config
- Add API_ROUTES.PREFERENCES + preferencesBySearchId to route constants
- Simplify color swatch rendering: remove gradient overlay, add border,
  reduce model-card swatch from 16px to 13px
```
