# Jira Story: Browse By Style cards should trigger search agent flow (navigate to /search/[id])

## Summary

Clicking a "Browse By Style" category card on the landing page should initiate the conversational search agent flow (same as typing "suv" in the search input) — creating a search session and navigating to `/search/{id}`. Currently it navigates to a static `/search?type=suv` query-param URL which does not trigger the agent.

## User Story

As a visitor on the landing page, when I click a category card (e.g., "SUVs"), I want it to behave the same as if I typed "SUV" in the search box — so that I get the full conversational agent experience with results, refinements, and filters, rather than a static filtered page.

## Background

**Expected flow (what happens when user types "suv" in search input):**
1. User types "suv" → submits
2. Frontend creates a new search session UUID
3. Navigates to `/search/{sessionId}`
4. The search orchestrator auto-submits "suv" as the first turn to the agent
5. Agent streams results → inventory cards appear

**Current flow (what happens when user clicks "SUVs" category card):**
1. User clicks → `<LinkCard href="/search?type=suv">` navigates
2. Lands on `/search?type=suv` — this is just the base search page with a query param
3. No agent session is created, no conversational flow starts
4. The `?type=` param is not consumed by the search orchestrator

## Root Cause

The `CategoryCard` component uses `<LinkCard>` with a static `href` pointing to `/search?type={categoryKey}`. The search orchestrator at `/search` doesn't read `?type=` to auto-trigger a search. The correct behavior requires:
1. Creating a search session ID (UUID)
2. Navigating to `/search/{id}` (the conversational route)
3. Auto-submitting the category name as the first query (like the `nextSearchPlan` pattern used in editorial cards)

## Scope

- Change Browse By Style card click behavior to initiate the search agent flow
- On click: create a new search session UUID, store the category query in a queued turn (IDB), navigate to `/search/{id}`
- The orchestrator at `/search/[id]` should auto-submit the category name as the first turn (using the existing `nextSearchPlan` / auto-submit pattern)
- Remove the static `/search?type=` navigation
- Keep the `seed.categoryKey` available for the agent (it may use it as a filter hint)

## Design References

- `apps/web/src/features/landing/components/shop-by-category-section.tsx` — maps cards, builds `shopUrl`
- `apps/web/src/features/landing/components/category-card/category-card.tsx` — renders `<LinkCard href={shopUrl}>`
- `apps/web/src/features/landing/types.ts` — `CategoryCardData` interface (has `shopUrl: string`)
- `apps/web/src/features/search/components/search-results-orchestrator/` — auto-submit on mount
- `apps/web/src/features/landing/components/personalized-search-carousel.tsx` — uses `nextSearchPlan` pattern for editorial cards (reference implementation)
- `apps/web/src/config/routes/constants.ts` — `ROUTES.SEARCH_CAR`, `SEARCH_TRUCK`, `SEARCH_SUV`, `SEARCH_ELECTRIC`

## Acceptance Criteria

1. Clicking a Browse By Style card creates a new search session UUID.
2. The browser navigates to `/search/{sessionId}` (not `/search?type=...`).
3. The search orchestrator at `/search/[id]` auto-submits the category name (e.g., "SUV", "Truck", "Cars & Minivans") as the first agent turn.
4. The agent processes the query and returns inventory results — identical to typing the category name manually.
5. The category `seed.categoryKey` is available as context for the agent (passed in the turn's plan or as a filter hint).
6. Back navigation from `/search/{id}` returns to the landing page (standard browser back).
7. No static `/search?type=` URLs remain in the category card navigation.
8. The flow works for all 4 categories: Cars & Minivans, Trucks, SUVs, Electric.

## Implementation Approach

The pattern already exists in the editorial card carousel (`PersonalizedSearchCarousel`):
- `nextSearchPlan: { searchId, query }` is stored in the card data
- On click, a queued turn is inserted into IDB with the `searchId` + `query`
- Navigation goes to `/search/{searchId}`
- The `useAutoSubmitTurnHandler` hook picks up the queued turn and auto-submits

**Apply the same pattern to category cards:**

### Option A: Client Component wrapper (recommended)

Convert `CategoryCard` click to a client-side action:

```tsx
"use client";

function handleCategoryClick(categoryName: string) {
  const searchId = crypto.randomUUID();
  // Insert queued turn into IDB (same as editorial card pattern)
  insertQueuedTurn(collection, { searchId, query: categoryName });
  router.push(`/search/${searchId}`);
}
```

### Option B: Use `nextSearchPlan` on CategoryCardData

Extend `CategoryCardData` with `nextSearchPlan` and route through the same carousel click handler used by editorial cards.

## QA Notes

- Click "SUVs" card → verify navigates to `/search/{uuid}` (not `/search?type=suv`)
- Verify the agent receives "SUV" as the first query and returns inventory results
- Verify the conversational UI shows the search input with "SUV" as the submitted query
- Click "Trucks" card → same verification
- Click "Cars & Minivans" → verify full phrase is submitted
- Click "Electric" → verify agent processes it
- Verify back button returns to landing page
- Compare results with manually typing the category name — should be identical

## Non-Functional Requirements

- **Performance:** Creating a UUID and IDB write is ~1ms — no perceptible delay before navigation.
- **Accessibility:** Card remains a focusable link with appropriate `aria-label`. Keyboard Enter triggers the same flow.
- **Reliability:** If IDB write fails, navigation should still proceed — the orchestrator will handle a missing queued turn gracefully (empty search page where user can type).

## Out of Scope

- Changing the Browse By Style data source (still fixture-backed)
- Adding category-specific filters automatically (agent infers from the query)
- Changing the card visual design
- Deep linking / shareable category URLs (the UUID is session-specific)

## Suggested File Name

browse-by-style-search-agent-navigation.md
