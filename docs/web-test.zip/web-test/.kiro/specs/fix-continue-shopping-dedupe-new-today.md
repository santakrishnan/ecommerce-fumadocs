# Jira Story: Continue Shopping carousel — deduplicate New Today vehicles already in Recently Viewed

## Summary

In the Continue Shopping carousel on the welcome-back page, a vehicle can appear twice — once in the "Recently Viewed" group and again in the "New Today" group. This happens when a user clicks a New Today vehicle, views its VDP (adding it to history), then returns to the landing page. The New Today section should filter out any VINs already present in the Recently Viewed group to avoid showing duplicates within the same carousel.

## User Story

As a returning visitor, I don't want to see the same vehicle twice in the Continue Shopping carousel — so that the section feels curated and each card shows a unique vehicle.

## Background

The `ContinueShoppingCarousel` merges two data sources into a single combined carousel:
1. **Recently Viewed** — from IndexedDB vehicle history (`useVehicleHistory`)
2. **New Today** — from the BED search API (server-fetched, passed as `newToday` prop)

When a user views a New Today vehicle's VDP, it gets recorded in the vehicle history IDB. On the next landing page visit, that vehicle appears in both groups — the carousel shows the same VIN in two places.

The BED upstream has no `excludeVins` filter, so the deduplication must happen **client-side** before rendering.

## Current Architecture

```
ContinueShoppingSection (server)
  → getFeaturedVehicles() → Vehicle[] (New Today from BED)
  → passes as `newToday` prop to:

ContinueShoppingConnected (client, ssr: false)
  → useVehicleHistory() → Vehicle[] (from IDB)
  → passes both to:

ContinueShoppingCarousel (client)
  → renders "RECENTLY VIEWED" group (history)
  → renders "NEW TODAY" group (newToday)
  → NO deduplication between groups
```

## File to Fix

`apps/web/src/features/landing/components/continue-shopping/continue-shopping-carousel.tsx`

(or `continue-shopping-connected.tsx` — either is appropriate)

## Recommended Fix

In `ContinueShoppingConnected` or `ContinueShoppingCarousel`, filter the `newToday` array to exclude any VINs already present in the `recentlyViewed` array before rendering:

```tsx
// In ContinueShoppingConnected or ContinueShoppingCarousel:
const viewedVins = new Set(recentlyViewed.map(v => v.vin ?? v.id));
const dedupedNewToday = newToday.filter(v => !viewedVins.has(v.vin ?? v.id));
```

Then render `dedupedNewToday` in the "New Today" group instead of raw `newToday`.

## Acceptance Criteria

1. A vehicle that appears in "Recently Viewed" does NOT appear in "New Today" within the same carousel.
2. The deduplication uses VIN (or `id` as fallback) as the unique key.
3. "Recently Viewed" takes priority — if a VIN is in both sources, it stays in Recently Viewed only.
4. If filtering removes all New Today vehicles, the "New Today" group header is hidden (no empty group).
5. The total card count may decrease after dedup — this is acceptable (no padding with extra vehicles needed).
6. No server-side changes required (dedup is client-only).

## QA Notes

- View a New Today vehicle's VDP → return to welcome-back page → verify that vehicle only appears once (in "Recently Viewed", not in "New Today")
- View multiple New Today vehicles → verify all are deduplicated correctly
- Verify "New Today" group is hidden entirely when all its vehicles exist in history
- Verify vehicles that are ONLY in New Today (never viewed) still appear in the "New Today" group

## Non-Functional Requirements

- **Performance:** `Set` lookup is O(1) per vehicle — negligible cost even with 20+ vehicles.
- **Reactivity:** Since `recentlyViewed` comes from `useLiveQuery` (IDB), the dedup re-evaluates whenever history changes — a newly viewed vehicle is immediately removed from the New Today group without a page refresh.

## Out of Scope

- Server-side exclusion via the BED API (no `excludeVins` filter available)
- Deduplication across different sections (e.g., "Because You Viewed" vs "New Today") — separate concern
- Limiting the total number of cards in the combined carousel

## Suggested File Name

fix-continue-shopping-dedupe-new-today.md
