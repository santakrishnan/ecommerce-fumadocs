# Jira Story: Migrate all usages of `normalizeLocalhostImageUrl` to `normalizeImageUrl` from `@shared/lib/media`

## Summary

Replace all usages of `normalizeLocalhostImageUrl` (from `utils` package) with the new `normalizeImageUrl` (from `@shared/lib/media`) across the codebase. The new utility properly routes header-gated media CDN images through the `/api/v1/media` proxy, handles `public/` relative paths, and supports both client and server callers.

## User Story

As a developer, I want a single image URL normalization utility that handles all image sources (CDN proxy, localhost fixtures, relative paths, external CDNs) — so that images render correctly on both local dev and Vercel deployments without 400/403 errors from the media CDN's WAF.

## Background

The old `normalizeLocalhostImageUrl` from `packages/utils/src/image.ts` only handled two cases:
1. Stripping `localhost` origins to same-origin paths
2. Resolving `public/` prefixed paths to absolute CDN URLs

The new `normalizeImageUrl` from `@shared/lib/media` additionally:
- Routes `public/` paths through `/api/v1/media/…` (injects `X-Origin-Verify` server-side)
- Routes absolute media-host URLs through the same proxy
- Falls back to placeholder when path is empty after stripping
- Passes external CDN domains (cdnrs.inventoryrsc.com, etc.) through unchanged

After migration, the old `normalizeLocalhostImageUrl` export in `packages/utils` can be deprecated.

## Files to Migrate

### Feature: Landing (2 files)

| File | Usages | Notes |
|---|---|---|
| `features/landing/services/get-personalized-search-cards.ts` | 2 calls (imageUrl, ctaLink) | `ctaLink` is not an image — may need a separate URL helper or pass through unchanged |
| `features/landing/services/get-search-recommendations.ts` | 1 call (imageUrl) | Straightforward swap |

### Feature: Search — Card Mappers (6 files)

| File | Usages | Notes |
|---|---|---|
| `features/search/lib/card-mappers/map-option-card-to-model-card.ts` | 2 calls (svgSrc, carImage) | SVG src may not need proxy routing — verify |
| `features/search/lib/card-mappers/map-v3-card-to-result-item.ts` | 2 calls (image.src, imageUrl) | Inventory card photo + spec card image |
| `features/search/lib/card-mappers/map-inventory-card-to-inventory-card.ts` | 1 call (imageUrl) | Primary image or first photo |
| `features/search/lib/card-mappers/map-option-card-to-editorial-card.ts` | 1 call (imageUrl) | Editorial card image |
| `features/search/lib/card-mappers/map-option-card-to-spec-card.ts` | 1 call (image.src) | Spec card image |
| `features/search/lib/card-mappers/map-option-card-to-trim-card.ts` | 1 call (imageUrl) | Trim card image |
| `features/search/lib/card-mappers/map-sdk-inventory-card-to-vehicle.ts` | 1 call (imageUrl) | SDK inventory card |

### Feature: Recommendations (1 file)

| File | Usages | Notes |
|---|---|---|
| `features/recommendations/bff/mappers/because-you-viewed.mapper.ts` | 1 call (imageUrl) | Straightforward swap |

### Feature: Vehicle Detail (3 files)

| File | Usages | Notes |
|---|---|---|
| `features/vehicle-detail/bff/utils/gallery-utils.ts` | 1 call (photo.url) | Gallery image URLs |
| `features/vehicle-detail/mappers/select-vehicle.ts` | 1 call (imageUrl) | Vehicle summary photo |
| `features/vehicle-detail/mappers/to-purchase-card-from-api.ts` | 1 call (mapThumbnailUrl) | Dealer map thumbnail |

### VDP Page (1 file)

| File | Usages | Notes |
|---|---|---|
| `app/(shop)/used-cars/details/[make]/[model]/[trim]/[year]/[vin]/page.tsx` | 2 calls (heroImageUrl, galleryCoverUrl) | VDP hero and gallery cover |

### Feature: Vehicle Detail — Components (2 files)

| File | Usages | Notes |
|---|---|---|
| `features/vehicle-detail/components/dealer-info-dialog/dealer-info-dialog.tsx` | 2 calls (photos, mapUrl) | Dealer photos + map thumbnail |
| `features/vehicle-detail/components/buy-with-confidence/buy-with-confidence.tsx` | 1 call (image.src) | Buy with confidence hero |

### Shared Components (5 files)

| File | Usages | Notes |
|---|---|---|
| `shared/components/comparison-card/comparison-card-content.tsx` | 1 call (image.src) | Comparison card image |
| `shared/components/model-card/model-card-colors.tsx` | 1 call (svgSrc) | Color swatch SVG |
| `shared/components/model-card/model-card-content.tsx` | 1 call (carImage) | Model card hero |
| `shared/components/spec-card/spec-card-content.tsx` | 1 call (image.src) | Spec card image |
| `shared/components/trim-card/trim-card-content.tsx` | 1 call (image.src) | Trim card image |

---

**Total: 20 files, ~24 call sites**

## Acceptance Criteria

1. All 20 files listed above import `normalizeImageUrl` from `@shared/lib/media` instead of `normalizeLocalhostImageUrl` from `utils`.
2. All image URLs that originate from the media CDN (prefix `public/` or absolute `media.sandbox.arrow.toyotafinancial.com`) are routed through `/api/v1/media/…`.
3. External CDN images (`cdnrs.inventoryrsc.com`, `tmna.aemassets.toyota.com`, etc.) pass through unchanged.
4. Non-image URLs (e.g., `ctaLink` in personalized search cards) are NOT passed through `normalizeImageUrl` — use a separate link normalizer or leave unchanged.
5. `normalizeLocalhostImageUrl` is removed from the `utils` package import barrel (or marked deprecated).
6. All existing tests pass after migration.
7. No new `any` or `@ts-ignore`.
8. `pnpm lint && pnpm type-check && pnpm test` passes.

## Implementation Approach

1. **Direct swap** for most files: `normalizeLocalhostImageUrl(url)` → `normalizeImageUrl(url)`
2. **Import change**: `import { normalizeLocalhostImageUrl } from "utils"` → `import { normalizeImageUrl } from "@shared/lib/media"`
3. **Special case — `ctaLink`** in `get-personalized-search-cards.ts`: This is a navigation URL, not an image. It should NOT go through the image normalizer. Replace with a simple localhost-strip or leave as-is.
4. **Shared components** (`comparison-card`, `model-card`, `spec-card`, `trim-card`): These are client components — `normalizeImageUrl` is client-safe (no `import "server-only"`), so direct swap is fine.
5. **After migration**: Remove or deprecate `normalizeLocalhostImageUrl` from `packages/utils/src/image.ts` and its barrel export.

## QA Notes

- Verify images load on local dev (localhost:3000)
- Verify images load on Vercel deployment (media CDN images go through proxy)
- Verify VDP page images (hero, gallery, dealer info)
- Verify search results card images (inventory, spec, model, trim, editorial)
- Verify landing page images (personalized search, recommendations, new today)
- Verify comparison cards, buy-with-confidence section
- Verify SVG color swatches on model cards still render

## Non-Functional Requirements

- **Performance:** No additional network hops for non-media-CDN images (they pass through unchanged). Media CDN images already go through the proxy.
- **Bundle size:** `normalizeImageUrl` is ~30 lines — no meaningful increase.
- **Security:** No secrets exposed — `normalizeImageUrl` is client-safe; the proxy secret is only in server-side `media-upstream.ts`.

## Out of Scope

- Removing `packages/utils/src/image.ts` entirely (other non-image exports may still be used)
- Adding proxy support for `cdnrs.inventoryrsc.com` (it doesn't need WAF headers)
- Changing how `ctaLink` URLs are handled beyond the normalizer swap

## Suggested File Name

migrate-normalize-image-url-utility.md
