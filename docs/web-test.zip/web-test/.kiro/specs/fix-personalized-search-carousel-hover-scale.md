# Jira Bug: Personalized Search carousel missing hover scale effect on welcome-back page

## Summary

The `PersonalizedSearchCarousel` on the welcome-back page uses a raw `<Carousel>` without hover scale, so editorial cards don't lift/scale on hover. Other carousels (Category, Inventory) correctly use `CardCarousel` with `hoverScaleRatio`. The personalized search carousel should use `CARD_HOVER_SCALE.lg` (1.015) for its `size="large"` editorial cards.

## Bug Description

**Current:** Hovering over a personalized search editorial card produces no scale/lift animation. The card is static on hover.

**Expected:** Cards should scale up slightly (1.015×) with a shadow lift on hover, matching the visual behaviour of category cards and inventory cards across the site.

## Root Cause

`PersonalizedSearchCarousel` renders cards using raw `<Carousel>` / `<CarouselContent>` / `<CarouselItem>` primitives directly — these have no hover behaviour built in.

The shared `CardCarousel` component (used by `CategoryCarousel`, `InventoryCardCarousel`) accepts a `hoverScaleRatio` prop which:
1. Sets `--carousel-hover-scale-ratio` CSS variable on the viewport
2. Applies `hover:scale-[var(--carousel-hover-scale-ratio,1)]` + `hover:shadow-hover` to each item

The personalized search carousel skips this entirely.

## Scale Values (from `card-size.ts`)

| Card size | Token | Scale ratio |
|---|---|---|
| `sm` (inventory small) | `sm` | 1.025 |
| `md` (editorial medium, category) | `md` | 1.02 |
| **`lg` (editorial large — personalized search)** | **`lg`** | **1.015** |

## File to Fix

`apps/web/src/features/landing/components/personalized-search-carousel.tsx`

## Recommended Fix

Replace the raw `<Carousel>` with the shared `CardCarousel` component:

```diff
- import { Carousel, CarouselContent, CarouselItem } from "@ucmp/ui";
+ import { CARD_HOVER_SCALE, CardCarousel } from "@shared/components/card";
+ import { EDITORIAL_SIZE_TOKEN } from "@shared/components/editorial-card";

  export function PersonalizedSearchCarousel({ cards, colSpan, size = "large" }) {
    return (
-     <Carousel>
-       <CarouselContent>
-         {cards.map(({ iconName, nextSearchPlan, ...card }) => (
-           <CarouselItem colSpan={colSpan} key={card.href}>
-             <LinkEditorialCard ... />
-           </CarouselItem>
-         ))}
-       </CarouselContent>
-     </Carousel>
+     <CardCarousel
+       colSpan={colSpan}
+       getItemKey={(_, i) => cards[i]?.href ?? String(i)}
+       hoverScaleRatio={CARD_HOVER_SCALE[EDITORIAL_SIZE_TOKEN[size]]}
+       items={cards}
+       renderItem={({ iconName, nextSearchPlan, ...card }) => (
+         <LinkEditorialCard ... />
+       )}
+     />
    );
  }
```

**Alternative (minimal change):** Keep the raw Carousel and manually add hover classes to each `CarouselItem`:

```diff
+ const HOVER_CLASSES = cn(
+   "transition-[transform,box-shadow] duration-200 ease-out",
+   "hover:z-10 hover:scale-[1.015] hover:shadow-hover",
+   "has-[a:focus-visible]:z-10 has-[a:focus-visible]:scale-[1.015]",
+   "motion-reduce:transform-none"
+ );

  <CarouselItem className={HOVER_CLASSES} colSpan={colSpan} key={card.href}>
```

## Acceptance Criteria

1. Personalized search editorial cards scale up (1.015×) with shadow on hover.
2. Keyboard focus produces the same visual lift.
3. `prefers-reduced-motion` disables the animation.
4. No overflow clipping — cards scale within their allocated space without being cut off.
5. The effect matches the hover behaviour on category cards (same timing, same shadow).

## QA Notes

- Hover over personalized search cards on welcome-back page → verify scale + shadow lift
- Tab through cards → verify focus produces same lift
- Compare with category carousel hover — should feel consistent (though slightly less scale since large cards use 1.015 vs category's 1.02)
- Test with `prefers-reduced-motion: reduce` → no animation

## Suggested File Name

fix-personalized-search-carousel-hover-scale.md
