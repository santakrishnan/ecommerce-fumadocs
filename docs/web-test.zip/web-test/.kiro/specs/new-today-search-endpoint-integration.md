# Jira Story: New Today Section — Replace BED service with traditional search endpoint using availability + zip + 1-week date filter

## Summary

Replace the current BED/fixture-based data source for the "New Today" landing section with the traditional search endpoint (no search ID), applying availability filter + user's zip code + 1-week date range filter to surface recently-listed vehicles. Hide the entire section when no results are returned.

## User Story

As a visitor on the landing page, I want to see vehicles that were listed in the last week near my location — so that I can discover fresh inventory that is actually available and relevant to my area.

## Background

The "New Today" section (`<FeaturedVehiclesSection />`) currently calls `getNewTodayResponse()` which returns hardcoded fixture data from `new-today.fixtures.ts`. The section title says "latest listings I've found in the last 24 hours" but it doesn't call any real inventory service. The requirement is to replace this with a call to the traditional search endpoint (the same one used for `/search` results, but without a search ID) using specific filters: availability status, the visitor's zip code, and a 1-week date range — to surface genuinely new/available vehicles in the user's area.

## Problem Statement

1. The New Today section shows hardcoded fixture data regardless of user location or actual inventory state.
2. There is no conditional hiding — if the BED service returns no data or errors, the section currently shows an empty-state text message ("No new listings found today") instead of being completely hidden.
3. The section needs to call a real search endpoint with structured filters to show actually available, recently-listed vehicles near the user.

## Scope

- Replace `getNewTodayResponse()` internals with a call to the traditional search endpoint (no search ID)
- Pass filters: `availability: "available"` + `zipCode` (from location cookie) + `listedAfter: <1 week ago ISO date>`
- Map search response vehicles to the existing `Vehicle` UI model (reuse `toVehicle` mapping)
- **Hide the entire section** when 0 vehicles are returned (remove empty-state text fallback)
- Update `<FeaturedVehiclesSection />` to return `null` when vehicles array is empty
- Define/update Zod schema for the search endpoint response at the BFF boundary
- Maintain the `"use cache"` + `cacheLife("landing")` + `cacheTag("new-today-inventory")` caching strategy (re-enable when validated)
- Keep zip-scoped cache tag `cacheTag("new-today-inventory:<zip>")` for targeted revalidation

## Dependencies / Constraints

- Requires the traditional search endpoint to accept filters: availability, zip code, and date range (listedAfter/listedSince)
- Requires `zipCode` from the visitor's location cookie (already extracted outside cache scope in the current flow)
- The search endpoint is called **without a search ID** — this is a filter-only query, not a saved-search replay
- The response vehicle shape must be mappable to the existing `Vehicle` type used by `InventoryCardCarousel`
- Section must be completely hidden (render `null`) when no results — no empty-state message

## Design References

- `apps/web/src/features/landing/components/featured-vehicles-section.tsx`
- `apps/web/src/features/landing/services/inventory-vehicles-service.ts`
- `apps/web/src/features/landing/services/get-new-today-response.ts`
- `apps/web/src/features/landing/api/get-new-today.ts`
- `apps/web/src/features/landing/data/schemas/new-today-response.ts`
- `apps/web/src/features/landing/__fixtures__/new-today.fixtures.ts`

## Acceptance Criteria

1. `getNewTodayResponse()` (or a replacement service) calls the traditional search endpoint **without a search ID**, passing structured filters.
2. The search request includes an **availability filter** set to available/in-stock vehicles only.
3. The search request includes the visitor's **zip code** from the location cookie as a location filter.
4. The search request includes a **date filter** constraining results to vehicles listed within the **last 1 week** (e.g., `listedAfter: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()`).
5. The search response vehicles are mapped to the existing `Vehicle` UI model using the `toVehicle` transform (or an equivalent mapper matching the new response shape).
6. When the search returns **0 vehicles** (empty results), the entire `<FeaturedVehiclesSection />` renders `null` — the section is completely hidden from the DOM.
7. When the search endpoint **fails** (network error, non-200, timeout), the section renders `null` — no error UI shown to the user.
8. The section **no longer shows** the empty-state text message ("No new listings found today. Check back soon.") — that fallback is removed.
9. Vehicle deduplication by ID is preserved (upstream may return duplicates).
10. Caching strategy: `"use cache"` + `cacheLife("landing")` + `cacheTag("new-today-inventory")` + zip-scoped tag remain in place.
11. Zod schema validates the search endpoint response at the BFF boundary before mapping.
12. The `USE_PROFILE_MOCKS` / fixture path is preserved behind an env flag for local development.
13. The carousel renders the same `InventoryCardCarousel` with `size="small"` and existing visual treatment.

## QA Notes

- Test with a valid zip code that has inventory listed in the past week — verify vehicles shown
- Test with a zip code that has no recent inventory — verify section is completely hidden (not in DOM)
- Test with no zip code (new visitor, no location cookie) — verify behavior (should still query without zip or use a default)
- Test with search endpoint unavailable — verify section hidden, no console errors visible to user
- Verify vehicle cards link to correct VDP pages
- Verify images load correctly (photo URLs from search response)
- Verify deduplication — no duplicate vehicle IDs in the carousel

## Non-Functional Requirements

- **Accessibility:** No change — existing `aria-labelledby` on the section is preserved; section renders `null` cleanly when hidden.
- **Performance:** Cached with `cacheLife("landing")` (15min stale / 15min revalidate / 1hr expire). Wrapped in `<Suspense>` with skeleton — does not block the static shell under PPR.
- **Reliability:** Graceful degradation — any upstream failure results in section hidden. No user-facing errors.
- **Observability:** Log search failures at `warn` level with zip context. Remove current `console.dir` debug logging.

## Out of Scope

- Customizing the number of vehicles shown (uses whatever the search returns, deduplicated)
- "Load more" or pagination within the section
- Changing the section title/subtitle copy (remains "NEW TODAY")
- Filtering by make/model/price (only availability + zip + date)
- Real-time inventory updates (cache TTL handles freshness)

## Search Endpoint Contract (Expected)

```
POST /search (or GET /search/results)
Headers: X-Visitor-Id: <visitorId> (optional)

Request body / params:
{
  "filters": {
    "availability": "available",
    "zipCode": "90210",
    "listedAfter": "2025-06-22T00:00:00.000Z"  // 1 week ago
  },
  "limit": 12,
  "sort": "listedDate:desc"
}

Response 200:
{
  "data": {
    "vehicles": [
      {
        "VehicleInfo": { "VehicleID", "Year", "Make", "Model", "Trim", "Vin", "Mileage", ... },
        "ListOfPhotos": [{ "PhotoUrl", "Order", ... }],
        "Pricing": { "Cost", "List", "Special" }
      }
    ],
    "totalCount": number
  }
}
```

## Implementation Notes

- The 1-week date calculation should be computed at call time (server-side), not hardcoded
- `new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()` for the `listedAfter` filter
- If the search endpoint uses a different vehicle shape than the current BED `NewTodayVehicle`, update `toVehicle` mapper accordingly
- Remove the `FEATURED_COPY.emptyState` rendering branch — replace with early `return null`
- The fixture selector logic (`toFixture`, `resolvedFixture`) can be removed from the production path

## Suggested File Name

new-today-search-endpoint-integration.md
