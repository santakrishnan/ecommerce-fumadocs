# Jira Story: Fix Budget Calculator heading typography — replace CardTitle with proper h1 utility

## Summary

Replace the `CardTitle` component with a plain `<h2>` using the `h1` typography utility for the "Shop cars that fit your budget" heading in the Budget Calculator.

## User Story

As a shopper viewing the budget calculator, I want the heading to match the design system's H1 sizing (28px mobile → 32px desktop), so that it has the correct visual hierarchy and is consistent with other page headings.

## Background

The Budget Calculator heading currently uses `CardTitle` from `@ucmp/ui` with an `h1` class override:

```tsx
<CardTitle className="h1 text-text-primary">Shop cars that fit your budget</CardTitle>
```

`CardTitle` renders a `<div>` with built-in typography:
```
text-sm leading-heading font-bold tracking-tightest md:text-sm lg:text-base xl:text-base
```

This is designed for **small card labels** (14–16px), not page section headings. The `h1` utility class (28px mobile → 32px desktop via `@utility h1` in typography.css) is applied via `className` but competes with `CardTitle`'s base classes at responsive breakpoints. Depending on CSS specificity and Tailwind v4 layer ordering, the result may not match the design.

## Problem Statement

- `CardTitle` applies `text-sm` / `lg:text-base` (14–16px) — wrong for a section heading
- The `h1` utility (28px → 32px) must fight `CardTitle`'s responsive variants for specificity
- The rendered element is a `<div>` — should be an `<h2>` for correct heading hierarchy (the page already has `<h1>` from the hero section)
- The heading is inside `CardHeader` which adds its own grid/spacing — unnecessary for this layout

## Scope

Replace:
```tsx
<CardHeader className="grid-cols-1 gap-0 rounded-none px-0">
  <CardTitle className="h1 text-text-primary">Shop cars that fit your budget</CardTitle>
</CardHeader>
```

With:
```tsx
<h2 className="h1 text-text-primary">Shop cars that fit your budget</h2>
```

- Remove `CardHeader` wrapper (adds grid layout overhead not needed here)
- Remove `CardTitle` (wrong typography scale)
- Use a plain `<h2>` with the `h1` utility class (matches design, correct heading level)

## Acceptance Criteria

1. The "Shop cars that fit your budget" heading renders at 28px (mobile) → 32px (desktop) using the `h1` typography utility.
2. No conflicting `text-sm` / `text-base` from `CardTitle` present in the computed styles.
3. The heading is an `<h2>` element (correct heading hierarchy — page `<h1>` is the hero).
4. `CardHeader` and `CardTitle` imports can be removed from the budget calculator if no longer used.
5. Visual output matches the design — bold, tight letter-spacing, heading line-height.
6. No layout shift or spacing regression (verify the `mt-14` gap below the heading is preserved).

## QA Notes

- Compare the heading size before/after — it should be visibly larger (14px → 28px on mobile)
- Inspect computed styles in DevTools: `font-size` should be `1.75rem` (28px) on mobile, `2rem` (32px) on ≥1024px
- Screen reader check: heading should announce as level 2 (`<h2>`)

## Design References

- `apps/web/src/features/landing/components/budget-calculator-client.tsx` — line 55
- `packages/ui-theme/utilities/typography.css` — `@utility h1` definition
- `packages/ui/src/components/card.tsx` — `CardTitle` built-in classes
- `docs/TYPOGRAPHY-VARIANTS.md` — H1 utility: 28px mobile, 32px desktop

## Non-Functional Requirements

- **Accessibility:** Correct heading hierarchy (`<h2>` under the page's `<h1>`)
- **Performance:** Removes 2 unnecessary component wrappers (CardHeader + CardTitle)

## Out of Scope

- Refactoring other Card components that correctly use CardTitle
- Changing the budget calculator's overall Card layout structure

## Suggested File Name

fix-budget-calculator-heading-typography.md
