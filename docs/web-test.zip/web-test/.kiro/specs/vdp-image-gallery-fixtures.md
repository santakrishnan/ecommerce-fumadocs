# Jira Story: VDP Image Gallery — Test Fixtures

## Summary

Create typed fixture data for the VDP image gallery component and hotspot overlays to support Vitest unit tests covering happy path, empty state, partial (single-section), and hotspot scenarios.

## User Story

As a developer writing Vitest tests for the VDP image gallery and hotspot overlays, I want a set of well-typed fixture files covering all meaningful data states, so that tests are readable, deterministic, and never rely on hardcoded inline mock data.

## Background

The VDP image gallery component (`VehicleImageGallery`) accepts a `VehicleImage[]` prop, and the hotspot overlay component accepts `keyFeaturesHotspots: Hotspot[]` and `conditionHotspots: Hotspot[]` props. To test reliably across different data states — full set, empty, exterior-only, interior-only, and various hotspot configurations — fixture files must be defined once and reused across all tests. Co-locating fixtures under `__fixtures__/` next to the component's `__tests__/` folder follows the project's screaming architecture convention.

## Problem Statement

Without shared fixture files, each test file would define its own inline mock data, leading to duplication, inconsistency, and brittle tests that are hard to maintain when the `VehicleImage` or `Hotspot` types evolve.

## Scope

- Define the `VehicleImage` type in the gallery's types file (if not already defined by the functionality story)
- Define the `Hotspot` type: `{ x: number; y: number; label: string }`
- Create fixture files under `features/vehicle-detail/__fixtures__/` covering:
  - **Happy path** — full set of Exterior + Interior images (realistic quantity, e.g. 6 exterior, 4 interior)
  - **Empty state** — empty array (`[]`)
  - **Exterior only** — images with `type: 'exterior'` only
  - **Interior only** — images with `type: 'interior'` only
- Create hotspot fixture file under `features/vehicle-detail/__fixtures__/` covering:
  - **Key Features — full set** — array of 4–6 hotspots with realistic feature labels and varied coordinates
  - **Condition — full set** — array of 3–5 hotspots with realistic condition labels and varied coordinates
  - **Key Features — empty** — empty array (`[]`)
  - **Condition — empty** — empty array (`[]`)
  - **Edge positions** — hotspots at boundary coordinates (x: 0, y: 0 and x: 100, y: 100) for tooltip flip testing
- Each fixture exports a named constant typed as `VehicleImage[]` or `Hotspot[]`
- Write at least one Vitest smoke test per fixture to confirm the component renders without throwing

## Dependencies / Constraints

- Depends on `VehicleImage` type being defined (from the functionality story, or defined here if that story is not yet merged) — **Assumption:** `{ url: string; alt: string; type: 'exterior' | 'interior' }`
- Depends on `Hotspot` type being defined (from the hotspots story, or defined here) — **Assumption:** `{ x: number; y: number; label: string }`
- Fixture image URLs should use a stable placeholder service (e.g. `https://placehold.co/800x600`) — no real CDN URLs in fixtures
- Fixtures must not be imported across feature boundaries — they are internal to `features/vehicle-detail/`
- Tests use Vitest 4 + `@testing-library/react` + `jsdom` 29

## Design References

> [!TODO]
> Add design or specification links

## Acceptance Criteria

1. A `VehicleImage` type is exported from `features/vehicle-detail/types.ts` (or equivalent) as `{ url: string; alt: string; type: 'exterior' | 'interior' }`.
2. A `Hotspot` type is exported from `features/vehicle-detail/types.ts` (or equivalent) as `{ x: number; y: number; label: string }`.
3. A fixture file `features/vehicle-detail/__fixtures__/vehicle-images.ts` exists and exports all four named constants: `vehicleImagesFullSet`, `vehicleImagesEmpty`, `vehicleImagesExteriorOnly`, `vehicleImagesInteriorOnly`.
4. `vehicleImagesFullSet` contains at least 6 exterior images and 4 interior images, all with non-empty `url` and `alt` values.
5. `vehicleImagesEmpty` is an empty array (`[]`) typed as `VehicleImage[]`.
6. `vehicleImagesExteriorOnly` contains only items with `type: 'exterior'` (minimum 3 items).
7. `vehicleImagesInteriorOnly` contains only items with `type: 'interior'` (minimum 2 items).
8. All fixture URLs use placeholder images (e.g. `https://placehold.co/800x600`) — no real or CDN-hosted URLs.
9. All fixture items have descriptive `alt` text that would be valid in production (e.g. `"2024 Toyota Camry — exterior front"`).
10. A fixture file `features/vehicle-detail/__fixtures__/hotspots.ts` exists and exports: `keyFeaturesHotspotsFullSet`, `conditionHotspotsFullSet`, `keyFeaturesHotspotsEmpty`, `conditionHotspotsEmpty`, `hotspotsEdgePositions`.
11. `keyFeaturesHotspotsFullSet` contains 4–6 hotspots with `x` and `y` values between 10–90 and descriptive labels (e.g. `"Panoramic Sunroof"`, `"LED Headlights"`, `"Alloy Wheels"`).
12. `conditionHotspotsFullSet` contains 3–5 hotspots with `x` and `y` values between 10–90 and descriptive labels (e.g. `"Minor scratch — rear bumper"`, `"Paint chip — driver door"`).
13. `keyFeaturesHotspotsEmpty` is an empty array (`[]`) typed as `Hotspot[]`.
14. `conditionHotspotsEmpty` is an empty array (`[]`) typed as `Hotspot[]`.
15. `hotspotsEdgePositions` contains hotspots at boundary coordinates (`{ x: 0, y: 0 }`, `{ x: 100, y: 100 }`, `{ x: 0, y: 100 }`, `{ x: 100, y: 0 }`) for tooltip flip/clamp testing.
16. A test file `features/vehicle-detail/__tests__/vehicle-image-gallery.test.tsx` exists with a smoke test for each image fixture: renders `<VehicleImageGallery images={fixture} />` without throwing.
17. A test file `features/vehicle-detail/__tests__/hotspot-overlay.test.tsx` exists with smoke tests for hotspot fixtures: renders the hotspot overlay component with each fixture without throwing.
18. The smoke test for `vehicleImagesEmpty` asserts the component renders null / nothing (no visible images).
19. The smoke test for `vehicleImagesExteriorOnly` asserts the Interior section/tab is not present in the DOM.
20. The smoke test for `vehicleImagesInteriorOnly` asserts the Exterior section/tab is not present in the DOM.
21. The smoke test for `keyFeaturesHotspotsEmpty` asserts no pin markers are rendered in the overlay.
22. The smoke test for `keyFeaturesHotspotsFullSet` asserts the correct number of pin markers are rendered.
23. `pnpm test` passes with all new tests green.
24. No inline mock data in any test file — all data is imported from `__fixtures__/`.

## QA Notes

- Run `pnpm test --filter web` and confirm all smoke tests pass (image gallery + hotspot overlay).
- Inspect the rendered output for `vehicleImagesEmpty` — confirm no section headers or images are in the DOM.
- Inspect `vehicleImagesExteriorOnly` — confirm only the "Exterior" tab and section are present.
- Inspect `vehicleImagesInteriorOnly` — confirm only the "Interior" tab and section are present.
- Inspect `keyFeaturesHotspotsFullSet` — confirm correct number of pins render at expected positions.
- Inspect `keyFeaturesHotspotsEmpty` — confirm no pins render.
- Inspect `hotspotsEdgePositions` — confirm pins at (0,0) and (100,100) render without error and tooltip positioning handles boundaries.
- Check TypeScript strict mode passes (`pnpm type-check`) — fixture types must match `VehicleImage[]` and `Hotspot[]` exactly.

## Non-Functional Requirements

- **Accessibility:** Not applicable to fixture data itself; smoke tests should assert no axe violations if `@axe-core/react` is available.
- **Reliability:** Fixtures must be deterministic and side-effect free — no randomised data, no API calls.
- **Observability:** N/A for fixture data.
- **Compatibility:** Fixtures are internal to the feature — no cross-feature imports. If `VehicleImage` or `Hotspot` types change, fixtures are the single source of truth to update.

## Out of Scope

- Storybook stories (separate story if needed)
- Integration or E2E tests
- Fixtures for other VDP components
- Real image URLs or CDN-hosted assets in fixtures
- Performance or analytics testing

## Suggested File Name

`vdp-image-gallery-fixtures.md`
