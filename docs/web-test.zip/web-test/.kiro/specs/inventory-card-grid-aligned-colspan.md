# Jira Story: Refactor inventory card sizing to aspect-ratio-only with consumer-controlled colSpan

## Summary

Remove fixed width/height from inventory card sizes and adopt aspect-ratio-only dimensions so carousel items align to the PageGrid via the `colSpan` prop, with span values controlled by the consuming page (e.g. landing page wrappers).

## User Story

As a developer composing a carousel on a landing page, I want the inventory card to fill whatever grid column span I give it (via `colSpan`) while maintaining its design aspect ratio, so that cards align to the page grid without hardcoded pixel dimensions and respond fluidly to any layout.

## Background

The carousel primitive now supports a `colSpan` prop on `CarouselItem` (see `carousel-grid-aligned.stories.tsx`) that derives item width from `--page-grid-col-width`. However, the current inventory card sizing system (`shared/components/card/card-size.ts`) defines fixed `w-[Xpx] h-[Ypx]` values that override the grid-derived width — defeating the alignment.

The inventory card (`shared/components/inventory-card/`) uses a `SIZE_TOKEN` map that resolves named sizes (`small`, `medium`, `large`) to `CARD_SIZE` entries with hardcoded pixel dimensions. To support `colSpan`-based layouts, card sizes must express only **aspect ratio** — the width comes from the grid column span, and the height is derived from the ratio.

## Problem Statement

- `CARD_SIZE` defines fixed `w-[178px] h-[237px]` etc. — these fight the `colSpan` grid width
- The inventory card ignores the carousel's `colSpan` because its own width class takes precedence
- Every carousel consumer must currently pick a t-shirt size that hardcodes dimensions, rather than declaring how many grid columns the card should span
- No single card can resize fluidly across different page contexts (landing vs search vs VDP)

## Scope

### 1. Refactor `CARD_SIZE` to aspect-ratio-only

Replace fixed `w-[Xpx] h-[Ypx]` with `aspect-[W/H]` only:

```ts
// Before
sm: "h-[237px] w-[178px] lg:aspect-[220/293] lg:h-[293px] lg:w-[220px]"

// After
sm: "aspect-[178/237] lg:aspect-[220/293]"
```

No width, no height — the card fills its container width (set by `colSpan`) and derives height from the ratio.

### 2. Move card size definitions into the inventory-card folder

Move `CARD_SIZE`, `CARD_HOVER_SCALE`, and `CARD_IMAGE_SIZES` from `shared/components/card/card-size.ts` into `shared/components/inventory-card/` (or keep shared if other card types also use them — decision TBD). The inventory card owns its own aspect ratios.

### 3. Consumer controls `colSpan`

Landing page wrappers (`featured-vehicles-section.tsx`, `rare-finds-section.tsx`, `continue-shopping-carousel.tsx`) pass `colSpan` to `CarouselItem`:

```tsx
<CarouselItem colSpan={{ sm: 2, md: 3, lg: 3 }}>
  <LinkInventoryCard vehicle={vehicle} />
</CarouselItem>
```

The card inside has no width — it fills the item's grid-derived width.

### 4. Update `CARD_IMAGE_SIZES` to match

Image `sizes` hints should reflect the grid-column-based width rather than fixed pixel values. E.g.:
```ts
sm: "(max-width: 768px) calc(2 * var(--page-grid-col-width)), calc(3 * var(--page-grid-col-width))"
```

Or simplified breakpoint estimates based on the known grid math.

### 5. Update tests

Inventory card tests currently assert `toHaveClass("w-[178px]")` — update to assert aspect ratio classes instead.

## Dependencies / Constraints

- `CarouselItem` `colSpan` prop is already implemented (see stories)
- `--page-grid-col-width` CSS variable is already defined in `packages/ui-theme/base/tokens/grid.css` (or `page-grid.tsx`)
- Cards inside `colSpan` items must have `w-full` (or no explicit width) so they stretch to fill
- This change affects all carousel consumers — start with landing page only, leave search/VDP for follow-up
- `CardCarousel` (the wrapper component) may need an update to pass `colSpan` through to its `CarouselItem` children

## Acceptance Criteria

1. `CARD_SIZE` entries contain **only** aspect-ratio classes — no `w-[...]` or `h-[...]` pixel values.
2. Inventory cards rendered inside a `CarouselItem colSpan={N}` fill the full column-span width and derive height from their aspect ratio.
3. The landing page carousels (featured vehicles, rare finds, continue shopping) pass `colSpan` to their carousel items and cards align to the PageGrid columns.
4. No visual regression on card proportions — aspect ratios match the current pixel dimensions (178:237 ≈ 3:4, 220:293, 334:445, 362:482, 448:597).
5. `CARD_IMAGE_SIZES` updated to provide appropriate responsive `sizes` hints.
6. Existing tests updated — no assertions on fixed pixel widths.
7. `pnpm type-check`, `pnpm lint`, `pnpm test`, `pnpm build` all pass.
8. Storybook: `carousel-grid-aligned` stories render correctly with the refactored card sizes.

## QA Notes

- Compare the landing page carousels before/after — card proportions should be visually identical
- Resize the viewport: cards should scale fluidly with the grid columns (no fixed pixel snapping)
- Check the carousel in the PageGrid overlay: card edges should align with grid column boundaries
- Mobile/tablet/desktop breakpoints: verify the aspect ratio steps match design

## Design References

- `packages/ui/src/components/__stories__/carousel/carousel-grid-aligned.stories.tsx` — colSpan demo
- `apps/web/src/shared/components/card/card-size.ts` — current fixed sizing
- `apps/web/src/shared/components/inventory-card/inventory-card-content.tsx` — SIZE_TOKEN map
- Figma: card proportions should match current ratios (verify with design)

## Non-Functional Requirements

- **Accessibility:** No change — cards remain keyboard-navigable via carousel
- **Performance:** Proper `sizes` hints prevent oversized image downloads
- **CLS:** Aspect ratio ensures the card reserves space before image loads — no layout shift

## Out of Scope

- Refactoring search-surface card sizes (`search`, `search-fill`, `search-fill-stacked`) — separate ticket
- VDP card sizes
- Editorial cards (these have their own sizing, not using inventory card)
- Adding new card sizes or aspect ratios beyond what currently exists
- Changing the carousel `colSpan` primitive itself (already done)

## Suggested File Name

inventory-card-grid-aligned-colspan.md
