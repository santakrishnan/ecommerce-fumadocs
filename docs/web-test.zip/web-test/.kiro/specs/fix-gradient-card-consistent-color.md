# Jira Bug: Standardize gradient card bottom color across all inventory cards

## Summary

All inventory cards using `variant="gradient"` should use the same fixed bottom gradient color instead of dynamically sampling each vehicle image. Apply the override directly in `GradientCardImage` so every gradient card across the site is consistent — no per-section configuration needed.

## Bug Description

**Current:** Each gradient card independently samples the bottom pixels of its vehicle image and uses that as the gradient fill color. This produces inconsistent gradients (some light, some dark) across adjacent cards in the same carousel.

**Expected:** All gradient cards site-wide should use one consistent dark gradient color (e.g., `oklch(25% 0.01 250)` or the design token equivalent) for a uniform look.

## Root Cause

`GradientCardImage` always relies on dynamic sampling. The underlying `GradientImage` from `@ucmp/ui` supports `overrideColor` which skips sampling entirely — but `GradientCardImage` never uses it.

## File to Change

`apps/web/src/shared/components/inventory-card/gradient-card-image.tsx`

## Fix

Pass a hardcoded `overrideColor` to `GradientImage` so all cards use the same gradient:

```diff
+ /** Fixed gradient color applied to all inventory cards for visual consistency. */
+ const GRADIENT_COLOR = "oklch(25% 0.01 250)";

  return (
    <div className="absolute inset-0" ref={containerRef}>
      <GradientImage
        aspectRatio={aspectRatio}
        blendHeightPercent={25}
        className="size-full"
        image={...}
        minImageHeightPercent={IMAGE_FILL_PERCENT}
        onColorSampled={handleColorSampled}
+       overrideColor={GRADIENT_COLOR}
      />
    </div>
  );
```

The `onColorSampled` callback still fires (GradientImage calls it with the override value), so `data-surface` on the card root is still set correctly for text contrast.

## Acceptance Criteria

1. All gradient inventory cards across the entire site use the same bottom gradient color.
2. The color is defined as a single constant (`GRADIENT_COLOR`) in `gradient-card-image.tsx`.
3. Text contrast (`data-surface`) is still set correctly based on the chosen color's lightness.
4. No per-section or per-card configuration needed — it's a global default.
5. No flash/flicker of a different color on load (since override skips sampling entirely).
6. The color value is confirmed with design (align with Figma token or neutral palette).

## QA Notes

- Verify all gradient cards (Continue Shopping, Because You Viewed, Rare Finds, Search Results) show the same gradient band
- Verify text is readable (white text on dark gradient)
- Verify no CLS or color flash on initial load
- Compare with Figma — confirm the gradient color matches the design spec

## Suggested File Name

fix-gradient-card-consistent-color.md
