# Jira Bug: PersonalizedSearchSkeleton does not match carousel design layout

## Summary

The `PersonalizedSearchSkeleton` component on the welcome-back page uses fixed pixel widths with a `flex` container, but the actual `PersonalizedSearchCarousel` uses grid-column-based `colSpan={{ sm: 4, lg: 4 }}` with the `@ucmp/ui` Carousel primitives. This mismatch causes the skeleton to render at incorrect sizes relative to the real cards, producing a visible layout shift (CLS) when the content loads.

## Bug Description

**Current:** The skeleton renders 3 cards at fixed widths (`w-[22.5rem]` / `w-[28rem]`) inside a `flex gap-2` container. These don't align with the grid-based carousel that uses `colSpan` for responsive sizing.

**Expected:** The skeleton should mirror the exact layout of the real carousel — same column spans, same aspect ratios, same gap, and same edge bleed — so there's zero visible shift when the real cards replace the skeleton.

## Root Cause

```tsx
// Skeleton (WRONG — fixed pixel widths, flex layout)
<div className="flex gap-2 overflow-hidden">
  <Skeleton className="aspect-[360/480] w-[22.5rem] shrink-0 rounded-xl lg:aspect-[448/601] lg:w-[28rem]" />
</div>

// Actual carousel (CORRECT — grid-column colSpan)
<Carousel>
  <CarouselContent>
    <CarouselItem colSpan={{ sm: 4, lg: 4 }}>
      <LinkEditorialCard size="large" ... />  {/* aspect-[360/480] lg:aspect-[448/601] */}
    </CarouselItem>
  </CarouselContent>
</Carousel>
```

The skeleton should use the same `Carousel` → `CarouselContent` → `CarouselItem colSpan` structure (or at minimum, the same CSS grid column classes) as the real carousel.

## File to Fix

`apps/web/src/features/landing/components/personalized-search-skeleton.tsx`

## Recommended Fix

Use the Carousel primitives with matching `colSpan` and aspect ratio:

```tsx
import { Carousel, CarouselContent, CarouselItem, Skeleton } from "@ucmp/ui";

const SKELETON_COUNT = 3;
const SKELETON_IDS = Array.from({ length: SKELETON_COUNT }, (_, i) => `search-skeleton-${i}`);

export function PersonalizedSearchSkeleton() {
  return (
    <section aria-label="Personalized search recommendations loading" className="w-full">
      <Carousel>
        <CarouselContent>
          {SKELETON_IDS.map((id) => (
            <CarouselItem colSpan={{ sm: 4, lg: 4 }} key={id}>
              <Skeleton className="aspect-[360/480] w-full rounded-xl lg:aspect-[448/601]" />
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>
    </section>
  );
}
```

**Key changes:**
- Replace `flex gap-2` with `Carousel` / `CarouselContent` / `CarouselItem` (matches real layout)
- Use `colSpan={{ sm: 4, lg: 4 }}` (matches real carousel)
- Use `w-full` instead of fixed pixel widths (responsive, grid-aware)
- Keep the same aspect ratios (`360/480`, `448/601`) as `EDITORIAL_SIZE_CLASSES.large`

## Acceptance Criteria

1. The skeleton renders at the same dimensions as the real editorial cards at every breakpoint (mobile, tablet, desktop).
2. No layout shift (CLS) when the skeleton is replaced by the real carousel content.
3. The skeleton uses the same gap and overflow behavior as the real carousel.
4. The skeleton count (3) matches the maximum number of cards shown.
5. The skeleton has appropriate `aria-label` for accessibility (loading state).
6. Edge bleed behavior (bleeds to right edge) matches the real section.

## QA Notes

- Throttle network (Slow 3G) → observe skeleton → verify no visible jump when real cards load
- Compare skeleton card sizes with real card sizes at each breakpoint (mobile 375px, tablet 768px, desktop 1440px)
- Verify the skeleton respects the `CAROUSEL_BLEED` class applied by the parent
- Run Lighthouse CLS check → verify no regression

## Suggested File Name

fix-personalized-search-skeleton-layout.md
