# Jira Story: Member Access Flow — `/member` shell + layout

## Summary

Build the `/member` page shell with the static Phone Entry layout (PageGrid, hero background) — no behaviour.

## User Story

As a Visitor, I want a dedicated "become a Toyota member" page that presents the phone-entry screen, so that a later story can wire up the sign-in behaviour on a layout that already matches the design.

## Background

The app has no sign-in today; identity is an anonymous Visitor (device fingerprint + session cookies). We are introducing a passwordless Member Access Flow (phone → verification code → confirmation) UI-first, sliced into stories. This first story delivers only the route and the static layout of the first screen so it can be reviewed for layout fidelity before any behaviour, validation, or server calls are added.

## Problem Statement

There is no `/member` route or feature module, and no reviewable layout for the Member Access Flow's first screen. Subsequent behaviour stories have nothing to attach to.

## Scope

- New `(member)` route group with a synchronous `/member` route (PPR shell, per repo convention).
- New `features/member/` module scaffold with a public `index.ts` barrel.
- A `(member)` route-group `layout.tsx` that renders the flow **full-screen** (without the global `Header`/`Footer`), matching the screenshots.
- Background: a **single static hero image** (`next/image`) with a **dark overlay**.
- Foreground content laid out with the `@ucmp/ui` `PageGrid` (4 / 8 / 12 responsive columns): headline, supporting copy, a US phone input field, and a primary CTA button.
- Use existing `@ucmp/ui` primitives (`Field`, `Input`, `Button`) and semantic theme tokens only.

## Dependencies / Constraints

- Depends on `@ucmp/ui` `PageGrid`, `Field`, `Input`, `Button`, and `next/image`.
- **Assumption:** a hero background image asset is available (or a placeholder is used and swapped later). Final asset from design.
- **Assumption:** exact copy (headline/subtext/CTA label) and the in-screen chrome (e.g. back affordance) come from design; placeholders used until confirmed.
- Must follow `AGENTS.md`: synchronous `page.tsx` export, semantic tokens (no hardcoded hex/px), `import type`, feature self-containment, `data-slot` retention on primitives.
- Routing model is fixed by ADR `docs/adr/member-access-flow-routing.md` (single `/member` route, client-driven steps — no route per step).

## Design References

> [!TODO]
> Add Figma link. Interim reference: attached flow screenshots (screens 2–4: "become a Toyota member" intro / phone entry). This story implements the static layout of those screens only.

## Acceptance Criteria

1. Navigating to `/member` renders a page served by a new `(member)` route group; the `page.tsx` default export is **synchronous** (PPR static shell) with no `await` at the top level.
2. A `features/member/` module exists with an `index.ts` barrel that re-exports only the public surface; route code imports the page composition from the feature, not from deep internal paths.
3. The `(member)` route group has its own `layout.tsx` that renders the flow **full-screen**, without the global `Header` and `Footer`.
4. The page shows a **single static hero image** rendered via `next/image` (LCP image marked `priority`), covering the viewport, with a **dark overlay** above it for foreground contrast.
5. Foreground content is positioned using `PageGrid` and `col-span-*` utilities, and includes, in order: a headline, supporting copy, a **US phone input field** (`Field` + `Input`, masked presentation `(XXX) XXX-XXXX`), and a primary **CTA button** (`Button`).
6. The phone field and CTA are **inert**: no validation, no `react-hook-form` wiring, no Server Action, and no step transition. Activating the CTA does not navigate or submit.
7. Only semantic theme tokens are used for colour/spacing/typography (e.g. overlay, text, button); no hardcoded hex values or arbitrary `px` (borders/hairlines excepted per `AGENTS.md`).
8. The layout is responsive and reflows correctly against `PageGrid`'s 4 (mobile) / 8 (tablet) / 12 (desktop) columns; the design is mobile-first per the screenshots.
9. No identity side effects: no cookies written (including `_ucmp_profile_id`), no calls to `/resolve`, fingerprint, or any backend.

## QA Notes

- Verify at `sm` (<768px), `md` (≥768px), and `lg` (≥1024px): column count, 8px gutters, and page margins behave; content stays aligned to `PageGrid`.
- Confirm the hero image loads as the LCP with `priority` and produces no cumulative layout shift.
- Confirm the phone field is focusable and labelled, and that the CTA is present but does nothing when clicked/tapped.
- Confirm the global `Header`/`Footer` do **not** render on `/member`.
- Confirm no network calls fire and no cookies are set on load or interaction.

## Non-Functional Requirements

- **Accessibility:** The phone input has an associated visible label (or accessible name); the hero image has an appropriate `alt` (empty `alt` if purely decorative); text/overlay meets contrast; logical focus order (field → CTA); the CTA is a real `button`.
- **Reliability:** Static shell only — no loading/error states this story; the page renders deterministically with no async data.
- **Observability:** No analytics or logging in this story.
- **Compatibility:** Net-new route and module; no change to existing routes, identity, or tracking behaviour.

## Out of Scope

- Phone validation, RHF + Zod, masking behaviour beyond static presentation (Story 2).
- `requestCode` / `verifyCode` Server Actions and the client step-machine (Stories 2–3).
- Code Entry (`InputOTP`, auto-submit, resend, inline error) and Confirmation step (Stories 3–4).
- Header CTA entry point into `/member` (Story 5).
- Vehicle-photo mosaic background, `_ucmp_profile_id` elevation, real OTP provider, contextual prompts (deferred epic).

## Suggested File Name

member-access-flow-shell-layout.md

---

## Remaining stories in this epic (for reference — each gets its own grilling/spec)

- **Story 2 — Phone Entry behaviour:** RHF + Zod US-phone validation, masked input, disabled-until-valid, `requestCode` Server Action stub returning `{ success, error?, data? }`, and the client step-machine advancing to Code Entry.
- **Story 3 — Code Entry:** 6-digit `InputOTP` (`REGEXP_ONLY_DIGITS`), auto-submit on completion, `verifyCode` Server Action stub (fixed dev code succeeds; others return an inline error), and a Resend Code action with a ~30s cooldown.
- **Story 4 — Confirmation:** brief success step (message + CTA) that links on to `/profile`.
- **Story 5 — Header CTA entry point:** a "Sign in / Become a member" action in the shared `Header` linking to `/member`.
- **Deferred epic — real auth:** real OTP provider integration + `_ucmp_profile_id` Member elevation, vehicle-photo mosaic background, contextual (in-context) prompts.
