# Jira Bug: ZIP code popover — submit arrow triggers "Use my current location" due to event propagation

## Summary

In the header location popover, tapping/clicking the right arrow button (submit ZIP) unintentionally also activates the "Use my current location" link below. This is an event propagation issue — the click event bubbles from the submit button through to the geolocation trigger underneath.

## Bug Description

**Steps to reproduce:**
1. Open the location popover in the header (click the location pill)
2. Enter a ZIP code (e.g., "91731")
3. Click/tap the right arrow (→) button to submit

**Current:** Both the ZIP submission AND "Use my current location" are triggered simultaneously. The browser may prompt for geolocation permission unexpectedly, or the ZIP resolves and then gets immediately overwritten by the geolocation result.

**Expected:** Only the ZIP submission fires. The "Use my current location" link should not activate.

## Root Cause (Likely)

The submit button's click event propagates (bubbles) up to a parent container that also contains the "Use my current location" element. Possible causes:
- The submit button and geolocation link share a click handler on a common ancestor
- The submit button is not calling `e.stopPropagation()` after handling the ZIP submission
- Touch events on mobile may be hitting both elements due to overlapping touch targets (the arrow button is small and close to the geolocation link)

## File to Investigate

`apps/web/src/features/location/components/zip-code-popover.tsx`

## Recommended Fix

Add `e.stopPropagation()` on the ZIP submit handler, and ensure the submit button and "Use my current location" are not nested in a way that allows event bubbling between them:

```tsx
function handleSubmit(e: React.FormEvent | React.MouseEvent) {
  e.preventDefault();
  e.stopPropagation(); // ← prevent click from reaching geolocation trigger
  // ... existing ZIP submission logic
}
```

Also verify touch target sizing — the submit button should have sufficient padding so touch events don't bleed into the geolocation link area below.

## Acceptance Criteria

1. Clicking/tapping the right arrow (→) submits the ZIP code only — does NOT trigger "Use my current location".
2. Clicking "Use my current location" triggers geolocation only — does NOT submit the ZIP input.
3. No browser geolocation permission prompt appears when submitting a ZIP code.
4. Works correctly on both mouse (desktop) and touch (mobile/tablet).
5. Keyboard Enter in the ZIP input submits the ZIP only (no geolocation side-effect).

## QA Notes

- Desktop: Click the arrow button → verify only ZIP resolves (check network tab for geo API call, should not see a navigator.geolocation request)
- Mobile: Tap the arrow button → verify no geolocation permission prompt appears
- Test rapid tapping — verify no double-submission
- Verify "Use my current location" still works independently when tapped directly

## Suggested File Name

fix-zip-popover-event-propagation.md
