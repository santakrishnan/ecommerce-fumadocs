# Jira Story: Refactor category card sizing to aspect-ratio-only with consumer-controlled colSpan

## Summary

Remove fixed width/height from the category card (`ShopByCategorySection`) and adopt aspect-ratio-only dimensions so carousel items align to the PageGrid via the `colSpan` prop, with span values controlled by the landing page wrapper.

## User Story

As a developer composing the "Browse by Style" carousel on the landing page, I want the category card to fill whatever grid column span I assign via `colSpan` while maintaining its design aspect ratio, so that cards align to the page grid without hardcoded pixel dimensions.

## Background

The category card (`CategoryCard`) currently defines fixed pixel dimensions via `CATEGORY_SIZE_CLASSES`:
```ts
const CATEGORY_SIZE_CLASSES = "h-[357px] w-[268px] lg:h-[445px] lg:w-[334px]";
```

This mirrors the same problem addressed for the inventory card — fixed dimensions fight the carousel's `colSpan` grid-based width. The `CategoryCarousel` wraps cards in the shared `CardCarousel` but doesn't pass `colSpan`, so items can't align to the PageGrid.

The fix follows the same pattern established for the inventory card: aspect-ratio-only sizing + consumer-controlled `colSpan`.

## Problem Statement

- `CATEGORY_SIZE_CLASSES` defines `w-[268px] h-[357px]` / `lg:w-[334px] lg:h-[445px]` — fights `colSpan` grid width
- `CategoryCarousel` doesn't pass `colSpan` to `CarouselItem` (uses the shared `CardCarousel` which renders items at fixed size)
- The image container inside the card also uses fixed `h-[208px]` / `lg:h-[263px]` which won't scale with a fluid card width
- Category cards can't participate in PageGrid-aligned carousels

## Scope

### 1. Refactor `CATEGORY_SIZE_CLASSES` to aspect-ratio-only

```ts
// Before
const CATEGORY_SIZE_CLASSES = "h-[357px] w-[268px] lg:h-[445px] lg:w-[334px]";

// After
const CATEGORY_SIZE_CLASSES = "aspect-[268/357] lg:aspect-[334/445]";
```

No width, no height — the card fills its container width (set by `colSpan`) and derives height from the ratio.

### 2. Refactor image container to relative sizing

Replace the fixed-height image container:
```tsx
// Before
<CardContent className="relative h-[208px] w-full p-0 lg:h-[263px]">

// After — image fills ~58% of the card height (208/357 ≈ 0.58)
<CardContent className="relative flex-1 w-full p-0">
```

The image area scales proportionally with the card.

### 3. Consumer controls `colSpan` via `CategoryCarousel`

Update `CategoryCarousel` to accept and forward `colSpan`:

```tsx
export interface CategoryCarouselProps {
  categories: CategoryCardData[];
  colSpan?: CarouselItemColSpan;
}

// Inside — pass colSpan to CardCarousel or directly to CarouselItem
<CardCarousel
  colSpan={colSpan ?? { sm: 2, md: 3, lg: 3 }}
  ...
/>
```

`ShopByCategorySection` (or `landing-body.tsx`) passes the appropriate span for the landing page context.

### 4. Update image `sizes` hint

Current: `sizes="(max-width: 1024px) 232px, 294px"` — hardcoded pixel estimates.

After: derive from grid column width or use breakpoint-based estimates matching the `colSpan` configuration.

### 5. Update tests

Remove assertions on fixed pixel widths/heights; assert aspect-ratio classes instead.

## Dependencies / Constraints

- The category card is a **stacked** card (image box + text footer), NOT an overlay card — the aspect ratio applies to the full card, not just the image
- The image inside uses `object-contain` (not `object-cover`) — scaling behaviour is different from inventory cards
- Start with landing page; if category cards appear elsewhere, those consumers set their own `colSpan`

## Acceptance Criteria

1. `CATEGORY_SIZE_CLASSES` contains **only** aspect-ratio classes — no `w-[...]` or `h-[...]` pixel values.
2. The image container inside `CategoryCard` scales proportionally with the card width (no fixed pixel height).
3. Category cards rendered inside a `CarouselItem colSpan={N}` fill the full column-span width and derive height from their aspect ratio.
4. The landing page "Browse by Style" carousel (`ShopByCategorySection`) passes `colSpan` and cards align to PageGrid columns.
5. No visual regression on card proportions — aspect ratios match current pixel dimensions (268:357, 334:445).
6. Image `sizes` hint updated to reflect grid-based widths.
7. Existing tests updated — no assertions on fixed pixel widths.
8. `pnpm type-check`, `pnpm lint`, `pnpm test`, `pnpm build` all pass.

## QA Notes

- Compare "Browse by Style" section before/after — card proportions should be identical
- Resize viewport: cards should scale fluidly (no fixed-pixel snapping at breakpoints)
- Verify the image inside the card scales proportionally (not stretched/clipped)
- Mobile/tablet/desktop: confirm the stacked layout (image + footer) maintains visual balance at all sizes
- Check with the PageGrid overlay: card edges should align with grid column boundaries

## Design References

- `apps/web/src/features/landing/components/category-card/category-card.tsx` — current fixed sizing
- `apps/web/src/features/landing/components/category-card/category-carousel.tsx` — carousel adapter
- `apps/web/src/features/landing/components/shop-by-category-section.tsx` — section wrapper
- `packages/ui/src/components/__stories__/carousel/carousel-grid-aligned.stories.tsx` — colSpan demo
- Current ratios: 268:357 (mobile), 334:445 (desktop) — both ≈ 3:4

## Non-Functional Requirements

- **Accessibility:** No change — cards remain keyboard-navigable via carousel, links retain aria-labels
- **Performance:** Updated `sizes` hint prevents oversized image downloads
- **CLS:** Aspect ratio ensures the card reserves space before image loads — no layout shift

## Out of Scope

- Refactoring inventory card sizes (separate ticket — already written)
- Editorial card sizes
- Dealer offer card sizes
- Changes to the carousel `colSpan` primitive itself
- Adding new category card variants or sizes

## Suggested File Name

category-card-grid-aligned-colspan.md
