# Pull Request

## Summary

Eliminates the skeleton flash that occurs in the Search Recommendations and Continue Shopping sections on the welcome-back page. The skeletons were rendering during SSR/hydration and then immediately vanishing when IndexedDB returned empty — causing a noticeable CLS flash. The fix removes eagerly-rendered `loading` fallbacks from `dynamic()` calls and defers skeleton rendering until actual data (VINs) is confirmed, showing nothing for visitors with empty history.

## Jira

Jira story: PEDX01-2817

## Changes

### `continue-shopping-client.tsx`

| Change | Detail |
|---|---|
| Remove inner `<Suspense>` | The outer `<Suspense>` in `welcome-body` already provides the streaming skeleton — a nested one caused a double-render flash |
| Remove skeleton import | `ContinueShoppingSkeleton` no longer used as fallback here |
| Simplify JSDoc | Updated comment to explain why no inner fallback is needed |

### `continue-shopping-connected.tsx`

| Change | Detail |
|---|---|
| Early return when IDB loading + no server data | `if (isLoading && newToday.length === 0) return null` — prevents skeleton flash for visitors with empty history |

### `continue-shopping-skeleton.tsx`

| Change | Detail |
|---|---|
| Replace real text with shape-only `<Skeleton>` | Swapped `SectionHeader` (real "Pick up where you left off" copy) for generic `<Skeleton>` bars — avoids flashing recognizable text that vanishes |
| Remove `CONTINUE_SHOPPING` import | No longer rendering real section copy in the skeleton |

### `home-body-skeleton.tsx`

| Change | Detail |
|---|---|
| Two-section layout | Expanded to match `WelcomeBody` structure: PersonalizedSearch placeholder (3 large aspect-ratio cards via `Carousel`) + ContinueShopping placeholder (title bars + 6 small cards) |
| Text-free placeholders | All heading placeholders are shape-only `<Skeleton>` — no real copy that could flash and vanish |
| Proper Carousel structure | Uses `Carousel`/`CarouselContent`/`CarouselItem` with `colSpan` for layout-accurate skeleton |

### `welcome-body.tsx`

| Change | Detail |
|---|---|
| Pass `className` to `SearchRecommendationsConnected` | Removes extra wrapper `<div>` — the section component now owns its own bleed class |

### `search-recommendations-client.tsx`

| Change | Detail |
|---|---|
| Accept `className` prop | New `SearchRecommendationsClientProps` interface; section applies bleed class directly |
| Conditional skeleton | Renders nothing until VINs confirmed (`isCollectionLoading \|\| selectedVins.length === 0 \|\| hasFailed → null`); shows skeleton only while taxonomy API is in-flight |
| Remove upfront skeleton render | Previously showed `SearchRecommendationsSkeleton` during any loading state — now deferred |

### `search-recommendations-connected.tsx`

| Change | Detail |
|---|---|
| Remove `loading` fallback from `dynamic()` | `{ ssr: false }` only — no eagerly-rendered skeleton that would flash and vanish for empty IDB |
| Accept/pass `className` prop | Thread-through to the dynamic component |
| Updated JSDoc | Explains why no loading fallback is used (IDB resolves synchronously for empty collections) |

## Visual QA

- **Before**: Welcome-back page flashes skeleton text and card placeholders that vanish immediately for visitors with no history.
- **After**: No skeleton renders unless the component confirms it has data to fetch; layout is stable on first paint.

## Checklist

- [x] PR title uses Conventional Commits format (`fix(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes — no new `any` or unjustified `@ts-ignore`
- [x] `pnpm lint` passes — no new warnings introduced
- [x] `pnpm test` passes
- [x] `pnpm build` passes — no route-level bundle regression
- [x] No hydration mismatch in dev or production build
- [x] No unexpected layout shift (CLS verified for UI changes)
- [x] Accessibility reviewed (`aria-busy`, `role="status"` preserved on skeletons)
- [x] No breaking changes
- [x] No hardcoded colors — tokens from `@ucmp/ui-theme` in OKLCH only

## Out-of-scope items observed

- The broader "Continue Shopping always show New Today" layout rework (cap at 3 cards desktop, mobile stacking) described in the spec — this PR only fixes the skeleton flash regression
- Test coverage for the new early-return path in `continue-shopping-connected.tsx` — existing tests cover the data-present path

## Reviewer focus

- Verify that removing the `loading` fallback from both `dynamic()` calls doesn't produce a blank gap on slow IndexedDB reads (IDB resolves synchronously for empty collections, and the skeleton is shown once VINs are confirmed and taxonomy fetch begins)
- `home-body-skeleton` now imports `Carousel`/`CarouselContent`/`CarouselItem` — confirm these are Server Component-safe and don't pull client JS into the streaming shell
- The `continue-shopping-connected` early return (`isLoading && newToday.length === 0`) assumes `newToday` is always passed from the server — verify this holds for the landing page variant as well

## Commit message

```
fix(web): eliminate skeleton flash in Search Recommendations and Continue Shopping [PEDX01-2817]

- Remove eagerly-rendered `loading` fallback from dynamic() in both
  SearchRecommendationsConnected and ContinueShoppingClient
- Defer skeleton rendering until VINs are confirmed from IDB
- Return null when IDB is loading and no server data exists (no flash)
- Replace real section header text in skeletons with shape-only
  <Skeleton> bars to avoid flashing recognizable copy
- Expand HomeBodySkeleton to two-section layout matching WelcomeBody
- Thread className prop through SearchRecommendations components
```
