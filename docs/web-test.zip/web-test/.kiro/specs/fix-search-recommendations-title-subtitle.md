# Jira Bug: Fix search recommendations section title and subtitle copy

## Summary

The `SearchRecommendationsClient` component has an incorrect subtitle and the title needs to be dynamic. Update the subtitle to "Because You Viewed" (title case) and derive the section title from the selected vehicle.

## Bug Description

**Current:** The subtitle is `"I found a few options you haven't seen yet that I think you'll like"` — this is leftover copy from the old "Based on your search" mock. The title is hardcoded as `"BASED ON YOUR SEARCH FOR COMPACT SUVS"`.

**Expected:** The subtitle should read `"Because You Viewed"` (title case) to match the new taxonomy-based data source which surfaces similar vehicles based on a previously viewed/saved vehicle.

## File to Change

`apps/web/src/features/landing/components/search-recommendations-client.tsx`

## Fix

```diff
-const SUBTITLE = "I found a few options you haven't seen yet that I think you'll like";
+const SUBTITLE = "Because You Viewed";
```

## Acceptance Criteria

1. The subtitle text reads "Because You Viewed" (title case — capital B, Y, V).
2. No other functionality changes.

## Suggested File Name

fix-search-recommendations-title-subtitle.md
