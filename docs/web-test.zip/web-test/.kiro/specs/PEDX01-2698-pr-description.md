# Pull Request

## Summary

Migrates all 20 production files from the legacy `normalizeLocalhostImageUrl` (from `utils`) to the new `normalizeImageUrl` (from `@shared/lib/media`) which routes header-gated media CDN images through the `/api/v1/media` proxy. Also fixes the price resolution in `mapSdkInventoryCardToVehicle` where `0` values from the API were not falling through to the next pricing field.

## Jira

Jira story: PEDX01-2698

## Changes

### Image URL normalizer migration (19 files)

All imports changed from:
```ts
import { normalizeLocalhostImageUrl } from "utils";
```
to:
```ts
import { normalizeImageUrl } from "@shared/lib/media";
```

| Area | Files |
|---|---|
| Search card mappers | `map-inventory-card-to-inventory-card.ts`, `map-option-card-to-editorial-card.ts`, `map-option-card-to-model-card.ts`, `map-option-card-to-spec-card.ts`, `map-option-card-to-trim-card.ts`, `map-sdk-inventory-card-to-vehicle.ts`, `map-v3-card-to-result-item.ts` |
| Landing services | `get-search-recommendations.ts` |
| Recommendations | `because-you-viewed.mapper.ts` |
| Vehicle Detail mappers/utils | `gallery-utils.ts`, `select-vehicle.ts`, `to-purchase-card-from-api.ts` |
| VDP page | `page.tsx` (hero + gallery cover URLs) |
| VDP components | `dealer-info-dialog.tsx`, `buy-with-confidence.tsx` |
| Shared components | `comparison-card-content.tsx`, `model-card-colors.tsx`, `model-card-content.tsx`, `spec-card-content.tsx`, `trim-card-content.tsx` |

### Price resolution fix (1 file)

| File | Change |
|---|---|
| `map-sdk-inventory-card-to-vehicle.ts` | `listPrice ?? sellingPrice ?? msrp ?? 0` → `sellingPrice \|\| listPrice \|\| msrp \|\| 0` — treats `0` as "not set" so it falls through to the next pricing field |

### Not included (deferred)

- `features/landing/services/get-personalized-search-cards.ts` — uses `normalizeLocalhostImageUrl` on `ctaLink` (navigation URL, not image). Needs separate handling.

## Visual QA

N/A — functional parity. Images that previously loaded from localhost fixtures continue to work. Images from the media CDN now route through the proxy (fixes 400s on Vercel). Price "0" bug on `/search/[id]/results` is resolved.

## Checklist

- [x] PR title uses Conventional Commits format (`refactor(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes — no new `any` or unjustified `@ts-ignore`
- [x] `pnpm lint` passes — no new warnings introduced
- [x] `pnpm test` passes
- [x] No hydration mismatch — `normalizeImageUrl` is client-safe (no `import "server-only"`)
- [x] No breaking changes — drop-in replacement with identical behavior for non-media-host URLs
- [x] No hardcoded colors

## Out-of-scope items observed

- `get-personalized-search-cards.ts` still uses `normalizeLocalhostImageUrl` on `ctaLink` — not an image URL, needs a separate link normalizer
- `packages/utils/src/image.ts` still exports `normalizeLocalhostImageUrl` — can be deprecated once all consumers are migrated
- The `resolveVehicleImage` fallback is commented out in `search.mapper.ts` (from PEDX01-2659 branch) — should be re-enabled or removed in a follow-up

## Reviewer focus

- **Price fix in `map-sdk-inventory-card-to-vehicle.ts`** — switched from `??` to `||` and reordered to `sellingPrice || listPrice || msrp || 0`. The BED API returns `listPrice: 0` when no list price exists; `??` kept the `0`, `||` falls through correctly. Confirm the priority order matches business intent (selling price > list price > MSRP).
- **Shared components are client components** — `normalizeImageUrl` is intentionally client-safe (pure function, no `import "server-only"`). The proxy routing logic reads `NEXT_PUBLIC_MEDIA_CDN_URL` which is statically inlined at build time.
- **No test changes needed** — the function signatures are identical (`normalizeImageUrl(url, fallback?)` matches `normalizeLocalhostImageUrl(url, fallback?)`), just with additional routing for media-host URLs.

## Commit message

```
refactor(web): migrate normalizeLocalhostImageUrl to normalizeImageUrl [PEDX01-2698]

- Replace normalizeLocalhostImageUrl (from utils) with normalizeImageUrl
  (from @shared/lib/media) across 20 production files
- The new utility routes media-host URLs and public/ relative paths through
  the /api/v1/media proxy (injects X-Origin-Verify server-side)
- External CDN domains (cdnrs.inventoryrsc.com, etc.) pass through unchanged
- Fix price resolution in mapSdkInventoryCardToVehicle: use || instead of ??
  so BED API's listPrice:0 falls through to sellingPrice/msrp
- Deferred: get-personalized-search-cards.ts (ctaLink is not an image URL)
```
