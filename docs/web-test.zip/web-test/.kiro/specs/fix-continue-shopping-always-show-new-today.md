# Jira Story: Continue Shopping carousel — always show both groups, cap recently viewed at 3 on desktop, stack on mobile

## Summary

Change the Continue Shopping carousel visibility rules so that "New Today" is **always shown** alongside "Continue Shopping" regardless of how many recently viewed vehicles exist. Cap "Continue Shopping" at 3 cards on desktop so both groups fit in the viewport. On mobile, stack "New Today" below "Continue Shopping" instead of hiding it.

## User Story

As a returning visitor, I want to always see both my recently viewed vehicles AND new listings in the Continue Shopping section — so that I can easily resume where I left off while also discovering fresh inventory.

## Background — Current Behaviour

The current visibility rules hide New Today based on the recently viewed count:

```
N = 0       → New Today only (no CS heading)
N = 1–2     → CS + New Today (hidden mobile, visible md+)
N = 3–4     → CS + New Today (hidden mobile+tablet, visible lg+)
N ≥ 5       → CS only — New Today hidden at ALL breakpoints
```

This means users with 5+ viewed vehicles never see New Today, and mobile users with 3+ viewed vehicles lose New Today entirely.

## New Behaviour Required

| Breakpoint | Continue Shopping | New Today |
|---|---|---|
| Desktop (lg+) | Max 3 cards (most recent), horizontal scroll | Always shown after CS group in the same track |
| Tablet (md) | Max 3 cards, horizontal scroll | Always shown after CS group |
| Mobile (sm) | All viewed cards, horizontal scroll | **Stacked below** CS as a separate visual block (not hidden) |

### Key Changes

1. **Remove the N≥5 hide rule** — New Today is always shown regardless of CS count
2. **Cap CS at 3 on desktop/tablet** — `recentlyViewed.slice(0, 3)` on `md+` breakpoints so both groups fit
3. **Mobile layout** — instead of hiding New Today, render it as a separate section below CS (stacked, not in the same horizontal track)
4. **Remove `newTodayVisibility` responsive hiding logic entirely**

## File to Fix

`apps/web/src/features/landing/components/continue-shopping/continue-shopping-carousel.tsx`

## Current Visibility Logic (to remove)

```tsx
// REMOVE THIS BLOCK:
let newTodayVisibility: string | false = false;
if (recentCount <= 2) {
  newTodayVisibility = "hidden md:flex";
} else if (recentCount <= 4) {
  newTodayVisibility = "hidden lg:flex";
}
// N ≥ 5 → newTodayVisibility stays false → New Today never renders
```

## Recommended Implementation

### Desktop/Tablet: cap CS to 3 + always show New Today in same track

```tsx
const MAX_CS_DESKTOP = 3;
const displayedRecent = recentlyViewed.slice(0, MAX_CS_DESKTOP);

return (
  <section className={className}>
    <Carousel hoverScaleRatio={...} scrollBySubitem stickyGroupLabels={stickyHeader}>
      <CarouselContent>
        {/* Continue Shopping — max 3 */}
        <CarouselGroup>
          <CarouselGroupLabel title="CONTINUE SHOPPING" subtitle="..." />
          <VehicleItems vehicles={displayedRecent} />
        </CarouselGroup>

        {/* New Today — ALWAYS shown */}
        {newToday.length > 0 && (
          <CarouselGroup>
            <CarouselGroupLabel title="NEW TODAY" subtitle="..." />
            <VehicleItems vehicles={newToday} />
          </CarouselGroup>
        )}
      </CarouselContent>
    </Carousel>
  </section>
);
```

### Mobile: stack New Today below

On mobile (`sm`), render the two groups as separate vertical sections instead of one horizontal track:

```tsx
{/* Mobile only: stacked layout */}
<div className="flex flex-col gap-8 md:hidden">
  <section>
    <SectionHeader title="CONTINUE SHOPPING" subtitle="..." />
    <HorizontalScroll><VehicleItems vehicles={recentlyViewed} /></HorizontalScroll>
  </section>
  {newToday.length > 0 && (
    <section>
      <SectionHeader title="NEW TODAY" subtitle="..." />
      <HorizontalScroll><VehicleItems vehicles={newToday} /></HorizontalScroll>
    </section>
  )}
</div>

{/* Tablet+Desktop: grouped carousel */}
<div className="hidden md:block">
  <Carousel ...>
    <CarouselContent>
      <CarouselGroup>CS cards (max 3)</CarouselGroup>
      <CarouselGroup>New Today cards</CarouselGroup>
    </CarouselContent>
  </Carousel>
</div>
```

## Acceptance Criteria

1. "New Today" is **always visible** regardless of how many recently viewed vehicles exist (no more N≥5 hide).
2. On desktop/tablet, "Continue Shopping" is capped at **3 cards** (most recent by `viewedAt`).
3. On desktop/tablet, both groups appear in the **same horizontal carousel track** with sticky labels.
4. On mobile, "New Today" is **stacked below** "Continue Shopping" as a separate scrollable row — not hidden.
5. On mobile, "Continue Shopping" shows **all** recently viewed vehicles (no 3-card cap — mobile has more scroll room).
6. If either group has 0 vehicles, that group is hidden (but the other still shows).
7. The `newTodayVisibility` responsive hiding logic is completely removed.

## QA Notes

- View 10 vehicles → return to welcome-back → verify both "Continue Shopping" (3 cards) and "New Today" are visible on desktop
- Same scenario on mobile → verify both sections are visible, stacked vertically
- View 1 vehicle → verify both groups show on all breakpoints
- View 0 vehicles → verify only "New Today" shows (existing UC-4 preserved)
- Verify "Continue Shopping" shows the 3 most recent (check order matches last viewed)

## Out of Scope

- Deduplication between CS and New Today (separate ticket exists)
- Changing the New Today data source or card count
- Adding a "View all" link for Continue Shopping

## Suggested File Name

fix-continue-shopping-always-show-new-today.md
