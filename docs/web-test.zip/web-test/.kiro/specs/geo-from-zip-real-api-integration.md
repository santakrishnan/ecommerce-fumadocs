# Jira Story: Header Location — Connect geo/fromZip to real Arrow Geo API and remove mock dependency

## Summary

Connect the header location/ZIP code change feature to the real Arrow Geo API (`https://api.sandbox.arrow.toyotafinancial.com/geo/v1/fromZip/{zip}`) by configuring the upstream URL, adding required authentication headers (X-Api-Key, X-Tenant-Id, X-Dealer-Id, X-Trace-Id), and removing the reliance on mock data (`USE_GEO_MOCKS`) for deployed environments.

## User Story

As a visitor, when I change my location in the header ZIP code popover, I want the system to resolve my ZIP against the real geo service — so that I get accurate city/state information and my location-scoped inventory results reflect real geography.

## Background

The geo BFF layer is already well-structured:
- `getGeoFromZip()` use case routes to mock or upstream based on env vars
- `fetchGeoFromZipCached()` calls the upstream with caching
- `createGeoClient()` creates the HTTP client with base URL and `X-Origin-Verify`
- `geo-from-zip-upstream.ts` handles request/response mapping + Zod validation
- `update-location.ts` Server Action orchestrates the ZIP → geo → cookie write flow

The missing piece is:
1. The real upstream API requires additional headers: `X-Api-Key`, `X-Tenant-Id`, `X-Dealer-Id`, `X-Trace-Id`
2. The upstream URL path is `/geo/v1/fromZip/{zip}` (path-based ZIP, not query param)
3. Vercel env vars need to be configured for the sandbox/production API key
4. `USE_GEO_MOCKS` should be `false` (or absent) in deployed environments

### Real API Details

```bash
curl --location 'https://api.sandbox.arrow.toyotafinancial.com/geo/v1/fromZip/91731' \
  --header 'X-Trace-Id: a858a035-9ec8-eee6-e84c-247a1256dae8' \
  --header 'X-Tenant-Id: string' \
  --header 'X-Dealer-Id: string' \
  --header 'Accept: application/json' \
  --header 'X-Api-Key: <API_KEY>'
```

## Problem Statement

1. The deployed app uses `USE_GEO_MOCKS=true` because `API_UPSTREAM_URL` is not configured for the geo service, returning fake location data.
2. The current `createGeoClient()` only sends `X-Origin-Verify` — missing required headers (`X-Api-Key`, `X-Tenant-Id`, `X-Dealer-Id`, `X-Trace-Id`).
3. The upstream call uses a query param `?zip=` but the real API uses a path param `/geo/v1/fromZip/{zip}`.
4. Location-scoped features (New Today, Rare Finds, search) all depend on accurate geo resolution.

## Scope

- Update `createGeoClient()` to include required headers: `X-Api-Key` (from env), `X-Tenant-Id`, `X-Dealer-Id`, `X-Trace-Id` (generated per request)
- Update `fetchGeoFromZip()` to call the correct path: `/geo/v1/fromZip/${zip}` (path param instead of query param)
- Verify the upstream response schema matches `fromZipUpstreamResponseSchema` — update if the real API returns a different shape
- Update `mapFromZipUpstreamToResponse` mapper if field names differ
- Configure Vercel env vars: `GEO_API_URL`, `GEO_API_KEY` (or use existing `API_UPSTREAM_URL` pattern)
- Remove `USE_GEO_MOCKS=true` from deployed env (keep for local dev only)
- Ensure the `geo/fromCoords` path is also reviewed (if it shares the same client)

## Dependencies / Constraints

- Requires Vercel env vars configured: API base URL + API key for the geo service
- The API key (`X-Api-Key`) must be stored as a server-only env var (NOT `NEXT_PUBLIC_*`)
- `X-Trace-Id` should be a UUID generated per request for traceability
- `X-Tenant-Id` and `X-Dealer-Id` values need to be confirmed with the backend team (may be static config or per-tenant)
- The upstream response shape must be validated — if it differs from `fromZipUpstreamResponseSchema`, update the schema
- The `geo/fromCoords` endpoint may use the same base URL and auth — coordinate changes

## Design References

- `apps/web/src/features/geo/bff/services/geo-client.ts` — HTTP client factory
- `apps/web/src/features/geo/bff/services/geo-from-zip-upstream.ts` — upstream fetch + cache
- `apps/web/src/features/geo/bff/use-cases/get-geo-from-zip.ts` — use case routing
- `apps/web/src/features/geo/bff/contracts/from-zip-response.schema.ts` — Zod schemas
- `apps/web/src/features/geo/bff/mappers/from-zip.mapper.ts` — response mapper
- `apps/web/src/features/geo/bff/services/geo-from-zip-mock.ts` — mock to be removed from prod
- `apps/web/src/features/location/services/update-location.ts` — Server Action calling the use case
- `apps/web/src/features/location/components/zip-code-popover.tsx` — UI trigger
- `apps/web/src/app/api/v1/geo/from-zip/route.ts` — route handler

## Acceptance Criteria

1. When a user enters a ZIP code in the header popover, `updateZipCode()` resolves against the **real Arrow Geo API** (not mocks) in deployed environments.
2. The request to the upstream includes all required headers: `X-Api-Key`, `X-Tenant-Id`, `X-Dealer-Id`, `X-Trace-Id`, `Accept: application/json`.
3. `X-Api-Key` is read from a **server-only** environment variable (e.g., `GEO_API_KEY`) — never exposed to the client bundle.
4. `X-Trace-Id` is a **freshly generated UUID** per request for distributed tracing.
5. The upstream URL path is `/geo/v1/fromZip/{zip}` — ZIP is a **path parameter**, not a query parameter.
6. The upstream response is validated against `fromZipUpstreamResponseSchema` — if the real API returns additional/different fields, the schema is updated to match.
7. The mapped response (`city`, `state`, `stateCode`, `zip`, `latitude`, `longitude`) is written to location cookies on success.
8. On upstream **failure** (non-200, timeout, network error), the user sees a friendly error message ("Location service is temporarily unavailable") — no stack traces or internal details.
9. `USE_GEO_MOCKS` is removed from deployed Vercel environments (sandbox, production). Mock path is preserved for local dev with `USE_GEO_MOCKS=true`.
10. The `/api/v1/geo/from-zip` route handler also works with the real upstream (same use-case code path).
11. Caching remains active: `cacheLife("landing")` + `cacheTag("geo-from-zip", "geo-from-zip:<zip>")`.
12. The `geo/fromCoords` endpoint (browser geolocation) is reviewed and updated to use the same auth headers if it shares the geo API base URL.
13. The integration works in the Vercel sandbox deployment (`dev.sandbox.arrow.toyotafinancial.com`).

## QA Notes

- Test ZIP entry in header popover with real API — verify city/state resolves correctly (e.g., 91731 → El Monte, CA)
- Test with invalid ZIP (e.g., 00000) — verify graceful error message
- Test with geo API unavailable — verify user sees "temporarily unavailable" message
- Test browser geolocation "Use my location" — verify reverse-geocode also works with real API
- Verify location cookies are set correctly after successful resolution
- Verify inventory sections (New Today, etc.) update to reflect the new ZIP
- Verify no API key is exposed in client-side bundle or network tab requests from the browser
- Test caching — same ZIP within 15min should not hit upstream again

## Non-Functional Requirements

- **Security:** API key stored as server-only env var with `import "server-only"` guard. Never exposed to client. Validated at build time via Zod env schema if available.
- **Performance:** Cached with `cacheLife("landing")` — repeat lookups for the same ZIP are served from cache. ZIP-scoped tags allow targeted revalidation.
- **Reliability:** Timeout handling on upstream calls. Graceful user-facing errors. Mock fallback preserved for local development.
- **Observability:** `X-Trace-Id` UUID per request enables distributed tracing across Arrow services. Log geo failures at `warn` level with trace ID.

## Out of Scope

- Geo resolution from IP address (uses fingerprint/browser geolocation instead)
- Auto-detecting location on first visit without user consent
- Multi-dealer support (single `X-Dealer-Id` value for now)
- Location history / recently used ZIP codes
- Geo-fencing or radius-based searches

## Environment Variables Required

| Variable | Description | Scope |
|---|---|---|
| `GEO_API_URL` (or reuse `API_UPSTREAM_URL`) | Base URL for geo service (e.g., `https://api.sandbox.arrow.toyotafinancial.com`) | Server-only |
| `GEO_API_KEY` | API key for geo service authentication | Server-only, secret |
| `GEO_TENANT_ID` | Tenant identifier for multi-tenant routing | Server-only |
| `GEO_DEALER_ID` | Dealer identifier | Server-only |

## Implementation Notes

### Updated `createGeoClient()`

```ts
import { randomUUID } from "node:crypto";

export function createGeoClient(baseUrl: string) {
  return createServerClient({
    baseUrl,
    serviceName: "Geo",
    defaultHeaders: {
      ...originVerifyHeader(),
      "X-Api-Key": process.env.GEO_API_KEY ?? "",
      "X-Tenant-Id": process.env.GEO_TENANT_ID ?? "string",
      "X-Dealer-Id": process.env.GEO_DEALER_ID ?? "string",
      "X-Trace-Id": randomUUID(),
      Accept: "application/json",
    },
  });
}
```

### Updated upstream fetch path

```ts
// Before (query param):
const raw = await client.get("/geo/fromZip", { params: { zip: request.zip } });

// After (path param):
const raw = await client.get(`/geo/v1/fromZip/${request.zip}`);
```

### Verify upstream response schema

The real API may return:
```json
{
  "city": "El Monte",
  "state": "California",
  "stateCode": "CA",
  "zipCode": "91731",
  "lat": 34.0686,
  "lon": -118.0276
}
```

This matches the existing `fromZipUpstreamResponseSchema` (uses `zipCode`, `lat`, `lon`). Confirm and adjust if needed.

## Suggested File Name

geo-from-zip-real-api-integration.md
