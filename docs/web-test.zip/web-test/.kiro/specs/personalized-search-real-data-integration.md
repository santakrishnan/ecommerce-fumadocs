# Jira Story: PersonalizedSearchSection — Replace mock data with profile/searches endpoint integration

## Summary

Replace the hardcoded mock data in `<PersonalizedSearchSection />` with real user search history fetched from the `profile/searches` endpoint, using fixture images as visual placeholders while displaying real search metadata.

## User Story

As a returning visitor, I want to see my actual recent searches displayed in the personalized search carousel on the welcome page — so that I can quickly resume or refine searches I've already started.

## Background

`<PersonalizedSearchSection />` currently delegates to `getPersonalizedSearchCards()` which calls `getSearchRecent()`. That use-case either returns hardcoded mock fixture data (when `USE_PROFILE_SEARCH_MOCKS=true`) or calls a placeholder upstream. The section needs to integrate with the real `profile/searches` endpoint to show the user's actual top 3 searches with real metadata (search ID, query/headline) while continuing to use the existing editorial card images from fixtures as visual placeholders.

## Problem Statement

The personalized search carousel shows fake mock data that is identical for every user regardless of their search history. This defeats the purpose of the "welcome back" experience — the section should reflect actual user behavior. The upstream `profile/searches` endpoint is available and returns the user's search history; the BFF layer needs to consume it and map the response into the `EditorialCardData` view model.

## Scope

- Create/update BFF service to call `GET /profile/searches?limit=3` with the resolved `visitorId`
- Define Zod schema for the `profile/searches` upstream response
- Update `getPersonalizedSearchCards()` to call the new service and map results to `EditorialCardData`
- Merge real API data (searchId, query, createdAt) with static fixture images (round-robin from image pool)
- Cap results at **3** cards maximum
- Return `{ success: true, data: [] }` when the API returns 0 results or errors — section renders `null`
- Populate `nextSearchPlan` with `{ searchId, query }` from the real response
- Remove reliance on `USE_PROFILE_SEARCH_MOCKS` for the production path (keep mock behind env flag for local dev only)
- Re-enable `"use cache"` + `cacheLife("profile")` once integration is validated

## Dependencies / Constraints

- Requires the `profile/searches` upstream endpoint to be available and returning user search history
- Requires `visitorId` from the resolved profile (already available via cookie / `ProfileResolveResponse`)
- Image pool is static — images are NOT fetched from the API; they cycle through the existing editorial card fixtures
- Maximum 3 cards — even if the API returns more results
- Section must gracefully hide (render `null`) on error or empty results — no error UI

## Design References

- `apps/web/src/features/landing/components/personalized-search-section.tsx`
- `apps/web/src/features/landing/services/get-personalized-search-cards.ts`
- `apps/web/src/features/landing/data/personalized-search-cards.ts`
- `apps/web/src/features/search/bff/use-cases/get-search-recent.ts`
- `apps/web/src/features/search/bff/contracts/search-recent-response.schema.ts`
- `apps/web/src/features/search/bff/__fixtures__/search-recent.fixture.ts`
- `apps/web/src/features/landing/components/home-experience/welcome-body.tsx`

## Acceptance Criteria

1. `getPersonalizedSearchCards()` calls the `profile/searches` endpoint (via BFF service) with the user's `visitorId`.
2. The top **3** most recent searches are returned, ordered by recency (`createdAt` descending).
3. Each card's `headline` and `eyebrow` are derived from the real API response (`query` field maps to `headline`; `eyebrow` defaults to `"Continue searching"`).
4. Each card's `href` is `/search/<searchId>` using the real `searchId` from the API.
5. Each card's `imageUrl` is assigned from the static fixture image pool (`/editorial-card/carousel2.png`, `/editorial-card/carousel1.png`, `/editorial-card/img-one.png`) by index (round-robin).
6. Each card's `nextSearchPlan` is `{ searchId: <real id>, query: <real query> }`.
7. Each card's `surface` defaults to `"dark"`.
8. If the API returns **0 results** (empty array), the function returns `{ success: true, data: [] }` and the section renders `null`.
9. If the API call **fails** (network error, non-200), the function returns `{ success: false, data: [] }` and the section renders `null`.
10. Maximum cards is always **3** — results are sliced before mapping.
11. Zod schema validates the `profile/searches` upstream response at the BFF boundary.
12. `"use cache"` + `cacheLife("profile")` is re-enabled once integration is validated.
13. `USE_PROFILE_SEARCH_MOCKS=true` still works for local development (mock path preserved).

## QA Notes

- Test with a user who has 5+ searches — verify only 3 cards shown
- Test with a user who has 0 searches — verify section is completely hidden
- Test with upstream unavailable — verify section is hidden, no error shown
- Verify card headlines match the user's actual search queries
- Verify clicking a card navigates to `/search/<real-id>`
- Verify images cycle through the fixture pool (not fetched from API)
- Test with `USE_PROFILE_SEARCH_MOCKS=true` — verify mock fallback still works

## Non-Functional Requirements

- **Accessibility:** No change — existing section markup already has `aria-label="Personalized search recommendations"`
- **Performance:** Cached with `cacheLife("profile")` (5min stale / 10min revalidate). Section wrapped in `<Suspense>` with skeleton fallback — does not block the static shell.
- **Reliability:** Graceful degradation on upstream failure — section hidden, no user-facing error.
- **Observability:** Log upstream failures at `warn` level with visitor context (no PII).

## Out of Scope

- Personalized image generation per search (uses static fixture images)
- More than 3 cards or pagination/infinite scroll
- Analytics/tracking for card clicks (separate ticket)
- Custom eyebrow text per card (always "Continue searching" for now)
- `matches` count from real data (omit or default to undefined until API supports it)

## Upstream Contract (Expected)

```
GET /profile/searches?limit=3
Headers: X-Visitor-Id: <visitorId>

Response 200:
{
  "data": {
    "searches": [
      { "id": "uuid-v4", "query": "string", "createdAt": "ISO-8601", "matchCount": number? }
    ]
  },
  "meta": { "traceId": "string", "timestamp": "ISO-8601" }
}
```

## Data Mapping (Pseudo-code)

```ts
const FIXTURE_IMAGES = [
  "/editorial-card/carousel2.png",
  "/editorial-card/carousel1.png",
  "/editorial-card/img-one.png",
];

function toCard(search: ProfileSearch, index: number): EditorialCardData {
  return {
    eyebrow: "Continue searching",
    headline: search.query,
    href: `/search/${search.id}`,
    imageUrl: FIXTURE_IMAGES[index % FIXTURE_IMAGES.length],
    surface: "dark",
    nextSearchPlan: { searchId: search.id, query: search.query },
  };
}
```

## Suggested File Name

personalized-search-real-data-integration.md
