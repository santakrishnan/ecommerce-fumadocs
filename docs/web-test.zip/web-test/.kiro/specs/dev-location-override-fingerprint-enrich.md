# Jira Story: Dev location override — seed fixed ZIP/geo from env var in fingerprint enrich

## Summary

Add an env-based override in the fingerprint `enrich` use-case so that when `DEV_SEED_LOCATION` is set (e.g., `DEV_SEED_LOCATION=90210,34.074,-118.4`), the fingerprint enrichment writes that fixed ZIP + coordinates to the location cookies instead of the real fingerprint geo result. Manual ZIP changes via the header popover still work and override it (since `source: "manual"` always wins).

## User Story

As a developer, I want to set a fixed ZIP/geo via an env var so that every fresh visit seeds a known location — making it easy to test location-scoped features (New Today, Rare Finds, search) without relying on the fingerprint geo service or browser geolocation.

## Background

The fingerprint enrich flow:
1. Browser calls `/api/v1/fingerprint/enrich` with a `requestId`
2. Server calls Fingerprint Server API → gets `{ visitorId, geo: { postalCode, latitude, longitude } }`
3. Calls `writeLocationCookies({ zip, latitude, longitude, source: "fingerprint" })` — seeds cookies only if no ZIP cookie exists yet
4. Returns `{ zip, coordinates }` to the client

With the override:
- Step 2 still happens (fingerprint identity is resolved normally)
- Step 3 uses the env var values instead of the real geo result
- `source: "fingerprint"` is preserved — so if the user manually changes ZIP later, the manual override still wins (existing precedence logic)

## File to Fix

`apps/web/src/features/fingerprint/bff/use-cases/enrich.ts`

## Recommended Implementation

```ts
// At the top of enrich.ts
const DEV_SEED_LOCATION = process.env.DEV_SEED_LOCATION?.trim();

function parseDevSeedLocation(): { zip: string; latitude: number; longitude: number } | null {
  if (!DEV_SEED_LOCATION) return null;
  const [zip, lat, lng] = DEV_SEED_LOCATION.split(",");
  if (!zip || !lat || !lng) return null;
  const latitude = Number(lat);
  const longitude = Number(lng);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;
  return { zip, latitude, longitude };
}
```

Then in the enrich function, after fingerprint resolves:

```diff
+ const devOverride = parseDevSeedLocation();
+ const seedZip = devOverride?.zip ?? geo?.postalCode;
+ const seedLat = devOverride?.latitude ?? geo?.latitude;
+ const seedLng = devOverride?.longitude ?? geo?.longitude;

- if (geo?.postalCode && geo.latitude != null && geo.longitude != null) {
-   const written = await writeLocationCookies({
-     zip: geo.postalCode,
-     latitude: geo.latitude,
-     longitude: geo.longitude,
-     source: "fingerprint",
-   });
+ if (seedZip && seedLat != null && seedLng != null) {
+   const written = await writeLocationCookies({
+     zip: seedZip,
+     latitude: seedLat,
+     longitude: seedLng,
+     source: "fingerprint",
+   });
```

## Env Var Format

```bash
# .env.local
# Format: ZIP,LATITUDE,LONGITUDE
DEV_SEED_LOCATION=90210,34.074,-118.4
```

- Server-only (no `NEXT_PUBLIC_` prefix) — never reaches the client bundle
- Comma-separated: ZIP, latitude, longitude
- Unset or empty → normal fingerprint geo behaviour (no override)

## Acceptance Criteria

1. When `DEV_SEED_LOCATION=90210,34.074,-118.4` is set, the first visit seeds ZIP `90210` + coordinates `34.074, -118.4` regardless of the fingerprint geo result.
2. The fingerprint identity flow (visitorId, fpHash cookie) works normally — only the geo seed is overridden.
3. Manual ZIP change via the header popover **still works** and overrides the dev seed (because `source: "manual"` always wins over `source: "fingerprint"`).
4. When `DEV_SEED_LOCATION` is unset, the flow is unchanged (real fingerprint geo used).
5. Invalid format (missing parts, non-numeric lat/lng) falls back to real fingerprint geo silently.
6. The env var is documented in `.env.local.example`.

## QA Notes

- Set `DEV_SEED_LOCATION=90210,34.074,-118.4` → clear cookies → visit site → verify location pill shows 90210
- Change ZIP to 10001 via header → verify it overrides (manual wins)
- Clear cookies again → revisit → verify 90210 is re-seeded
- Unset `DEV_SEED_LOCATION` → clear cookies → verify real fingerprint geo is used

## Suggested File Name

dev-location-override-fingerprint-enrich.md
