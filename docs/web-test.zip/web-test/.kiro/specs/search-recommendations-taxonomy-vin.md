# Jira Story: SearchRecommendationsSection — Replace "Because You Viewed" with taxonomy-based similar vehicles from first watchlist VIN

## Summary

Replace the current "Because You Viewed" mock/recommendations endpoint in `<SearchRecommendationsSection />` with a taxonomy search call using the first VIN from the user's local storage (IndexedDB watchlist). The backend returns similar vehicles based on taxonomy filters derived from that VIN, and the section title becomes dynamic: "Based on your search for {first vehicle title}".

## User Story

As a returning visitor, I want to see vehicles similar to the one I recently saved — so that I can discover relevant alternatives without repeating my search, with the section clearly telling me which vehicle it's based on.

## Background

`<SearchRecommendationsSection />` currently shows a hardcoded title "BASED ON YOUR SEARCH FOR COMPACT SUVS" and calls `getBecauseYouViewed()` which returns mock/fixture data. The new requirement is to:

1. Read the **first vehicle VIN** from the user's local storage (IndexedDB bookmarked vehicles collection)
2. Pass that VIN to the **taxonomy search endpoint** on the backend — the backend uses the VIN to derive taxonomy filters (make, model, body style, etc.) and returns similar available vehicles
3. Use the **first vehicle's title** (from local storage) as the dynamic section heading: "BASED ON YOUR SEARCH FOR {VEHICLE TITLE}"
4. Display the similar vehicles in the existing carousel

## Problem Statement

1. The section title is hardcoded ("COMPACT SUVS") and doesn't reflect the user's actual browsing history.
2. The recommendations data comes from a mock service that returns the same results for every user.
3. There is no personalization based on the user's saved/viewed vehicles.
4. The user's watchlist in IndexedDB already stores VIN + title — this data is available client-side to drive the taxonomy query.

## Scope

- Read the first bookmarked vehicle (VIN + title) from IndexedDB (`bookmarkedVehiclesCollection`) on the client
- Pass the VIN to a new/existing BFF endpoint that calls the taxonomy search backend
- The backend receives the VIN, derives taxonomy attributes, and returns similar vehicles
- Map the response to the existing `Vehicle[]` UI model for the carousel
- Make the section title dynamic: `"BASED ON YOUR SEARCH FOR ${firstVehicleTitle.toUpperCase()}"`
- Hide the section entirely if: no VIN in local storage, or taxonomy search returns 0 results, or API errors
- This section lives in the **welcome-back** experience only (returning visitor)

## Architecture Change

The current flow is purely server-side:
```
SearchRecommendationsSection (RSC) → getSearchRecommendations() → getBecauseYouViewed() → mock/upstream
```

The new flow requires a **client → server roundtrip** because the VIN lives in IndexedDB (client-only):
```
Client wrapper (reads first VIN from IDB) → BFF API call with VIN → taxonomy search upstream → Vehicle[]
```

**Option A — Client Component wrapper:**
- A thin Client Component reads the first VIN + title from `bookmarkedVehiclesCollection`
- Calls a BFF endpoint (e.g., `GET /api/v1/recommendations/similar?vin=<VIN>`)
- Renders the carousel with the response + dynamic title
- Shows skeleton while loading, `null` if no VIN or empty results

**Option B — Pass VIN via cookie/header from layout:**
- The `WatchlistSyncClient` (already in root layout) writes the first VIN to a cookie
- The Server Component reads the cookie and calls the taxonomy search directly
- Avoids client-side fetch but adds cookie management complexity

Recommended: **Option A** — cleaner separation, no cookie overhead, leverages existing IDB collection.

## Dependencies / Constraints

- Requires the taxonomy search backend endpoint to accept a VIN and return similar vehicles
- Requires `bookmarkedVehiclesCollection` in IndexedDB to have at least 1 entry (VIN + title)
- The taxonomy endpoint derives filters (make, model, body style, year range, etc.) from the VIN server-side — the client only passes the VIN
- Section is only shown in the welcome-back experience (`WelcomeBody`)
- If no VIN exists in local storage (new user, empty watchlist), the section renders `null`

## Design References

- `apps/web/src/features/landing/components/search-recommendations-section.tsx`
- `apps/web/src/features/landing/services/get-search-recommendations.ts`
- `apps/web/src/features/recommendations/bff/use-cases/get-because-you-viewed.ts`
- `apps/web/src/features/profile/watchlist/hooks/use-bookmarked-vehicle.ts`
- `apps/web/src/features/profile/watchlist/lib/bookmarked-vehicles-collection.ts`
- `apps/web/src/features/landing/components/home-experience/welcome-body.tsx`

## Acceptance Criteria

1. The section reads the **first vehicle** (by insertion order / most recent) from the IndexedDB `bookmarkedVehiclesCollection`.
2. The VIN from that vehicle is sent to the taxonomy search endpoint (e.g., `GET /api/v1/recommendations/similar?vin=<VIN>`).
3. The backend uses the VIN to derive taxonomy filters and returns a list of similar available vehicles.
4. The section title is dynamic: `"BASED ON YOUR SEARCH FOR {FIRST_VEHICLE_TITLE}"` — using the `title` field from the bookmarked vehicle in IDB (uppercased).
5. The subtitle remains: `"I found a few options you haven't seen yet that I think you'll like"`.
6. The similar vehicles are displayed in the existing `Carousel` → `LinkInventoryCard` layout with `size="small"`.
7. If the user has **no vehicles in IDB** (empty watchlist), the entire section renders `null`.
8. If the taxonomy search returns **0 results**, the section renders `null`.
9. If the taxonomy search **fails** (network error, non-200), the section renders `null` — no error UI.
10. A loading skeleton is shown while the client fetches the VIN and awaits the taxonomy response.
11. The VIN passed to the backend is the raw 17-character string — no additional client-side processing.
12. The response vehicles are deduplicated by ID and exclude the source VIN itself (don't recommend the same vehicle).
13. Section hidden for first-time visitors (no IDB data).

## QA Notes

- Test with 1+ vehicles in watchlist — verify section shows with dynamic title matching first vehicle's title
- Test with empty watchlist — verify section completely hidden
- Test with VIN that has no similar vehicles in backend — verify section hidden
- Test with taxonomy endpoint unavailable — verify section hidden, no errors shown
- Verify the recommended vehicles are taxonomically similar (same body style, similar year/price range)
- Verify the source vehicle (first VIN) is NOT shown in the recommendations carousel
- Verify loading skeleton appears before data loads

## Non-Functional Requirements

- **Accessibility:** Section `aria-label` updates dynamically to match the title. Skeleton has appropriate `aria-busy` state.
- **Performance:** Client-side fetch means this section is a dynamic hole under PPR. Skeleton streams immediately. TanStack Query caching prevents redundant refetches on re-mount.
- **Reliability:** Triple fallback — no VIN → hide, empty results → hide, error → hide. No user-facing errors.
- **Observability:** Log taxonomy failures at `warn` level server-side with VIN context (VIN is not PII).

## Out of Scope

- Multiple VIN-based recommendation rows (only uses the first/most-recent VIN)
- Backend taxonomy derivation logic (backend team owns that — we just pass the VIN)
- Fallback to "Because You Viewed" if taxonomy fails (section just hides)
- Changing the carousel visual layout or card size
- Analytics tracking for recommended vehicle clicks (separate ticket)

## Taxonomy Search Endpoint Contract (Expected)

```
GET /api/v1/recommendations/similar?vin=<VIN>
Headers: X-Visitor-Id: <visitorId> (optional)

Response 200:
{
  "data": {
    "results": [
      {
        "id": "string",
        "make": "string",
        "model": "string",
        "year": number,
        "trim": "string",
        "price": number,
        "mileage": number,
        "imageUrl": "string",
        "ctaLink": "string",
        "surface": "light" | "dark"
      }
    ],
    "sourceVehicle": {
      "vin": "string",
      "title": "string",
      "taxonomyFilters": { "bodyStyle": "string", "make": "string", ... }
    }
  },
  "meta": { "traceId": "string", "timestamp": "string" }
}
```

## Implementation Notes

### Client Component wrapper (recommended approach)

```tsx
"use client";

function SearchRecommendationsLoader() {
  const collection = useBookmarkedVehiclesCollection();
  const { data: vehicles } = useLiveQuery(
    () => collection && q.from({ v: collection }).orderBy(/* insertion order */).limit(1),
    [collection]
  );

  const firstVehicle = vehicles?.[0];
  if (!firstVehicle) return null;

  return (
    <SearchRecommendationsContent
      vin={firstVehicle.vin}
      title={firstVehicle.title}
    />
  );
}
```

### Data fetching inside the content component

```tsx
function SearchRecommendationsContent({ vin, title }: { vin: string; title: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["recommendations", "similar", vin],
    queryFn: () => fetch(`/api/v1/recommendations/similar?vin=${vin}`).then(r => r.json()),
    staleTime: 5 * 60 * 1000,
  });

  if (isLoading) return <SearchRecommendationsSkeleton />;
  if (!data?.results?.length) return null;

  const sectionTitle = `BASED ON YOUR SEARCH FOR ${title.toUpperCase()}`;
  return (
    <section aria-label={sectionTitle.toLowerCase()}>
      <SectionHeader title={sectionTitle} subtitle="..." />
      <Carousel>...</Carousel>
    </section>
  );
}
```

## Suggested File Name

search-recommendations-taxonomy-vin.md
