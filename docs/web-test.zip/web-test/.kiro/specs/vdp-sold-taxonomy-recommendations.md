# Jira Story: VDP Sold Page — Replace hardcoded editorial cards with taxonomy-based similar vehicles

## Summary

Replace the hardcoded `UNAVAILABLE_VEHICLE_EDITORIAL_CARDS` fixture on the VDP sold/unavailable page with dynamic vehicle recommendations using the existing `searchByTaxonomy` Server Action. Pass the sold vehicle's VIN + a limit of 3 to get similar available vehicles, then render them using inventory cards instead of editorial cards.

## User Story

As a visitor viewing a sold vehicle's page, I want to see similar vehicles that are actually available — so that I can find alternatives to the vehicle I was interested in without starting a new search from scratch.

## Background

The VDP sold page (`UnavailableVehicleLayout`) currently shows 3 hardcoded editorial cards with placeholder images and search URLs (e.g., "A 2022–2024 Highlander in Midnight Black Metallic"). These are static fixtures that never change and don't reflect real inventory.

The `searchByTaxonomy` Server Action (created in PEDX01-2719) already does exactly what's needed:
- Accepts a VIN + configurable limit
- Reads location cookies + visitor identity server-side
- Calls the BED search endpoint with `vinTaxonomy` filter
- Returns similar available vehicles as `Vehicle[]`
- Excludes the source VIN from results
- Deduplicates by ID

The sold page already has the VIN available (it's the route param). The goal is to wire `searchByTaxonomy(vin, { limit: 3 })` into the sold layout and replace the editorial carousel with an inventory card carousel.

## Problem Statement

1. The "Keep searching what's available now" section shows hardcoded fixture data (same 3 cards for every sold vehicle).
2. The cards are editorial cards (image + headline + link) — not real vehicle cards with price/year/make/model.
3. There is no personalization or relevance — a sold Camry shows Highlander suggestions.
4. The `searchByTaxonomy` utility exists and is proven on the welcome-back page — just needs to be wired here.

## Scope

- Call `searchByTaxonomy(vin, { limit: 3 })` on the VDP sold page with the sold vehicle's VIN
- Replace `EditorialSuggestionsCarousel` (editorial cards) with an `InventoryCardCarousel` (real vehicle cards) showing similar available vehicles
- Keep the section heading "KEEP SEARCHING WHAT'S AVAILABLE NOW" (or update to "SIMILAR VEHICLES AVAILABLE NOW")
- Hide the section entirely if taxonomy search returns 0 results or errors
- The sold page is server-rendered — call the Server Action directly (no client component needed since the VIN is known at render time)
- Keep `UNAVAILABLE_VEHICLE_EDITORIAL_CARDS` as fallback for local dev when `USE_SEARCH_RESULTS_MOCKS=true` or API is unavailable

## Dependencies / Constraints

- Requires `searchByTaxonomy` from `@features/search/actions/search-by-taxonomy` (already merged via PEDX01-2719)
- Requires the BED search endpoint to support `vinTaxonomy` filter (already working)
- Requires location cookie to be set (ZIP code) — `searchByTaxonomy` returns `{ success: false }` without it, section hides gracefully
- The sold page has the VIN from route params — no client-side data dependency
- Max 3 cards displayed (matching current editorial card count)


## Acceptance Criteria

1. The VDP sold page calls `searchByTaxonomy(vin, { limit: 3 })` with the sold vehicle's VIN.
2. The "Keep searching" section displays **real inventory cards** (make, model, year, trim, price, mileage, image) — not editorial cards.
3. Each card links to the correct VDP page for that vehicle (using `ROUTES.vdpSafe`).
4. The sold vehicle itself is **excluded** from recommendations (handled by `searchByTaxonomy`).
5. Maximum **3 vehicles** are shown.
6. When taxonomy search returns **0 results** or **fails**, the section renders `null` (hidden).
7. The section heading remains contextual (e.g., "KEEP SEARCHING WHAT'S AVAILABLE NOW" or "SIMILAR VEHICLES AVAILABLE NOW").
8. Cards show the save/bookmark icon (`showSaveButton`) so users can save alternatives.
9. The section is wrapped in `<Suspense>` with a skeleton so it doesn't block the static shell.
10. `UNAVAILABLE_VEHICLE_EDITORIAL_CARDS` is preserved for local dev fallback (behind env flag or when search fails).

## QA Notes

- Navigate to a sold vehicle's VDP → verify 3 similar available vehicle cards are shown
- Verify cards have real prices, real images, and link to valid VDP pages
- Verify the sold vehicle is NOT shown in the recommendations
- Test with a VIN that has no similar vehicles → verify section is completely hidden
- Test without location cookie → verify section hidden (no crash)
- Test with `USE_SEARCH_RESULTS_MOCKS=true` → verify fallback behavior
- Verify save/bookmark icon works on recommendation cards

## Non-Functional Requirements

- **Accessibility:** Cards use the same accessible `LinkInventoryCard` component — keyboard navigable, proper aria labels.
- **Performance:** Server-rendered via Server Action call — no client-side fetch waterfall. Wrapped in `<Suspense>` for streaming.
- **Reliability:** Graceful degradation — any failure → section hidden. No error UI on the sold page.
- **Observability:** `searchByTaxonomy` already logs failures internally.

## Out of Scope

- Changing the sold hero card or SoldCard component
- Adding "Why it sold" or similar insights
- More than 3 recommendations
- Personalization beyond taxonomy (e.g., price range, color preference)
- The "missing vehicle" (404) page — that can use the same pattern in a follow-up

## Implementation Notes

### Server Component approach (recommended)

Since the VIN is known at render time (route param), call `searchByTaxonomy` directly in the server component — no client wrapper needed:

```tsx
// In VdpPageContent (sold branch):
async function SoldRecommendations({ vin }: { vin: string }) {
  const result = await searchByTaxonomy(vin, { limit: 3 });
  if (!result.success || result.vehicles.length === 0) return null;

  return (
    <section aria-labelledby="sold-recs-heading">
      <SectionHeader title="SIMILAR VEHICLES AVAILABLE NOW" />
      <InventoryCardCarousel
        vehicles={result.vehicles}
        colSpan={{ sm: 4, md: 4, lg: 4 }}
        showSaveIcon
        size="large"
      />
    </section>
  );
}
```

### Integration in page.tsx (sold state)

```tsx
// Replace:
<UnavailableVehicleLayout
  editorialCards={UNAVAILABLE_VEHICLE_EDITORIAL_CARDS}
  heroCard={...}
/>

// With:
<UnavailableVehicleLayout
  heroCard={...}
  recommendations={
    <Suspense fallback={<InventoryCardSkeleton count={3} />}>
      <SoldRecommendations vin={vin} />
    </Suspense>
  }
/>
```

### Interface change to UnavailableVehicleLayout

```tsx
export interface UnavailableVehicleLayoutProps {
  heroCard: ReactNode;
  recommendations: ReactNode;  // replaces editorialCards
}
```

## Suggested File Name

vdp-sold-taxonomy-recommendations.md
