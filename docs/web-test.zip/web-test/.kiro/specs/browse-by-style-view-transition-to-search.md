# Jira Story: Browse By Style — View Transition morph to search input with pre-filled query

## Summary

When a user clicks a Browse By Style category card on the landing page, the card text should morph (via the View Transitions API) into the search input on `/search/{id}`, pre-filled with `"show me {category name}"` (e.g., "show me cars and minivans"). The agent then auto-submits the query and streams results.

## User Story

As a visitor on the landing page, when I click a category card like "SUVs", I want to see a smooth visual transition where the card morphs into the search input pre-filled with "show me SUVs" — so that the experience feels connected and I understand my intent has been captured.

## Background

The project already has:
- **View Transitions enabled** — `viewTransition: true` in `next.config.ts` (Next.js 16 triggers the browser's View Transitions API on every `router.push` / `<Link>` navigation)
- **Shared element transitions** — `VIEW_TRANSITION_NAME_HERO` pattern used on VDP card-to-hero morph
- **`nextSearchPlan` auto-submit** — editorial cards queue a turn in IDB with `{ searchId, query }`, the orchestrator auto-submits on mount
- **`SearchPromptClient`** — the search input component on `/search/[id]` that accepts initial text

The new behaviour connects these existing capabilities: assign matching `view-transition-name` on the category card element and the search input, queue the query, and let the browser morph them during navigation.

## Scope

- Convert `CategoryCard` click from static `<LinkCard href>` to a client-side handler that:
  1. Creates a new search session UUID
  2. Inserts a queued turn into IDB with `query: "show me {category name}"`
  3. Navigates via `router.push(`/search/${searchId}`)` (triggers View Transition)
- Assign `view-transition-name: category-to-search` on the category card's title/button area (source)
- Assign matching `view-transition-name: category-to-search` on the `SearchPromptClient` input (destination)
- The orchestrator auto-submits the queued query → agent streams results
- The search input visually shows `"show me {category name}"` during and after the transition

## Dependencies / Constraints

- Requires `viewTransition: true` in `next.config.ts` (already enabled)
- Requires the `nextSearchPlan` + auto-submit pattern (already working in personalized search cards)
- View Transitions only work in Chromium browsers (Chrome, Edge) — other browsers fall back to instant navigation (graceful degradation, no morph animation)
- Only one element per `view-transition-name` can exist on a page at a time — the source element must be the clicked card only (not all cards simultaneously)
- The category card is currently a Server Component (`CategoryCard` → `LinkCard`) — needs a Client Component wrapper for the click handler + IDB write

## Design References

- `apps/web/src/features/landing/components/category-card/category-card.tsx` — current card (Server Component with `<LinkCard href>`)
- `apps/web/src/features/landing/components/category-card/category-carousel.tsx` — carousel wrapper
- `apps/web/src/features/landing/components/shop-by-category-section.tsx` — section (maps data, renders carousel)
- `apps/web/src/features/search/components/search-prompt-client.tsx` — search input (transition destination)
- `apps/web/src/features/landing/components/personalized-search-carousel.tsx` — reference: editorial card `nextSearchPlan` click handler
- `apps/web/src/shared/components/shared-hero-transition.ts` — reference: `VIEW_TRANSITION_NAME_HERO` constant pattern
- `apps/web/src/features/search/hooks/use-auto-submit-turn-handler.ts` — auto-submits queued turns on mount

## Acceptance Criteria

1. Clicking a category card triggers a smooth View Transition animation where the card text/button area morphs into the search input on the `/search/{id}` page.
2. The search input is pre-filled with `"show me {category name}"` (lowercase category name, e.g., "show me suvs", "show me trucks", "show me cars and minivans", "show me electric").
3. The query is auto-submitted to the agent immediately after the transition completes — no user action needed.
4. The agent returns results for the category query (same as typing it manually).
5. In browsers that don't support View Transitions (Firefox, Safari), the navigation happens instantly without animation — no broken UX.
6. Only the clicked card participates in the transition (other cards don't have `view-transition-name` assigned).
7. Back navigation returns to the landing page (standard browser back).
8. Keyboard Enter on a focused card triggers the same flow.
9. The transition duration feels natural (~300–400ms, matching existing VDP hero transition timing).

## Implementation Notes

### Client Component wrapper

```tsx
"use client";

import { useRouter } from "next/navigation";
import { useAgentSearchTurnsCollection } from "@features/search";

export function CategoryCardClient({ data }: { data: CategoryCardData }) {
  const router = useRouter();
  const collection = useAgentSearchTurnsCollection();

  function handleClick(e: React.MouseEvent) {
    e.preventDefault();
    const searchId = crypto.randomUUID();
    const query = `show me ${data.name.toLowerCase()}`;

    // Queue a turn in IDB — orchestrator auto-submits on mount
    insertQueuedTurn(collection, { searchId, query, source: "category-card" });

    // Assign view-transition-name dynamically to clicked card only
    const target = e.currentTarget as HTMLElement;
    target.style.viewTransitionName = "category-to-search";

    router.push(`/search/${searchId}`);
  }

  return <CategoryCard data={data} onClick={handleClick} />;
}
```

### Search input (destination)

```css
/* On the SearchPromptClient input wrapper */
.search-input-transition {
  view-transition-name: category-to-search;
}
```

### Transition keyframes (optional polish)

```css
::view-transition-old(category-to-search) {
  animation: 300ms ease-out fade-out;
}
::view-transition-new(category-to-search) {
  animation: 300ms ease-in fade-in;
}
```

## QA Notes

- Test in Chrome/Edge → verify smooth morph animation from card to search input
- Test in Firefox/Safari → verify navigation works without animation (no errors)
- Click "SUVs" → verify input shows "show me suvs" and agent returns SUV results
- Click "Trucks" → verify input shows "show me trucks"
- Click "Cars & Minivans" → verify input shows "show me cars and minivans"
- Click "Electric" → verify input shows "show me electric"
- Use keyboard (Tab + Enter) → verify same flow triggers
- Verify only the clicked card animates (other cards stay static during transition)
- Verify back button works after transition

## Non-Functional Requirements

- **Performance:** View Transition is GPU-accelerated — no JavaScript animation overhead. The IDB write + UUID generation is <1ms.
- **Accessibility:** Transition respects `prefers-reduced-motion` — when set, the morph is suppressed (instant swap). Keyboard navigation preserved.
- **Progressive enhancement:** Non-supporting browsers get instant navigation — zero degradation in functionality, only the animation is missing.
- **Bundle impact:** Minimal — a thin Client Component wrapper (~20 lines) + one CSS rule.

## Out of Scope

- Animating the category card image (only the text/button area morphs)
- Adding transition animation on back navigation (landing → search only)
- Cross-fade between the landing page background and search page background
- Custom spring/bounce easing (use browser default or simple ease-out)

## Suggested File Name

browse-by-style-view-transition-to-search.md
