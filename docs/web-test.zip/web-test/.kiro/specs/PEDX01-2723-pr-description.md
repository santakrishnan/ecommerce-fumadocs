# Pull Request

## Summary

Replaces the mock `getSearchRecent` data source for the Personalized Search carousel with the real `profile/searches` BFF endpoint (`getSearches`). The section now shows the visitor's actual recent/saved search sessions with editorial card images from a static pool, and hides entirely when no sessions exist.

## Jira

Jira story: PEDX01-2723

## Changes

| File | Change |
|---|---|
| `landing/services/get-personalized-search-cards.ts` | Replaced `getSearchRecent` with `getSearches` from `@features/profile/searches/bff`. Maps `SearchSession` fields (name, query, searchId) to `EditorialCardData`. Images cycle through a static pool. Removed `cacheLife`/`use cache` (commented out previously). |
| `landing/components/personalized-search-section.tsx` | Added `className` prop, applied with `cn()`. Updated JSDoc to reflect new data source. |
| `landing/components/home-experience/welcome-body.tsx` | Moved `<Suspense>` to wrap the full section (so `null` return hides the bleed div). Passed `className={CAROUSEL_BLEED}` to the section. |
| `landing/__tests__/get-personalized-search-cards.test.ts` | Complete rewrite — mocks `getSearches` instead of `getSearchRecent`. Tests: name mapping, query fallback, "Saved search" fallback, href from searchId, static image cycling, nextSearchPlan, error/empty cases. |

## Key Design Decisions

- **Images are static** — The profile/searches API doesn't return images. Cards cycle through 3 fixture images (`img-one.png`, `card-demo.png`, `img-three.png`) by index.
- **Headline precedence**: `session.name` → `session.query` → `"Saved search"` (fallback for sessions with neither).
- **No `visitorId` parameter** — `getSearches()` reads the visitor identity internally from cookies (same pattern as other BFF services).
- **Section hidden when empty** — `getPersonalizedSearchCards()` returns `{ success: true, data: [] }` for 0 sessions, and the section renders `null`.
- **Suspense restructured** — The `<Suspense>` now wraps the section directly (not a bleed div), so when the section returns `null` there's no empty DOM node left behind.

## Visual QA

Before: 3 hardcoded mock cards always shown (same for every user).
After: Cards reflect the visitor's actual search sessions (name/query as headline, link to `/search/{id}`). Section hidden for new visitors with no sessions.

## Checklist

- [x] PR title uses Conventional Commits format (`feat(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` passes
- [x] `pnpm test` passes — test suite rewritten for new data source
- [x] No hydration mismatch
- [x] No breaking changes to the carousel rendering (same `EditorialCardData` shape)
- [x] No hardcoded colors

## Out-of-scope items observed

- `cacheLife("profile")` is not re-enabled yet — should be added once the integration is validated in sandbox
- `matches` count is not returned by the profile/searches API — button label omitted (shows no count badge)
- The `PersonalizedSearchCarousel` still uses the same `colSpan` and `size` — no visual layout changes

## Reviewer focus

- **`getSearches` import path** — `@features/profile/searches/bff`. Confirm this barrel exists and exports the function.
- **`SearchSession` type** — imported from `@ucmp/sdk-visitor-profile-api`. Confirm the type has `searchId`, `name`, `query` fields.
- **Suspense restructure in welcome-body.tsx** — The skeleton now wraps in the bleed div via `<div className={CAROUSEL_BLEED}><PersonalizedSearchSkeleton /></div>` inside the fallback, while the section itself receives `className` for the bleed. This ensures `null` returns produce no DOM artifacts.
- **Test coverage** — 11 test cases covering: success mapping, name/query/fallback headline, href, image cycling, nextSearchPlan, error handling, empty state, card shape.

## Commit message

```
feat(web): connect personalized search carousel to profile/searches BFF [PEDX01-2723]

- Replace getSearchRecent (mock) with getSearches from profile/searches BFF
- Map SearchSession (name, query, searchId) to EditorialCardData
- Cycle through static image pool (API doesn't return images)
- Headline precedence: session.name → session.query → "Saved search"
- Add className prop to PersonalizedSearchSection for layout flexibility
- Restructure Suspense in welcome-body so null return hides cleanly
- Rewrite test suite for new data source (11 cases)
```
