# Jira Story: VDP Image Gallery — Functionality

## Summary

Build a vertically stacked, section-anchored image gallery for the Vehicle Detail Page (VDP) displaying Exterior and Interior photos, with an interactive overlay tab bar on the hero image providing "360° view", "Key Features", and "Condition" tab switching.

## User Story

As an anonymous or authenticated shopper, I want to scroll through a vehicle's Exterior and Interior photos on the VDP, quickly jump between sections via anchor tabs, and switch between view modes on the hero image via an overlay tab bar, so that I can evaluate the vehicle's appearance before making a purchase decision.

## Background

The Vehicle Detail Page currently has no image gallery component. Shoppers need a way to browse vehicle photos organised by Exterior and Interior categories without leaving the page. Per the Figma design, the first hero image in each section (Exterior and Interior) includes a pill-shaped overlay tab bar at the bottom-left with three tabs — "360° view", "Key Features", and "Condition" — enabling different interactive views on that image. The gallery must be mobile-first and perform well on low-bandwidth connections, with priority loading on the first visible images.

## Problem Statement

There is no image gallery on the VDP. Shoppers cannot view vehicle photos or switch between 360° view and other overlay modes, which are critical conversion drivers for any automotive e-commerce experience.

## Scope

- Vertically stacked image list (one image per row, full-width)
- Two labelled sections: **Exterior** and **Interior**
- Sticky or inline anchor tab bar to jump between sections (smooth-scroll)
- **Hero image overlay tab bar** — a pill-shaped tab bar overlaid at the bottom-left of the **first image only** in each section (first Exterior image and first Interior image), containing three tabs: "360° view", "Key Features", "Condition". The tab bar does **not** appear on subsequent images in the section.
- **Tab bar visual behaviour:**
  - Tab bar colour matches the product card theme (adapts to light/dark mode)
  - "360° view" is selected by default (active state: dark/filled pill background)
  - Inactive tabs have a lighter/muted background
  - Switching tabs changes the active state visually
- **360° view tab** — when active, displays the available 360-degree images for that vehicle (image switching within the hero frame)
- **Key Features tab** — when active, renders a placeholder container (hotspot overlay content is a separate story)
- **Condition tab** — when active, renders a placeholder container (hotspot overlay content is a separate story)
- `next/image` with `priority` on first 3 images; all others lazy-loaded
- Mobile-first layout with desktop breakpoint adaptations
- Displays only the sections for which images exist; if only one type is available, shows that section without the missing tab
- Component receives image data as props from the VDP Server Component
- Define the `VehicleImage` type (`url`, `alt`, `type: 'exterior' | 'interior'`)
- Define an `activeTab` state type: `'360-view' | 'key-features' | 'condition'`

## Dependencies / Constraints

- Images are passed as props from the parent VDP Server Component (no additional fetch in this component)
- `VehicleImage` type must be defined and agreed upon before implementation — **Assumption:** `{ url: string; alt: string; type: 'exterior' | 'interior' }`
- 360° images are passed as a separate prop (e.g. `threeSixtyImages: string[]`) — **Assumption:** array of image URLs for the 360° spin set
- Uses `next/image` from Next.js 16 with `fill` + sized parent or explicit `width`/`height`
- The overlay tab bar requires `"use client"` for interactive state (tab switching) — pushed to the smallest leaf component
- No lightbox, zoom, or carousel interaction in this story
- No hotspot rendering in this story (Key Features and Condition content deferred to a follow-up story)
- No analytics events in this story
- No feature flag — directly added to VDP

## Design References

- [Figma Handoff — VDP Image Gallery](https://www.figma.com/design/S84HaAL9hckSZcWm8k2Vk2/Handoff?node-id=4331-97432&m=dev)

## Acceptance Criteria

1. The gallery renders a vertically stacked list of images, one per row, in the order provided by the parent.
2. Images are grouped into two sections: **Exterior** and **Interior**, each with a visible section header label.
3. An anchor tab bar (with "Exterior" and "Interior" tabs) is rendered above the gallery; clicking a tab smooth-scrolls to the corresponding section.
4. The first 3 images in the list render with `priority` (Next.js LCP optimisation); all remaining images use lazy loading.
5. All images use `next/image` — no bare `<img>` tags.
6. Each image has a meaningful `alt` attribute sourced from the image data; it is never empty or `"image"`.
7. If a vehicle has only Exterior images, only the Exterior section and its tab are rendered (the Interior tab is hidden).
8. If a vehicle has only Interior images, only the Interior section and its tab are rendered (the Exterior tab is hidden).
9. If a vehicle has no images at all, the gallery renders nothing (null) — the parent VDP is responsible for handling the empty state.
10. The component accepts a `images: VehicleImage[]` prop; `VehicleImage` is typed as `{ url: string; alt: string; type: 'exterior' | 'interior' }`.
11. On mobile (< `md` breakpoint) images are full-width; on desktop (`md`+) images respect the column layout defined in Figma.
12. The anchor tab bar remains accessible via keyboard (Tab to focus, Enter/Space to activate) with visible focus rings.
13. Each section heading (`<h2>` or equivalent) is reachable by the anchor scroll — the `id` attribute on the section matches the tab's `href`.
14. The component is a Server Component by default; the overlay tab bar is the only `"use client"` leaf.
15. A pill-shaped overlay tab bar is rendered at the bottom-left of the **first image only** in the Exterior section and the **first image only** in the Interior section. It does not appear on any subsequent images in either section.
16. The overlay tab bar contains three tabs labelled: **"360° view"**, **"Key Features"**, and **"Condition"**.
17. The "360° view" tab is selected by default on initial render (active state styling: dark/filled pill background).
18. The overlay tab bar adapts to the product card's colour mode (matches light or dark theme).
19. Clicking a tab updates the active tab state and visually highlights the selected tab while deactivating the others.
20. When "360° view" is active, the hero image area displays the available 360-degree images for the vehicle (cycling through the `threeSixtyImages` array or showing the first frame).
21. When "Key Features" is active, the hero image area renders a placeholder container (slot) ready for hotspot content (implemented in a follow-up story).
22. When "Condition" is active, the hero image area renders a placeholder container (slot) ready for hotspot content (implemented in a follow-up story).
23. If no 360° images are available for the vehicle, the "360° view" tab is still rendered but shows the default hero image (graceful fallback).
24. The overlay tab bar has `role="tablist"` with each tab using `role="tab"` and `aria-selected` for screen reader support.

## QA Notes

- Test on Chrome (mobile emulation 375px), Safari iOS, and Chrome desktop (1280px+).
- Verify smooth-scroll to Interior section does not overshoot or undershoot the header.
- Confirm first 3 images have `loading="eager"` / `priority` and the rest have `loading="lazy"` in the rendered DOM.
- Test with 0, 1, 5, and 20 images.
- Test with exterior-only and interior-only image sets.
- Verify keyboard tab navigation between anchor tabs fires scroll correctly.
- Check that no `<img>` tags without `next/image` wrapper appear in the output.
- **Overlay tab bar:** Verify "360° view" is active by default with correct pill styling.
- **Overlay tab bar:** Click each tab and confirm active state updates visually (dark pill for active, muted for inactive).
- **Overlay tab bar:** Verify tab bar adapts correctly in dark mode vs light mode.
- **Overlay tab bar:** Confirm the tab bar is positioned at the bottom-left of the hero image and does not overflow on mobile.
- **Overlay tab bar:** Verify keyboard navigation (arrow keys between tabs, Enter/Space to activate).
- **Overlay tab bar:** Test with and without 360° images available — confirm graceful fallback.
- **Overlay tab bar:** Verify "Key Features" and "Condition" tabs render placeholder containers (no hotspot logic yet).

## Non-Functional Requirements

- **Accessibility:** Anchor tabs must be keyboard accessible with visible focus rings; section headers must have matching `id` targets; images must have non-empty, descriptive `alt` text. Overlay tab bar must use WAI-ARIA tabs pattern (`role="tablist"`, `role="tab"`, `aria-selected`, `role="tabpanel"`).
- **Reliability:** Handle zero-image state gracefully (render null); handle single-section data without breaking the tab bar; handle missing 360° images without breaking the overlay tab bar.
- **Observability:** No analytics in this story — add in a follow-up if required.
- **Compatibility:** No breaking change to the existing VDP layout — gallery is a new additive component. Overlay tab bar placeholder slots must be extensible for the hotspot follow-up story.

## Out of Scope

- Lightbox / fullscreen modal
- Image zoom
- Carousel / swipe gestures
- Full 360° spin interaction (WebGL spinner, drag-to-rotate)
- **Key Features hotspot overlay content** (separate story)
- **Condition hotspot overlay content** (separate story)
- Analytics event tracking
- Feature flag / A/B rollout
- Storybook stories (separate story)
- Fixture data (covered in companion story)

## Suggested File Name

`vdp-image-gallery-functionality.md`
