# Pull Request

## Summary

Implements a same-origin reverse proxy for the header-gated Arrow media CDN, fixing `INVALID_IMAGE_OPTIMIZE_REQUEST` errors on Vercel. The media CDN requires `X-Origin-Verify` on every request, which Vercel's `next/image` optimizer cannot inject. The proxy route injects the key server-side, streams the image, and keeps the secret out of the client bundle. Also renames the `model` filter key to `bodyStyle` across the filters dialog to match the SDK contract.

## Jira

Jira story: PEDX01-2659

## Changes

### Media proxy (new files)

| File | Purpose |
|---|---|
| `shared/lib/media/media-constants.ts` | Shared media host + proxy path prefix constants (client-safe) |
| `shared/lib/media/media-upstream.ts` | Server-only upstream config resolver (reads `HEADER_X_ORIGIN_VERIFY`, timeout, cache settings) |
| `shared/lib/media/media-proxy.ts` | Streaming reverse proxy — injects `X-Origin-Verify`, handles timeout/502/504, path traversal guard, conditional/range passthrough |
| `shared/lib/media/normalize-image-url.ts` | Client-safe URL rewriter — routes `public/…` relative paths and absolute media-host URLs through `/api/v1/media/…` |
| `shared/lib/media/index.ts` | Public barrel (client-safe surface) |
| `shared/lib/media/__tests__/media-proxy.test.ts` | 11 tests: 503 unconfigured, 400 traversal/empty, 200 streaming, cache-control fallback/passthrough, 403/206/504/502, HEAD |
| `shared/lib/media/__tests__/normalize-image-url.test.ts` | URL rewriting tests: fallback, localhost strip, relative `public/` → proxy, absolute media host → proxy, other CDNs pass-through |
| `app/api/v1/media/[...mediaPath]/route.ts` | Route handler (GET + HEAD) — thin wrapper over `proxyMediaRequest` |

### Search mapper migration to new media utility

| File | Change |
|---|---|
| `search/bff/mappers/search.mapper.ts` | Replaced `normalizeLocalhostImageUrl` + `resolveVehicleImage` with `normalizeImageUrl` from `@shared/lib/media` |
| `search/bff/mappers/__tests__/search.mapper.test.ts` | Updated fallback assertion to match `normalizeImageUrl` default (placeholder instead of make/model/trim resolved image) |

### Filter key rename: `model` → `bodyStyle`

| File | Change |
|---|---|
| `search/components/filters-dialog/filter-sections-data.ts` | `key: "model"` → `key: "bodyStyle"` |
| `search/components/filters-dialog/filter-mock-data.ts` | `model:` → `bodyStyle:` in mock data keys |
| `search/lib/filter-converters.ts` | `ACTIVE_TO_SMART_KEY_MAP.model` → `.bodyStyle` |
| `search/__tests__/filter-content-panel.test.tsx` | Updated expected filter ID |
| `search/__tests__/filter-converters.test.ts` | Updated "no mapping" test to use `model` as unknown key |
| `search/__tests__/filter-mock-data.test.ts` | Updated describe/assertions from `model` → `bodyStyle` |
| `search/__tests__/filter-sections-data.test.ts` | Updated expected section key |

### Other

| File | Change |
|---|---|
| `shared/lib/http/status-codes.ts` | Added `HTTP_STATUS_NOT_MODIFIED = 304` (used by media proxy for conditional requests) |

## Visual QA

N/A — the media proxy is invisible to the user. Images that were previously broken (400 on Vercel) now load correctly through the proxy.

## Checklist

- [x] PR title uses Conventional Commits format (`feat(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes — no new `any` or unjustified `@ts-ignore`
- [x] `pnpm lint` passes — no new warnings introduced
- [x] `pnpm test` passes — 19 new tests + filter tests updated
- [x] No hydration mismatch (proxy is server-only, `normalizeImageUrl` is pure)
- [x] No breaking changes — `normalizeImageUrl` is a drop-in replacement for `normalizeLocalhostImageUrl` with additional proxy routing
- [x] Server-side secret (`HEADER_X_ORIGIN_VERIFY`) never reaches the client bundle — enforced by `import "server-only"` on `media-upstream.ts` and `media-proxy.ts`
- [x] No hardcoded colors

## Out-of-scope items observed

- `resolveVehicleImage` (make/model/trim fallback) is commented out in `search.mapper.ts` — should be re-enabled or removed in a follow-up once local vehicle images are confirmed available
- Other mappers (recommendations, VDP gallery) still use `normalizeLocalhostImageUrl` from `utils` — they should migrate to `normalizeImageUrl` from `@shared/lib/media` in a follow-up
- `cdnrs.inventoryrsc.com` images still go directly through `next/image` without the proxy (they don't need `X-Origin-Verify`) — verify they work on Vercel

## Reviewer focus

- **Security: `media-proxy.ts`** — path traversal guard rejects `..` segments; each segment is individually `encodeURIComponent`'d before building the URL. Upstream response headers are strictly allowlisted (no `set-cookie` relay). Verify this is sufficient for SSRF protection.
- **Streaming** — body is streamed (never buffered), so memory stays flat regardless of image size. Verify `Response` constructor with `upstream.body` passthrough works correctly on Vercel edge runtime.
- **Cache-Control** — respects upstream's `Cache-Control` when present; falls back to `public, max-age=86400` (configurable via `MEDIA_CACHE_MAX_AGE`). This means Vercel's CDN will cache proxied images for 24h by default.
- **`normalizeImageUrl` routing** — routes ONLY the configured media host through the proxy; other CDN domains (`cdnrs.inventoryrsc.com`, `tmna.aemassets.toyota.com`) pass through unchanged. Verify this logic in the test suite.
- **Filter rename** — `model` → `bodyStyle` aligns with the SDK contract. Confirm the label "Model" is still appropriate for the `bodyStyle` key in the UI.

## Commit message

```
feat(web): add media proxy route for header-gated Arrow CDN [PEDX01-2659]

- Add /api/v1/media/[...mediaPath] reverse proxy that injects X-Origin-Verify
  server-side, streams images without buffering, and guards against path traversal
- Add normalizeImageUrl utility (replaces normalizeLocalhostImageUrl for media
  paths) — rewrites relative "public/…" and absolute media-host URLs to the
  same-origin proxy; passes other CDN domains through unchanged
- Add media-upstream.ts config resolver (HEADER_X_ORIGIN_VERIFY, timeout, cache)
- Add media-constants.ts shared host + prefix (client-safe)
- Migrate search.mapper.ts to normalizeImageUrl from @shared/lib/media
- Rename filter key "model" → "bodyStyle" to match SDK contract
- Add HTTP_STATUS_NOT_MODIFIED (304) to status-codes
- Add 19 tests covering proxy behaviour and URL normalization
```
