# Jira Story: Rare Finds Section — Replace hardcoded data with search API filtered by expensive vehicles

## Summary

Replace the hardcoded `RARE_FINDS_VEHICLES` fixture data in the "Rare Finds" section with a dynamic call to the search API, filtering by high-price/expensive vehicles. The section should show dynamically changing premium inventory and hide entirely when no results are returned.

## User Story

As a visitor on the landing page, I want to see curated high-value/rare vehicles that are dynamically sourced from real inventory — so that I can discover premium vehicles that are actually available and the selection feels fresh on each visit.

## Background

The "Rare Finds" section (`<RareFindsWrapper />` → `<RareFindsSection />`) currently returns 3 hardcoded vehicles from `rare-finds-vehicles.ts` — all high-priced Toyotas (Supra $58K, GR Corolla $46K, 4Runner TRD Pro $54K). The service `getRareFinds()` simply slices this static array.

The requirement is to replace this with a real search API call that filters by expensive vehicles (high price threshold), returning dynamic results that change as inventory updates. The backend will be given a query/filter for "expensive vehicles" and will return matching available inventory.

## Problem Statement

1. The Rare Finds section shows the same 3 hardcoded vehicles for every user on every visit — never changes.
2. These vehicles may not exist in actual inventory (they're fixtures).
3. There is no dynamic sourcing from real inventory data.
4. The section subtitle claims "Handpicked for their rare mix of features, mileage, and value" but nothing is actually curated dynamically.

## Scope

- Replace `getRareFinds()` internals with a call to the search API using a price filter for expensive vehicles
- Pass a minimum price threshold filter (e.g., `priceMin: 40000` or similar high-value filter) to the search endpoint
- Map the search response to the existing `Vehicle[]` UI model
- Hide the entire section when 0 vehicles are returned or on error
- Maintain the `"use cache"` + `cacheLife("landing")` + `cacheTag("rare-finds")` caching strategy
- Keep the existing visual treatment (large cards, binocular icon, section copy)
- Remove `RARE_FINDS_VEHICLES` hardcoded data from the production path (keep for tests/local dev if needed)

## Dependencies / Constraints

- Requires the search API to support a price filter (min price) to surface expensive/premium vehicles
- The search query will be provided by the backend team (may include additional filters like availability, sort by price desc, etc.)
- Results should be available vehicles only (no sold/pending inventory)
- Section rendering is server-side (RSC) — no client-side data dependency
- Maximum vehicles displayed: configurable but currently 3 (large cards)
- The search endpoint is called **without a search ID** — this is a filter-only query

## Design References

- `apps/web/src/features/landing/components/rare-finds/rare-finds-wrapper.tsx`
- `apps/web/src/features/landing/components/rare-finds/rare-finds-section.tsx`
- `apps/web/src/features/landing/components/rare-finds/rare-finds-skeleton.tsx`
- `apps/web/src/features/landing/services/get-rare-finds.ts`
- `apps/web/src/features/landing/data/rare-finds-vehicles.ts`
- `apps/web/src/features/landing/data/rare-finds-copy.ts`

## Acceptance Criteria

1. `getRareFinds()` calls the search API with a **price filter for expensive vehicles** (e.g., `priceMin >= $40,000` or backend-defined threshold).
2. The search request includes an **availability filter** — only available/in-stock vehicles.
3. Results are sorted by **price descending** (or relevance as defined by the backend query).
4. The response vehicles are mapped to the existing `Vehicle` UI model (id, make, model, year, trim, price, mileage, imageUrl, href, surface).
5. Maximum **3 vehicles** are displayed (slice results to 3).
6. When the search returns **0 vehicles**, the entire section renders `null` — completely hidden from DOM.
7. When the search endpoint **fails** (network error, non-200, timeout), the section renders `null`.
8. Vehicle deduplication by ID is applied (no duplicate cards).
9. Each vehicle card links to the correct VDP page (using `ROUTES.vdpSafe()` or the `ctaLink` from the response).
10. The section dynamically changes as inventory updates — fresh data on each cache revalidation.
11. Caching: `"use cache"` + `cacheLife("landing")` (15min stale) + `cacheTag("rare-finds")` for targeted revalidation.
12. Zod schema validates the search response at the BFF boundary.
13. The existing section copy (title: "RARE FINDS", subtitle, binocular icon) is preserved.
14. `USE_RECOMMENDATIONS_MOCKS` or equivalent env flag still works for local dev (returns fixture data).

## QA Notes

- Verify vehicles shown are actually high-priced/premium (above the price threshold)
- Verify section shows different vehicles after cache expires and inventory changes
- Verify section is hidden when no expensive vehicles match the filter
- Verify section is hidden when search endpoint is unavailable
- Verify vehicle images load correctly from the search response URLs
- Verify VDP links are correct for each vehicle card
- Verify at most 3 vehicles are shown regardless of how many the search returns
- Compare with previous hardcoded data — confirm dynamic content is visually consistent (large cards, dark/light surface)

## Non-Functional Requirements

- **Accessibility:** No change — existing `aria-labelledby` and section structure preserved.
- **Performance:** Cached with `cacheLife("landing")` (15min stale / 15min revalidate / 1hr expire). Wrapped in `<Suspense>` with `<RareFindsSkeleton />` — does not block the static shell under PPR.
- **Reliability:** Graceful degradation — upstream failure → section hidden, no error UI.
- **Observability:** Log search failures at `warn` level. Remove/replace any console debug logging.

## Out of Scope

- AI-generated `aiDescription` text per vehicle (can be added later if the backend supports it)
- User-specific personalization of rare finds (same results for all users in same cache window)
- "Load more" or pagination
- Changing the visual layout (stays as large cards, 3 max)
- Price threshold configurability via admin UI (hardcoded or env-based for now)

## Search API Contract (Expected)

```
POST /search (or GET /search/results)

Request:
{
  "filters": {
    "availability": "available",
    "priceMin": 40000,
    "sort": "price:desc"
  },
  "limit": 6
}

Response 200:
{
  "data": {
    "vehicles": [
      {
        "id": "string",
        "make": "string",
        "model": "string",
        "year": number,
        "trim": "string",
        "vin": "string",
        "price": number,
        "mileage": number,
        "imageUrl": "string",
        "ctaLink": "string",
        "surface": "light" | "dark",
        "aiDescription": "string" (optional)
      }
    ],
    "totalCount": number
  }
}
```

## Implementation Notes

### Updated `getRareFinds()` service

```ts
"use cache";

import "server-only";
import type { Vehicle } from "@shared/components/inventory-card";
import { cacheLife, cacheTag } from "next/cache";

const MAX_RARE_FINDS = 3;
const PRICE_MIN = 40_000; // Backend-defined threshold for "expensive"

export async function getRareFinds(): Promise<Vehicle[]> {
  cacheLife("landing");
  cacheTag("rare-finds");

  const response = await searchVehicles({
    filters: { availability: "available", priceMin: PRICE_MIN },
    sort: "price:desc",
    limit: MAX_RARE_FINDS * 2, // Fetch extra for dedup headroom
  });

  if (!response.success || response.data.vehicles.length === 0) {
    return [];
  }

  return deduplicateById(response.data.vehicles.map(toVehicle)).slice(0, MAX_RARE_FINDS);
}
```

### Section hiding (already supported)

`<RareFindsSection />` already conditionally renders — just ensure it returns `null` when `rareFinds.length === 0` (verify existing behavior handles this).

## Suggested File Name

rare-finds-search-api-expensive-vehicles.md
