# Jira Bug: VDP records $0 price in vehicle history — use resolveDisplayPrice utility

## Summary

The VDP page records vehicle data to IndexedDB browsing history (for the "Continue Shopping" carousel) using `bffVehicle?.pricing?.listPrice` directly. When the BED API returns `listPrice: 0` (no list price available), the history stores `price: 0`. This should use the shared `resolveDisplayPrice` utility which handles the full precedence: `effectivePrice → finalPrice → sellingPrice → listPrice → msrp`.

## Bug Description

**Current:** The `rv.listPrice` in VDP `page.tsx` is computed as:
```ts
listPrice: bffVehicle?.pricing?.listPrice ?? vehicle.price,
```

This has two problems:
1. Uses `??` (nullish coalescing) — `listPrice: 0` from the API is kept as `0` instead of falling through
2. Only reads `pricing.listPrice` — ignores `computed.effectivePrice`, `pricing.sellingPrice`, and `pricing.msrp`

**Result:** The "Continue Shopping" carousel on the welcome-back page shows "$0" for vehicles viewed on the VDP when the API's `listPrice` was `0`.

**Expected:** The recorded price should use the same `resolveDisplayPrice` utility used by all other mappers, giving the correct display price.

## Root Cause

```ts
// VDP page.tsx — line ~195
const rv = {
  ...
  listPrice: bffVehicle?.pricing?.listPrice ?? vehicle.price,  // ❌ doesn't use resolveDisplayPrice
};

// Then passed to history:
<RecordVehicleViewClient vehicle={{ price: rv.listPrice, ... }} />
```

The `resolveDisplayPrice` utility (from `@shared/lib/pricing`) already handles this correctly:
```ts
effectivePrice || finalPrice || sellingPrice || listPrice || msrp || 0
```

## File to Fix

`apps/web/src/app/(shop)/used-cars/details/[make]/[model]/[trim]/[year]/[vin]/page.tsx`

## Recommended Fix

```diff
+ import { resolveDisplayPrice } from "@shared/lib/pricing";

  const rv = {
    make: bffVehicle?.vehicleInfo.make ?? vehicle.make,
    model: bffVehicle?.vehicleInfo.model ?? vehicle.model,
    trim: bffVehicle?.vehicleInfo.trim ?? vehicle.trim,
    year: bffVehicle?.vehicleInfo.year ?? vehicle.year,
    mileage: bffVehicle?.status.mileage ?? vehicle.mileage,
-   listPrice: bffVehicle?.pricing?.listPrice ?? vehicle.price,
+   listPrice: bffVehicle
+     ? resolveDisplayPrice({
+         effectivePrice: bffVehicle.computed?.effectivePrice,
+         sellingPrice: bffVehicle.pricing?.sellingPrice,
+         listPrice: bffVehicle.pricing?.listPrice,
+         msrp: bffVehicle.pricing?.msrp,
+       })
+     : vehicle.price,
  };
```

## Acceptance Criteria

1. The price stored in vehicle history IndexedDB uses `resolveDisplayPrice` (same precedence as all other inventory card mappers).
2. No `$0` prices appear in the "Continue Shopping" carousel for vehicles viewed on the VDP.
3. The price shown on the VDP purchase card matches the price stored in history.
4. Existing vehicles with `price: 0` in IDB history are unaffected (they were recorded before the fix — acceptable stale data).

## QA Notes

- View a VDP where `listPrice` is 0 but `sellingPrice` or `effectivePrice` exists
- Navigate to the welcome-back page → "Continue Shopping" → verify the viewed vehicle shows the correct price (not $0)
- Check IndexedDB (`tdb-vehicle-history`) → verify the `price` field has the correct value

## Suggested File Name

fix-vdp-vehicle-history-price.md
