# Jira Story: Member Access Flow — Phone Entry behaviour

## Summary

Wire the `/member` Phone Entry step: RHF + Zod US-phone validation, masking, `requestCode` stub, and the client step-machine advancing to Code Entry.

## User Story

As a Visitor, I want to enter my US phone number and request a verification code, so that I can begin becoming a Member.

## Background

Story 1 shipped the `/member` shell with the static (unwired) Phone Entry layout. This story adds behaviour: it introduces the client-driven step-machine that the whole flow rides on, validates and masks the phone number, and submits it to a stubbed `requestCode` Server Action that advances the flow to Code Entry. Verification, resend, confirmation, and real auth remain out of scope.

## Problem Statement

The Phone Entry screen is currently inert — no validation, no submission, no transition. There is also no client state machine for the flow, so no step can advance.

## Scope

- A `useReducer`-backed `useMemberFlow()` hook plus a **flow-scoped** context (`MemberFlowProvider`) that defines the full three-step machine (`phone` → `code` → `confirmation`), with **only the `phone` → `code` transition wired** this story.
- `page.tsx` remains a **synchronous server shell** (hero background stays server-rendered); a single `"use client"` `<MemberFlow>` island owns the provider/machine and renders the active step.
- Story 1's static Phone Entry markup migrates into a client `PhoneEntry` step component.
- `react-hook-form` + `zodResolver` validation using a shared `phoneSchema`.
- Pure `normalizePhone` and `formatUsPhone` helpers added to `packages/utils`.
- A `requestCode(phone)` Server Action (stub) returning `{ success, error?, data?: { phone } }`.

## Dependencies / Constraints

- Builds on Story 1 (`member-access-flow-shell-layout.md`).
- Uses `@ucmp/ui` `Field`, `Input`, `Button`; `react-hook-form@7`, `@hookform/resolvers@5`, `zod@4`; lucide `Loader2` for the pending spinner (`Button` has no built-in loading prop).
- **Placement (locked):** pure `normalizePhone` (→ 10 digits) and `formatUsPhone` (→ `(XXX) XXX-XXXX`) live in `packages/utils`; the Zod `phoneSchema` lives in a **feature-local, non-server-only** module (`features/member/lib/phone.ts`) so both the RHF resolver and the Server Action import the same schema.
- **Deviation (noted, not an ADR):** submit is **RHF-driven** — `handleSubmit` calls the Server Action directly and uses `formState.isSubmitting` for pending — rather than `useActionState`/`useFormStatus`. `useFormStatus` is for plain server-action forms and conflicts with RHF's submit ownership; this is easily reversible.
- Governed by existing ADRs: single `/member` route with client-driven steps; mutations as Server Actions.

## Design References

> [!TODO]
> Add Figma link. Interim reference: attached flow screenshots (screens 2–4: phone entry with keyboard).

## Acceptance Criteria

1. A `useMemberFlow()` hook backed by `useReducer` and a flow-scoped `MemberFlowProvider` define a machine with steps `phone`, `code`, `confirmation`; the reducer exposes a `submitPhone(phone)` transition (`phone` → `code`). `code`/`confirmation` states exist but their transitions may be unwired placeholders.
2. `/member` `page.tsx` stays a **synchronous** server component that renders the hero background and mounts a `"use client"` `<MemberFlow>` island; the background is not inside the client boundary.
3. A client `PhoneEntry` step renders the migrated Story 1 markup and uses `react-hook-form` with `zodResolver(phoneSchema)`.
4. `normalizePhone` and `formatUsPhone` are added to `packages/utils` (pure, unit-tested); `phoneSchema` in `features/member/lib/phone.ts` validates a US number as exactly 10 digits and is importable by both client and server (no `import "server-only"`).
5. The phone input masks input as `(XXX) XXX-XXXX`: `onChange` strips non-digits, caps at 10, stores digits, and displays the formatted value. The input uses `type="tel"`, `inputMode="numeric"`, `autoComplete="tel-national"`.
6. RHF runs in `mode: "onChange"`; the CTA is **disabled while the number is invalid** and **while submitting**. The field's validation error message appears only **after blur/touched**, not while typing.
7. On valid submit, `handleSubmit` calls the `requestCode` Server Action; while it is pending the CTA is disabled, shows a `Loader2` spinner, and sets `aria-busy`.
8. `requestCode(phone)` (stub) returns `{ success: true, data: { phone } }` with `phone` normalized to 10 digits; its return type is `{ success: boolean; error?: string; data?: { phone: string } }`.
9. On `success`, the component dispatches `submitPhone(phone)` and the machine transitions to the `code` step with the phone available in flow state.
10. If the action returns `{ success: false }` (defensive branch; the stub does not trigger it), a **form-level error** renders in a `Field` error region with `role="alert"`/`aria-live` so it is announced. The flow does not advance.
11. Only `@ucmp/ui` primitives and semantic tokens are used; `data-slot` attributes are preserved; no hardcoded hex/arbitrary px.
12. No identity side effects: no cookies (including `_ucmp_profile_id`), no `/resolve`/fingerprint/backend calls, no analytics.

## QA Notes

- Type a partial number → CTA stays disabled, no error shown; blur an invalid number → error appears; complete 10 digits → CTA enables.
- Verify masking during typing, paste, and backspace (deleting across separators behaves sensibly; stored value is digits only).
- Submit a valid number → spinner shows, CTA disabled, then the flow advances to the (placeholder) Code step and the phone is retained in state.
- Confirm a rapid double-click cannot double-submit (disabled during pending).
- Screen reader: the input has an accessible name; validation and form-level errors are announced.
- Confirm no network calls and no cookies on submit; `page.tsx` still renders the hero as a server-rendered static shell.

## Non-Functional Requirements

- **Accessibility:** Labelled phone input; error regions use `role="alert"`/`aria-live`; focus remains on the field when a validation error appears; the CTA is a real `button` with `aria-busy` while pending.
- **Reliability:** Pending and (defensive) error branches are handled; the stub always succeeds but the failure path is wired for real auth.
- **Observability:** None this story.
- **Compatibility:** Extends the Story 1 route/module; adds two exports to `packages/utils`; no change to other routes, identity, or tracking.

## Out of Scope

- Code Entry: `InputOTP`, auto-submit, `verifyCode`, inline invalid-code error, resend cooldown (Story 3).
- Confirmation step and navigation to `/profile` (Story 4).
- Header CTA entry point (Story 5).
- Real `requestCode` provider, verification handle/session id, code expiry, and `_ucmp_profile_id` Member elevation (deferred epic).
- Vehicle-photo mosaic background (deferred epic).

## Suggested File Name

member-access-flow-phone-entry.md
