# Jira Story: Replace Watchlist with Search icon in NavigationBar

## Summary

Replace the Saved/Watchlist nav item with a Search icon in the NavigationBar default variant, navigating to /search on click

## User Story

As a shopper, I want a Search icon in the main navigation bar, so that I can quickly access vehicle search from any page without relying on the hero prompt.

## Background

The current `NavigationBar` default variant renders three icon buttons: Home, Saved (Watchlist), and Profile. The updated Figma design (Handoff node `9:4053`) shows the navigation pill with Home, Search, and Profile — removing Watchlist entirely from the primary nav. This aligns with the product decision to surface search as a top-level action and move saved vehicles under the Profile section.

## Problem Statement

The navigation bar does not match the latest Figma design. There is no persistent Search entry point in the nav, forcing users to scroll back to the hero section or use browser history to initiate a new search.

## Scope

- Replace the "Saved" (Watchlist) nav item with "Search" in `DEFAULT_NAV_ITEMS`
- Use `IconSearch` (inactive) for the Search item — no filled variant needed since the active state is handled by the search-variant back button
- Search icon links to `ROUTES.SEARCH` (`/search`)
- Profile icon continues to link to `ROUTES.PROFILE` (`/profile`)
- Update the `isActive` logic: Search is active when pathname starts with `/search`
- Update the Home `isActive` logic to exclude `/search` paths (Home is active when not on `/search` or `/profile`)
- Create/update a Storybook story for the NavigationBar showing the new default variant
- Remove `IconSaved` and `IconSavedFilled` imports if no longer used elsewhere in the component

## Dependencies / Constraints

- `ROUTES.SEARCH` (`/search`) already exists in `@config/routes/constants.ts`
- `ROUTES.PROFILE` (`/profile`) already exists
- `IconSearch` is already imported in the NavigationBar component (used by the searchResults variant)
- The search and searchResults back-button variants remain unchanged
- **Assumption:** No filled variant of IconSearch is needed for the active state — the search page uses the "search" variant (back button), not the default nav

## Design References

- [Figma: Navigation Header — Handoff node 9:4053](https://www.figma.com/design/S84HaAL9hckSZcWm8k2Vk2/Handoff?node-id=9-4053&m=dev)

## Acceptance Criteria

1. The NavigationBar default variant renders exactly three icon buttons: Home, Search, Profile (in that order).
2. The Saved/Watchlist icon and its nav item are removed from the default variant.
3. Clicking the Search icon navigates to `/search`.
4. Clicking the Profile icon navigates to `/profile`.
5. The Search icon shows active state (`aria-current="page"`) when the pathname starts with `/search`.
6. The Profile icon shows active state when the pathname starts with `/profile`.
7. The Home icon shows active state when the pathname does NOT start with `/search` or `/profile`.
8. The `search` and `searchResults` back-button variants remain unchanged in behaviour and appearance.
9. A Storybook story exists for the NavigationBar default variant showing Home, Search, and Profile icons.
10. No unused icon imports (`IconSaved`, `IconSavedFilled`) remain in the NavigationBar module.
11. The nav bar width constant (`NAV_WIDTH_DEFAULT`) is adjusted if the rendered width changes (verify visually — three equally-sized icon buttons should remain ~168px).

## QA Notes

- Verify on mobile (393px), tablet (768px), and desktop (1440px) breakpoints
- Test navigation: tap Search → lands on `/search`; tap Profile → lands on `/profile`; tap Home → lands on `/`
- Verify active state toggles correctly when navigating between pages
- Confirm the back-button variants (search overlay, search results page) still function correctly
- Check that Watchlist is no longer accessible from the nav (it may still exist at `/saved` but should not be linked from the nav bar)

## Non-Functional Requirements

- **Accessibility:** Each nav button retains `aria-label` and `aria-current="page"` semantics. Keyboard navigation (Tab/Enter) between the three items must work. Focus ring visible on all buttons.
- **Reliability:** No layout shift when the nav bar mounts or when active state changes between items.
- **Observability:** No new analytics events required for this change (existing route-change tracking covers navigation).
- **Compatibility:** This is a breaking change to the default nav — Watchlist/Saved is no longer linked from the primary navigation. The `/saved` route still exists but is only reachable from Profile or direct URL.

## Out of Scope

- Removing or deprecating the `/saved` route itself
- Changes to the Location Pill (right side of the nav)
- Changes to the search or searchResults back-button variants
- Adding Watchlist access from the Profile page (separate ticket)
- Mobile bottom navigation (if planned separately)

## Suggested File Name

navigation-bar-search-icon-replacement.md
