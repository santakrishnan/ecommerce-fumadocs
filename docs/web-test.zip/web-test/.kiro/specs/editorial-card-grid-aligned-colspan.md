# Jira Story: Refactor editorial card sizing to aspect-ratio-only with consumer-controlled colSpan

## Summary

Remove fixed widths from the editorial card size classes so carousel items align to the PageGrid via the `colSpan` prop, with span values controlled by the landing page wrapper.

## User Story

As a developer composing the editorial cards carousel on the landing page, I want the editorial card to fill whatever grid column span I assign via `colSpan` while maintaining its design aspect ratio, so that cards align to the page grid without hardcoded pixel widths.

## Background

The editorial card (`shared/components/editorial-card/`) already defines aspect ratios but pairs them with fixed widths:
```ts
export const EDITORIAL_SIZE_CLASSES: Record<EditorialCardSize, string> = {
  large: "w-[360px] aspect-[360/480] md:w-[360px] md:aspect-[360/480] lg:w-[448px] lg:aspect-[448/601]",
  medium: "w-[268px] aspect-[268/357] md:w-[268px] md:aspect-[268/357] lg:w-[334px] lg:aspect-[334/445]",
  "large-fill": "w-[360px] aspect-[360/480] ... lg:h-[calc(...)] lg:w-auto lg:aspect-[448/601]",
};
```

The fixed `w-[Xpx]` classes override the grid-derived width from `colSpan`, defeating PageGrid alignment. The aspect ratios are already correct — only the width classes need removal. The card will then fill its container (the `CarouselItem` sized by `colSpan`) and derive height from the ratio.

The `EditorialCardsCarousel` currently renders `CarouselItem` without a `colSpan` prop — it needs to accept and forward the span.

## Problem Statement

- `EDITORIAL_SIZE_CLASSES` defines `w-[268px]` / `w-[360px]` / `w-[448px]` — these fight `colSpan` grid width
- `EditorialCardsCarousel` renders `CarouselItem` without `colSpan`
- The card ignores the carousel's grid-alignment because its own width class takes precedence
- Cards can't participate in PageGrid-aligned layouts

## Scope

### 1. Remove fixed widths from `EDITORIAL_SIZE_CLASSES`

```ts
// Before
medium: "w-[268px] aspect-[268/357] md:w-[268px] md:aspect-[268/357] lg:w-[334px] lg:aspect-[334/445]"
large:  "w-[360px] aspect-[360/480] md:w-[360px] md:aspect-[360/480] lg:w-[448px] lg:aspect-[448/601]"

// After
medium: "aspect-[268/357] lg:aspect-[334/445]"
large:  "aspect-[360/480] lg:aspect-[448/601]"
```

Keep `large-fill` as-is (it uses `lg:w-auto` + viewport-relative height for search surfaces — out of scope).

### 2. Consumer controls `colSpan` via `EditorialCardsCarousel`

Update `EditorialCardsCarousel` to accept and forward `colSpan`:

```tsx
export interface EditorialCardsCarouselProps {
  cards: EditorialCardData[];
  colSpan?: CarouselItemColSpan;
  size?: "medium" | "large";
}

// Inside render:
<CarouselItem key={card.href} colSpan={colSpan}>
  <LinkEditorialCard ... />
</CarouselItem>
```

The landing page `EditorialCardsSection` passes the appropriate span for its context.

### 3. Update `IMAGE_SIZES` hint

Current: `"(min-width: 1024px) 334px, 268px"` — hardcoded pixel estimates.

After: derive from grid column width or use breakpoint-based estimates matching the `colSpan` configuration.

### 4. Update tests

Editorial card tests currently assert fixed width classes — update to assert aspect-ratio-only classes.

## Dependencies / Constraints

- `CarouselItem` `colSpan` prop is already implemented
- The editorial card uses `LinkCard` (from `shared/components/card`) which renders a polymorphic card with `className` — the size classes go on the card root, so removing widths works directly
- `large-fill` variant is used in search surfaces — leave it unchanged (it already uses `lg:w-auto`)
- The `EditorialCardsCarousel` uses raw `@ucmp/ui` `Carousel`/`CarouselContent`/`CarouselItem` directly (not `CardCarousel`)
- Three card variants exist (`LinkEditorialCard`, `ButtonEditorialCard`, `StaticEditorialCard`) — all share `EDITORIAL_SIZE_CLASSES`
- ADR-0003 Phase 2 notes a staged convergence of editorial → shared `CARD_SIZE` tokens; this change moves closer to that goal

## Acceptance Criteria

1. `EDITORIAL_SIZE_CLASSES.medium` and `.large` contain **only** aspect-ratio classes — no `w-[...]` pixel values.
2. `EDITORIAL_SIZE_CLASSES["large-fill"]` remains unchanged (search surface, out of scope).
3. Editorial cards rendered inside a `CarouselItem colSpan={N}` fill the full column-span width and derive height from their aspect ratio.
4. The landing page editorial carousel (`EditorialCardsSection`) passes `colSpan` and cards align to PageGrid columns.
5. No visual regression on card proportions — aspect ratios are preserved (268:357, 334:445, 360:480, 448:601).
6. `IMAGE_SIZES` updated to reflect grid-based widths.
7. All three editorial card variants (`Link`, `Button`, `Static`) render correctly with the refactored sizes.
8. Existing tests updated — no assertions on fixed pixel widths.
9. `pnpm type-check`, `pnpm lint`, `pnpm test`, `pnpm build` all pass.

## QA Notes

- Compare the editorial cards carousel before/after — card proportions should be identical
- Resize viewport: cards should scale fluidly with grid columns
- Check with PageGrid overlay: card edges should align with column boundaries
- Verify the full-bleed background image fills correctly at all breakpoints (no clipping or empty space)
- Test `medium` and `large` size variants (landing uses `medium`, other surfaces may use `large`)

## Design References

- `apps/web/src/shared/components/editorial-card/editorial-card-content.tsx` — current `EDITORIAL_SIZE_CLASSES`
- `apps/web/src/features/landing/components/editorial-cards-carousel.tsx` — carousel adapter
- `apps/web/src/features/landing/components/editorial-cards-section.tsx` — section wrapper
- `packages/ui/src/components/__stories__/carousel/carousel-grid-aligned.stories.tsx` — colSpan demo
- Current ratios: 268:357 (mobile medium), 334:445 (desktop medium), 360:480 (mobile large), 448:601 (desktop large)

## Non-Functional Requirements

- **Accessibility:** No change — cards remain navigable links with aria-labels
- **Performance:** Updated `sizes` hint prevents oversized image downloads
- **CLS:** Aspect ratio reserves space before image loads — no layout shift

## Out of Scope

- `large-fill` variant (search surface — uses viewport-relative height)
- Converging editorial sizes onto shared `CARD_SIZE` tokens (ADR-0003 Phase 2)
- Inventory card sizing (separate ticket)
- Category card sizing (separate ticket)
- Changes to the carousel `colSpan` primitive itself

## Suggested File Name

editorial-card-grid-aligned-colspan.md
