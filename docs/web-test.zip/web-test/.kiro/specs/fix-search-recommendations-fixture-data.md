# Jira Story: Fix search recommendations fixture data — add VINs, proper routes, and relative image URLs

## Summary

Update the "Because You Viewed" recommendations fixture to use valid 17-character VINs, proper VDP route paths for `ctaLink`, and relative image URLs — aligning with the patterns established in other fixtures.

## User Story

As a developer testing the "Based on your search" carousel on the welcome-back page, I want the fixture vehicles to have realistic VINs and proper detail-page links, so that clicking a card navigates to a valid VDP route and the data is representative of production.

## Background

The `SearchRecommendationsSection` on `/welcome-back` renders an inventory card carousel sourced from `getBecauseYouViewed` → `because-you-viewed.fixture.ts`. The fixture data has several data quality issues that make it inconsistent with the rest of the app's fixtures (e.g. `vehicle-detail.fixtures.ts`, `new-today.fixtures.ts`).

## Problem Statement

| Field | Current value | Expected value |
|-------|--------------|----------------|
| `id` | `"veh-001"` (arbitrary) | A valid 17-char ISO 3779 VIN (e.g. `"2T1BURHE8JC039175"`) |
| `ctaLink` | `"http://localhost:3000/vehicles/veh-001"` | `/used-cars/details/toyota/camry/xse/2024/2T1BURHE8JC039175` (canonical VDP route) |
| `imageUrl` | `"http://localhost:3000/inventory-card/..."` | `/inventory-card/inventory-card2.png` (relative, served from public/) |
| `imageAlt` | Present ✓ | OK |
| `vin` field | Missing | Should be present so save/history features can partition by VIN |

Additionally, both `BECAUSE_YOU_VIEWED_UPSTREAM_FIXTURE` and `BECAUSE_YOU_VIEWED_SUCCESS_FIXTURE` contain duplicated data — they should reference a shared vehicle array.

## Scope

### 1. Add valid VINs

Replace `id: "veh-001"` with real-looking 17-char VINs that follow ISO 3779 patterns (same approach as `vehicle-detail.fixtures.ts`):
- Toyota VINs start with `2T1`, `3TM`, `4T1`, `JTM`, `JTE`, etc.
- Position 10 = model year (N=2022, P=2023, R=2024, S=2025)
- Remaining positions = serial (unique per fixture entry)

### 2. Fix `ctaLink` to canonical VDP route

Replace absolute `http://localhost:3000/vehicles/veh-001` with:
```
/used-cars/details/{make}/{model}/{trim}/{year}/{vin}
```
Using the `ROUTES.vdp()` pattern from `@config/routes/constants`.

### 3. Fix `imageUrl` to relative path

Remove `IMAGE_BASE_URL` prefix — use relative paths: `/inventory-card/inventory-card1.png`.

Same fix applied in the dealer-deal fixture (PEDX01-2433).

### 4. Add `vin` field to the fixture items

The `InventoryUpstreamItem` type and `BecauseYouViewedResponse` result items should include a `vin` field matching the `id`. If the schema doesn't include it, add it as optional.

### 5. Deduplicate fixture arrays

Both `BECAUSE_YOU_VIEWED_UPSTREAM_FIXTURE` and `BECAUSE_YOU_VIEWED_SUCCESS_FIXTURE` contain identical vehicle entries. Extract to a shared `VEHICLES` array and reference it in both.

## Acceptance Criteria

1. All fixture vehicles have valid 17-character VINs as their `id`.
2. `ctaLink` for each vehicle is a relative canonical VDP route: `/used-cars/details/{make}/{model}/{trim}/{year}/{vin}`.
3. `imageUrl` for each vehicle is a relative path (no `http://localhost` prefix).
4. `IMAGE_BASE_URL` is no longer used in this fixture file.
5. Clicking a card in the "Based on your search" carousel navigates to a valid VDP route (no 404).
6. The `next/image` component renders images without `remotePatterns` warnings.
7. `pnpm type-check`, `pnpm lint`, `pnpm test` all pass.
8. Existing tests that reference these fixtures still pass (update assertions if VIN values changed).

## QA Notes

- Navigate to `/welcome-back`
- Verify the "Based on your search for compact SUVs" carousel renders cards with images
- Click a card → should navigate to a valid VDP page (not a 404 or broken URL)
- Inspect Network tab: image requests should be relative paths optimised by `next/image`

## Design References

- `apps/web/src/features/recommendations/bff/__fixtures__/because-you-viewed.fixture.ts` — file to fix
- `apps/web/src/features/vehicle-detail/__fixtures__/vehicle-detail.fixtures.ts` — reference for VIN patterns
- `apps/web/src/config/routes/constants.ts` — `ROUTES.vdp()` for canonical VDP URLs

## Non-Functional Requirements

- **Accessibility:** Card links will have meaningful `aria-label`s from real vehicle data
- **Performance:** Relative image URLs avoid remote-patterns configuration and enable Next.js optimisation

## Out of Scope

- Changing the `BecauseYouViewedResponse` schema contract itself (only fixture values change)
- Adding real upstream integration for recommendations
- Changing the search recommendations section component logic

## Suggested File Name

fix-search-recommendations-fixture-data.md
