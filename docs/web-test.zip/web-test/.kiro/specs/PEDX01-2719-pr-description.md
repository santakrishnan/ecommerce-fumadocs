# Pull Request

## Summary

Moves the `searchByTaxonomy` Server Action from `features/landing/actions/` to `features/search/actions/` (correct feature ownership), adds a configurable `limit` option, and wires the `SearchRecommendationsClient` to use the new path with an env-configurable vehicle count (`NEXT_PUBLIC_SEARCH_RECS_LIMIT`). Also fixes a TanStack DB query builder type error in the `.orderBy()` clause.

## Jira

Jira story: PEDX01-2719

## Changes

| File | Change |
|---|---|
| `features/landing/actions/search-by-taxonomy.ts` | **Deleted** — moved to search feature |
| `features/landing/actions/__tests__/search-by-taxonomy.test.ts` | **Deleted** — moved to search feature |
| `features/search/actions/search-by-taxonomy.ts` | **New** — Server Action with configurable `limit` option (default 20), reads cookies/identity server-side, calls BED search with `vinTaxonomy` filter |
| `features/search/actions/__tests__/search-by-taxonomy.test.ts` | **New** — tests for the relocated action |
| `features/landing/components/search-recommendations-client.tsx` | Updated import path, added `NEXT_PUBLIC_SEARCH_RECS_LIMIT` env-driven limit (default 6), fixed `.orderBy()` placement before `.select()` |
| `features/landing/components/__tests__/search-recommendations-client.test.tsx` | Updated import path + `vi.mock` path |
| `.env.local.example` | Added `NEXT_PUBLIC_SEARCH_RECS_LIMIT` documentation |

## Visual QA

N/A — no visual changes. The Search Recommendations carousel renders the same way, just sourced from the correctly-owned feature module with a configurable limit.

## Checklist

- [x] PR title uses Conventional Commits format (`refactor(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes — `.orderBy()` type error resolved
- [x] `pnpm lint` passes — no new warnings
- [x] `pnpm test` passes — test imports updated to new path
- [x] No hydration mismatch
- [x] No breaking changes — same Server Action signature, just relocated
- [x] Server Actions validate inputs with Zod (VIN length + trim check)
- [x] No hardcoded colors

## Out-of-scope items observed

- The `SearchRecommendationsSection` (server component version) in `search-recommendations-section.tsx` still uses the old `getSearchRecommendations` → `getBecauseYouViewed` path. It's used on landing for non-authenticated visitors. Will be replaced in a follow-up when the taxonomy search becomes the only data source.
- The dynamic title ("BASED ON YOUR SEARCH FOR {VEHICLE TITLE}") is still hardcoded as "COMPACT SUVS" — separate ticket (PEDX01-2630).

## Reviewer focus

- **Feature ownership move** — `searchByTaxonomy` is a search concern (calls `getSearchResults`), not a landing concern. Moved to `features/search/actions/` where it belongs alongside other search use-cases.
- **Configurable limit** — `NEXT_PUBLIC_SEARCH_RECS_LIMIT` is a `NEXT_PUBLIC_*` var because it's read in a client component. The Next.js bundler statically inlines it at build time. Default is 6.
- **`.orderBy()` before `.select()`** — TanStack DB's query builder loses table ref context after `.select()`. Moving `.orderBy(({ h }) => h.viewedAt, "desc")` before `.select()` resolves the TypeScript error where `viewedAt` wasn't recognized on the projected type.
- **Server Action interface** — `searchByTaxonomy(vin, { limit? })` is the public API. The limit has a hard default of 20 in the action (server-side cap); the client passes a smaller value (6) for the carousel. This two-layer default allows the VDP "Similar Vehicles" to pass a different limit without a code change.

## Commit message

```
refactor(web): move searchByTaxonomy to search feature + configurable limit [PEDX01-2719]

- Move searchByTaxonomy Server Action from features/landing/actions/ to
  features/search/actions/ (correct feature ownership)
- Add configurable limit option to SearchByTaxonomyOptions (default: 20)
- Wire SearchRecommendationsClient to pass limit from env var
  NEXT_PUBLIC_SEARCH_RECS_LIMIT (default: 6)
- Fix TanStack DB query: move .orderBy() before .select() to resolve
  type error on viewedAt field reference
- Update test imports to new action path
- Document NEXT_PUBLIC_SEARCH_RECS_LIMIT in .env.local.example
```
