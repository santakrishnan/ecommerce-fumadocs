# Jira Story: VDP Image Gallery — Hotspot Overlays (Key Features & Condition)

## Summary

Implement interactive hotspot pin overlays on the VDP hero image for the "Key Features" and "Condition" tabs, showing positioned markers with tooltip labels on tap/click.

## User Story

As an anonymous or authenticated shopper, I want to see positioned hotspot pins on the vehicle hero image when I select the "Key Features" or "Condition" tab, so that I can identify where prominent packages are located and where condition issues (scratches, dents) exist on the vehicle.

## Background

The VDP image gallery (parent story) introduces an overlay tab bar on the hero image with three tabs: "360° view", "Key Features", and "Condition". The parent story renders placeholder containers for the "Key Features" and "Condition" panels. This story fills those placeholders with interactive hotspot pin overlays — positioned markers on the image that reveal a label tooltip when tapped. The hotspot data (coordinates and labels) is passed as props from the VDP Server Component alongside the image data.

## Problem Statement

The "Key Features" and "Condition" tabs currently render empty placeholder containers. Shoppers cannot see where key packages or condition issues are located on the vehicle, which reduces confidence in the purchase decision.

## Scope

- Render hotspot pin markers at specified (x%, y%) coordinates over the hero image
- Same pin icon for both "Key Features" and "Condition" tabs (only data differs)
- Tapping/clicking a pin shows a tooltip/popover with the hotspot label
- Only one tooltip is open at a time — clicking another pin closes the previous
- Clicking outside the tooltip closes it; clicking the same pin toggles it
- Hide the "Key Features" tab entirely if no key features hotspot data exists
- Hide the "Condition" tab entirely if no condition hotspot data exists
- Define the `Hotspot` type: `{ x: number; y: number; label: string }`
- Accept hotspot data as props: `keyFeaturesHotspots: Hotspot[]` and `conditionHotspots: Hotspot[]`
- Integrate into the existing overlay tab bar placeholder slots from the parent gallery story

## Dependencies / Constraints

- Depends on the VDP Image Gallery parent story being completed (overlay tab bar with placeholder slots)
- Hotspot data is passed as props from the VDP Server Component (no separate fetch)
- **Assumption:** `Hotspot` type is `{ x: number; y: number; label: string }` where `x` and `y` are percentages (0–100) relative to the image dimensions
- Pin positioning uses CSS `position: absolute` with `left` and `top` as percentages inside a `position: relative` image container
- The tooltip component should use Base UI's Tooltip or Popover primitive from `@ucmp/ui` (or build a minimal one if not available)
- This is a `"use client"` component (requires click state management) — it renders inside the existing client leaf from the parent story
- No analytics events in this story
- No feature flag — ships as part of the image gallery

## Design References

- [Figma Handoff — VDP Image Gallery](https://www.figma.com/design/S84HaAL9hckSZcWm8k2Vk2/Handoff?node-id=4331-97432&m=dev)

## Acceptance Criteria

1. When the "Key Features" tab is active, hotspot pins render at the (x%, y%) positions specified in `keyFeaturesHotspots` prop over the hero image.
2. When the "Condition" tab is active, hotspot pins render at the (x%, y%) positions specified in `conditionHotspots` prop over the hero image.
3. Hotspot pins use the same icon/marker style for both tabs — no visual differentiation between Key Features and Condition pins.
4. Tapping or clicking a hotspot pin opens a tooltip/popover displaying the `label` value for that hotspot.
5. Only one tooltip can be open at a time — activating a different pin closes the currently open tooltip and opens the new one.
6. Clicking outside an open tooltip (anywhere else on the image or page) closes it.
7. Clicking the same pin that has an open tooltip toggles it closed.
8. If `keyFeaturesHotspots` is empty or undefined, the "Key Features" tab is hidden entirely from the overlay tab bar.
9. If `conditionHotspots` is empty or undefined, the "Condition" tab is hidden entirely from the overlay tab bar.
10. If both `keyFeaturesHotspots` and `conditionHotspots` are empty/undefined, only the "360° view" tab remains in the overlay tab bar.
11. Hotspot pins are positioned using percentage-based CSS (`left: x%`, `top: y%`) inside a relatively-positioned container wrapping the hero image, ensuring they scale correctly across all viewport sizes.
12. Hotspot pins are keyboard accessible — focusable via Tab, activated via Enter/Space to open the tooltip.
13. The tooltip includes `role="tooltip"` and is associated with the pin via `aria-describedby` for screen reader support.
14. The tooltip is positioned to avoid clipping at image edges (flips direction if near a boundary).
15. Pins and tooltips render correctly on mobile (375px) and desktop (1280px+) without overflowing the image container.
16. The component accepts typed props: `keyFeaturesHotspots?: Hotspot[]` and `conditionHotspots?: Hotspot[]` where `Hotspot = { x: number; y: number; label: string }`.
17. Switching between tabs clears any open tooltip from the previous tab.

## QA Notes

- Test on Chrome mobile (375px), Safari iOS, and Chrome desktop (1280px+).
- Verify pin positions are accurate relative to the image at different viewport widths (pins should not drift).
- Test with 1 hotspot, 5 hotspots, and 10+ hotspots to verify no overlap issues.
- Verify only one tooltip is open at a time — rapid clicking between pins should never show two tooltips.
- Test click-outside dismissal on both mobile (tap) and desktop (click).
- Test keyboard navigation: Tab through pins, Enter to open tooltip, Escape or Tab away to close.
- Verify tab hiding: provide empty arrays and confirm tabs are absent from the overlay tab bar.
- Test edge-positioned hotspots (x: 0, y: 0 and x: 100, y: 100) — tooltip should flip to stay visible.
- Verify switching from "Key Features" to "Condition" tab closes any open tooltip from the previous tab.
- Test in both light and dark mode — pin and tooltip styling should remain visible and readable.

## Non-Functional Requirements

- **Accessibility:** Hotspot pins must be keyboard focusable with visible focus rings; tooltips must have `role="tooltip"` with `aria-describedby` association; the component must support Escape key to dismiss an open tooltip.
- **Reliability:** Handle empty/undefined hotspot arrays gracefully by hiding the corresponding tab; handle malformed coordinates (outside 0–100 range) by clamping to valid bounds.
- **Observability:** No analytics in this story — add in a follow-up if required.
- **Compatibility:** Integrates into the placeholder slots defined in the parent image gallery story; no breaking changes to existing gallery behaviour. Pin component should be reusable for future overlay use cases.

## Out of Scope

- Different pin icons or colours per tab
- Hotspot detail panels or modals (beyond the single-label tooltip)
- Drag-to-reposition pins (admin/editing functionality)
- Analytics event tracking for hotspot interactions
- Hotspot data editing or CMS integration
- Animations or transitions on pin appearance
- 360° view functionality (covered in parent story)
- Storybook stories (separate story)

## Suggested File Name

`vdp-image-gallery-hotspots.md`
