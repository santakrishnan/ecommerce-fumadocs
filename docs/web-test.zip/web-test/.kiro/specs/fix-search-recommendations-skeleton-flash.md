# Jira Bug: SearchRecommendationsClient skeleton flashes briefly then vanishes on welcome-back page

## Summary

The "Search recommendations loading" skeleton in `SearchRecommendationsConnected` renders on the welcome-back page during SSR, then immediately vanishes after hydration when the IDB collections are empty (no VINs in history or watchlist). This causes a visible flash/CLS for new or returning visitors who haven't viewed any vehicles yet.

## Bug Description

**Steps to reproduce:**
1. Clear browser data (or use incognito) — ensures empty IDB
2. Navigate to the welcome-back page (set ZIP to 91731)
3. Observe the "Search recommendations loading" skeleton appears in the SSR HTML
4. After hydration (~100ms), skeleton vanishes — content below jumps up

**Current behavior:**
- SSR renders the component's initial state: `isCollectionLoading = true` → shows `<SearchRecommendationsSkeleton />`
- Hydration runs → `useLiveQuery` reads IDB → `data: []` (empty) + `isLoading: false`
- Component evaluates `combinedVins.length === 0` → returns `null`
- Skeleton disappears → footer/content shifts up (CLS)

**Expected behavior:**
- No skeleton flash for visitors with empty IDB (no browsing history, no watchlist)
- The section should either not render at all during SSR, or gracefully avoid the layout shift

## Root Cause

`SearchRecommendationsConnected` wraps `SearchRecommendationsClient` in the page. The client component:

```tsx
// Initial render (SSR + first client render):
if (isCollectionLoading) {
  return <SearchRecommendationsSkeleton />;  // ← shows skeleton
}

// After IDB resolves (typically next frame):
if (combinedVins.length === 0) {
  return null;  // ← skeleton vanishes
}
```

The `isLoading` state from `useLiveQuery` starts as `true` (no server snapshot for IDB data), renders the skeleton in SSR, then immediately flips to `false` on the client after the first microtask when IDB reports empty collections.

## File to Fix

`apps/web/src/features/landing/components/search-recommendations-client.tsx`

## Recommended Fix

Skip the skeleton entirely when there's no chance of data. Since `useLiveQuery` with an empty IDB resolves in the same frame as hydration, the skeleton is never visible long enough to be useful. Replace the loading skeleton with `null` for the initial server render:

```diff
  // Still loading IDB collections
- if (isCollectionLoading) {
+ if (isCollectionLoading && typeof window !== "undefined") {
+   // Only show skeleton client-side after hydration — during SSR there's no
+   // IDB snapshot, so the skeleton would always flash then disappear.
    return <SearchRecommendationsSkeleton />;
  }
+ if (isCollectionLoading) {
+   return null; // SSR: render nothing (no IDB on server)
+ }
```

**Or simpler** — since `ssr: false` via `SearchRecommendationsConnected` (it uses `next/dynamic`), the component never runs during SSR anyway. The fix is just to not show the skeleton until we confirm IDB has items:

```diff
- if (isCollectionLoading) {
-   return <SearchRecommendationsSkeleton />;
- }
+ // Don't show skeleton during the initial IDB read — it resolves too fast
+ // and causes a CLS flash. Only show skeleton once we know VINs exist and
+ // we're waiting for the taxonomy API response.
+ if (isCollectionLoading || combinedVins.length === 0) {
+   return null;
+ }
```

Then show the skeleton only during the API fetch:
```tsx
if (isFetching) {
  return <SearchRecommendationsSkeleton />;
}
```

## Acceptance Criteria

1. No skeleton flash on the welcome-back page for visitors with empty browsing history / watchlist.
2. The skeleton DOES show when the visitor has VINs and the taxonomy API is being called (legitimate loading state).
3. No CLS — the section either renders with content or doesn't render at all.
4. No regression for visitors with history — they should still see the skeleton while the API responds.

## QA Notes

- New visitor (empty IDB): verify no skeleton flash on welcome-back page
- Returning visitor (has viewed vehicles): verify skeleton shows while API loads, then cards appear
- Use DevTools Performance panel → verify no CLS attributed to this section

## Suggested File Name

fix-search-recommendations-skeleton-flash.md
