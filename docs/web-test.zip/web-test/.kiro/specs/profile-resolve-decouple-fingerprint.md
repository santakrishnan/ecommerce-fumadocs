# Jira Story: Implement /profile/resolve — VPS session resolve with envelope response

## Summary

Implement `/profile/resolve` as a pure VPS session-resolve endpoint exposing the full envelope response with `firstSeenAt` / `lastSeenAt`, reading `fpHash` from cookie

## User Story

As the web platform, I want `/profile/resolve` to do exactly one thing — extend the VPS session and return identity with recency timestamps — so that the per-navigation keep-alive has no fingerprint coupling and supports returning-user experiences.

## Background

`/resolve` currently fans two upstreams: VPS `/resolve` (identity + session) and `getGeoFromFingerprint` (geo). Geo is moving to a separate story (Story 1). This story implements the clean version of `/resolve` — calling only the VPS, exposing the full upstream envelope (`data` + `meta`) with the new `firstSeenAt` and `lastSeenAt` fields, and reading `fpHash` from the server-side cookie. The VPS is shipping a contract change alongside this story to include those recency timestamps.

## Problem Statement

`/resolve` as it exists today couples identity/session to fingerprint geo, requires a client-passed `fpHash` query param, returns a flat response shape inconsistent with the VPS envelope, and omits recency timestamps (`firstSeenAt`, `lastSeenAt`) needed by returning-user experiences. The endpoint needs to be reimplemented as a focused VPS-only operation with the proper response schema.

## Scope

- Remove the `getGeoFromFingerprint` call and all geo/zip cookie writes from `resolve-profile.ts`
- Remove `requestId` from the route's accepted params and Zod schema
- Read `fpHash` from `_ucmp_fp_id` cookie (server-side) first, fall back to `?fpHash=` query param for backward compatibility
- Implement the upstream VPS call via `visitor-profile-service.ts` and expose the full response
- Update `resolvedVisitorSchema` to include `firstSeenAt: z.string().datetime().optional()` and `lastSeenAt: z.string().datetime().optional()` (new upstream contract fields)
- Implement BFF response as envelope: `{ data: { visitorId, sessionId, deviceId, isNew, customerId?, firstSeenAt?, lastSeenAt? }, meta: { traceId, timestamp } }`
- Update `ProfileResolveResponse` type to match the new envelope shape
- Update `resolve-profile-client.ts` to consume the new envelope format and expose `firstSeenAt` / `lastSeenAt` to client consumers
- Set/refresh identity cookies (`_ucmp_visitor_id`, `_ucmp_session_id`, `_ucmp_profile_id`) and `_ucmp_last_visit_at`
- Remove `FingerprintGeolocation` type and `fingerprint-geo` service import from `resolve-profile.ts`
- Keep the route path `GET /api/v1/profile/resolve`
- Keep/refresh the env-flag mock (`USE_PROFILE_MOCKS`)
- Update mock to return `firstSeenAt` and `lastSeenAt`

## Dependencies / Constraints

- New upstream VPS contract ships alongside this story — adds `firstSeenAt` and `lastSeenAt` to the `/resolve` response `data` envelope
- Reuses `visitor-profile-service.ts` and identity-cookie writes from `resolve-profile.ts`
- **Must not** call the Fingerprint Server API (`getGeoFromFingerprint`)
- **Must not** write geo or zip cookies (moved to Story 1)
- Identity cookies remain `httpOnly`
- `fpHash` read from `_ucmp_fp_id` cookie first, query param fallback ensures backward compatibility during client-side migration
- Independent of Story 1 (geo decoupling)

## Design References

- `apps/web/src/features/profile/bff/use-cases/resolve-profile.ts`
- `apps/web/src/features/profile/bff/services/visitor-profile-service.ts`
- `apps/web/src/features/profile/bff/contracts/resolve-response.schema.ts`
- `apps/web/src/features/profile/bff/contracts/resolve-request.schema.ts`
- `apps/web/src/features/profile/services/resolve-profile-client.ts`
- `apps/web/src/app/api/v1/profile/resolve/route.ts`

## Acceptance Criteria

1. `/profile/resolve` makes **no** Fingerprint Server API call and writes **no** geo or zip cookies.
2. `requestId` is removed from the Zod request schema and route handler; passing it as a query param is a harmless no-op.
3. `fpHash` is read from the `_ucmp_fp_id` cookie server-side; falls back to `?fpHash=` query param if cookie is absent.
4. The endpoint returns 400 if neither cookie nor query param provides `fpHash`.
5. The BFF response uses the envelope format: `{ data: { visitorId, sessionId, deviceId, isNew, customerId?, firstSeenAt?, lastSeenAt? }, meta: { traceId, timestamp } }`.
6. `resolvedVisitorSchema` includes `firstSeenAt` and `lastSeenAt` as optional ISO datetime strings.
7. `ProfileResolveResponse` type matches the new envelope shape.
8. `resolve-profile-client.ts` is updated to unwrap the new envelope and expose `firstSeenAt` / `lastSeenAt` to client consumers.
9. Identity cookies (`_ucmp_visitor_id`, `_ucmp_session_id`, `_ucmp_profile_id`) and `_ucmp_last_visit_at` are set/refreshed on each call.
10. Repeated calls (per-navigation cadence) are idempotent — no identity rotation unless the session expired.
11. The mock (`USE_PROFILE_MOCKS=true`) returns valid `firstSeenAt` and `lastSeenAt` values.
12. `FingerprintGeolocation` type, `fingerprint-geo` service import, and geo cookie logic are removed from `resolve-profile.ts`.
13. Route/contract tests cover: happy path (cookie), happy path (query param fallback), missing fpHash (400), service-unavailable (503).

## QA Notes

- Test with `_ucmp_fp_id` cookie set (primary path) — verify response envelope and no geo calls
- Test with no cookie but `?fpHash=` query param — verify fallback works
- Test with neither — verify 400 response
- Verify `_ucmp_last_visit_at` cookie is refreshed on repeated calls
- Verify no geo/zip cookies are written (inspect Set-Cookie headers)
- Test with `USE_PROFILE_MOCKS=true` — verify mock returns `firstSeenAt` and `lastSeenAt`
- Verify client-side caller (`resolve-profile-client.ts`) correctly unwraps the envelope

## Non-Functional Requirements

- **Accessibility:** N/A (backend-only change)
- **Reliability:** Service-unavailable returns 503 with `PROFILE_SERVICE_UNAVAILABLE` code. Missing fpHash returns 400 with clear message.
- **Observability:** Existing structured logging (`profile-resolve` logger) retained; log the fpHash source (cookie vs query param) at info level.
- **Compatibility:** Breaking change to the BFF response shape (flat → envelope). The internal client (`resolve-profile-client.ts`) is updated in the same PR. No external consumers of this API.

## Out of Scope

- Geo resolution (moved to Story 1)
- Fingerprint Server API integration
- `/profile/activities` analytics endpoint
- Session touch as a separate endpoint (VPS `/resolve` is the touch)
- `_ucmp_fp_id` cookie creation (owned by the fingerprint SDK integration)

## Suggested File Name

profile-resolve-decouple-fingerprint.md
