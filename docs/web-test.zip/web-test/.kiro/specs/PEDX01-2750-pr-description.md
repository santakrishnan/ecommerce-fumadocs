# Pull Request

## Summary

Implements the visitor activities BFF proxy — replaces the legacy in-memory activity recorder with a real BED upstream integration. The route handler (`POST /api/v1/profile/activities`) now validates events via a Zod schema, forwards them to the visitors service, and returns a `202 Accepted` envelope. Introduces the `features/profile/activities/bff` module following the same screaming architecture pattern as watchlist and searches.

## Jira

Jira story: PEDX01-2750

## Changes

### New files (`features/profile/activities/bff/`)

| File | Purpose |
|---|---|
| `contracts/activity-event.schema.ts` | Zod schema for activity event validation (type discriminator + event-specific fields) |
| `errors/activities.errors.ts` | Error factory + typed error response helper |
| `services/activities-client.ts` | Creates a BED client for the visitors/activities upstream |
| `services/activities-upstream.ts` | Calls `POST /activities` on the visitors service, returns result union |
| `use-cases/activities.ts` | Use case: mock vs upstream routing (same pattern as watchlist/searches) |
| `bff/index.ts` | Public barrel for the BFF layer |
| `index.ts` | Feature barrel |

### Modified files

| File | Change |
|---|---|
| `app/api/v1/profile/activities/route.ts` | Rewritten: validates with Zod schema, calls `recordActivity` use case, returns `202` envelope with `{ data, meta: { traceId, timestamp } }`. Error responses use `activitiesErrorResponse`. |
| `app/api/v1/__tests__/profile-activities.test.ts` | Updated to mock the new BFF module, test 202 accepted, 400 validation, 503 upstream failure. Legacy feature-service tests preserved. |
| `config/bed-services.ts` | Added `ACTIVITIES_ENDPOINTS.base` — versioned path for visitors activities |
| `config/routes/constants.ts` | Added `API_ROUTES.ACTIVITIES` client route constant |

## Visual QA

N/A — backend-only change. No UI affected.

## Checklist

- [x] PR title uses Conventional Commits format (`feat(web):`)
- [x] Branch name follows `<type>/[ISSUE-KEY]-[issue-description]`
- [x] `pnpm type-check` passes
- [x] `pnpm lint` passes
- [x] `pnpm test` passes — route test suite updated for new contract
- [x] No hydration mismatch (server-only module)
- [x] Server Actions / route handlers validate inputs with Zod (`activityEventSchema`)
- [x] No hardcoded colors
- [x] `import "server-only"` on all BFF modules

## Out-of-scope items observed

- The legacy `getProfileActivityResponse` in `features/landing/bff/services/` is now dead code — can be removed in a follow-up cleanup PR
- `profileActivityErrorResponse` in `features/landing/bff/errors/` is also dead code after this change
- Client-side activity capture (`useRecordActivity` hook or equivalent) is not wired in this PR — separate ticket for instrumentation
- Activity event types beyond the discriminator are validated at TypeScript level only (SDK union) — runtime field validation per event type is deferred

## Reviewer focus

- **Route handler returns `202`** — Activities are processed async (EventBridge → SQS). `202 Accepted` is semantically correct vs the old `200 OK`.
- **Error response shape** — Uses `{ error: { code, message } }` matching the BED envelope pattern, returned via `activitiesErrorResponse()`.
- **Mock routing** — `USE_ACTIVITIES_MOCKS` env flag (or absence of upstream config) → mock path. Same pattern as `USE_GEO_MOCKS`, `USE_SEARCH_RESULTS_MOCKS`.
- **`ACTIVITIES_ENDPOINTS.base`** — Uses versioned path from `endpointPath("activities", "VISITORS_ACTIVITIES_VERSION", "VISITORS_API_VERSION")`. Confirm the version env vars are documented in `.env.local.example`.
- **Test mocking** — The test mocks `~/features/profile/activities/bff` at module level including a simplified `activityEventSchema.safeParse` inline implementation. Verify this is sufficient for the route-handler contract tests.

## Commit message

```
feat(web): implement visitor activities BFF proxy with BED upstream [PEDX01-2750]

- Add features/profile/activities/bff module (schema, errors, client,
  upstream service, use case) following watchlist/searches pattern
- Rewrite POST /api/v1/profile/activities route handler:
  - Validate event via activityEventSchema (Zod)
  - Forward to visitors service via recordActivity use case
  - Return 202 Accepted with { data, meta: { traceId, timestamp } }
  - Error responses: 400 (validation), 503 (upstream), 500 (catch-all)
- Add ACTIVITIES_ENDPOINTS.base to bed-services config
- Add API_ROUTES.ACTIVITIES to client route constants
- Update route test suite for new contract (202, validation, upstream error)
- Remove dependency on legacy getProfileActivityResponse
```
