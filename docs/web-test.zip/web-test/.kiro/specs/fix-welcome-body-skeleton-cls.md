# Jira Bug: Welcome-body skeletons cause layout shift (CLS) when sections resolve to null

## Summary

On the welcome-back page, skeleton placeholders show briefly then vanish with a visible layout jump. This happens because sections above (like `PersonalizedSearchSection`) resolve to `null` — the Suspense boundary removes the skeleton, and all sections below shift up. The user sees a flash of skeletons followed by content jumping.

## Bug Description

**Steps to reproduce:**
1. Set ZIP to 91731 (or any ZIP that triggers the welcome-back page)
2. Observe the page load — skeletons flash briefly then disappear with a visible vertical shift

**Current behavior:**
- `PersonalizedSearchSkeleton` shows → `PersonalizedSearchSection` resolves to `null` (no search sessions) → skeleton disappears → everything below jumps up
- `ContinueShoppingSkeleton` shows → `ContinueShoppingSection` resolves to `null` (no history + New Today empty) → skeleton disappears → everything below jumps up
- Multiple skeletons disappear in sequence causing cascading layout shifts

**Expected behavior:**
- No visible layout shift during loading
- Skeletons should only show for sections that will actually render content, OR
- The empty state should reserve no space (skeleton should not render for sections that will be empty)

## Root Cause

The Suspense boundaries unconditionally render skeletons (which reserve vertical space), but the async Server Components often resolve to `null` (section hidden). The skeleton → null transition creates CLS because:

1. Skeleton renders at full height (e.g., `aspect-[360/480]` × 3 cards = ~480px)
2. Section resolves to `null` → 0px
3. All content below shifts up by 480px

This is a fundamental tension in the architecture: **skeletons assume data will be present, but sections hide themselves when data is absent**.

## Possible Fixes

### Option A: Wrap each section in a min-height container that collapses gracefully

```tsx
<div className="contents [&:empty]:hidden">
  <Suspense fallback={<PersonalizedSearchSkeleton className={CAROUSEL_BLEED} />}>
    <PersonalizedSearchSection className={CAROUSEL_BLEED} />
  </Suspense>
</div>
```

Won't work — `contents` doesn't help with Suspense.

### Option B: Use `fallback={null}` for sections likely to be empty

If the section data depends on user state that's known client-side (e.g., empty IDB = no history), skip the skeleton entirely:

```tsx
{/* Only show skeleton when we expect data */}
<Suspense fallback={hasVisitorIdentity ? <PersonalizedSearchSkeleton /> : null}>
  <PersonalizedSearchSection className={CAROUSEL_BLEED} />
</Suspense>
```

### Option C: Move empty checks before the Suspense boundary (recommended)

Read the "will this section have data?" signal (cookie presence, visitor identity) in the sync page shell and conditionally render the Suspense boundary:

```tsx
// welcome-body.tsx (sync)
{hasSearchSessions && (
  <Suspense fallback={<PersonalizedSearchSkeleton className={CAROUSEL_BLEED} />}>
    <PersonalizedSearchSection className={CAROUSEL_BLEED} />
  </Suspense>
)}
```

This way, sections that will definitely be empty never show a skeleton at all.

### Option D: Accept the CLS but minimize it

Use `[&:empty]:hidden` on the Suspense wrapper's parent so the DOM collapses instantly. The AGENTS.md already notes: `overflow-x-clip [&:empty]:hidden` on carousel bleed divs. Verify this is applied.

## Files Involved

| File | Role |
|---|---|
| `landing/components/home-experience/welcome-body.tsx` | Orchestrates Suspense boundaries + skeletons |
| `landing/components/personalized-search-skeleton.tsx` | Skeleton that flashes then disappears |
| `landing/components/continue-shopping/continue-shopping-skeleton.tsx` | Skeleton that shifts up |
| `landing/components/personalized-search-section.tsx` | Returns `null` when no sessions |
| `landing/components/continue-shopping/continue-shopping-section.tsx` | Returns `null` when no data |

## Acceptance Criteria

1. No visible layout shift (CLS) when sections resolve to empty/null on the welcome-back page.
2. Skeletons only appear for sections that will render actual content.
3. Sections that have no data produce no DOM artifacts (no empty wrappers, no height reservation).
4. The page still streams correctly under PPR — sections that DO have data show skeletons while loading.

## QA Notes

- Throttle network to Slow 3G → observe skeleton behavior on welcome-back page
- Verify no vertical content jumps during load
- Run Lighthouse → check CLS score
- Test with visitor who has search sessions vs new visitor with no sessions

## Suggested File Name

fix-welcome-body-skeleton-cls.md
