# Jira Bug: EditorialCardsSection carousel missing hover scale effect on landing page

## Summary

The `EditorialCardsCarousel` on the landing page ("Curated collections" section) uses a raw `<Carousel>` without hover scale, so editorial cards don't lift/scale on hover. It should use the shared `CardCarousel` with `hoverScaleRatio={CARD_HOVER_SCALE.md}` (1.02) matching its `size="medium"` cards.

## Bug Description

**Current:** Hovering over an editorial card in the "Curated collections" section produces no scale/lift animation.

**Expected:** Cards should scale up (1.02×) with a shadow lift on hover, consistent with the category carousel and personalized search carousel on the same page.

## Root Cause

`EditorialCardsCarousel` renders cards using raw `<Carousel>` / `<CarouselContent>` / `<CarouselItem>` primitives — no hover behaviour.

The `PersonalizedSearchCarousel` was recently migrated to `CardCarousel` with hover scale (1.015× for `size="large"`). The `EditorialCardsCarousel` was not updated.

## File to Fix

`apps/web/src/features/landing/components/editorial-cards-carousel.tsx`

## Recommended Fix

Replace raw `<Carousel>` with the shared `CardCarousel`:

```diff
- import { Carousel, CarouselContent, CarouselItem } from "@ucmp/ui";
+ import { CARD_HOVER_SCALE, CardCarousel } from "@shared/components/card";
+ import { EDITORIAL_SIZE_TOKEN } from "@shared/components/editorial-card";

  export function EditorialCardsCarousel({ cards, colSpan, size = "medium" }) {
    return (
-     <Carousel>
-       <CarouselContent>
-         {cards.map(({ iconName, ...card }) => (
-           <CarouselItem colSpan={colSpan} key={card.href}>
-             <LinkEditorialCard ... />
-           </CarouselItem>
-         ))}
-       </CarouselContent>
-     </Carousel>
+     <CardCarousel
+       colSpan={colSpan}
+       getItemKey={(_, i) => cards[i]?.href ?? String(i)}
+       hoverScaleRatio={CARD_HOVER_SCALE[EDITORIAL_SIZE_TOKEN[size]]}
+       items={cards}
+       renderItem={({ iconName, ...card }) => (
+         <LinkEditorialCard
+           {...card}
+           icon={iconName ? ICON_MAP[iconName] : undefined}
+           size={size}
+         />
+       )}
+     />
    );
  }
```

## Scale Values

| Size | Token | Scale ratio |
|---|---|---|
| `medium` (editorial cards section) | `md` | **1.02** |
| `large` (personalized search) | `lg` | 1.015 |

## Acceptance Criteria

1. Editorial cards in the "Curated collections" section scale up (1.02×) with shadow on hover.
2. Keyboard focus produces the same visual lift.
3. `prefers-reduced-motion` disables the animation.
4. No overflow clipping issues during scale.
5. Matches the visual behaviour of the category carousel on the same page.

## QA Notes

- Hover over editorial cards in "Curated collections" → verify scale + shadow lift
- Tab through cards → verify focus produces same lift
- Compare with "Browse by style" category cards — should feel consistent (both use `md` scale)

## Suggested File Name

fix-editorial-cards-carousel-hover-scale.md
