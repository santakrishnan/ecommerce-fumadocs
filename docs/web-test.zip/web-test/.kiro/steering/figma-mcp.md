---
inclusion: auto
description: Rules for using the Figma Desktop MCP server — connect directly to http://127.0.0.1:3845/mcp, no discovery steps. Covers connection setup, best practices for node-level fetches, and token mapping to @ucmp/ui-theme.
---

⚠️ Figma MCP is not available for this organization. 

<!-- # Figma MCP — Usage Guide

## Connection Rules

When working with Figma designs, assets, or any Figma-related task:

1. **Do NOT** check Kiro Powers for Figma capabilities.
2. **Do NOT** run MCP discovery or list available MCP tools first.
3. **Go directly** to the `Figma Desktop` MCP server configured at `http://127.0.0.1:3845/mcp`.
4. Start a session and call the tools directly — no intermediate steps.

## Prerequisites (Developer Setup)

Before using Figma MCP, ensure:

- Figma Desktop app is running (not the browser version).
- Dev Mode is enabled in the Figma file you're working with.
- MCP Server is active: Figma → Settings → Dev Mode → "MCP Server" toggle is ON.
- The file/page you need is open in Figma Desktop.

## Test Connection

When a developer first asks to use Figma in a session, verify the connection works by calling the `get_file` tool (or equivalent list/read tool) on the Figma MCP server. If it fails:

1. Confirm Figma Desktop is running.
2. Confirm Dev Mode MCP is enabled in Figma settings.
3. Check that port 3845 is not blocked or in use by another process.
4. Ask the developer to restart Figma Desktop if the above checks pass.

Do NOT retry more than once — if the connection fails after one retry, stop and report the issue to the developer.

## Best Practices

- **Always provide a Figma URL or node ID** when asking the agent to inspect a design. The agent cannot browse Figma files without a reference.
- **Prefer node-level fetches** over full-file fetches. Full files can be large and slow. Use specific frame/component node IDs when possible.
- **Extract only what you need** — colors, spacing, typography, layout structure. Don't dump entire design trees into context.
- **Map Figma tokens to existing theme tokens** from `@ucmp/ui-theme` rather than creating new arbitrary values. See `docs/FIGMA-TOKEN-MAPPING.md`.
- **Use auto-layout properties** from Figma to infer flex/grid direction, gap, and padding rather than guessing from visual output.
- **Respect component boundaries** — if Figma shows a reusable component, check if it already exists in `@ucmp/ui` before building a new one.

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| Connection refused on 127.0.0.1:3845 | Figma Desktop not running or MCP not enabled |
| Tools return empty/null | The target file isn't open in Figma or Dev Mode is off for that file |
| Timeout errors | Large file — narrow the request to a specific node ID |
| Stale data | Switch to the correct page/frame in Figma, then retry | -->
