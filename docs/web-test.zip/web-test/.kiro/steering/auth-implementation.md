---
inclusion: [fileMatch, auto]
fileMatchPattern: "**/features/auth/**,**/app/api/**/auth/**,**/*auth*,**/*signin*,**/*otp*,**/*passkey*"
description: "Auth feature — AuthFlow, useAuth overlay, nudges, signin, login, step-up, OTP, passkey, auth, tier, edi, edi-session-id cookie, auth token"
---
# Authentication

Feature reference: #[[file:apps/web/src/features/auth/README.md]]

The cross-service design — tiers, flows, the EDI / enterprise-auth-gateway integration, and the
`/auth/*` contract — is owned by `ecommerce-arch/13-authentication/`. Steering cannot
`#[[file:]]` across repositories, so open it by path, starting with
`authentication-architecture.md` (glossary, tiers, prompting model). Flow state machines are in
`07-flows/auth-flows.md`, the cookie and refresh model in `07-flows/auth-edi-integration.md`, and
the field-level contract in `03-api-gw/auth-api.yml`. If the folder is not in the workspace, read
the same files from `ecommerce-arch` on `main`.

## Do / Don't

| Do | Don't |
| --- | --- |
| Send visitor identity as `X-Visitor-Id` / `X-Session-Id` headers | Conflate visitor identity with the auth session |
| Treat `edi-session-id` as an opaque `HttpOnly` pointer to the server-side session-token record | Read, mint, store, or replay the cookie in UI, BFF, or VPS code |
| Call the BFF from the UI; let the BFF forward `Cookie` and relay `Set-Cookie` unchanged | Call EDI from the UI, or add auth logic to the BFF |
| Let a stale enterprise-gated call surface as a 401 that triggers re-auth | Add proactive EDI validation to ecom-only actions |
| Use `useAuth().showAuthOverlay({ tier, onCompleted })` for on-demand auth | Build a separate sign-in modal or gate |
| Pass `nudgeScenario` for optional step-up so the overlay opens only when warranted | Open a nudge unconditionally or re-show one the visitor dismissed |
| Wrap routes that render `AuthFlow` in `VisitorIdentityHydrator` inside `<Suspense>` | Resolve the tier on the client and accept a flash of the wrong step |
| Pass slot overrides from Server Components via the `slots` prop | Pass JSX slot children across the RSC boundary |
| Use internal terms (verify, sign-in nudge, auth gate, step-up) and UI copy "Sign in" / "Become a member" | Write "sign up", "register", or "log in" in UI copy |
| Add web-side implementation detail to the feature README | Restate flows, tiers, or the contract from `ecommerce-arch` |
