---
inclusion: fileMatch
fileMatchPattern: "**/features/origination/components/**,**/features/origination/lib/state/**,**/features/origination/data/state/**"
description: "Origination state machine — defineState, buildMachine, blocks/fromContext, go() semantics"
---

# Origination state machine

Full reference: #[[file:docs/origination-state-machine.md]]

This flow is driven by a compiled XState machine, not hand-written XState config. Read the full
doc above before adding or modifying a state, a registered component, or the machine itself —
it covers the `loading` → `active` → `submitting` sub-state shape every non-final state compiles
to, `dataSchema` vs `formSchema`, and `go()`'s replace-not-merge semantics.

## Do / Don't

| Do | Don't |
| --- | --- |
| Author states with `defineState()` in `data/state/*.tsx` | Write XState config by hand for a flow state |
| Add a new state to the list in `data/state/index.ts` | Assume a state is live just because the file exists |
| Spread `ctx.data` explicitly in `onSubmit` when carrying data forward (`go(target, { ...ctx.data, ... })`) | Assume `go()` merges into the existing `context.data` — it replaces it wholesale |
| Resolve `onEnter` via `loadComplete(data)` | Return raw data from `onEnter` without the `loadComplete` wrapper |
| Use `submit: false` + a static `target` for actions that must skip form validation (skip/back links) | Use `submit: false` for an action that should validate the form first |
| Register a new block component in `component-registry.ts`'s `componentRegistry` | Reference a `componentId` that isn't registered — it won't compile |
| Use the `fromContext` helper handed to the `blocks` callback to reference `ctx.data` | Reach for a different context accessor or hardcode a value that should come from context |
| Declare `transitions` as a literal array so `go()`/`onSubmit`'s `target` narrow to a union | Type `transitions` as `string[]` |
