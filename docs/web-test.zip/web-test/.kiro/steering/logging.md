---
inclusion: fileMatch
fileMatchPattern: "**/logger/**,**/log/**,**/services/**,**/actions/**"
description: "Logging conventions — createLogger, structured data, levels, avoiding PII"
---

# Logging conventions

Full reference: #[[file:docs/LOGGING.md]]

## Do / Don't

| Do | Don't |
| --- | --- |
| Use `createLogger("feature:submodule")` from `@shared/lib/logger` for all server-side logging | Use raw `console.log` / `console.warn` / `console.error` |
| Use colon-separated, feature-first scope names (`"search:api"`, `"media:proxy"`) | Use free-form or inconsistent scope strings |
| Pass structured data objects (`log.error("failed", { url, status })`) | Interpolate values into the message string |
| Use `debug` for detailed diagnostics (cache hits, timing, query params) | Use `info` for high-volume diagnostic data — it pollutes production logs |
| Use `fatal` only for process-terminating / on-call-worthy events | Use `fatal` for caught errors that return a 500 but leave the server running |
| Log at external boundary crossings (API calls, DB, cache, CDN) | Log inside tight loops — summarize after instead |
| Manually omit, hash, or truncate PII and secrets before logging | Pass `email`, `password`, `token`, or other sensitive fields into log data |
| Import `createLogger` only in server-side code | Import `createLogger` in client code — it's server-only |
| Control verbosity via `LOG_LEVEL` env var for incident debugging | Redeploy with `debug` calls added just to diagnose a production issue |
| Keep log data flat (no nested objects) with `camelCase` field names | Nest objects in log data — aggregators handle flat JSON best |
| Check [`docs/LOGGING.md`](../../docs/LOGGING.md#client-side-error-reporting) for the target design before adding client-side error reporting | Assume `reportClientError` or a similar action exists — verify in the codebase before importing it |
