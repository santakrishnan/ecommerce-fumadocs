---
inclusion: fileMatch
fileMatchPattern: "**/{env,env-schema,client-env,.env}*"
---

# Environment Variables — Best Practices

Reference: #[[apps/web/src/config/env-schema.ts]]

## Architecture overview

| Layer | File | Import from | Surface |
|-------|------|-------------|---------|
| Schema | `src/config/env-schema.ts` | — | Shared by build & runtime |
| Server runtime | `src/config/env.ts` | `@config/env` → `env` | Server Components, Actions, Route Handlers, BFF |
| Client runtime | `src/config/client-env.ts` | `@config/client-env` → `clientEnv` | Client & Server Components |

The server module exports a **Proxy** that re-parses `process.env` on every access. This means `vi.stubEnv()` in tests is reflected immediately without `vi.resetModules()` — but only when the stubbed value passes the field's Zod schema.

## Adding a new variable

1. **Define the schema field** in `src/config/env-schema.ts`:
   - Server-only → add to `serverEnvSchema`
   - Client (`NEXT_PUBLIC_*`) → add to `clientEnvSchema`
2. **Pick the right Zod helper** (already declared at the top of the file):
   - `optStr` — optional non-empty string
   - `trimOptStr` — same but trims whitespace (use for headers/tokens)
   - `boolStr` — `"true" | "false"` optional enum
   - `optUrl` — valid URL, or `""` → `undefined`
   - `z.coerce.number().positive().optional()` — numeric with coercion
3. **Add the static property access** in `src/config/client-env.ts` if it's a `NEXT_PUBLIC_*` var. The Next.js bundler requires `process.env.NEXT_PUBLIC_FOO` to appear as a literal string — dynamic lookups won't inline.
4. **Document it** in `.env.local.example` with a comment explaining purpose, accepted values, and default (if any).
5. **Guard server secrets** — add `import "server-only"` at the top of any module that reads the new var from `env`.

## Updating an existing variable

- Change the Zod schema field **first** — the build will surface any type mismatches across consumers.
- If you change a variable's type (e.g., string → enum, string → URL), update:
  - The `.env.local.example` comment
  - Any `vi.stubEnv()` calls in tests that supply the old format

## Usage rules

| Do | Don't |
|----|-------|
| `import { env } from "@config/env"` | `process.env.MY_VAR` directly in server code |
| `import { clientEnv } from "@config/client-env"` | `process.env.NEXT_PUBLIC_X` directly in components |
| Use `optUrl` for URL vars (accepts `""` as "not configured") | Use `optStr` for URLs — empty string won't be coerced to `undefined` |
| Put secrets in server-only vars | Put secrets in `NEXT_PUBLIC_*` — they're bundled into the client |
| Add `import "server-only"` to files reading secrets | Assume server-only by convention |

## Mock toggle convention

Each BFF feature has a `USE_<FEATURE>_MOCKS` toggle (type: `boolStr`).

Resolution order in use cases:
1. `API_UPSTREAM_URL` set + service key present → **real upstream**
2. `USE_<FEATURE>_MOCKS === "true"` → **mock/fixture data**
3. Neither → **503 ServiceUnavailable**

The upstream path always takes precedence over mocks.

## Testing with env vars

### Always use `vi.stubEnv()` — never assign to `env` directly

```ts
// ✅ Correct — modifies process.env, proxy picks it up
vi.stubEnv("API_UPSTREAM_URL", "https://api.example.com");

// ❌ Wrong — writes to the old proxy target; fresh imports won't see it
env.API_UPSTREAM_URL = "https://api.example.com";
```

### Explicitly stub variables whose absence you depend on

Tests that exercise the "no upstream" or "mocks disabled" paths must explicitly
set the relevant vars to their disabled state. Otherwise they become
environment-dependent and break when a developer or CI has the var set.

```ts
// ✅ Environment-proof — won't accidentally hit upstream
vi.stubEnv("API_UPSTREAM_URL", "");
vi.stubEnv("USE_GEO_MOCKS", "false");

// ❌ Implicitly assumes the var is unset — flaky on different machines
// (no stubEnv call)
```

### Respect the schema when stubbing

- `boolStr` fields accept only `"true"` or `"false"` — not `""`.
- `optUrl` fields accept `""` as "not configured" (preprocessed to `undefined`).
- Numeric fields need string values that coerce cleanly: `"5000"`, not `""`.

If a stubbed value fails the field's Zod schema, the proxy falls back to the
initial parsed value (from startup), which may produce confusing results.

### Use `vi.resetModules()` + dynamic `import()` when testing use cases

The `env.ts` module caches its initial parse on first import. With
`vi.resetModules()` in `beforeEach` and `await import(...)` per test, each test
gets a fresh module that re-evaluates against the currently stubbed `process.env`.

```ts
beforeEach(() => {
  vi.resetModules();
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
});

it("returns 503 when upstream is not configured", async () => {
  vi.stubEnv("API_UPSTREAM_URL", "");
  vi.stubEnv("USE_SEARCH_MOCKS", "false");
  const { getSearchSuggestions } = await import("../use-cases/get-search-suggestions");

  const result = await getSearchSuggestions();
  expect(result.success).toBe(false);
});
```

## FEATURE_FLAG_* exception

Feature flag vars are assembled dynamically by the Vercel `flags` SDK and cannot
be enumerated statically. They are intentionally excluded from the schema. Do not
add `FEATURE_FLAG_*` entries to `env-schema.ts`.
