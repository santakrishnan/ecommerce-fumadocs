# UCMP — Project Context for KIRO

Reusable Next.js 16 monorepo scaffolding.

## Quick start

```bash
nvm use                           # Node 22.22.2
pnpm install
cp apps/web/.env.local.example apps/web/.env.local
pnpm dev                          # http://localhost:3000
```

## Monorepo structure

```
apps/web/                     # Next.js 16 app
packages/ui/                  # @ucmp/ui — Base UI primitives, shadcn-style
packages/ui-theme/            # @ucmp/ui-theme — Tailwind v4 multi-brand tokens
packages/shared/              # @ucmp/shared — providers, hooks, utils
packages/utils/               # utils — pure helpers (cn, slugify, formatters)
packages/config/typescript/   # @ucmp/tsconfig
packages/config/vitest/       # @ucmp/vitest-config
```

## Key versions

- Node 22.22.2 | pnpm 11.0.9 | Next.js 16.x | React 19.x | TypeScript 5.9
- Tailwind 4.x (CSS-first, no `tailwind.config.ts`) | Biome 2.x (via Ultracite) | Vitest 4.x
- shadcn/ui (new-york style) on Base UI 1.x (`@base-ui/react`)
- Forms: react-hook-form 7.x + Zod 4.x + `@hookform/resolvers`
- Icons: lucide-react + custom brand icons (`@ucmp/ui/icons`) | Theme switching: next-themes | Feature flags: Vercel `flags` SDK | Toasts: Sonner

## Do / Don't

### React & components
| Do | Don't |
| --- | --- |
| Write Server Components by default | Add `"use client"` unless you need state, effects, or browser APIs |
| Push `"use client"` to the smallest leaf (client islands inside server shells) | Mark a whole page client-only because one child needs it |
| Write plain functions and inline computations | Use `useMemo`, `useCallback`, or `React.memo` — React Compiler handles it |
| Use `useEffect` only for real side effects | Use `useEffect` for derived state |
| Use `<Context value={...}>` and `use(Context)` | Use `<Context.Provider>` or `useContext()` |
| Pass `ref` as a regular prop via `React.ComponentProps<...>` | Use `forwardRef` |
| Use Base UI's `render` prop (`<Button render={<Link />}>`) | Use `asChild` |
| Use composition and compound components for variants | Use boolean props to toggle behavior |
| Keep `page.tsx` exports **synchronous** — pass Promises (`params`, fetches) down to async leaf components wrapped in `<Suspense>` | Make page functions `async` and `await` at the top — blocks the static shell from streaming |

### Imports & boundaries
| Do | Don't |
| --- | --- |
| Use path aliases (`@features/`, `@shared/`, `@config/`, `@layout/`) | Use `../../` to escape module boundaries |
| Use `import type` for type-only imports | Use value imports for types |
| Keep features self-contained in `features/<name>/` | Import internals across features |
| Re-export public surface from `features/<name>/index.ts` | Import deep paths from another feature |
| Use `@ucmp/ui` primitives first | Hand-roll components that exist in the UI package |

### Styling & theming
| Do | Don't |
| --- | --- |
| Use semantic tokens from `@ucmp/ui-theme` | Hardcode colors or magic values |
| Define tokens via `@theme` in CSS (Tailwind v4) | Create a `tailwind.config.ts` |
| Use OKLCH for colors | Use HSL or hex in token definitions |
| Use Tailwind utilities or CVA variants | Use `@apply`, inline `style={...}`, CSS modules, or styled-components |
| Use `cn()` from `utils` for conditional classes | Concatenate class strings with template literals |
| Use CVA for component variants | Hand-roll variant logic with if/else class strings |
| Keep `data-slot` attributes on shadcn primitives | Remove them — they're styling hooks |
| Use Sonner for toasts | Use deprecated shadcn `Toast` |
| Use `next-themes` (`useTheme()`) for light/dark switching | Roll your own theme toggle / localStorage logic |
| Use Tailwind's spacing scale (`p-4`, `gap-6`, `text-sm`) — rem-based | Use arbitrary px values (`p-[14px]`, `text-[15px]`) |
| Use `px` only for borders, hairlines, focus rings, breakpoints | Use `px` for spacing, typography, or icon sizing |
| Use `em` for letter-spacing (`tracking-*`) | Use `em` for spacing or sizes — it compounds unpredictably |

### Forms & validation
| Do | Don't |
| --- | --- |
| Use `react-hook-form` with `zodResolver` | Manage form state with `useState` per field |
| Define a Zod schema once and reuse on client (RHF) and server (Server Action) | Validate inputs only in one place |
| Submit via Server Actions for mutations | `fetch()` POST from `onSubmit` |
| Use `useFormStatus` from `react-dom` for submit-button pending state | Prop-drill an `isPending` flag from the form root |
| Return `{ success, error?, data? }` from Server Actions | Throw raw errors — `useActionState` will hang |

### Icons & UI helpers
| Do | Don't |
| --- | --- |
| Use custom brand icons from `@ucmp/ui/icons` (`IconHome`, `IconCar`, etc.) | Use `<img>` tags for SVG icons |
| Use `lucide-react` for generic UI icons not in the brand set | Add another icon library |
| Size icons with Tailwind `size-4` / `size-5` (rem-based) | Use `width={16} height={16}` props |
| Wrap interactive icons in a `Button` or accessible element with `aria-label` | Render bare `<svg>` for click targets |
| Use `inline-flex` + token sizing for icons-beside-text alignment | Rely on default vertical-align — produces sub-pixel misalignment |
| Theme icons via `text-*` utilities (icons use `currentColor`) | Hardcode fill/stroke colors in icon usage |

### Data, caching & state
| Do | Don't |
| --- | --- |
| Use `"use cache"` with named `cacheLife()` profiles | Use deprecated `unstable_cache` or implicit `fetch()` caching |
| Use `cacheTag()` and `revalidateTag()` for invalidation | Roll your own cache headers |
| Read `cookies()`/`headers()`/`searchParams` outside `"use cache"` | Call them inside a `"use cache"` scope |
| Use Server Actions for mutations | `fetch()` POST from Client Components |
| Use TanStack React Query for client-side server reads | Add Redux, Zustand, Jotai, Recoil, or MobX |
| Use the Vercel `flags` SDK for feature flags | Read `process.env.NEXT_PUBLIC_FLAG_*` directly in components |
| Validate API inputs with Zod | Trust unvalidated data |

### Routing, loading & error handling
| Do | Don't |
| --- | --- |
| Add `loading.tsx` for each route segment with async data | Show a blank screen during navigation |
| Wrap async children in `<Suspense fallback={<Skeleton />}>` | Use `fallback={null}` on route-level Suspense (kills scroll anchor under PPR) |
| Add `error.tsx` for each route segment to catch render errors | Let errors bubble to the root error boundary |
| Add `not-found.tsx`; call `notFound()` from a Server Component | Render a custom "404" component manually |
| Use route groups `(group)` for organisational nesting | Add real path segments just to group files |
| Use `redirect()` from `next/navigation` in Server Components | Use `router.push()` in a `useEffect` for server-side redirects |

### Images & fonts
| Do | Don't |
| --- | --- |
| Use `next/image` with explicit `width` and `height` (or `fill` + sized parent) | Use bare `<img>` tags |
| Add `priority` to the LCP image only | Mark every image `priority` |
| Load fonts via `next/font/google` or `next/font/local` with `display: "swap"` | Use `<link rel="stylesheet">` to Google Fonts directly |
| Expose fonts as CSS variables and wire via `@theme inline` | Hardcode font-family in component styles |

### Code quality
| Do | Don't |
| --- | --- |
| Use `for...of` loops | Use `.forEach()` (Biome `noForEach`) |
| Use early returns for guard clauses | Nest deeply with else chains |
| Keep files under ~300 lines, complexity under 10 | Let files grow into god modules |
| Co-locate tests as `*.test.tsx` under `__tests__/` | Put tests in a separate top-level folder |
| Reference fixtures from `__fixtures__/` | Hardcode mock data inline in tests |
| Use Conventional Commits (`feat(web):`, `fix(ui):`) | Write freeform commit messages |
| Run `pnpm lint && pnpm type-check && pnpm test` before committing | Skip pre-commit checks |
| Justify any lint/type-error suppression with a comment | Suppress silently |

### Security
| Do | Don't |
| --- | --- |
| Render user content as text (React escapes) | Use `dangerouslySetInnerHTML` |
| Store auth tokens in `httpOnly` cookies | Use `localStorage` or `sessionStorage` |
| Read secrets from server-only env vars | Put secrets in `NEXT_PUBLIC_*` — they're bundled into the client |
| Validate every Server Action and route handler input with Zod | Process unvalidated form/request data |
| Use `import "server-only"` for modules with secrets | Assume a module won't be bundled just because it's only imported from server code |

## Next 16 / React 19 / Tailwind 4 specifics

- **PPR (Partial Prerendering)** — everything outside `<Suspense>` becomes the static shell streamed from the CDN; wrap per-request data in `<Suspense fallback={<Skeleton />}>` to mark it as a dynamic hole.
- **Streaming via promise-passing** — pass a promise from a Server Component to a Client Component and unwrap with `use(promise)` to stream without blocking the static shell.
- **`proxy.ts`, not `middleware.ts`** — Next.js 16 renamed the file convention. Create `apps/web/proxy.ts` exporting `proxy(request)` (formerly `middleware(request)`) for auth, redirects, and rewrites only.
- **Metadata API** — export `const metadata` or `async function generateMetadata()` from a `page.tsx` or `layout.tsx`. Don't render `<title>` or `<meta>` tags by hand.
- **Tailwind 4 container queries** — use `@container` and `@sm:`/`@md:` variants when a component's layout should respond to its own width, not the viewport.

## Architecture patterns

### React Compiler is ON
`reactCompiler: true` in `next.config.ts`. The compiler auto-memoizes. Biome's `useExhaustiveDependencies` is off.

### Theming — inheritance-based multi-brand
`@ucmp/ui-theme/base` holds generic tokens. Each theme under `themes/<brand>/` only overrides what differs. Apps import a single theme: `@import "@ucmp/ui-theme/themes/default";`

### UI — shadcn API on Base UI
`@ucmp/ui` uses `@base-ui/react` under shadcn-style named exports. Components are installed via `pnpm ui:add <name>` with `style: "base-vega"`.

### Features — screaming architecture
Each `apps/web/src/features/<name>/` is self-contained: `components/`, `hooks/`, `services/`, `data/`, `lib/`, `__tests__/`, `__fixtures__/`, `index.ts`.

### Cache profiles (next.config.ts)
| Profile | Stale | Revalidate | Expire |
| --- | --- | --- | --- |
| `landing` | 15 min | 15 min | 1 hr |
| `profile` | 5 min | 10 min | 1 hr |
| `detail` | 5 min | 5 min | 1 hr |
| `search` | 5 min | 5 min | 1 hr |

### Environment variables
- **`NEXT_PUBLIC_*`** — bundled into the client. Non-sensitive values only.
- **All other vars** — server-only. Add `import "server-only"` to modules reading them.

### Provider hierarchy
```
ThemeProvider → QueryProvider → {children}
```

## Naming & commits

- **Files & folders**: kebab-case (`landing.tsx`, `use-debounce.ts`, `features/vehicle-card/`)
- **Components**: PascalCase exports (`Landing`, `AlertDialog`)
- **Hooks**: `use-*.ts` files with `useFoo` exports
- **Utilities, services, Server Actions**: camelCase (`formatPrice`, `getVehicle`, `submitFormAction`)
- **Types**: PascalCase (`Vehicle`); **Zod schemas**: camelCase + `Schema` suffix (`vehicleSchema`)
- **Constants**: UPPER_SNAKE_CASE (`API_BASE_URL`)
- **Next.js reserved files**: lowercase (`page.tsx`, `layout.tsx`, `proxy.ts`, …)
- **Commits**: Conventional Commits — `feat(web):`, `fix(ui):`, `refactor(ui-theme):`, `test(web):`, `chore(monorepo):`. Scopes: `web`, `ui`, `ui-theme`, `shared`, `config`, `monorepo`.

Full file-kind table, 17 reserved Next.js file names, and route segment patterns live in [`../docs/NAMING.md`](../docs/NAMING.md).

Everything else is enforced by Biome via Ultracite — `pnpm fix` auto-corrects.

## Commands

| Command | What it does |
| --- | --- |
| `pnpm dev` | Start dev server (Turbopack) |
| `pnpm build` | Production build |
| `pnpm test` | Run all tests (Vitest) |
| `pnpm lint` | Lint (Biome) |
| `pnpm check` | Format check (Ultracite) |
| `pnpm fix` | Auto-fix formatting |
| `pnpm type-check` | TypeScript check |
| `pnpm ui:add <name>` | Add shadcn component |

## Path aliases (apps/web)

| Alias | Resolves to |
| --- | --- |
| `@features/*` | `./src/features/*` |
| `@shared/*` | `./src/shared/*` |
| `@config/*` | `./src/config/*` |
| `@layout/*` | `./src/layout/*` |
| `~/*` | `./src/*` |
| `@/*` | `../../packages/ui/src/*` |
| `utils` | `../../packages/utils/src` |

## Implementation workflow

See [`../docs/WORKFLOW.md`](../docs/WORKFLOW.md) — read context, plan, types first, fixtures, service, component, tests, document, validate, fill the PR template.

## Reference docs

- `AGENTS.md` — full agent instructions (canonical)
- `docs/ARCHITECTURE.md` — architecture deep dive
- `docs/THEMING.md` — theme system + unit rules (rem/px/em)
- `docs/CONTRIBUTING.md` — branches, commits, Definition of Done
- `docs/WORKFLOW.md` — implementation order
- `docs/PERFORMANCE.md` — perf budgets and Core Web Vital targets
- `docs/SECURITY.md` — security rules
- `.github/PULL_REQUEST_TEMPLATE.md` — PR / Return Contract template
- `.kiro/prompts/verify-pr.md` — verification agent prompt
