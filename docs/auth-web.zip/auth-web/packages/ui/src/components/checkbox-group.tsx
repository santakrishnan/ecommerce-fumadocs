"use client"

import { CheckboxGroup as CheckboxGroupPrimitive } from "@base-ui/react/checkbox-group"
import { type ReactNode, useId } from "react"

import { Checkbox } from "@/components/checkbox"
import { FieldDescription } from "@/components/field"
import type { Surface } from "@/lib/types"
import { cn } from "@/lib/utils"

interface CheckboxGroupProps extends CheckboxGroupPrimitive.Props {
  surface?: Surface
}

function CheckboxGroup({ className, surface, ...props }: CheckboxGroupProps) {
  return (
    <CheckboxGroupPrimitive
      data-slot="checkbox-group"
      {...(surface !== undefined ? { "data-surface": surface } : {})}
      className={cn(
        // Layout
        "flex w-full flex-col gap-5",

        // Surface
        "rounded-2xl bg-surface-primary px-5 py-6",

        className
      )}
      {...props}
    />
  )
}

interface CheckboxGroupItemProps {
  className?: string
  description?: ReactNode
  disabled?: boolean
  title: ReactNode
  value: string
}

function CheckboxGroupItem({
  className,
  description,
  disabled,
  title,
  value,
}: CheckboxGroupItemProps) {
  const id = useId()
  const titleId = `${id}-title`
  const descriptionId = `${id}-description`

  return (
    <label
      data-slot="checkbox-group-item"
      data-disabled={disabled ? "true" : undefined}
      className={cn(
        // Layout
        "flex w-full items-start justify-between gap-4",

        // Interaction
        "cursor-pointer data-disabled:cursor-not-allowed",

        className
      )}
      htmlFor={id}
    >
      <span data-slot="checkbox-group-item-content" className="flex flex-col gap-1">
        <span
          data-slot="checkbox-group-item-title"
          className="body-md text-text-primary in-data-disabled:text-text-inactive"
          id={titleId}
        >
          {title}
        </span>
        {description && <FieldDescription id={descriptionId}>{description}</FieldDescription>}
      </span>
      <Checkbox
        aria-describedby={description ? descriptionId : undefined}
        aria-labelledby={titleId}
        className="mt-1"
        disabled={disabled}
        id={id}
        value={value}
      />
    </label>
  )
}

export { CheckboxGroup, CheckboxGroupItem }
export type { CheckboxGroupItemProps, CheckboxGroupProps }
