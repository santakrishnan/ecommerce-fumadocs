import { defineConfig, devices } from "@playwright/test";
import { baseURL, createWebServer, isCI, testMatch } from "./playwright.shared";

/**
 * Base URL the E2E suite runs against, selectable via env rather than
 * hardcoded to one target (see `playwright.shared.ts`):
 *   - unset / local           → http://localhost:3000 (local `pnpm dev`)
 *   - PLAYWRIGHT_BASE_URL=... → any deployed target (e.g. Vercel dev sandbox)
 *
 * Example:
 *   PLAYWRIGHT_BASE_URL=https://<preview>.vercel.app pnpm test:e2e
 */
export default defineConfig({
  testDir: "./e2e",
  // Look for files with the .integ.js or .e2e.js extension
  testMatch,
  // The live-API happy-path suite runs only via playwright.happy-path.config.ts
  testIgnore: "**/happy-path/**",
  // Timeout per test, test running locally are slower due to database connections with PGLite
  timeout: 30 * 1000,
  fullyParallel: true,
  forbidOnly: isCI,
  retries: isCI ? 2 : 0,
  workers: isCI ? 1 : undefined,
  reporter: isCI ? [["html", { open: "never" }], ["github"], ["list"]] : "list",
  expect: {
    // Set timeout for async expect matchers
    timeout: 15 * 1000,
  },
  use: {
    baseURL,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [
    {
      name: "Desktop Chrome",
      use: { ...devices["Desktop Chrome"] },
    },
    {
      name: "Desktop Safari",
      use: { ...devices["Desktop Safari"] },
    },
    {
      name: "Mobile Chrome",
      use: { ...devices["Pixel 7"] },
    },
    {
      name: "Mobile Safari",
      use: { ...devices["iPhone 14"] },
    },
  ],
  // Only spin up `next dev` when targeting localhost — a Vercel dev sandbox
  // or any other deployed PLAYWRIGHT_BASE_URL is already running.
  webServer: createWebServer({
    timeout: 60 * 1000,
    reuseExistingServer: !isCI,
    // All-fixtures dev config — no real backend required (see
    // .env.local.example). Mirrors USE_*_MOCKS=true defaults so the
    // suite is deterministic and offline.
    env: {
      SEARCH_AGENT_BACKEND: "static_mock",
    },
  }),
});
