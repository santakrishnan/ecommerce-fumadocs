import { defineConfig, devices } from "@playwright/test";
import { baseURL, createWebServer, isCI, testMatch } from "./playwright.shared";

/**
 * Happy-path suite: one serial Desktop Chrome journey against the real APIs
 * configured in `apps/web/.env.local`. Excluded from `pnpm e2e` and CI by the
 * base config's `testIgnore`; run it with `pnpm e2e:happy-path`. Shared base
 * URL / web-server scaffolding lives in `playwright.shared.ts`.
 */
export default defineConfig({
  testDir: "./e2e/happy-path",
  testMatch,
  // Covers live-API latency (conversational search, agent streams) across a long multi-page journey
  timeout: 3 * 60 * 1000,
  // One stateful journey, the VDP view drives the welcome-back landing, so it must run serially
  fullyParallel: false,
  forbidOnly: isCI,
  // Let live-data failures surface, stability comes from event-based waits instead
  retries: 0,
  workers: 1,
  outputDir: "test-results/happy-path",
  reporter: [["list"], ["html", { open: "never", outputFolder: "playwright-report/happy-path" }]],
  expect: {
    timeout: 30 * 1000,
  },
  use: {
    baseURL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [
    {
      name: "Desktop Chrome",
      use: {
        ...devices["Desktop Chrome"],
        // Just past the theme's lg breakpoint (1440px), the device default of 1280 renders the md layout
        viewport: { width: 1460, height: 900 },
      },
    },
  ],
  // No `env` overrides, unlike the base config, so `next dev` runs on the developer's `.env.local` as-is.
  // A cold `next dev` compile against real services can exceed the base config's 60s; reuse even in CI.
  webServer: createWebServer({
    timeout: 180 * 1000,
    reuseExistingServer: true,
  }),
});
