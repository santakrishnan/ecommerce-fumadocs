import type { PlaywrightTestConfig } from "@playwright/test";

const configuredBaseURL = process.env.PLAYWRIGHT_BASE_URL?.trim() || undefined;
export const baseURL = configuredBaseURL ?? "http://localhost:3000";

export const isLocalTarget = !configuredBaseURL;

export const isCI = Boolean(process.env.CI);

export const testMatch = "*.@(integ|e2e).?(c|m)[jt]s?(x)";

type WebServerConfig = NonNullable<PlaywrightTestConfig["webServer"]>;

interface WebServerOptions {
  env?: Record<string, string>;
  reuseExistingServer: boolean;
  timeout: number;
}

export function createWebServer({
  timeout,
  reuseExistingServer,
  env,
}: WebServerOptions): WebServerConfig | undefined {
  if (!isLocalTarget) {
    return;
  }

  return {
    command: "pnpm dev",
    url: baseURL,
    timeout,
    reuseExistingServer,
    gracefulShutdown: { signal: "SIGTERM", timeout: 2 * 1000 },
    ...(env ? { env } : {}),
  };
}
