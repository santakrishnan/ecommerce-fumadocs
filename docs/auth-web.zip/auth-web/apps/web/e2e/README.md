# E2E tests

Two Playwright suites live here.

| Suite | Command (repo root) | Config | Data |
| --- | --- | --- | --- |
| Smoke | `pnpm e2e` | `playwright.config.ts` | Fixture mocks; 4 projects (Desktop Chrome, Desktop Safari, Mobile Chrome, Mobile Safari) |
| Happy path | `pnpm e2e:happy-path` | `playwright.happy-path.config.ts` | Real APIs; one Desktop Chrome journey |

## Running the happy path

- `apps/web/.env.local` must hold live/dev values for the services the journey hits. The test never reads or overrides them.
- Runs on Desktop Chrome at 1460×900 (just past the `lg` breakpoint).
- Reuses a dev server already on `:3000`, otherwise starts `pnpm dev`.
- Each run starts from a fresh browser context and sets ZIP `90210` through the location pill.
- It views up to 5 New Today vehicles before the welcome-back checks, so "Because You Viewed" has enough history.
- Base URL and dev-server setup shared by both configs live in `playwright.shared.ts`.

```bash
pnpm e2e:happy-path
pnpm e2e:happy-path --headed
pnpm e2e:happy-path --ui
PLAYWRIGHT_BASE_URL=https://<target> pnpm e2e:happy-path   # skips the local dev server
```

## Kept out of `pnpm e2e` and CI

- `playwright.config.ts` sets `testIgnore: "**/happy-path/**"`, so `pnpm e2e` never picks it up.
- The happy path has its own config and script; the root `e2e:happy-path` calls `pnpm --filter web` directly, not Turbo.
- `.github/workflows/e2e.yml` is unchanged.

## Layout

| Path | Contents |
| --- | --- |
| `happy-path/` | The journey test |
| `pages/` | Page objects: locators and small actions |
| `fixtures/` | `test` extended with the page-object fixtures |
| [`specs/happy-path.md`](specs/happy-path.md) | Steps, expected results, and confirmed locators |

## Conventions

- Role-based locators (`getByRole` with accessible names).
- Event-based waits only: URLs, responses, visible elements, `expect.poll`. No `waitForTimeout`.
- Walk as a visitor: back navigation uses the top-left nav buttons only, never `page.goBack()`.
- Assert on structure (regions, counts, formats), not on live data values.
