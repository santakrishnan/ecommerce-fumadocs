# OTP and passkey: proposed Jira stories

**Prepared:** 2026-09-28  
**Based on:** [passkey architecture and implementation plan](./ecommerce-auth-passkey-architecture-plan.md) and [authentication flow gap review](./13-authentication-industry-gap-review.md).  
**Purpose:** a high-level backlog for small, reviewable stories. Titles and descriptions can be copied into Jira; requirements and acceptance criteria describe observable outcomes, not implementation instructions.

## Delivery order

| Phase | Stories | Outcome |
| --- | --- | --- |
| 1. Agree on behavior | AUTH-01–02 | Authentication policy and browser/upstream contract are clear. |
| 2. Mock BFF | AUTH-03–09 | OTP and passkey endpoints work independently of the final UI, with repeatable HTTP examples. |
| 3. Connect the UI | AUTH-10–13 | Existing components use the BFF for real, verified ceremonies. |
| 4. Demo validation | AUTH-14 | The complete shopper journey is reproducible. |
| 5. Upstream integration | AUTH-15–16 | VPS/EDI replaces the mock without changing the shopper flow. |
| Later product/security work | AUTH-17–19 | Recovery, remote revocation, and notifications are defined and delivered when upstream capabilities exist. |

`AUTH-01` and similar labels below are **proposed ordering IDs**, not existing Jira issue keys. The first fourteen stories deliver the local end-to-end demo. Stories 15–19 are separate later work; their acceptance depends on VPS/EDI capabilities and product/security decisions.

## Shared acceptance rules for demo stories

- The browser communicates with the Next.js BFF; it does not call EDI or Auth0 directly. No account ID or EDI session value is exposed to browser JavaScript.
- A passkey is only considered registered or authenticated after the server accepts the completed browser ceremony. Creating a passkey alone does not grant T2.
- Mock authentication is available only in a non-production environment. Mock credentials and sessions are temporary and may disappear when the local server restarts.
- Each BFF story can be checked through HTTP requests before its UI story begins. A successful WebAuthn completion additionally needs a real browser authenticator or virtual authenticator.
- Each story includes its own focused positive and failure checks. The end-to-end demo story confirms they work together.

## Phase 1 — agree on behavior

### AUTH-01 — Agree on authentication and recovery policy

**Description:** Define which proof is required for first passkey setup, adding or deleting passkeys, sensitive actions, and account recovery.

**High-level requirements:** Product, security, VPS, and EDI agree on T1/T2 meanings, recent-authentication rules, and what happens when a factor is lost or compromised.

**Acceptance criteria:**

- A short decision record distinguishes first passkey enrollment from adding another passkey and deleting one or the last passkey.
- The record states when a fresh passkey assertion is required, how a customer recovers without one, and when current or other sessions are downgraded or ended.
- Any decisions EDI/VPS cannot yet support are identified as dependencies rather than silently assumed by the mock.

### AUTH-02 — Agree on the auth API and EDI-session contract

**Description:** Establish one agreed request and response contract for OTP, `/resolve`, auth profile, passkey management, and logout.

**High-level requirements:** Select the canonical VPS API draft and resolve how the EDI session is returned in OTP verify and `/resolve` while keeping account identifiers private.

**Acceptance criteria:**

- The agreed contract names the EDI-session response field, its lifetime/rotation behavior, and the difference between visitor-session and EDI-authentication expiry.
- Browser-facing examples omit account IDs and EDI session values; errors and passkey-management actions are consistently defined.
- VPS/EDI confirms which listed actions are available now and which require later upstream work.

## Phase 2 — mock BFF endpoints

### AUTH-03 — Create mock OTP sign-in and auth profile

**Description:** Let a shopper start and verify an OTP and receive a server-backed T1 authentication profile.

**High-level requirements:** The mock keeps OTP, shopper, and session state together and returns only safe profile information to the browser.

**Acceptance criteria:**

- A valid code establishes T1 and the auth profile remains consistent after a page refresh.
- Wrong, expired, replaced, or reused codes do not establish T1; separate browser sessions do not share authentication.
- The browser response contains neither an EDI-session value nor an account ID, and the endpoint can be exercised with curl or Postman.

### AUTH-04 — Add mock logout and session lifecycle

**Description:** Let a shopper sign out while keeping their registered passkeys available for a later sign-in.

**High-level requirements:** Model logout, visitor-session renewal, and EDI-authentication expiry as distinct outcomes.

**Acceptance criteria:**

- Logout returns the current browser to T0 and blocks its protected account actions; another browser's session is unaffected.
- A visitor-session renewal does not automatically mean EDI authentication has expired, and an expired EDI session does not pass an EDI-protected action.
- Logout and expiry responses are testable without the final UI.

### AUTH-05 — Start mock passkey registration

**Description:** Provide a fresh, time-limited passkey creation request to an eligible OTP-verified shopper.

**High-level requirements:** Apply the agreed first-versus-additional-passkey policy and associate each request with the current authenticated browser session.

**Acceptance criteria:**

- An eligible shopper receives registration options; an anonymous or expired session is rejected.
- A new request produces a new challenge, and an expired or already used request cannot complete registration.
- The response can be inspected with curl or Postman before a UI is connected.

### AUTH-06 — Complete registration and list passkeys

**Description:** Verify the shopper's browser registration result and show the newly registered passkey in their profile.

**High-level requirements:** Store the credential under the correct private mock shopper identity and leave the session at T1 until passkey authentication occurs.

**Acceptance criteria:**

- A real browser registration succeeds and the new passkey appears in that shopper's server-backed list.
- An invalid, expired, replayed, or wrong-session result creates no passkey; one shopper cannot see another shopper's list.
- Registering a passkey alone does not raise the session to T2.

### AUTH-07 — Add verified passkey sign-in

**Description:** Allow an existing passkey to sign a shopper in or step an OTP session up to T2.

**High-level requirements:** Offer a passkey challenge and grant T2 only when the server verifies the completed assertion and associates it with the correct shopper.

**Acceptance criteria:**

- A registered passkey can sign in from a signed-out browser without an account ID in the request.
- Only a valid completed passkey assertion grants T2; cancellation, unknown/deleted credentials, expiry, and replay do not.
- The endpoint is testable with a minimal browser harness or virtual authenticator before final UI integration.

### AUTH-08 — Add single-passkey deletion

**Description:** Let an eligible shopper remove one registered passkey and see the updated list.

**High-level requirements:** Apply the agreed recent-authentication policy and scope deletion to the current shopper; define the effect of deleting the active or last passkey.

**Acceptance criteria:**

- Deleting one passkey leaves other passkeys intact; deleting the last yields an empty list and the agreed session state.
- Another shopper cannot delete it, and the deleted passkey can no longer sign in.
- The endpoint and refreshed profile can be checked with curl or Postman after a passkey has been registered.

### AUTH-09 — Provide endpoint-level test examples

**Description:** Give developers a small, repeatable way to exercise each BFF endpoint before connecting the UI.

**High-level requirements:** Provide a curl script or Postman collection with mock-only variables and expected success/failure results. Add examples as each BFF endpoint lands.

**Acceptance criteria:**

- The examples cover OTP, profile, logout, registration options, login options, list, and delete, including session isolation and common error responses.
- The documentation explains that successful passkey completion requires a browser authenticator or virtual authenticator, and contains no production credentials or session values.

## Phase 3 — connect existing frontend components

### AUTH-10 — Connect OTP, auth profile, and logout UI

**Description:** Use the BFF as the source of truth for OTP sign-in, displayed auth state, refresh, and logout.

**High-level requirements:** Replace the demo-only tier behavior in the shopper flow with BFF results and present useful OTP error and retry states.

**Acceptance criteria:**

- A shopper can request and verify an OTP in the UI, reach T1, refresh, and see the correct state.
- Wrong/expired codes, resend, and logout have clear outcomes; an unverified shopper cannot access T1-only UI actions.

### AUTH-11 — Connect passkey creation UI

**Description:** Let a T1 shopper create a passkey through the existing UI using BFF-provided registration options.

**High-level requirements:** The browser performs the passkey prompt and sends its result back to the BFF; the UI reflects only the verified server response.

**Acceptance criteria:**

- Successful creation appears in the shopper's passkey list and leaves the session at T1.
- Cancellation, unsupported device, and server rejection show appropriate retry or skip choices without claiming success.

### AUTH-12 — Connect passkey sign-in and step-up UI

**Description:** Let shoppers sign in with a saved passkey or use it to unlock a T2-required action.

**High-level requirements:** Separate sign-in, step-up, OTP fallback, and new-passkey enrollment choices; use BFF profile state to decide the next screen.

**Acceptance criteria:**

- A verified passkey assertion reaches T2 and permits a T2-gated demo action; a cancelled or failed prompt does not.
- A shopper with no usable passkey sees an appropriate OTP/enrollment or cross-device path, and a T1-only action does not unnecessarily require T2.

### AUTH-13 — Connect passkey management UI

**Description:** Show the shopper's server-backed passkey list and let them remove one passkey.

**High-level requirements:** Replace local demo deletion with BFF list/delete results and explain that removal from the account may not delete the device's saved copy.

**Acceptance criteria:**

- The list handles loading, empty, success, failure, and stale-item states; deleting one item refreshes the list.
- The UI requires the agreed confirmation and reauthentication before deletion and offers new enrollment after the last passkey is removed.

## Phase 4 — make the demo reproducible

### AUTH-14 — Validate the complete mock shopper journey

**Description:** Demonstrate OTP → create passkey → logout → passkey sign-in → list → delete as one working journey.

**High-level requirements:** Confirm both happy and failure paths in a supported browser and document the demo setup and mock limitations.

**Acceptance criteria:**

- The complete journey works end to end, and a deleted passkey cannot sign in again.
- Cancellation, no passkey, two shoppers, browser refresh, visitor-session renewal, and EDI expiry give the expected results.
- The demo instructions state that mock state is temporary and is not a production identity store.

## Phase 5 — VPS/EDI integration after the demo

### AUTH-15 — Integrate OTP and EDI-session continuity with VPS

**Description:** Replace mock OTP/session handling with VPS responses while preserving the same browser-facing BFF contract.

**High-level requirements:** Keep the EDI session returned by OTP verify and `/resolve` on the server and handle renewal, expiry, and logout with VPS/EDI.

**Acceptance criteria:**

- A sandbox OTP verification establishes the expected auth profile; refresh and `/resolve` preserve the correct authenticated state.
- EDI session values and account IDs never appear in browser responses, readable cookies, or routine logs.
- Expiry and logout block protected actions according to the agreed policy.

### AUTH-16 — Integrate passkey ceremonies and management with VPS/EDI

**Description:** Route passkey creation, sign-in, listing, and supported deletion through VPS/EDI without changing the frontend journey.

**High-level requirements:** Use the agreed upstream contract and retain server-side ownership checks, error handling, and tier transitions.

**Acceptance criteria:**

- In a sandbox, an OTP-verified shopper can enroll, then authenticate with a passkey, reach T2, and see the credential in their list.
- Deletion is enabled only when the individual-delete upstream endpoint is confirmed ready; a removed credential cannot authenticate.
- Upstream errors and expired sessions produce the agreed browser-facing outcomes without exposing private upstream values.

## Later product and security stories

### AUTH-17 — Define and deliver lost-factor recovery

**Description:** Provide a safe route back when a shopper loses a passkey, an OTP channel, or both.

**High-level requirements:** Agree on support proof, factor replacement, temporary limits, and the identity/session effects for each recovery case.

**Acceptance criteria:**

- Each loss case has a documented shopper journey and a corresponding support or self-service path.
- Recovery cannot silently add a new strong factor based only on an old or compromised session; affected sessions and credentials follow the agreed revocation policy.

### AUTH-18 — Add lost-device and all-session sign-out

**Description:** Let a shopper respond to a lost or stolen device by ending its access and, when needed, ending other sessions.

**High-level requirements:** Coordinate session and credential revocation with EDI/VPS and explain what remains on a device or password manager.

**Acceptance criteria:**

- The shopper can identify the action to take after a device is lost and receive confirmation of what access was revoked.
- Revoked sessions and credentials no longer authenticate; unaffected credentials remain available according to policy.

### AUTH-19 — Notify shoppers about authentication changes

**Description:** Alert shoppers when passkeys or primary contacts change or an account recovery occurs.

**High-level requirements:** Send an independent notice to an already verified contact and provide a clear way to report an unrecognized change.

**Acceptance criteria:**

- The agreed events create an audit record and a notice to a previously verified contact, without exposing passkey secrets or session values.
- A shopper who does not recognize a change has a documented route to support or account protection.

## Scope notes

- **Clear all passkeys, primary-contact change, and account deletion** appear in the source journeys but depend on separate upstream capabilities. They should receive their own Jira stories when VPS/EDI confirms their contracts and the product policy; single-passkey deletion does not imply clear-all support.
- **Future nice-to-have UX** such as richer passkey labels, “this device” badges, and browser credential-state signaling can be added after the underlying upstream data is reliable.
- The proposed story order supports one focused PR per BFF story. UI stories may be delivered separately once their dependent endpoint is working and independently testable.
