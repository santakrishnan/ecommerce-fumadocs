# Passkey demo: architecture and delivery plan

## What we are building

We want a working local demo of OTP sign-in followed by passkey creation, passkey sign-in, listing, and deletion. The Next.js UI will call its own BFF. For the first version, the BFF will mock VPS/EDI and verify real browser passkey responses. Once the flow is working, we can replace the mock with VPS calls without changing the UI flow.

OTP verification gives the shopper **T1**. Creating a passkey keeps them at T1. A successful passkey **sign-in** gives them **T2**. This distinction matters for actions such as pre-qualification, which require T2.

The current passkey screens are useful as a starting point, but they are still a demo: they use a fixed challenge and browser storage, and they do not send the passkey result to a server for verification. We should connect them only after the BFF endpoints work on their own.

## The agreed boundary

```mermaid
flowchart LR
    U[Shopper] --> UI[Next.js UI]
    UI --> BFF[Next.js BFF]
    BFF --> M[Local mock now]
    BFF -. later .-> VPS[VPS]
    VPS --> EDI[EDI / Auth0]
    UI --> W[Browser passkey prompt]
    W --> UI
```

VPS has said it will return the EDI session as a **response field** after OTP verification and on `/resolve`; it will not expose an account ID. `ediSessionId` is our proposed JSON field name, matching the `edi-session-id` cookie terminology. VPS still needs to confirm the exact name and behavior in its OpenAPI contract. This EDI value belongs in BFF server state. The browser receives a separate, opaque HttpOnly BFF cookie and a profile without the EDI value.

There are three different session values to keep apart:

| Value | Used for |
| --- | --- |
| VPS `sessionId` | Visitor session returned by `/resolve`; it is not proof of OTP or passkey sign-in. |
| EDI session (`ediSessionId`, proposed) | Authentication continuity after OTP or passkey verification; kept by the BFF. |
| Passkey `authSession` | One short-lived registration or sign-in challenge; it is not a login session. |

The mock can keep credentials, challenges, and a private shopper key in server memory. The browser or passkey provider keeps the private passkey. The mock store is for one local server process and is disabled in production.

## Shopper flow

1. The shopper requests an OTP and enters the code. The BFF verifies it and returns a T1 profile.
2. The shopper chooses to create a passkey. The BFF issues registration options, the browser creates a passkey, and the BFF verifies the result. The profile still says T1.
3. The shopper signs out, then chooses passkey sign-in. The BFF issues a new challenge and verifies the browser's answer. Only then does the profile say T2.
4. The shopper can see passkeys held for their account and remove one. A removed passkey can no longer sign in, even if a copy remains in their password manager.

The UI should show retry, cancellation, no-passkey, and OTP fallback paths. A failed sign-in must not automatically start registration.

## Delivery plan

**First, agree on the contract and policy.** Choose the canonical v2 VPS spec. Add the agreed EDI-session field to OTP verify and `/resolve`, clarify session expiry and rotation, and remove browser-facing account IDs. Agree on the proof needed to add or remove a passkey, especially after one already exists. The [gap review](./13-authentication-industry-gap-review.md) explains why a blanket T1 rule for passkey management needs another look.

**Then build the mock BFF in small PRs:**

1. OTP verification and a server-backed auth profile.
2. Logout and separate visitor-session versus EDI-session expiry behavior.
3. Passkey registration options.
4. Registration verification and passkey list.
5. Passkey sign-in and T2 step-up.
6. Single-passkey deletion.

Each PR should be usable and testable before the next one. Curl or Postman can check the HTTP contract and error cases. Completing a passkey registration or sign-in also needs a browser authenticator or virtual authenticator; fabricated JSON is not a valid success test.

**Connect the existing UI next.** Wire OTP and profile first, then passkey creation, sign-in, and management. The BFF profile becomes the source of truth for T1/T2 and the passkey list. Remove browser storage and the demo-tier cookie as authentication authority.

**Finish with one end-to-end demo:** OTP → create passkey → sign out → sign in with passkey → list → delete → confirm the deleted passkey fails. Also check two separate shoppers, refresh, cancellation, and expired sessions. The [Jira story list](./ecommerce-auth-jira-stories.md) breaks this work into reviewable tickets.

**Use VPS/EDI after the demo.** Swap the mock adapter for VPS calls, keep the same browser-facing BFF contract, and test against an upstream sandbox. Do not enable live single-passkey deletion until EDI confirms that endpoint is implemented.

## Decisions still needed from VPS/EDI

- Exact EDI-session response field, lifetime, rotation, and absence behavior on OTP verify, `/resolve`, and passkey sign-in.
- How the BFF sends that session back to VPS, and how VPS connects it to EDI's `edi-session-id` continuity cookie.
- What proof allows `/resolve` to return an authenticated EDI session. A device fingerprint or visitor session alone is not enough.
- Whether a T2 session stays valid after its passkey is deleted, and whether other sessions are affected.
- Which passkey-management and recovery endpoints EDI can support now. Individual delete is marked as planned in the current EDI draft.

The fuller [architecture review](./ecommerce-auth-passkey-architecture-plan.md) contains the code findings, endpoint mapping, use-case coverage, and detailed test cases. This brief is intended for planning discussions and the first implementation PRs.
