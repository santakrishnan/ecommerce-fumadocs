# Passkey architecture review and implementation plan

**Reviewed:** 2026-09-24; updated for the VPS team's EDI-session decision  
**Codebase:** `/Users/santhana/dev/ecommerce-auth/web-test`  
**Additional review:** `13-authentication/*.md` and its `api-spec-v2-draft.yaml` (v0.3.0), 2026-09-25  
**Scope:** architecture and plan only; no application code changed.

## Goal and decision

Deliver a local, end-to-end demonstration of OTP enrollment, passkey registration, passkey sign-in, listing, and deletion through the Next.js BFF. Keep the browser-to-BFF contract aligned with `api-spec-v2-draft.yaml`; the BFF mock implements real WebAuthn verification with `@simplewebauthn/server`. Later, replace only the server adapter with VPS/EDI calls. The application never calls EDI or Auth0 directly.

For the demo, **store public-key credential records and outstanding challenges in server process memory**. Set only a random, opaque BFF session handle in an HttpOnly cookie. The browser/passkey provider stores the private key. Do not put credential records or public keys in a cookie. In-memory state is intentionally lost on a server restart and is suitable only for a single-process local demo, not a serverless or multi-instance deployment.

**Updated upstream assumption:** VPS will not expose an account ID to this application. Successful OTP verify and later `/resolve` responses will contain an opaque EDI session value in a **response field**. The Next.js BFF should read that field server-side, keep the EDI session in its server-side session record, and remove it from JSON returned to browser JavaScript. Its cookie contains only the BFF handle. VPS/EDI remains responsible for customer identity and passkey ownership. The mock may use a private, random `mockSubjectKey` to group credentials across sessions; that is a test-store key, never a browser field or a proposed upstream account ID.

This is a new agreement that is **not yet represented in either `api-spec-v2-draft.yaml` copy**. The root copy is v0.2.0; `13-authentication/api-spec-v2-draft.yaml` is v0.3.0 and adds logout, forget-device, and primary-contact routes. Both still expose `customerId` in `ResolvedVisitor` and omit the EDI-session response field on OTP verify and `/resolve`; both define a separate visitor `sessionId`. Confirm which copy is canonical and update it before implementing the real adapter.

**Authentication-policy decision before passkey management:** The source flow (j) allows T1 OTP to add or remove every passkey, even when one is already enrolled. The [industry gap review](</Users/santhana/Documents/AI Updates/13-authentication-industry-gap-review.md>) recommends distinguishing first enrollment from later factor changes. Decide the exact recent-authentication and recovery rules with product/security/VPS/EDI before BFF-3/4/6. Also define session-handle rotation at T0→T1 and T1→T2, and what deletion does to current and other T2 sessions. The six-PR split below can remain intact; its acceptance tests should reflect those decisions.

The installed package is `@simplewebauthn/browser@13.3.0` (lockfile); the requested server counterpart is `@simplewebauthn/server`, not a `simpleauth/server` package. Use a compatible 13.3.x server version for the mock, then upgrade browser and server together if desired.

## Current implementation findings

| Priority | Finding | Evidence | Consequence / plan |
| --- | --- | --- | --- |
| Critical | The browser uses the same literal `stub-challenge-value` for every ceremony and never sends attestation/assertion to a verifier. `startAuthentication()` resolving is treated as a successful login. | `apps/web/src/features/auth/hooks/use-auth-passkey.ts:62-93, 115-138` | Replace with server-generated, one-use challenge and server verification before any tier/session change. Current flow is a visual stub, not a working authentication system. |
| Critical | Passkey availability comes from `localStorage` credential IDs. Removing those IDs does not revoke a passkey; a synced credential may exist on another device. | `use-auth-passkey.ts:12-38`; `apps/web/src/features/demo-settings/components/demo-settings-form.tsx:159-161` | Drive account enrollment and management from `GET /auth/profile`; delete by server authentication-method ID. Remove localStorage as authority. |
| Critical | The UI raises T1 to T2 after **registration**. The VPS contract explicitly says registration leaves the tier unchanged, while passkey **login** raises it to T2. | `apps/web/src/features/auth/components/auth-flow.tsx:196-215`; `apps/web/src/features/auth/components/flows/passkey/use-passkey-flow.tsx:28-37`; `api-spec-v2-draft.yaml:721-728` | After enrollment return T1; if the requested gate needs T2, run an assertion ceremony before completing it. T2 must come from the verified BFF profile. |
| High | When passkey sign-in fails, `PasskeyFlow` falls through to the registration screen; registration can therefore start without a verified OTP session. | `apps/web/src/features/auth/components/flows/passkey/passkey.tsx:33-67`; EDI registration prerequisite at `edi_openapi_new.yaml:237-252` | Show retry / OTP fallback. Permit registration only with a server-verified T1 session. Treat user cancellation separately from technical failure. |
| High | Existing OTP mock accepts a fixed `000000` and returns only `verified: true`; it does not establish an EDI-like auth session. Start mock logs a random code that verify never accepts. | `apps/web/src/features/otp/bff/services/start-otp-mock.ts`; `verify-otp-mock.ts`; `apps/web/src/app/api/v1/auth/otp/verify/route.ts` | Make send/verify use the same code, then issue an opaque mock EDI session bound server-side to a private mock subject. The browser receives only the sanitized T1 profile. |
| High | Two OTP BFF routes/feature modules coexist: `/api/v1/auth/otp` (VPS shape) and `/api/v1/auth/otp/start` + `/verify` (current UI). The latter returns a smaller contract than VPS `PUT /auth/otp`. | `apps/web/src/config/routes/constants.ts`; `apps/web/src/features/auth/components/flows/otp/use-otp-flow.tsx`; `apps/web/src/app/api/v1/auth/otp/route.ts`; `api-spec-v2-draft.yaml:589-677` | Choose the VPS-shaped route as the target, adapt the UI service, and retire or explicitly alias the transitional endpoints. One mock session source must serve OTP and passkey. |
| High | Auth tiers and passkey metadata currently come from a writable demo-tier cookie and a hard-coded profile fixture. The server gate also reads that cookie. | `apps/web/src/features/profile/bff/use-cases/get-profile-tier.ts`; `apps/web/src/features/profile/bff/__fixtures__/profile-resolve-auth.fixture.ts`; `apps/web/src/features/auth/components/auth-gate.tsx` | Keep the demo tier switch isolated as a developer tool. The end-to-end demo must derive auth state from the mock BFF, and production authorization must use trusted VPS/EDI session state. |
| Medium | Passkey success component calls completion after a 3.5-second timer, in addition to the hook's registration completion callback. | `apps/web/src/features/auth/components/flows/passkey/passkey-created.tsx`; `use-passkey-flow.tsx` | Make completion exactly once after server confirmation. Keep any success animation independent of the security state transition. |
| Medium | `AuthPasskey.deviceBound` is described as derived from `authenticatorAttachment=platform`; platform attachment does not prove a credential is device-bound. `isThisDevice` is similarly an advisory UX hint for synced passkeys. | `api-spec-v2-draft.yaml:1001-1045`; [WebAuthn Level 3, attachment and backup flags](https://www.w3.org/TR/webauthn-3/) | Rename/clarify these fields upstream or treat them as labels only. Use backup-eligibility/state when the verifier actually supplies them. Do not use either field for authorization. |
| Medium | VPS defines per-passkey delete, but EDI marks `DELETE /passkeys/{authentication-method-id}` as planned and unimplemented. EDI list includes both primary passkeys and older Guardian MFA authenticators. | `api-spec-v2-draft.yaml:758-789`; `edi_openapi_new.yaml:707-899` | Demo per-item delete in mock. Gate live per-item deletion on EDI implementation; do not substitute clear-all. Keep primary passkeys distinct from Guardian MFA in UI and mapping. |
| High | The newly agreed EDI-session response field is absent from the checked-in VPS draft. `ResolvedVisitor.customerId` and `/merge` still assume an exposed customer ID, and the current BFF sets a profile-ID cookie from `customerId`. | `api-spec-v2-draft.yaml:81-135, 1342-1380`; `apps/web/src/features/profile/bff/services/profile-resolve-cookies.ts`; VPS team discussion | Ask VPS to revise OTP verify and `/resolve` schemas and clarify `/merge`; remove the profile-ID cookie dependency from auth. Do not build browser auth around `customerId`, `visitorId`, or the VPS visitor `sessionId`. |

## Contract and ownership map

| Browser → Next.js BFF (VPS-shaped) | BFF mock now | VPS → EDI later |
| --- | --- | --- |
| OTP verify, then `GET /api/v1/profile/resolve` on later page loads | Capture mock EDI-session value in BFF session store; return sanitized T1 profile | VPS supplies EDI session in a response field; BFF captures it and strips it from browser JSON |
| `POST /api/v1/auth/passkey` `{action:"register-options"}` | Require active T1 EDI-like session; generate registration options and `authSession` | VPS `POST /auth/passkey` → EDI `POST /passkeys/register` using the EDI continuity session; no account ID from FED |
| `PUT /api/v1/auth/passkey` `{action:"register", authSession, response}` | Verify registration; store public-key record; return refreshed auth profile at T1 | VPS `PUT /auth/passkey` → EDI `POST /passkeys/register/complete`; map `response` → `authnResponse` |
| `POST /api/v1/auth/passkey` `{action:"login-options"}` | Generate authentication options; no prior authenticated EDI session required | VPS → EDI `POST /passkeys/authenticate/start` |
| `PUT /api/v1/auth/passkey` `{action:"login", authSession, response}` | Resolve verified credential to private mock subject; issue a T2 mock EDI session | VPS → EDI `POST /passkeys/authenticate/complete`; EDI resolves identity and establishes T2 |
| `GET /api/v1/auth/profile` | Return T0/T1/T2 plus `metadata.auth.passkeys[]` from mock store | VPS `GET /auth/profile`, with EDI `GET /passkeys` behind it |
| `DELETE /api/v1/auth/passkey` `{authenticationMethodId}` | Authorize through current EDI-like session; remove one record; refresh list | VPS `DELETE /auth/passkey` → EDI per-item delete **when implemented** |

The VPS spec returns `{data, meta}` envelopes and expects `options`/`response`. EDI returns `authnParamsPublicKey` and expects `authnResponse`; these conversions belong only in the eventual VPS/EDI adapter. The BFF must not expose the new EDI-session field, Auth0 tokens, API keys, or internal trusted headers to browser JavaScript. VPS itself uses `X-Visitor-Id` and `X-Session-Id` for **visitor context**, not authenticated customer identity. The existing Next BFF already sets HttpOnly tracking cookies from `/profile/resolve` and should derive those headers server-side rather than accept client-provided identity headers. See `api-spec-v2-draft.yaml:1-38` and `apps/web/src/features/profile/bff/services/profile-resolve-cookies.ts`.

### Four identifiers with different jobs

| Value | Purpose | Lifetime / owner |
| --- | --- | --- |
| VPS `visitorId` + `sessionId` | Device/visitor profile context for VPS headers. Neither proves OTP or passkey authentication. | VPS `/resolve` may rotate `sessionId`; the existing BFF stores both in tracking cookies. |
| EDI session from OTP verify and `/resolve` | Opaque authentication continuity for T1/T2 and passkey ownership. This is the new VPS-team agreement. | VPS/EDI defines validity and rotation; the BFF keeps the value server-side behind its own opaque HttpOnly cookie. |
| BFF session handle | Random browser cookie that looks up the server-side EDI session; it does not reveal the EDI value. | Next.js BFF issues/rotates it and clears it on logout or expiry. |
| Passkey `authSession` | Correlation handle for **one** registration or authentication challenge. | Expires quickly and is consumed at ceremony completion; it is not a login session. |

`/resolve` must not create or disclose an **EDI-authenticated** session from a fingerprint alone. The newer authentication docs allow VPS to retain an **ecommerce-only** `deviceSessionTier` after the EDI session expires; that tier and EDI validity must be modeled separately. A T1-looking `/resolve` profile is not proof that a later passkey-management or enterprise action has a live EDI session. If a new browser can obtain another customer's EDI session merely by resolving a device fingerprint, the upstream contract needs a security change before integration.

WebAuthn registration options still contain an opaque `user.id` (the WebAuthn user handle), as shown in the EDI registration example in `edi_openapi_new.yaml`. The browser passes that value to the authenticator unchanged; it does not need a business account ID. EDI should generate/manage the production user handle. The mock should keep one stable, random WebAuthn user handle per private mock subject. Never use the EDI session as `user.id`: sessions expire and rotate, while a registered credential must remain associated with its user.

### Proposed production handoff

```mermaid
sequenceDiagram
    actor Shopper
    participant UI as Next.js UI
    participant BFF as Next.js BFF
    participant VPS as Visitor Profile Service
    participant EDI as EDI/Auth0 wrapper
    Shopper->>UI: Enter OTP
    UI->>BFF: PUT /api/v1/auth/otp
    BFF->>VPS: PUT /auth/otp with server-derived visitor context
    VPS->>EDI: Verify OTP
    EDI-->>VPS: Auth result / EDI continuity session
    VPS-->>BFF: T1 profile + EDI session response field
    BFF->>BFF: Store EDI value behind opaque BFF cookie handle
    BFF-->>UI: Sanitized T1 profile + HttpOnly BFF cookie
    UI->>BFF: GET /api/v1/profile/resolve on later load
    BFF->>VPS: POST /resolve with agreed continuity context
    VPS-->>BFF: Visitor profile + current EDI session field, if valid
    BFF->>BFF: Validate/refresh server record; remove EDI field
    BFF-->>UI: Sanitized visitor profile
```

The BFF should never call EDI directly; VPS decides how the EDI session reaches EDI's `edi-session-id` cookie. The arrow labeled “agreed continuity context” is deliberately pending the revised VPS contract. The BFF must not manufacture T1 from the returned tier alone if session continuity is unproven.

### VPS contract decisions needed before the real adapter

1. Exact EDI-session response-field name, expiry, rotation, and absence/null behavior on OTP verify, `/resolve`, and passkey login.
2. What authenticated proof lets `/resolve` return an existing EDI session? Device fingerprint and VPS visitor IDs alone are insufficient.
3. How should the BFF present the EDI session on later VPS passkey/profile requests, and how does VPS convert it into EDI's `edi-session-id` continuity cookie? This is not defined in the current draft.
4. Does VPS visitor `sessionId` rotation preserve the EDI auth session, and what does logout or OTP verification for a different user invalidate?
5. If `customerId` is no longer exposed, how does VPS perform `/merge` and maintain the existing `PROFILE_ID` cookie behavior? This must be a server-side VPS decision, not a FED identity claim.
6. When the EDI session expires but VPS `deviceSessionExpiresAt` remains valid, which ecommerce-only actions may still use T1, and which auth/profile or passkey routes must return 401? The newer integration guide and the earlier mock plan differ on this point.
7. After logout, which masked `metadata.auth` hints may remain on a known device at T0? The v0.3 logout draft says they remain, while passkey list/delete must still require authenticated ownership. Define this before exposing passkey names or contact hints on a shared browser.

## Demo state model

- `bffSessions`: random cookie handle → mock EDI-session value, private `mockSubjectKey` when authenticated, OTP verification time, **ecommerce tier/expiry and EDI validity/expiry separately**, and current visitor context. The cookie contains only the handle, with `HttpOnly`, `SameSite=Lax`, and `Secure` outside localhost. The EDI-session value is modeled separately from the VPS visitor `sessionId`.
- `mockSubjects`: normalized verified OTP contact (or a server-resolved contact token) → private random `mockSubjectKey` and stable random WebAuthn user handle. This is only a local way to make repeat OTP sign-ins reach the same demo credentials; never expose the subject key or treat it as a VPS/EDI account identifier. Passkey sign-in later finds the subject from the verified credential.
- `ceremonies`: random opaque passkey `authSession` → ceremony kind, challenge, BFF session and private subject binding for registration, created/expiry time, consumed flag. Expire and atomically consume each ceremony; reject replay, mismatched action, or another browser session using it.
- `credentials`: credential ID → private `mockSubjectKey`, public key, counter, transports, backup flags when available, server-generated management ID, label and timestamps. Do not store the private key. Key list and delete are scoped through the active mock EDI session to its private subject.
- `resolve` behavior: on OTP verify, mint a mock EDI session and bind it to the BFF handle. On later mock `/resolve`, return/refresh that EDI value internally only when valid continuity exists. A rotated VPS visitor `sessionId` must not rotate the EDI value by accident. If EDI expires first, the mock may retain a separately expiring ecommerce tier only if the agreed VPS policy allows it; EDI-gated operations still return 401 and require re-auth. On logout or user switch, clear the EDI binding. Fingerprint, `visitorId`, and VPS `sessionId` must never reconstruct an EDI session by themselves.
- Use a module/global process singleton only in mock mode so local hot reload can retain state as far as the runtime permits; tests receive a resettable store. Reject enabling this store in production. Expect restart and multi-worker loss.

**WebAuthn policy for the mock:** a fixed configured RP ID and exact allowed origin(s), HTTPS in deployed environments (localhost for local development), a fresh cryptographic challenge per ceremony, discoverable credentials (`residentKey: "required"`) for passkey sign-in, and user verification enforced at verification. Use `@simplewebauthn/server` for option generation and both response verifiers; avoid hand-written CBOR or signature parsing. The verified credential ID, challenge, origin, RP ID hash, signature, private-subject binding, and one-time use determine success. Handle a zero or non-increasing signature counter per the library/spec rather than assuming every synced passkey increments it. [W3C WebAuthn Level 3](https://www.w3.org/TR/webauthn-3/), [SimpleWebAuthn server 13.3.x](https://simplewebauthn.dev/docs/13.3.x/packages/server), [SimpleWebAuthn passkey guidance](https://simplewebauthn.dev/docs/advanced/passkeys).

## Sequence A: OTP → passkey enrollment

```mermaid
sequenceDiagram
    actor Shopper
    participant UI as Next.js UI
    participant BFF as Next.js BFF mock
    participant Device as Browser/passkey provider
    Shopper->>UI: Enter email/phone and OTP
    UI->>BFF: OTP start, then verify
    BFF->>BFF: Verify code; create private subject and mock EDI session (T1)
    BFF->>BFF: Store EDI session behind opaque BFF cookie handle
    BFF-->>UI: Auth profile T1 + HttpOnly BFF cookie (no EDI value in JSON)
    UI->>BFF: GET /profile/resolve after refresh
    BFF->>BFF: Validate BFF/EDI continuity; refresh sanitized profile
    BFF-->>UI: T1 profile, no EDI value in JSON
    Shopper->>UI: Choose Create passkey
    UI->>BFF: POST /auth/passkey register-options
    BFF->>BFF: Require T1 EDI session; bind challenge to BFF handle and private subject
    BFF-->>UI: options + authSession
    UI->>Device: startRegistration(optionsJSON)
    Device-->>UI: attestation response
    UI->>BFF: PUT /auth/passkey register + response
    BFF->>BFF: Verify challenge, origin, RP ID, UV; store public key
    BFF-->>UI: Auth profile T1, hasPasskey=true
```

The EDI registration completion example still reports OTP ACR; the VPS draft also states that registration does not raise the current session tier. If a gated action requires T2 immediately, perform Sequence B next. Do not infer T2 from passkey creation.

## Sequence B: passkey sign-in / step-up

```mermaid
sequenceDiagram
    actor Shopper
    participant UI as Next.js UI
    participant BFF as Next.js BFF mock
    participant Device as Browser/passkey provider
    Shopper->>UI: Choose Sign in with passkey
    UI->>BFF: POST /auth/passkey login-options
    BFF->>BFF: Save fresh challenge and authSession
    BFF-->>UI: options + authSession
    UI->>Device: startAuthentication(optionsJSON)
    Shopper->>Device: Unlock/select passkey
    Device-->>UI: assertion response
    UI->>BFF: PUT /auth/passkey login + response
    BFF->>BFF: Find credential; verify challenge, origin, RP ID, UV, signature
    BFF->>BFF: Map verified credential to private subject; issue T2 mock EDI session
    BFF-->>UI: Auth profile T2 + HttpOnly BFF cookie (no EDI value in JSON)
```

If no passkey is available, or the user cancels, offer OTP sign-in. Do not automatically turn an unsuccessful sign-in into registration. A blank/omitted `allowCredentials` supports discoverable passkey selection; the mock maps a **verified** credential to its private subject, while production EDI resolves customer identity internally. The fact that a credential exists in browser storage is never proof of authentication.

## Sequence C: list and delete

After OTP or passkey sign-in, `GET /auth/profile` returns passkey entries scoped by the active EDI session; no account ID is sent by the browser. Show label, created/last-used times, and a per-item Remove action. `DELETE /auth/passkey` accepts the **server management ID**, checks that the EDI session owns it and has suitable recent authentication, deletes one record, and refreshes the list. Deleted credentials may still appear in the device's password manager; explain that they can no longer sign in to this service. Decide with VPS whether deleting the passkey used for the current T2 session should revoke/downgrade that session; the current drafts do not specify this. Do not equate EDI's clear-all route with VPS single deletion.

## Coverage against `13-authentication` use cases

The current plan covers the **core passkey demonstration**, not the full (a)–(o) authentication program. This table makes the remaining work explicit; “later” means it is outside the first mock BFF/UI delivery, not that the user journey can be silently ignored.

| Catalog flow | Coverage in this plan | Addition or decision |
| --- | --- | --- |
| **(a) OTP** | Partial | Happy path exists in BFF-1. Add wrong/expired code, resend replacing the previous code, attempt limit, and rate-limit/error UX tests. `contactPointToken` return sign-in stays pending EDI support. |
| **(b) Passkey enrollment** | Core covered | Keep T1 after registration; add user cancellation, unsupported browser/device, and duplicate-credential outcomes. |
| **(c) Passkey step-up / direct sign-in** | Core covered | Add explicit T2 gate, retry, user cancellation, no-passkey inline enrollment, and cross-device browser-mediated authentication. The browser controls any QR prompt. |
| **(d) Lost phone/email recovery** | Later | Offer passkey or alternate OTP when available; contact replacement and support recovery need separate identity APIs/policy. No automatic re-enrollment on a failed sign-in. |
| **(e) New device / merge / shared-device conflict** | Partial isolation test | Test distinct users in separate cookie jars and prevent credential mixing. Full VPS merge and 409 shared-device branch are later; the draft's `existingCustomerId` response conflicts with the no-exposed-account-ID agreement. |
| **(f) Passkey failed/corrupted** | Partial | Distinguish cancel, no matching credential, verifier rejection, and unsupported platform. Re-enroll only after valid OTP/T1; then perform a new assertion for T2. |
| **(g) All passkeys deleted** | Partial | After the last deletion, show an empty list and offer OTP-backed enrollment; a T2-gated flow cannot continue until a new passkey is registered **and used**. |
| **(h) VPS visitor session timeout** | Missing | Simulate `/resolve` rotating the VPS `sessionId` while preserving eligible device metadata; do not confuse this with the EDI session or passkey `authSession`. |
| **(i) EDI session expiry** | Contract-dependent | Model EDI validity separately from `deviceSessionTier`; enterprise/EDI-gated calls return 401 and trigger passkey-first or OTP re-auth. Confirm whether ecommerce-only T1 may persist as the integration doc says. |
| **(j) Manage passkeys** | Partial | List/add/single-delete are planned. Clear-all is mentioned in the journeys and EDI spec but lacks a VPS contract; treat it as a separate future endpoint/story. WebAuthn Signal API integration is optional and needs an exact WebAuthn user handle plus credential IDs. |
| **(k) Soft step-up** | Later | Activity thresholds, dismiss behavior, and prompt scheduling belong to a separate product/UI story; the BFF auth endpoints can be reused. |
| **(l) Add contact channel** | Later | Requires verified-new-channel and identity-linking semantics beyond the passkey demo. |
| **(m) Logout** | Missing but needed for demo | Add a local mock logout that invalidates the BFF/EDI-like session and returns T0 without deleting passkeys or visitor data. Production logout depends on EDI invalidation. |
| **(n) Forget this device** | Later | Separate from logout: VPS device unlink plus client cache/cookie reset. The v0.3 draft route is pending EDI/VPS capabilities. |
| **(o) Change primary phone/email** | Later | v0.3 adds `/auth/primary-contact`, but EDI identifier swap and other-session invalidation remain pending; no passkey credential should be rebound to a phone number. |

Also outside the first demo: `PUT /auth/name`, hard-versus-soft trigger policy for profile/booking/pre-qual, and future account deletion. Track these as separate product/API stories rather than implying the passkey BFF implements them.

### Documentation and contract corrections found

- `auth-integration.md` and `auth-overview.md` describe a gateway-set `edi-session-id` **browser cookie** and a thin BFF cookie relay. The new VPS-team agreement says OTP verify and `/resolve` return the EDI session in a **response field**. Rewrite those sequences and decide whether the BFF stores/forwards the field or VPS stores it internally; do not implement both designs at once.
- `13-authentication/api-spec-v2-draft.yaml` is v0.3.0; the root copy is v0.2.0. The overview also names `visitor-profile-api.yml`, which is absent from this checkout. Pick one canonical spec before generating schemas, examples, or a Postman collection.
- `auth-flows.md` uses `customerId`/`identityProfileId` in merge, conflict, and WebAuthn Signal API examples. The new no-account-ID rule requires server-only mapping and a conflict response that does not expose another shopper's identifier. A WebAuthn user handle must be the actual stable `user.id` associated with the credential, not an assumed encoding of `identityProfileId`.
- The flow catalog describes per-passkey deletion as available, while the checked EDI OpenAPI draft says its individual delete implementation is still planned. The v0.3 VPS draft has only single-delete, although the journeys also offer clear-all. Gate those UI actions on real endpoint readiness and add a distinct clear-all contract if product requires it.
- OTP lockout values and rate-limit status in the journeys are proposed integration behavior, not a substitute for EDI contract tests; `auth-edi-open-questions.md` records a 429-versus-503 mismatch. The mock should have explicit, testable error behavior without claiming it matches EDI until confirmed.
- `getClientCapabilities()` reports **browser capabilities**, not whether this shopper has a credential on the device. Do not infer local passkey presence from `passkeyPlatformAuthenticator`, and do not run a “silent” `navigator.credentials.get()` merely as a presence probe. Conditional mediation waits for user selection; ordinary authentication requires user interaction. Let the browser show any hybrid/QR choice. [W3C WebAuthn Level 3](https://www.w3.org/TR/webauthn-3/), [Google WebAuthn capability guidance](https://web.dev/articles/webauthn-client-capabilities), [conditional passkey UI](https://web.dev/articles/webauthn-discoverable-credentials).
- The Signal API calls in `auth-flows.md` show array arguments; WebAuthn Level 3 defines **object** arguments. `signalAllAcceptedCredentials({rpId,userId,allAcceptedCredentialIds})` requires an authenticated user, the exact stable WebAuthn user handle, and a complete credential-ID list; `signalUnknownCredential({rpId,credentialId})` is appropriate after an unrecognized assertion. These are opportunistic cleanup hints, not proof of local deletion. [W3C WebAuthn Level 3 signal methods](https://www.w3.org/TR/webauthn-3/#sctn-signal-methods).

## Ordered implementation plan (after review approval)

1. **Freeze the browser contract.** Choose the canonical v0.3 draft in `13-authentication/` or an agreed successor, then add Zod schemas and route constants for its OTP, auth-profile, logout, and passkey requests/responses. Ask VPS to specify the EDI-session response field on OTP verify and `/resolve`, its expiry/rotation and null behavior, and the separate ecommerce-tier-versus-EDI-validity rule; remove or clarify `ResolvedVisitor.customerId`, `/merge`, and 409 conflict fields. Clarify upstream `deviceBound`, Guardian MFA filtering, and per-item delete readiness. This is a contract-only PR: schema examples and invalid-body tests pass without adding behavior.
2. **Deliver the mock BFF as six small PRs.** The table below is the recommended merge order. Each PR runs with `USE_AUTH_MOCKS`, remains disabled in production, and has its own route-level tests plus a Postman/curl example. Return the VPS `{data, meta}` envelope and defined errors from the first PR. Apply Zod validation, an opaque HttpOnly BFF cookie, and same-origin protection to every cookie-authenticated mutation as it is added. The BFF consumes the EDI-session response field internally and omits it from browser JSON.

   | PR | Scope | Individually testable result |
   | --- | --- | --- |
   | **BFF-1: OTP-backed EDI-session mock and profile** | Make OTP start/verify share one code and model wrong/expired/replaced codes. On success mint a mock EDI session bound to a private subject, capture it behind an HttpOnly BFF handle, and sanitize OTP and `/resolve` JSON. Add `GET /api/v1/auth/profile` returning T0/T1 and an empty passkey list; keep old UI OTP aliases temporarily. | OTP creates T1; profile survives refresh; invalid/replaced OTP and leaked EDI field tests fail safely. Two cookie jars remain isolated. No passkey route is needed. |
   | **BFF-2: Session lifecycle and mock logout** | Add `POST /api/v1/auth/logout` in mock mode. Clear the BFF auth binding but retain visitor data and credentials. Model VPS visitor-session rotation and EDI expiry as distinct transitions using an injectable clock, without adding a production test-only endpoint. | Logout returns T0 and prevents protected list/delete; allowed known-device hints follow the agreed policy, and another browser remains signed in. Visitor rotation does not invalidate valid EDI auth. EDI expiry causes an EDI-gated 401. |
   | **BFF-3: Registration options** | Add compatible `@simplewebauthn/server`, a short-lived one-use ceremony store, and `POST /api/v1/auth/passkey` for `register-options` only. Require the BFF-1 T1 EDI session; bind challenge to the BFF handle and private subject, returning `options` + passkey `authSession`. | Two requests produce distinct challenges; T0, malformed action, and expired EDI/BFF sessions are rejected. Curl/Postman can inspect options without a browser credential. |
   | **BFF-4: Registration completion and list** | Add `PUT /api/v1/auth/passkey` for `register`, verify the attestation against stored challenge/origin/RP ID/user verification, and save the public-key credential under the private mock subject. Extend profile to list credentials scoped by the active EDI session. Leave the tier at T1. | A real signed registration appears in profile; replay, wrong BFF session/private subject/origin/RP ID, and invalid response do not store a credential. Use a same-origin browser harness or virtual authenticator for the success test. |
   | **BFF-5: Passkey sign-in** | Add `login-options` and `login` actions to POST/PUT. Issue a discoverable-credential challenge; map the **verified** credential ID to a private mock subject, verify assertion and counter policy, then mint/upgrade the T2 mock EDI session behind the BFF handle. | A registered credential signs in from a fresh logged-out session without an account ID; unknown/deleted credentials, wrong signature/origin/RP ID, expiry, and replay fail without T2. Test both route halves together. |
   | **BFF-6: Single passkey deletion** | Add `DELETE /api/v1/auth/passkey` using the server management ID, scope it through the active EDI-like session and suitable recent authentication, remove only that credential, and refresh profile. | Deleting one credential leaves others; another authenticated mock subject cannot delete it; the deleted credential cannot sign in. Deleting the last one produces an empty list. Device/password-manager copies may remain. |

   Keep memory-store modules replaceable so the later VPS adapter can preserve the same browser contract. A process restart resets this demo state; never enable this store in production or a multi-instance deployment.
3. **Connect the existing FED component in focused PRs.** First connect OTP/profile/logout to BFF-1/2, then replace `use-auth-passkey.ts` registration/localStorage stub using BFF-3/4, then connect sign-in using BFF-5. Use `startRegistration({optionsJSON})` and `startAuthentication({optionsJSON})` only with BFF options and send each response back for verification. Update `AuthFlow`/`PasskeyFlow` to take returned auth profile as authority, separate cancel/retry/OTP fallback/create states, and allow one completion callback. Handle unsupported/cancelled/failed credentials and inline enrollment after OTP. Make the intended gate explicit: account information needs T1; a sensitive pre-qual flow needs a verified T2. Registration stays T1; a verified assertion grants T2.
4. **Add management UI after BFF-6.** Replace the demo-settings localStorage reset with a server-backed list and per-item delete flow (or add a focused demo management screen). Include loading, empty, failure, and stale-item states; refresh `GET /auth/profile` after deletion. Offer enrollment when the last passkey is removed. Do not promise OS/password-manager deletion.
5. **Verify the full demo.** Run the focused tests from each PR, then exercise OTP → create → logout → passkey sign-in → list → delete → failed sign-in in a supported browser or Playwright virtual authenticator. Also test cancellation, no passkey, two separate users, visitor-session rotation, and EDI expiry independently. Run lint and type-check. Avoid treating a mocked verifier alone as proof that a real ceremony works.
6. **Switch to VPS/EDI in a later PR.** Keep the FED contract unchanged; swap the mock adapter for VPS calls with server-derived visitor/session headers, trace propagation, timeouts, and response/error mapping. Capture the agreed EDI-session **response field** from OTP verify and `/resolve` into a durable server-side BFF session store (for example Redis), never pass that field to browser JavaScript, and use it for passkey registration/list/delete continuity. Confirm with VPS how it passes the value to EDI's `edi-session-id` continuity cookie, how it expires/rotates, and how passkey login replaces or upgrades it. Test against a sandbox before enabling per-item delete. Remove demo-only tier authority before any production use.

## Test each BFF endpoint before connecting the UI

Yes: the BFF is ordinary HTTP, so **curl or Postman can test every route's request/response contract, cookies, authorization, validation, and failure paths** as soon as its PR lands. Keep one cookie jar per test shopper; Postman has a per-domain cookie jar, and curl uses `-c`/`-b`. Add a small checked-in Postman collection or `scripts/auth-bff-smoke.sh` only after the canonical contract is chosen, with `baseUrl`, test recipient, and mock OTP as variables. Never put a real EDI session or production OTP into a shared collection. [Postman cookie manager](https://learning.postman.com/docs/use/send-requests/response-data/cookies).

| Endpoint | curl/Postman alone? | What to verify before UI work |
| --- | --- | --- |
| `GET /api/v1/profile/resolve`, `POST/PUT /api/v1/auth/otp`, `GET /api/v1/auth/profile` | Yes | T0 → T1, cookie persistence, no EDI field in browser JSON, wrong/replaced OTP, two isolated cookie jars, visitor-session rotation. |
| `POST /api/v1/auth/logout` | Yes | Current session becomes T0, retained passkeys, second browser session unaffected. Mock-only until EDI invalidation exists. |
| `POST /api/v1/auth/passkey` with `register-options` or `login-options` | Yes | Fresh challenge and `authSession`, spec envelope, RP ID/options, T1 guard for registration, expiry and invalid action errors. |
| `PUT /api/v1/auth/passkey` with `register` or `login` | For errors, yes; for **success**, a real signed browser/authenticator response is needed | Reject invalid/replayed/wrong-origin responses. Verify a successful ceremony with a same-origin minimal test page using `@simplewebauthn/browser`, or a Playwright Chromium virtual authenticator, **before** wiring the production UI. [Chrome DevTools Protocol virtual authenticator](https://chromedevtools.github.io/devtools-protocol/tot/WebAuthn/). |
| `DELETE /api/v1/auth/passkey` and follow-up `GET /auth/profile` | Yes, after a credential exists | Delete one management ID, keep others, reject wrong subject and invalid session, and deny later sign-in with the deleted credential. |

Illustrative smoke calls **after BFF-1 and BFF-3 exist** (use the OTP shown by the local mock; production does not expose OTPs). Run these against the Next.js origin, not the EDI host:

```sh
DEMO_ORIGIN='http://localhost:3000'
DEMO_COOKIES='/tmp/ecommerce-auth-demo.cookies'
DEMO_CODE='replace-with-local-mock-code'

curl -i -c "$DEMO_COOKIES" -b "$DEMO_COOKIES" \
  "$DEMO_ORIGIN/api/v1/profile/resolve?fpHash=local-demo-device"
curl -i -c "$DEMO_COOKIES" -b "$DEMO_COOKIES" \
  -H "Origin: $DEMO_ORIGIN" -H 'Content-Type: application/json' \
  --data-raw '{"channel":"email","recipient":"demo@example.test"}' \
  "$DEMO_ORIGIN/api/v1/auth/otp"
curl -i -c "$DEMO_COOKIES" -b "$DEMO_COOKIES" \
  -H "Origin: $DEMO_ORIGIN" -H 'Content-Type: application/json' -X PUT \
  --data-raw "{\"channel\":\"email\",\"recipient\":\"demo@example.test\",\"code\":\"$DEMO_CODE\"}" \
  "$DEMO_ORIGIN/api/v1/auth/otp"
curl -i -c "$DEMO_COOKIES" -b "$DEMO_COOKIES" \
  -H "Origin: $DEMO_ORIGIN" -H 'Content-Type: application/json' \
  --data-raw '{"action":"register-options"}' \
  "$DEMO_ORIGIN/api/v1/auth/passkey"
```

An HTTP client cannot by itself create the authenticator's valid attestation or assertion; sending fabricated JSON should fail. A small same-origin harness should call the start endpoint, invoke `startRegistration()` or `startAuthentication()`, then submit the resulting JSON to the complete endpoint. That harness can be a development-only page removed before production; automated tests can use Chromium's virtual authenticator. Keep it separate from the final FED components so the BFF can be verified first.

## Acceptance criteria for the future implementation

- A fresh browser can verify OTP, enroll a passkey, and see it in the server-backed list.
- A signed-out browser can sign in with that passkey; only successful **server verification** sets T2.
- Mock logout returns T0 without deleting passkeys, and a later passkey sign-in succeeds from that state.
- A separately authenticated mock subject cannot list or delete another subject's passkeys; no account ID is present in browser passkey requests.
- A deleted passkey cannot authenticate; deleting one does not remove another.
- Replayed/expired challenges and malformed responses fail without changing session tier.
- OTP verify and `/resolve` EDI-session response fields never appear in browser JSON, logs, or readable cookies. A fresh browser or fingerprint alone cannot recover an **EDI-authenticated** T1/T2 session.
- VPS visitor-session rotation and EDI auth expiry are tested separately; an EDI-gated call never succeeds from ecommerce tier metadata alone.
- A browser refresh preserves the demo while the single server process lives; a process restart clearly resets mock state.
- The same frontend services work against the future VPS adapter without changing component-level WebAuthn orchestration.

## Jira breakdown for the mock BFF

Use **Mock passkey BFF for an end-to-end demo** as the parent item. Each row below is one independently testable story and PR; the FED connections can follow as separate stories.

| Story title | One-line description |
| --- | --- |
| Create OTP-backed EDI-session mock and auth profile | Capture a mock EDI session after verified OTP, preserve it through safe `/resolve` continuity, and return a sanitized T1 profile. |
| Add mock logout and session-lifecycle handling | Clear only this device's mock auth session and test visitor rotation separately from EDI expiry. |
| Add passkey registration options endpoint | Issue unique, expiring WebAuthn registration options only for a verified T1 EDI-like session. |
| Verify passkey registration and list credentials | Verify the registration response, store the public key in memory, and list credentials scoped by the active EDI-like session while retaining T1. |
| Add verified passkey sign-in | Issue authentication options and grant T2 only after successful server-side assertion verification. |
| Add single passkey deletion | Delete one credential owned by the current EDI-like session's private subject and reject subsequent sign-in with it. |

## Sources checked for current standards and API behavior

- [W3C Web Authentication Level 3 Recommendation](https://www.w3.org/TR/webauthn-3/) — registration/assertion verification, RP ID and origin, backup flags, signature counters.
- [SimpleWebAuthn browser 13.3.x](https://simplewebauthn.dev/docs/13.3.x/packages/browser) and [server 13.3.x](https://simplewebauthn.dev/docs/13.3.x/packages/server) — APIs corresponding to the installed browser major.
- [Auth0 passkey APIs for embedded applications](https://auth0.com/docs/authenticate/database-connections/passkeys/passkey-apis) — enrollment after authentication and passkey login API shape. EDI/VPS remain the production intermediary for this project.
- [Auth0 OTP on database connections via API](https://auth0.com/docs/authenticate/database-connections/auth-api-passwordless-db-connections) — OTP session/token behavior relevant to the EDI wrapper.

**Review limit:** This was a static code/spec review. No application server, browser ceremony, or upstream endpoint was executed; the YAML files were read as text rather than validated by an OpenAPI parser.
