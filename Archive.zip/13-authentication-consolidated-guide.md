# Authentication documentation: consolidated guide

**Reviewed:** 2026-09-25  
**Source:** the five Markdown files in `/Users/santhana/dev/ecommerce-auth/web-test/13-authentication`  
**Purpose:** explain what each document says and how the pieces fit together. These files describe a design; a described endpoint or flow is not necessarily implemented.

## The system in one minute

The shopper uses the Next.js UI. The UI calls its Next.js BFF, which calls the Visitor Profile Service (**VPS**). VPS owns visitor/device profile data and coordinates authentication through **EDI**, the wrapper around Auth0. The browser performs the passkey prompt; EDI/Auth0 verifies the result. An enterprise gateway can enforce the required authentication strength for sensitive actions.

| State | How the shopper reaches it | What it means |
| --- | --- | --- |
| **T0** | Visits the site and is resolved as a visitor | Browsing without verified identity. |
| **T1** | Verifies an email or SMS one-time code (OTP) | Can access actions needing basic identity proof. |
| **T2** | Completes a passkey **authentication** ceremony | Can access actions requiring stronger proof, such as pre-qualification. |

Creating a passkey while at T1 stores a credential but **does not** raise the session to T2. The shopper must then authenticate with that passkey. A previously enrolled passkey can also take a new T0 session directly to T2.

```mermaid
flowchart LR
    T0["T0: anonymous"] -->|Verify OTP| T1["T1: OTP verified"]
    T1 -->|Register passkey| T1
    T1 -->|Use passkey| T2["T2: passkey verified"]
    T0 -->|Use an existing passkey| T2
```

Four identifiers appear in this design and must not be confused: the VPS `visitorId` identifies a visitor profile; the VPS `sessionId` tracks its short-lived visitor session; the **EDI session** represents authentication continuity; and passkey `authSession` identifies one WebAuthn challenge. The latest VPS-team discussion says the EDI session will arrive in an OTP-verify and `/resolve` **response field**, which conflicts with the older cookie-relay sequence diagrams in these documents. See [Decisions and inconsistencies to resolve](#decisions-and-inconsistencies-to-resolve).

## What each document is for

| Document | Main question it answers | Best reader |
| --- | --- | --- |
| [auth-overview.md](/Users/santhana/dev/ecommerce-auth/web-test/13-authentication/auth-overview.md) | What are the tiers, actors, and main authentication paths? | Anyone new to the design. |
| [auth-flows.md](/Users/santhana/dev/ecommerce-auth/web-test/13-authentication/auth-flows.md) | What happens in each technical path or edge case (a–o)? | Engineers and reviewers. |
| [auth-user-journeys.md](/Users/santhana/dev/ecommerce-auth/web-test/13-authentication/auth-user-journeys.md) | What does the shopper see, choose, and recover from? | Product, design, frontend. |
| [auth-integration.md](/Users/santhana/dev/ecommerce-auth/web-test/13-authentication/auth-integration.md) | How do BFF, VPS, EDI, Auth0, gateway, and sessions interact? | Backend and integration engineers. |
| [auth-edi-open-questions.md](/Users/santhana/dev/ecommerce-auth/web-test/13-authentication/auth-edi-open-questions.md) | Which upstream capabilities or answers are still needed? | EDI/VPS/platform teams and tech leads. |

## 1. `auth-overview.md`: the conceptual model

This is the entry point. It defines the actors (UI, BFF, VPS, EDI, plus gateway/authorizer), T0/T1/T2, which actions require each tier, and the two main paths into passkey authentication.

**Capabilities and required tiers.** OTP send/verify starts at T0 and reaches T1. Passkey registration requires T1 and leaves the tier unchanged. Passkey sign-in can start at T0 and reaches T2 after a verified assertion. The document also describes updating the display name at T1, logging out, forgetting a shared device, and changing the primary phone/email. A primary-contact change requires T2 when a passkey exists, otherwise T1.

**Hard versus soft prompts.** Hard gates cannot be dismissed: pre-qualification and financial offer details need T2; booking a dealer visit, joining a shared watchlist, and account information need T1. Soft prompts suggest sign-in after meaningful activity such as watchlist or saved-search use. A dismissed soft prompt should wait for **new** activity before resurfacing.

**Data returned by `/resolve`.** The overview expects `deviceSessionTier`, `customerTier`, and `deviceSessionExpiresAt`, plus `metadata.auth` flags, masked contacts with roles and optional `contactPointToken`, and passkey entries. `GET /auth/profile` offers an auth-only refresh. A `primary` contact is the preferred OTP channel; an old primary can become `recovery`.

**Main paths.** Path A is OTP → register passkey → use passkey. Path B is direct passkey sign-in by a person who enrolled previously, perhaps on another device. The path diagrams say WebAuthn options and `authSession` come from EDI through VPS, and the browser returns attestation or assertion for server verification.

**Other content.** It describes updating the Auth0 `name` claim, gateway ACR enforcement, logout versus “forget me,” and future ideas: automatically starting OTP with `contactPointToken` and passkey-first silent return sign-in. Both are deferred. The duration of T2 step-up remains open.

## 2. `auth-flows.md`: technical flow catalog (a–o)

This is the detailed state-machine reference. Each diagram shows transitions, service calls, auth metadata changes, fallbacks, and failures. Read it as **proposed behavior**; several branches require capabilities still listed as open questions.

| Flow | What it covers | Important result or branch |
| --- | --- | --- |
| **(a) OTP authentication** | Phone/email selection, code send, verify, wrong/expired code, resend, lockout, alternate channel. | Correct code establishes T1. The diagram models three failed attempts per code and an eventual support path. |
| **(b) Passkey enrollment** | Start registration, browser biometric/PIN, complete registration, cancellation and platform failure. | Requires OTP/T1; successful creation stores the credential and **stays T1**. |
| **(c) Passkey step-up** | Use a local/synced passkey, another device through browser hybrid/QR, or enroll inline. | Successful assertion establishes T2. Cancellation, missing credential, and unsupported platform lead to different paths. |
| **(d) Channel lost/changed** | Recover when the primary phone/email is unavailable. | Try passkey first, alternate channel OTP second, support last; verify a replacement contact before binding it. |
| **(e) New device and identity merge** | New fingerprint, existing-user OTP, profile merge, shared-device conflict. | VPS merges a recognized identity's visitor data. A different person on one device is modeled as a 409 conflict, with household/persona behavior deferred. |
| **(f) Passkey failed/corrupted** | Missing credential, platform failure, cancellation. | If identity is established with OTP, a new passkey can be registered **and then used**; unsupported platform stops a T2-only action. |
| **(g) All passkeys deleted** | T2-gated action when no credential remains. | If supported, enroll a new passkey inline and authenticate with it. |
| **(h) VPS visitor-session timeout** | Redis visitor session expires after inactivity. | `/resolve` rotates VPS `sessionId`; persistent auth metadata may remain. This is separate from EDI-session expiry. |
| **(i) EDI-session expiry** | Enterprise auth expires while ecommerce device metadata may still be valid. | Ecommerce-only actions may continue; a gateway/EDI 401 on an enterprise action triggers passkey-first or OTP re-auth. |
| **(j) Passkey management** | List, add, remove one, remove all, and browser credential-state signaling. | Requires T1 in the design. The browser's password manager may retain a credential after server revocation. Clear-all and Signal API data need contract work. |
| **(k) Soft step-up** | Activity-based, dismissible OTP invitation. | Acceptance starts OTP; dismissal waits for new qualifying activity. |
| **(l) Add contact channel** | Add a second verified phone or email in settings. | Prove ownership of the new channel; keep the existing one. |
| **(m) Logout** | Sign out from this device. | End its auth session, return to T0, retain known-device metadata for faster return. Upstream invalidation is pending. |
| **(n) Forget me completely** | Stronger exit on a shared/public device. | Logout, unlink this device from VPS, clear client state; the account and other devices remain. |
| **(o) Change primary identifier** | Replace sign-in phone/email. | Use the strongest available factor, verify old and new channels, make the new one primary, keep old as recovery, and invalidate other sessions. EDI's Auth0-level swap is pending. |

**Passkey detection model.** The catalog combines server `passkeys[]` (whether credentials are registered) with browser capabilities (whether a platform or hybrid path can be offered). It discusses synced versus device-bound credentials, cross-device QR, a credential missing from the OS, and the WebAuthn Signal API. A capability does **not** prove that this shopper's credential exists locally; actual authentication and server verification decide success. The Signal API examples need the exact WebAuthn user handle and credential IDs, which the latest no-account-ID agreement does not yet provide to the UI. See [review notes below](#decisions-and-inconsistencies-to-resolve).

**Future and internal questions.** Account deletion is not supported yet. The options EDI chooses for WebAuthn registration (`rpId`, attachment preference, discoverable credential setting, user verification) still need confirmation. Internal questions include the 409 shared-device model, recovery fraud controls, soft-prompt thresholds, OTP attempt visibility, and lockout duration.

## 3. `auth-user-journeys.md`: shopper-facing experience

This document tells the same system as user choices and messages. It is most useful for designing screens, loading states, errors, and fallback choices. Its journeys map back to technical flows (a–o).

| Journey group | What the shopper experiences |
| --- | --- |
| **Signing in** | Choose email/SMS, enter OTP, retry a wrong code, request a new code, switch to an alternate channel, or contact support if no digital method remains. |
| **Setting up a passkey** | After OTP, accept a benefit-led setup prompt. Cancellation can retry or skip; an unsupported device gets a clear message. Creation alone does not finish a T2-gated action. |
| **Accessing elevated flows** | Use a passkey already usable here, use one from another device, or create one and then verify it. A T2-only action stays blocked when no usable passkey method exists. |
| **Cross-device and synced passkeys** | A browser may offer a synced credential on a new device or show a QR/hybrid prompt for a passkey on a phone. The passkey stays with its provider/device; using a phone does not automatically enroll the current computer. |
| **Failed or removed passkeys** | Retry cancellation, distinguish missing credential from unsupported platform, and offer OTP-backed re-enrollment when possible. After all passkeys are removed, the user needs a new registration **plus** authentication for T2. |
| **Managing passkeys** | At T1, view passkeys with labels/timestamps, add one, remove one, or request clear-all, each with appropriate confirmation and list refresh. Exact labels and “this device” badges depend on upstream data quality. |
| **Signing out versus forgetting** | Sign out ends this device's auth but keeps it recognized. “Forget me” also unlinks the device and clears local traces for a shared/public machine. |
| **Changing sign-in contact and recovery** | Changing a known primary contact verifies both old and new channels. Losing the old channel instead follows passkey → alternate OTP → support recovery. |
| **Returning or sharing a device** | After inactivity, re-authenticate only when required. A second person on one device must not silently inherit or merge the first person's identity; the household-persona branch is deferred. |

This document expresses intended UX, not guaranteed current endpoint behavior. For example, “remove all passkeys,” automatic known-contact OTP, and some recovery branches still need VPS/EDI support.

## 4. `auth-integration.md`: services, sessions, and testing

This is the most detailed backend reference. It follows requests through browser → BFF → VPS → EDI → Auth0 and, for protected actions, through the enterprise API gateway and its authorizer.

**Gateway session model described in the file.** On a first cookie-less auth request, the authorizer creates an anonymous `edi-session-id`; the gateway sets it as a browser cookie, but no authenticated session row exists yet. OTP verification causes EDI to write a row in the Session-Token Service/DynamoDB with identity, Auth0 tokens, and ACR `1fa`. Passkey registration adds a credential without changing ACR. Passkey authentication updates the same session to `2fa:phr`. A sensitive request succeeds only when the authorizer reads the row and its ACR meets the route's requirement; otherwise it returns an insufficient-ACR response. **This is the older transport model and needs reconciliation with the team's newer response-field decision.**

**Expiry and refresh described in the file.** It distinguishes a long-lived cookie, a shorter access-token/session-row expiry, OTP lifetime, optional token refresh, and an unresolved T2 step-up lifetime. Its example says a 90-day cookie, a 60-minute token, refreshing near expiry, and at most five refreshes. Later it gives a different `expiresIn` example, so these numbers should be confirmed with EDI rather than treated as fixed application constants.

**OTP constraints described in the file.** It lists a six-digit/three-minute code, three failed attempts per code, ten failed attempts per hour, a send-rate limit, and “latest code wins.” EDI does not surface all counters, and the open-questions doc reports a 429-versus-503 rate-limit mismatch. The UX should handle upstream error codes actually observed in contract/staging tests.

**VPS metadata model.** VPS writes auth metadata during `/auth/*` completion, persists it by device in Postgres, and reloads it after a Redis visitor-session rotation. `deviceSessionTier` describes this device's ecommerce auth state; `customerTier` and contacts/passkeys describe broader capabilities. VPS, rather than EDI, records the passkey-to-device association used for `isThisDevice`; EDI's list lacks a direct link to a VPS device and lacks reliable friendly labels or sync status.

**Logout and identifier change.** The document proposes EDI token invalidation plus gateway cookie clearing on logout, VPS device unlink for “forget me,” and bulk invalidation after changing a primary contact. Those are forward asks, not completed capabilities.

**Testing strategy.** It proposes local unit tests, OpenAPI contract tests in CI, real EDI/Auth0 integration in dev or staging, and complete staging journeys. It asks for dev/test-only EDI helpers to create/remove users, bypass OTP delivery, and clear sessions. Successful passkey ceremonies still need a real browser/authenticator or a Chromium virtual authenticator; fake HTTP JSON cannot prove WebAuthn verification.

## 5. `auth-edi-open-questions.md`: external decisions and dependencies

This is the team-to-team question list. Its twelve items are grouped by owner and payoff; none should be mistaken for a committed EDI feature.

| Group | Questions to settle | Why it matters |
| --- | --- | --- |
| **Passkey detection and labeling (1–5)** | Can EDI expose WebAuthn backup eligibility/state (`BE`/`BS`), AAGUID/friendly authenticator label, passkey-to-device link, stable `userAgent`, and the registration options it sends to Auth0? | Accurate “syncs across devices,” “this device,” and device-name labels; predictable browser enrollment prompts. |
| **Session lifecycle (6–8)** | Can EDI invalidate one or other sessions? Can VPS unlink a device? Can the gateway reliably clear its auth cookie? | Logout, forget-device, and primary-contact-change safety. |
| **Identity/account management (9–11)** | Can EDI swap the registered primary identifier, delete/deactivate an identity, and link multiple phone/email channels within Auth0 limits? | Contact changes, account deletion, and recovery without breaking passkeys. |
| **Contract/platform (12)** | Will EDI align rate-limit responses (OpenAPI 429 versus handler 503)? | Reliable client error handling and contract tests. |

The file says the browser-first passkey routing can begin without the labeling enrichments. It does **not** mean that browser capability checks identify exactly where a particular shopper's passkey is stored.

## Decisions and inconsistencies to resolve

1. **EDI session transport changed.** The Markdown integration diagrams assume the gateway sets a browser `edi-session-id` cookie and the BFF relays it. The recent VPS-team statement says OTP verify and `/resolve` return the EDI session in a response field, with no account ID exposed. Agree on the exact field, expiry, renewal, forwarding, and logout behavior; keep that value out of browser JavaScript in the proposed BFF design.
2. **Identity fields conflict with the new rule.** The docs and current YAML drafts still mention `customerId`/`identityProfileId`, including a 409 response that exposes `existingCustomerId`. VPS/EDI need a server-only merge/ownership method and a non-identifying conflict response. The opaque WebAuthn `user.id` in registration options is a credential user handle, not the application's business account ID.
3. **Two VPS draft copies exist.** The repository-root `api-spec-v2-draft.yaml` says v0.2.0; `13-authentication/api-spec-v2-draft.yaml` says v0.3.0 and adds logout, forget-device, and primary-contact routes. The overview points to `visitor-profile-api.yml`, which is absent from this checkout. Choose a canonical contract before generating clients or Postman collections.
4. **Ecommerce tier and EDI validity can diverge.** The integration doc permits ecommerce-only use while EDI auth has expired, with an enterprise 401 triggering re-auth. Define exactly which BFF routes require live EDI continuity and how `/resolve` presents a T1-looking profile without implying the enterprise session is valid.
5. **Some flows are designed ahead of upstream capability.** EDI logout/invalidation, VPS unlink, Auth0-level primary-contact swap, `contactPointToken` OTP targeting, account deletion, and some passkey-management options are pending. Individual passkey deletion is described as available in user flows but marked planned in the checked EDI OpenAPI draft.
6. **Browser passkey signals need precise interpretation.** `getClientCapabilities()` reports browser capabilities, not proof of this shopper's local credential. The flow catalog's Signal API examples use array syntax and assume `identityProfileId` can serve as the WebAuthn user handle; [WebAuthn Level 3](https://www.w3.org/TR/webauthn-3/) uses object arguments and the actual user handle. Treat client signals as hints and a verified assertion as the authentication decision.

For the planned mock BFF and FED work, see the separate [passkey architecture and implementation plan](</Users/santhana/Documents/AI Updates/ecommerce-auth-passkey-architecture-plan.md:166>). It maps all flows (a–o) to initial demo work versus later stories, and explains how to test BFF endpoints before integrating the final UI.

For a comparison with current WebAuthn, NIST, OWASP, and FIDO guidance, see the [OTP and passkey flow gap review](</Users/santhana/Documents/AI Updates/13-authentication-industry-gap-review.md>). It identifies journeys that are already covered, missing cases, and policies to decide before building passkey management.
